// handler/antilink.js
import { registerHandler } from '../libx/handlers.js';
import { isFeatureEnabled, getGroupLang } from '../libx/grup_db.js';
import { findUser } from '../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../libx/lang.js';
import config from '../config.js';
import chalk from 'chalk';

const POLA_URL = /(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?/g;

const TLD_DIKENAL = new Set([
  'com', 'net', 'org', 'info', 'biz', 'co', 'io', 'me', 'tv', 'cc', 'ly', 'gg',
  'to', 'be', 'app', 'dev', 'xyz', 'site', 'online', 'store', 'shop', 'link',
  'live', 'club', 'fun', 'win', 'vip', 'top', 'pro', 'space', 'website', 'click',
  'zip', 'page', 'blog', 'news', 'tech', 'cloud', 'id', 'my', 'sg', 'ph', 'th',
  'vn', 'jp', 'kr', 'cn', 'in', 'au', 'nz', 'ca', 'uk', 'us', 'de', 'fr', 'nl',
  'es', 'it', 'br', 'ru', 'tr', 'ir', 'pk', 'bd', 'sa', 'ae',
  'co.id', 'my.id', 'web.id', 'or.id', 'sch.id', 'ac.id', 'go.id', 'co.uk',
]);

function kandidatUrlValid(k) {
  if (/^https?:\/\//i.test(k)) return true;
  if (/^www\./i.test(k)) return true;
  const host = k.split('/')[0].toLowerCase();
  const bagian = host.split('.').filter(Boolean);
  if (bagian.length < 2) return false;
  return (
    TLD_DIKENAL.has(bagian.slice(-2).join('.')) || TLD_DIKENAL.has(bagian[bagian.length - 1])
  );
}

function daftarUrl(str) {
  if (typeof str !== 'string') return [];
  const hasil = [];
  for (const cocok of str.matchAll(POLA_URL)) {
    if (cocok.index > 0 && str[cocok.index - 1] === '@') continue;
    if (kandidatUrlValid(cocok[0])) hasil.push(cocok[0]);
  }
  return hasil;
}

const POLA_LINK_WA = /^(?:https?:\/\/)?(?:www\.)?(?:chat\.whatsapp\.com|whatsapp\.com\/channel)(?:\/|$)/i;

const TEXT = {
  id: {
    title: '⚠️ *ANTILINK*',
    body: 'Halo *{name}*, kamu mengirim link di grup.\nLink telah dihapus.',
  },
  ch: {
    title: '⚠️ *反链接*',
    body: '*{name}*，你在群组中发送了链接。\n链接已被删除。',
  },
  uk: {
    title: '⚠️ *ANTILINK*',
    body: 'Hi *{name}*, you sent a link in the group.\nThe link has been deleted.',
  },
};

function T(lang, key, vars = {}) {
  const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
  let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
  for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
  return str;
}

registerHandler('Antilink', async (ctx) => {
  const { sock, msg, isGroup, remoteJid, text, sender, reply } = ctx;
  if (!isGroup) return;

  const groupId = remoteJid.split('@')[0];
  if (!isFeatureEnabled(groupId, 'anti_link')) return;

  const PREFIX = config.prefix || '.';
  if (text && text.startsWith(PREFIX)) return;

  let isAdmin = false;
  try {
    const metadata = await sock.groupMetadata(remoteJid);
    const participant = metadata.participants.find(p =>
      p.id === sender.rawJid || p.id === sender.lid || p.phoneNumber === sender.nomor
    );
    isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
  } catch (e) {
    console.log(chalk.red(`[ANTILINK] Gagal cek admin: ${e.message}`));
  }
  if (isAdmin) return;

  const urls = daftarUrl(text);
  if (urls.length === 0) return;

  const nonWaUrls = urls.filter(url => !POLA_LINK_WA.test(url));
  if (nonWaUrls.length === 0) return;

  // Resolve bahasa
  const user = findUser({ lid: sender?.lid, nomor: sender?.nomor });
  let lang = 'uk';
  if (user && isValidLang(user.lang)) lang = user.lang;
  else {
    const gl = getGroupLang(groupId);
    if (isValidLang(gl)) lang = gl;
  }

  console.log(chalk.red(`[ANTILINK] Link dari @${sender.nomor || sender.lid}: ${nonWaUrls[0]}`));

  try {
    await sock.sendMessage(remoteJid, { delete: msg.key });
  } catch (e) {
    console.log(chalk.red(`[ANTILINK] Gagal hapus: ${e.message}`));
  }

  const namaUser = msg.pushName || sender.nomor || 'User';
  try {
    await reply(
      `${T(lang, 'title')}\n\n` +
      `${T(lang, 'body', { name: namaUser })}`
    );
  } catch (e) {
    console.log(chalk.red(`[ANTILINK] Gagal warning: ${e.message}`));
  }

  ctx.stop();
}, { priority: 2 });