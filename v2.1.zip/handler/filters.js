// handler/filter_auto.js
// Auto-trigger filter grup — SELALU AKTIF (tidak bisa di-off).
// Kalau user ketik teks yang persis sama dengan alias filter di grup → kirim isinya.

import { registerHandler } from '../libx/handlers.js';
import { getGroupLang } from '../libx/grup_db.js';
import { isValidLang, DEFAULT_LANG } from '../libx/lang.js';
import {
  listItems,
  getItem,
  rebuildMediaOpts,
} from '../libx/filters.js';
import { sendMedia, sendText } from '../libx/whatsapp/sendmsg.js';
import config from '../config.js';
import chalk from 'chalk';

// ============================================================
// COOLDOWN (cegah spam trigger alias yang sama)
// ============================================================
const COOLDOWN_MS = 10 * 1000; // 10 detik per user per alias
const lastTriggers = new Map(); // key: `${groupId}:${userId}:${alias}`

function checkCooldown(groupId, userId, alias) {
  const key = `${groupId}:${userId}:${alias}`;
  const now = Date.now();
  const last = lastTriggers.get(key) || 0;

  if (now - last < COOLDOWN_MS) return false;

  lastTriggers.set(key, now);

  // Cleanup entry lama
  setTimeout(() => {
    const check = lastTriggers.get(key);
    if (check && Date.now() - check >= COOLDOWN_MS) {
      lastTriggers.delete(key);
    }
  }, COOLDOWN_MS + 1000);

  return true;
}

// ============================================================
// CACHE LIST PER GRUP (biar tidak read file tiap pesan)
// ============================================================
const aliasCache = new Map(); // groupId -> { aliases: [{alias, id, type}], expireAt }
const CACHE_TTL = 30 * 1000; // 30 detik

function getAliasCache(groupId) {
  const now = Date.now();
  const cached = aliasCache.get(groupId);

  if (cached && cached.expireAt > now) return cached.aliases;

  const items = listItems(groupId);
  const aliases = items
    .filter((x) => x.alias)
    .map((x) => ({ alias: x.alias, id: x.id, type: x.type }));

  aliasCache.set(groupId, {
    aliases,
    expireAt: now + CACHE_TTL,
  });

  return aliases;
}

/**
 * Invalidate cache grup — dipanggil saat filter di-save / del / clear.
 */
export function invalidateFilterCache(groupId) {
  if (!groupId) {
    aliasCache.clear();
    return;
  }
  aliasCache.delete(String(groupId).replace(/\D/g, '').split('@')[0]);
}

// ============================================================
// HANDLER
// ============================================================
registerHandler('FilterAuto', async (ctx) => {
  const { sock, msg, isGroup, remoteJid, text, sender } = ctx;

  // 1. Hanya di grup & ada teks
  if (!isGroup) return;
  if (!text) return;

  // 2. Skip pesan dari bot sendiri
  if (msg.key?.fromMe) return;

  // 3. Skip command (diawali prefix)
  const PREFIX = config.prefix || '.';
  const trimmed = text.trim();

  if (!trimmed) return;
  if (trimmed.startsWith(PREFIX)) return;

  // 4. Skip teks kepanjangan (alias max biasanya <= 60 char)
  if (trimmed.length > 60) return;

  const groupId = remoteJid.split('@')[0];
  
  // ✅ FIX 1: Gunakan standar LID-first (sama seperti antibot_verify.js)
  const userId = sender?.lid || sender?.nomor;
  
  if (!userId) {
    if (config.mode === 'development') {
      console.log(chalk.yellow(`[FILTER-AUTO] Skip: userId kosong!`, sender));
    }
    return;
  }

  // 5. Cek alias di grup (pakai cache)
  let aliases;
  try {
    aliases = getAliasCache(groupId);
  } catch (err) {
    if (config.mode === 'development') {
      console.log(chalk.red(`[FILTER-AUTO] Cache error: ${err.message}`));
    }
    return;
  }

  if (!aliases.length) return;

  // 6. Cari exact match (case-insensitive)
  const clean = trimmed.toLowerCase();
  const match = aliases.find((x) => x.alias.toLowerCase() === clean);
  if (!match) return;

  // 7. Cooldown per user per alias
  if (!checkCooldown(groupId, userId, match.alias)) {
    if (config.mode === 'development') {
      console.log(chalk.gray(`[FILTER-AUTO] Cooldown: +${userId} → "${match.alias}"`));
    }
    return;
  }

  // 8. Ambil item full (buffer)
  const res = getItem(groupId, match.id);
  if (!res.ok) {
    if (config.mode === 'development') {
      console.log(chalk.yellow(`[FILTER-AUTO] Item hilang: ${match.id}`));
    }
    // Invalidate cache karena kemungkinan data tidak sinkron
    invalidateFilterCache(groupId);
    return;
  }

  // 9. Kirim
  try {
    if (res.item.type === 'text' || !res.buffer) {
      await sendText(sock, remoteJid, res.item.text || '(kosong)', { quoted: msg });
    } else {
      const opts = rebuildMediaOpts(res.item, res.buffer);
      opts.quoted = msg;
      await sendMedia(sock, remoteJid, opts, { quoted: msg });
    }

    if (config.mode === 'development') {
      console.log(chalk.cyan(`[FILTER-AUTO] ✓ Trigger "${match.alias}" dari +${userId}`));
    }
  } catch (err) {
    console.log(chalk.red(`[FILTER-AUTO] Gagal kirim: ${err.message}`));
  }

  // 10. Hentikan rantai handler
  ctx.stop();
  
// ✅ FIX 2: Ubah priority menjadi 2 (agar didahulukan sebelum handler lain yang lebih rendah prioritasnya)
}, { priority: 2 }); 