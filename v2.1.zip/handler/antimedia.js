// handler/antimedia.js
import { registerHandler } from '../libx/handlers.js';
import { isFeatureEnabled, getGroupLang } from '../libx/grup_db.js';
import { findUser } from '../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../libx/lang.js';
import config from '../config.js';
import chalk from 'chalk';

const TEXT = {
  id: {
    title: '⚠️ *ANTIMEDIA*',
    body: 'Halo *{name}*, kamu mengirim *{label}* di grup.\nMedia telah dihapus karena melanggar aturan grup.',
    label_image: 'Gambar',
    label_audio: 'Audio',
    label_video: 'Video',
    label_sticker: 'Sticker',
    label_media: 'Media',
  },
  ch: {
    title: '⚠️ *反媒体*',
    body: '*{name}*，你在群组中发送了 *{label}*。\n媒体已被删除，因为它违反了群组规则。',
    label_image: '图片',
    label_audio: '音频',
    label_video: '视频',
    label_sticker: '贴纸',
    label_media: '媒体',
  },
  uk: {
    title: '⚠️ *ANTIMEDIA*',
    body: 'Hi *{name}*, you sent *{label}* in the group.\nThe media has been deleted because it violates the group rules.',
    label_image: 'an image',
    label_audio: 'audio',
    label_video: 'a video',
    label_sticker: 'a sticker',
    label_media: 'media',
  },
};

function T(lang, key, vars = {}) {
  const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
  let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
  for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
  return str;
}

registerHandler('AntiMedia', async (ctx) => {
  const { sock, msg, isGroup, remoteJid, sender, reply } = ctx;

  if (!isGroup) return;

  const text = msg.message?.conversation
    || msg.message?.extendedTextMessage?.text
    || msg.message?.imageMessage?.caption
    || msg.message?.videoMessage?.caption
    || '';
  const PREFIX = config.prefix || '.';
  if (text && text.startsWith(PREFIX)) return;

  const m = msg.message || {};
  const mediaTypes = {
    imageMessage: 'anti_image',
    audioMessage: 'anti_audio',
    videoMessage: 'anti_video',
    stickerMessage: 'anti_sticker',
  };

  let detectedType = null;
  let featureKey = null;
  for (const [type, key] of Object.entries(mediaTypes)) {
    if (m[type]) { detectedType = type; featureKey = key; break; }
  }
  if (!detectedType) return;

  const groupId = remoteJid.split('@')[0];
  if (!isFeatureEnabled(groupId, featureKey)) return;

  let isAdmin = false;
  try {
    const metadata = await sock.groupMetadata(remoteJid);
    const participant = metadata.participants.find(p =>
      p.id === sender.rawJid || p.id === sender.lid || p.phoneNumber === sender.nomor
    );
    isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
  } catch (e) {
    console.log(chalk.red(`[ANTIMEDIA] Gagal cek admin: ${e.message}`));
  }
  if (isAdmin) return;

  // Resolve bahasa
  const user = findUser({ lid: sender?.lid, nomor: sender?.nomor });
  let lang = 'uk';
  if (user && isValidLang(user.lang)) lang = user.lang;
  else {
    const gl = getGroupLang(groupId);
    if (isValidLang(gl)) lang = gl;
  }

  console.log(chalk.red(`[ANTIMEDIA] ${featureKey} dari @${sender.nomor || sender.lid}`));

  try {
    await sock.sendMessage(remoteJid, { delete: msg.key });
  } catch (e) {
    console.log(chalk.red(`[ANTIMEDIA] Gagal hapus: ${e.message}`));
  }

  const namaUser = msg.pushName || sender.nomor || 'User';
  const labelKey = {
    anti_image: 'label_image',
    anti_audio: 'label_audio',
    anti_video: 'label_video',
    anti_sticker: 'label_sticker',
  }[featureKey] || 'label_media';
  const label = T(lang, labelKey);

  try {
    await reply(
      `${T(lang, 'title')}\n\n` +
      `${T(lang, 'body', { name: namaUser, label })}`
    );
  } catch (e) {
    console.log(chalk.red(`[ANTIMEDIA] Gagal kirim warning: ${e.message}`));
  }

  ctx.stop();
}, { priority: 3 });