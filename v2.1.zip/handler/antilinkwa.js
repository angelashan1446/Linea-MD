// handler/antilinkwa.js
import { registerHandler } from '../libx/handlers.js';
import { isFeatureEnabled, getGroupLang } from '../libx/grup_db.js';
import { findUser } from '../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../libx/lang.js';
import config from '../config.js';
import chalk from 'chalk';

const POLA_LINK_WA = [
  /(?:https?:\/\/)?(?:www\.)?chat\.whatsapp\.com\/[A-Za-z0-9]+/i,
  /(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\/[A-Za-z0-9]+/i,
  /(?:https?:\/\/)?(?:www\.)?wa\.me\/[0-9]+(?:\?[^\s]*)?/i,
  /(?:https?:\/\/)?(?:www\.)?api\.whatsapp\.com\/send\/?\?[^\s]*/i,
];

const TEXT = {
  id: {
    title: '⚠️ *ANTILINK WA*',
    body: 'Halo *{name}*, kamu mengirim link WhatsApp.\nLink telah dihapus karena melanggar aturan grup.',
  },
  ch: {
    title: '⚠️ *反 WhatsApp 链接*',
    body: '*{name}*，你发送了 WhatsApp 链接。\n链接已被删除，因为它违反了群组规则。',
  },
  uk: {
    title: '⚠️ *ANTILINK WA*',
    body: 'Hi *{name}*, you sent a WhatsApp link.\nThe link has been deleted because it violates the group rules.',
  },
};

function T(lang, key, vars = {}) {
  const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
  let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
  for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
  return str;
}

registerHandler('AntilinkWA', async (ctx) => {
  const { sock, msg, isGroup, remoteJid, text, sender, reply } = ctx;

  if (!isGroup) return;

  const PREFIX = config.prefix || '.';
  if (text && text.startsWith(PREFIX)) return;

  const groupId = remoteJid.split('@')[0];
  if (!isFeatureEnabled(groupId, 'anti_link_wa')) return;

  let isAdmin = false;
  try {
    const metadata = await sock.groupMetadata(remoteJid);
    const participant = metadata.participants.find(p =>
      p.id === sender.rawJid || p.id === sender.lid || p.phoneNumber === sender.nomor
    );
    isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
  } catch (e) {
    console.log(chalk.red(`[ANTILINKWA] Gagal cek admin: ${e.message}`));
  }
  if (isAdmin) return;

  let matchedLink = null;
  for (const pola of POLA_LINK_WA) {
    const match = text.match(pola);
    if (match) { matchedLink = match[0]; break; }
  }
  if (!matchedLink) return;

  // Resolve bahasa
  const user = findUser({ lid: sender?.lid, nomor: sender?.nomor });
  let lang = 'uk';
  if (user && isValidLang(user.lang)) lang = user.lang;
  else {
    const gl = getGroupLang(groupId);
    if (isValidLang(gl)) lang = gl;
  }

  console.log(chalk.red(`[ANTILINKWA] Link WA dari @${sender.nomor || sender.lid}: ${matchedLink}`));

  try {
    await sock.sendMessage(remoteJid, { delete: msg.key });
  } catch (e) {
    console.log(chalk.red(`[ANTILINKWA] Gagal hapus pesan: ${e.message}`));
  }

  const namaUser = msg.pushName || sender.nomor || 'User';
  try {
    await reply(
      `${T(lang, 'title')}\n\n` +
      `${T(lang, 'body', { name: namaUser })}`
    );
  } catch (e) {
    console.log(chalk.red(`[ANTILINKWA] Gagal kirim warning: ${e.message}`));
  }

  ctx.stop();
}, { priority: 2 });