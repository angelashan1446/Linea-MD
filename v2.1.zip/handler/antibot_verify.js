// handler/antibot_verify.js
// AntiBot: verifikasi user baru / bot asing.
// Multi-bahasa: user terdaftar → pakai user.lang.
//               guest → pakai grup_lang.

import { registerHandler } from '../libx/handlers.js';
import { isFeatureEnabled, getBotService, getGroupLang } from '../libx/grup_db.js';
import {
    isVerified, saveVerification, getVerification, generateCode,
    markVerified, canNotify, updateNotifTime, containsCode,
} from '../libx/verify_db.js';
import { isOwner, isPremium, findUser } from '../libx/db.js';
import { sendText } from '../libx/whatsapp/sendmsg.js';
import { isValidLang, DEFAULT_LANG } from '../libx/lang.js';
import config from '../config.js';
import chalk from 'chalk';

// ============================================================
// ✅ LOCK PER USER (cegah 2 pesan user sama diproses bareng)
// ============================================================
const userLocks = new Map();
const USER_LOCK_MS = 30000; // 5 detik — cukup untuk selesaikan 1 siklus notif

function tryLockUser(userId) {
    if (!userId) return false;
    const now = Date.now();
    const lock = userLocks.get(userId);

    if (lock && lock > now) return false;

    userLocks.set(userId, now + USER_LOCK_MS);
    setTimeout(() => {
        const current = userLocks.get(userId);
        if (current && current <= Date.now()) {
            userLocks.delete(userId);
        }
    }, USER_LOCK_MS + 100);

    return true;
}

// ============================================================
// KAMUS BAHASA
// ============================================================
const TEXT = {
    id: {
        header_ok: `✅ *Verifikasi Berhasil!*`,
        welcome_private:
            'Halo *{name}*, selamat datang! 🎉\n' +
            'Sekarang kamu bisa chat bebas di grup yang pakai AntiBot.',
        welcome_group:
            'Halo *{name}*, selamat datang! 🎉\n' +
            'Sekarang kamu bisa chat bebas di grup ini.',

        antibot_title: `🚨 *ANTIBOT*`,
        antibot_body: 'Pesan bot asing telah dihapus.',

        verify_hello:
            '👋 Halo *{name}*!\n\n' +
            'Verifikasi dulu ya sebelum bisa chat.\n\n' +
            '🔑 *Kode:* *{code}*\n\n' +
            '📲 *Klik link ini buat verifikasi otomatis:*\n{link}\n\n' +
            '_Atau ketik manual: "verif {code}"_',

        verify_reminder:
            'Hai *{name}*, pesanmu aku hapus.\n\n' +
            '📲 *Klik link ini buat verifikasi:*\n{link}\n\n' +
            '_Atau kirim: "verif {code}"_',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        header_ok: `✅ *验证成功！*`,
        welcome_private:
            '你好 *{name}*，欢迎！🎉\n' +
            '现在你可以在启用 AntiBot 的群组中自由聊天了。',
        welcome_group:
            '你好 *{name}*，欢迎！🎉\n' +
            '现在你可以在本群组中自由聊天了。',

        antibot_title: `🚨 *ANTIBOT*`,
        antibot_body: '已删除外部机器人消息。',

        verify_hello:
            '👋 你好 *{name}*！\n\n' +
            '请先完成验证才能聊天。\n\n' +
            '🔑 *验证码：* *{code}*\n\n' +
            '📲 *点击下方链接自动验证：*\n{link}\n\n' +
            '_或手动输入："verif {code}"_',

        verify_reminder:
            '*{name}*，你的消息已被删除。\n\n' +
            '📲 *点击此链接进行验证：*\n{link}\n\n' +
            '_或发送："verif {code}"_',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        header_ok: `✅ *Verification Successful!*`,
        welcome_private:
            'Hello *{name}*, welcome! 🎉\n' +
            'You can now chat freely in groups using AntiBot.',
        welcome_group:
            'Hello *{name}*, welcome! 🎉\n' +
            'You can now chat freely in this group.',

        antibot_title: `🚨 *ANTIBOT*`,
        antibot_body: 'Foreign bot message has been deleted.',

        verify_hello:
            '👋 Hello *{name}*!\n\n' +
            'Please verify before you can chat.\n\n' +
            '🔑 *Code:* *{code}*\n\n' +
            '📲 *Click this link for automatic verification:*\n{link}\n\n' +
            '_Or type manually: "verif {code}"_',

        verify_reminder:
            'Hi *{name}*, your message was deleted.\n\n' +
            '📲 *Click this link to verify:*\n{link}\n\n' +
            '_Or send: "verif {code}"_',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function resolveLang({ user, isGroup, remoteJid }) {
    if (user && isValidLang(user.lang)) return user.lang;

    if (isGroup && remoteJid) {
        try {
            const groupId = remoteJid.split('@')[0];
            const gl = getGroupLang(groupId);
            if (isValidLang(gl)) return gl;
        } catch {}
    }

    return 'uk';
}

// ============================================================
// HANDLER
// ============================================================
registerHandler('AntiBotVerify', async (ctx) => {
    const { sock, msg, isGroup, remoteJid, text, sender } = ctx;

    if (msg.key?.fromMe) return;

    const userId = sender?.lid || sender?.nomor;
    if (!userId) return;

    // ============================================================
    // ✅ LOCK PER USER — cegah 2 pesan user sama diproses bareng
    // ============================================================
    if (!tryLockUser(userId)) {
        if (config.mode === 'development') {
            console.log(chalk.gray(`[ANTIBOT] Skip ${userId} — sedang di-lock (hindari notif dobel)`));
        }
        return;
    }

    // Cari user DB untuk resolve bahasa
    const user = findUser({ lid: sender?.lid, nomor: sender?.nomor });
    const lang = resolveLang({ user, isGroup, remoteJid });

    // ============================================================
    // 1. CEK BOT SERVICE
    // ============================================================
    if (isGroup) {
        const groupId = remoteJid.split('@')[0];
        const botService = getBotService(groupId);
        const myBotNumber = sock.user?.id?.split(':')[0]?.split('@')[0];

        if (botService !== 'dynamic' && botService !== myBotNumber) {
            if (config.mode === 'development') {
                console.log(chalk.gray(`[ANTIBOT] Skip ${groupId} — grup milik bot +${botService}`));
            }
            return;
        }
    }

    // ============================================================
    // 2. VERIFIKASI VIA LINK WA.ME (Private Chat)
    // ============================================================
    if (!isGroup) {
        if (containsCode(userId, text)) {
            const v = getVerification(userId);
            if (v?.code) {
                markVerified(userId);
                const name = msg.pushName || userId.split('@')[0];
                try {
                    await sendText(sock, remoteJid,
                        `${T(lang, 'header_ok')}\n\n` +
                        `${T(lang, 'welcome_private', { name })}\n\n` +
                        `${T(lang, 'footer')}`
                    );
                } catch {}
                ctx.stop();
                return;
            }
        }
        return;
    }

    // ============================================================
    // KHUSUS GRUP
    // ============================================================
    const groupId = remoteJid.split('@')[0];
    if (!isFeatureEnabled(groupId, 'anti_bot')) return;

    // Skip owner/premium
    if (isOwner({ lid: sender?.lid, nomor: sender?.nomor })) return;
    if (isPremium({ lid: sender?.lid, nomor: sender?.nomor })) return;

    // Skip admin
    let isAdmin = false;
    try {
        const metadata = await sock.groupMetadata(remoteJid);
        const p = metadata.participants.find(x =>
            x.id === sender.rawJid || x.id === sender.lid || x.phoneNumber === sender.nomor
        );
        isAdmin = p?.admin === 'admin' || p?.admin === 'superadmin';
    } catch {}
    if (isAdmin) return;

    // Skip command (kecuali .daftar)
    const PREFIX = config.prefix || '.';
    if (text?.startsWith(PREFIX)) {
        const cmd = text.slice(PREFIX.length).trim().split(/\s+/)[0]?.toLowerCase();
        if (['daftar'].includes(cmd)) return;
    }

    const namaUser = msg.pushName || userId.split('@')[0];

    // ============================================================
    // LAPISAN 1: VERIFIKASI KODE
    // ============================================================
    if (isVerified(userId)) return;

    if (containsCode(userId, text)) {
        try { await sock.sendMessage(remoteJid, { delete: msg.key }); } catch {}
        markVerified(userId);
        try {
            await sendText(sock, remoteJid,
                `${T(lang, 'header_ok')}\n\n` +
                `${T(lang, 'welcome_group', { name: namaUser })}\n\n` +
                `${T(lang, 'footer')}`
            );
        } catch {}
        ctx.stop();
        return;
    }

    // ============================================================
    // LAPISAN 2: DETEKSI BOT
    // ============================================================
    const isBotSignal =
        msg.key?.isBot === true ||
        sender.rawJid?.endsWith('@bot') ||
        sender.lid?.endsWith('@bot') ||
        msg.pushName?.toLowerCase().includes('bot');

    if (isBotSignal) {
        console.log(chalk.bgRed.white(` [ANTIBOT] LAPISAN 2: isBot terdeteksi `));
        console.log(chalk.red(`> Pengirim: @${sender.nomor || sender.lid}`));

        try {
            await sock.sendMessage(remoteJid, { delete: msg.key });
        } catch (e) {
            console.log(chalk.red(`[ANTIBOT] Gagal hapus: ${e.message}`));
        }

        if (canNotify(userId)) {
            // ✅ Update DULU sebelum kirim → cegah dobel dari handler paralel
            updateNotifTime(userId);
            try {
                await sendText(sock, remoteJid,
                    `${T(lang, 'antibot_title')}\n\n` +
                    `${T(lang, 'antibot_body')}`
                );
            } catch {}
        }

        ctx.stop();
        return;
    }

    // ============================================================
    // BELUM VERIF + BUKAN BOT → Hapus pesan + kirim kode
    // ============================================================
    try { await sock.sendMessage(remoteJid, { delete: msg.key }); } catch {}

    const v = getVerification(userId);
    const myBotNumber = sock.user?.id?.split(':')[0]?.split('@')[0]
        || config.phone_number_bot;

    // Pertama kali → generate kode
    if (!v?.code) {
        // ✅ Update DULU sebelum kirim
        updateNotifTime(userId);

        const code = generateCode();
        saveVerification(userId, code);
        const display = `${code.slice(0, 4)}-${code.slice(4)}`;
        const verifyLink = `https://wa.me/${myBotNumber}?text=${encodeURIComponent(`verif ${display}`)}`;

        try {
            await sendText(sock, remoteJid,
                `${T(lang, 'verify_hello', { name: namaUser, code: display, link: verifyLink })}\n\n` +
                `${T(lang, 'footer')}`
            );
        } catch {}

        ctx.stop();
        return;
    }

    // Punya kode tapi belum verif → reminder (cooldown)
    if (canNotify(userId)) {
        // ✅ Update DULU sebelum kirim
        updateNotifTime(userId);

        const display = `${v.code.slice(0, 4)}-${v.code.slice(4)}`;
        const verifyLink = `https://wa.me/${myBotNumber}?text=${encodeURIComponent(`verif ${display}`)}`;

        try {
            await sendText(sock, remoteJid,
                `${T(lang, 'verify_reminder', { name: namaUser, code: display, link: verifyLink })}\n\n` +
                `${T(lang, 'footer')}`
            );
        } catch {}
    }

    ctx.stop();
}, { priority: 0 });