// handler/antibadword.js
import { registerHandler } from '../libx/handlers.js';
import { isFeatureEnabled, getGroupLang } from '../libx/grup_db.js';
import { findUser } from '../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../libx/lang.js';
import chalk from 'chalk';

const BADWORDS = [
  'anjing', 'anjg', 'anjir', 'ajg',
  'bangsat', 'bgst', 'bajingan',
  'kontol', 'kntl', 'memek', 'mmk',
  'babi', 'bngst',
  'tai', 'taik', 'taii',
  'asu', 'asw', 'asuu',
  'goblok', 'gblk', 'tolol', 'tll',
  'pepek', 'ppk',
  'jancok', 'jancuk', 'cok',
  'pukimak', 'puk1mak',
  'kimak', 'kmk',
];

function normalizeText(str) {
  return String(str)
    .toLowerCase()
    .replace(/[0@]/g, 'o')
    .replace(/[1!|]/g, 'i')
    .replace(/[3]/g, 'e')
    .replace(/[4]/g, 'a')
    .replace(/[5$]/g, 's')
    .replace(/[7]/g, 't')
    .replace(/[^a-z]/g, '');
}

function detectBadword(text) {
  const clean = normalizeText(text);
  for (const word of BADWORDS) {
    if (clean.includes(word)) return word;
  }
  return null;
}

// ============================================================
// KAMUS
// ============================================================
const TEXT = {
  id: {
    title: '⚠️ *ANTIBADWORD*',
    body: 'Halo *{name}*, pesanmu mengandung kata kasar.\nPesan telah dihapus. Mohon jaga bahasa di grup ini.',
  },
  ch: {
    title: '⚠️ *反脏话*',
    body: '*{name}*，你的消息包含不雅词汇。\n消息已被删除。请在本群组注意用语。',
  },
  uk: {
    title: '⚠️ *ANTIBADWORD*',
    body: 'Hi *{name}*, your message contained offensive words.\nThe message has been deleted. Please keep your language clean in this group.',
  },
};

function T(lang, key, vars = {}) {
  const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
  let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
  for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
  return str;
}

registerHandler('Antibadword', async (ctx) => {
  const { sock, msg, isGroup, remoteJid, text, sender, reply } = ctx;

  if (!isGroup) return;
  if (!text) return;

  const groupId = remoteJid.split('@')[0];
  if (!isFeatureEnabled(groupId, 'anti_badword')) return;

  let isAdmin = false;
  try {
    const metadata = await sock.groupMetadata(remoteJid);
    const participant = metadata.participants.find(p =>
      p.id === sender.rawJid || p.id === sender.lid || p.phoneNumber === sender.nomor
    );
    isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
  } catch (e) {
    console.log(chalk.red(`[ANTIBADWORD] Gagal cek admin: ${e.message}`));
  }
  if (isAdmin) return;

  const badword = detectBadword(text);
  if (!badword) return;

  // Resolve bahasa
  const user = findUser({ lid: sender?.lid, nomor: sender?.nomor });
  let lang = 'uk';
  if (user && isValidLang(user.lang)) lang = user.lang;
  else {
    const gl = getGroupLang(groupId);
    if (isValidLang(gl)) lang = gl;
  }

  console.log(chalk.red(`[ANTIBADWORD] Kata kasar "${badword}" dari @${sender.nomor || sender.lid}`));

  try {
    await sock.sendMessage(remoteJid, { delete: msg.key });
  } catch (e) {
    console.log(chalk.red(`[ANTIBADWORD] Gagal hapus pesan: ${e.message}`));
  }

  const namaUser = msg.pushName || sender.nomor || 'User';
  try {
    await reply(
      `${T(lang, 'title')}\n\n` +
      `${T(lang, 'body', { name: namaUser })}`
    );
  } catch (e) {
    console.log(chalk.red(`[ANTIBADWORD] Gagal kirim warning: ${e.message}`));
  }

  ctx.stop();
}, { priority: 3 });