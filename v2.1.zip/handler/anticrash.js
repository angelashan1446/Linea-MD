// handler/anticrash.js
import { registerHandler } from '../libx/handlers.js';
import { isFeatureEnabled, getGroupLang } from '../libx/grup_db.js';
import { findUser } from '../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../libx/lang.js';
import config from '../config.js';
import chalk from 'chalk';

const MAX_TEXT_LENGTH = 5000;
const MAX_WEIRD_CHARS = 30;
const MAX_FILENAME_LENGTH = 200;
const ZALGO_REGEX = /[\u0300-\u036F\u1AB0-\u1AFF\u1DC0-\u1DFF\u20D0-\u20FF\uFE20-\uFE2F]/g;

const TEXT = {
  id: {
    title: '🚨 *ANTI-CRASH*',
    kick_msg: 'Terdeteksi pesan berbahaya (Bug/Card Bomb).\nPengirim telah di-*kick* dari grup.',
    kick_fail: 'Pesan berbahaya telah dihapus.\n_(Gagal kick: pastikan bot adalah admin grup)_',
    admin_deleted: 'Pesan berbahaya dari admin telah dihapus.',
  },
  ch: {
    title: '🚨 *反崩溃*',
    kick_msg: '检测到危险消息（Bug/Card Bomb）。\n发送者已被*移出*群组。',
    kick_fail: '危险消息已删除。\n_（移除失败：请确保机器人为群组管理员）_',
    admin_deleted: '来自管理员的危险消息已被删除。',
  },
  uk: {
    title: '🚨 *ANTI-CRASH*',
    kick_msg: 'Dangerous message detected (Bug/Card Bomb).\nThe sender has been *kicked* from the group.',
    kick_fail: 'Dangerous message has been deleted.\n_(Kick failed: make sure the bot is a group admin)_',
    admin_deleted: 'Dangerous message from admin has been deleted.',
  },
};

function T(lang, key, vars = {}) {
  const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
  let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
  for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
  return str;
}

registerHandler('AntiCrash', async (ctx) => {
  const { sock, msg, isGroup, remoteJid, sender, reply } = ctx;

  if (!isGroup) return;
  if (msg.key?.fromMe) return;

  const groupId = remoteJid.split('@')[0];
  if (!isFeatureEnabled(groupId, 'anti_crash')) return;

  const text =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption ||
    '';

  const PREFIX = config.prefix || '.';
  if (text.startsWith(PREFIX)) return;

  const isTooLong = text.length > MAX_TEXT_LENGTH;
  const weirdMatches = text.match(ZALGO_REGEX);
  const isZalgo = weirdMatches && weirdMatches.length > MAX_WEIRD_CHARS;
  const fileName = msg.message?.documentMessage?.fileName || '';
  const isWeirdFileName = fileName.length > MAX_FILENAME_LENGTH ||
    (fileName.match(ZALGO_REGEX)?.length > 5);

  if (!isTooLong && !isZalgo && !isWeirdFileName) return;

  // Resolve bahasa
  const user = findUser({ lid: sender?.lid, nomor: sender?.nomor });
  let lang = 'uk';
  if (user && isValidLang(user.lang)) lang = user.lang;
  else {
    const gl = getGroupLang(groupId);
    if (isValidLang(gl)) lang = gl;
  }

  console.log(chalk.bgRed.white(` [ANTICRASH] SERANGAN TERDETEKSI! `));
  console.log(chalk.red(`> Pengirim: @${sender.nomor || sender.lid}`));
  console.log(chalk.red(`> Alasan: ${isTooLong ? 'Teks Kepanjangan' : isZalgo ? 'Zalgo Text' : 'Nama File Aneh'}`));

  try {
    await sock.sendMessage(remoteJid, { delete: msg.key });
  } catch (e) {
    console.log(chalk.red(`[ANTICRASH] Gagal hapus: ${e.message}`));
  }

  let isAdmin = false;
  try {
    const metadata = await sock.groupMetadata(remoteJid);
    const p = metadata.participants.find(x =>
      x.id === sender.rawJid || x.id === sender.lid || x.phoneNumber === sender.nomor
    );
    isAdmin = p?.admin === 'admin' || p?.admin === 'superadmin';
  } catch {}

  if (!isAdmin) {
    try {
      await sock.groupParticipantsUpdate(remoteJid, [sender.rawJid || sender.lid], 'remove');
      await reply(`${T(lang, 'title')}\n\n${T(lang, 'kick_msg')}`);
    } catch {
      await reply(`${T(lang, 'title')}\n\n${T(lang, 'kick_fail')}`);
    }
  } else {
    await reply(`${T(lang, 'title')}\n\n${T(lang, 'admin_deleted')}`);
  }

  ctx.stop();
}, { priority: 0 });