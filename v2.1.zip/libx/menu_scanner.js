// libx/menu_scanner.js
// Scan folder plugins/ untuk mencari kategori, command & deskripsi (multi-bahasa).

import fs from 'fs';
import path from 'path';

// ============================================================
// PICK DESCRIPTION BERDASARKAN BAHASA
// ============================================================
/**
 * Ambil deskripsi plugin sesuai bahasa.
 * Prioritas:
 *   1. description_<lang> (mis. description_ch)
 *   2. description (fallback generik)
 *   3. null
 *
 * @param {object} mod - Module plugin
 * @param {'id'|'ch'|'uk'} lang
 * @returns {string|null}
 */
function pickDescription(mod, lang) {
    const l = String(lang || 'uk').toLowerCase();

    // description_<lang>
    const byLang = mod?.[`description_${l}`];
    if (typeof byLang === 'string' && byLang.trim()) return byLang;

    // fallback: description generic
    if (typeof mod?.description === 'string' && mod.description.trim()) {
        return mod.description;
    }

    return null;
}

// ============================================================
// SCAN MENU
// ============================================================
/**
 * Scan folder plugins/ dan return array berisi info plugin.
 *
 * @param {string} pluginsDir - Path absolut folder plugins
 * @param {object} [opts]
 * @param {'id'|'ch'|'uk'} [opts.lang='uk'] - Bahasa untuk deskripsi
 * @returns {Promise<Array<{
 *   category: string,
 *   cmd: string[],
 *   description: string | null,
 *   file: string,
 *   filePath: string,
 * }>>}
 */
export async function scanMenu(pluginsDir = path.join(process.cwd(), 'plugins'), opts = {}) {
    const lang = opts.lang || 'uk';
    const result = [];

    if (!fs.existsSync(pluginsDir)) return result;

    // Fungsi rekursif untuk masuk ke sub-folder
    async function walk(dir, category) {
        const files = fs.readdirSync(dir, { withFileTypes: true });

        for (const entry of files) {
            const fullPath = path.join(dir, entry.name);

            if (entry.isDirectory()) {
                // Kalau folder, lanjut scan & jadikan nama folder sebagai kategori
                await walk(fullPath, entry.name);
            } else if (entry.isFile() && entry.name.endsWith('.js')) {
                try {
                    // Load plugin untuk ambil `cmd` & `description`
                    const mod = await import(`file://${fullPath}?update=${Date.now()}`);

                    if (mod.cmd) {
                        const cmds = Array.isArray(mod.cmd) ? mod.cmd : [mod.cmd];
                        result.push({
                            category: category || 'umum',
                            cmd: cmds,
                            description: pickDescription(mod, lang),
                            file: entry.name,
                            filePath: fullPath,
                        });
                    }
                } catch (err) {
                    console.error(`[Menu Scanner] Gagal load ${entry.name}:`, err.message);
                }
            }
        }
    }

    await walk(pluginsDir, null);

    // Urutkan berdasarkan kategori
    result.sort((a, b) => a.category.localeCompare(b.category));

    return result;
}

// ============================================================
// HELPER: GROUP BY CATEGORY
// ============================================================
/**
 * Group hasil scanMenu() berdasarkan kategori.
 *
 * @param {Awaited<ReturnType<typeof scanMenu>>} items
 * @returns {Record<string, typeof items>}
 */
export function groupByCategory(items) {
    const out = {};
    for (const item of items) {
        if (!out[item.category]) out[item.category] = [];
        out[item.category].push(item);
    }
    return out;
}

// ============================================================
// HELPER: FORMAT MENU TEKS
// ============================================================
/**
 * Bangun menu teks dari hasil scan.
 *
 * @param {object} opts
 * @param {Awaited<ReturnType<typeof scanMenu>>} opts.items
 * @param {string} opts.prefix
 * @param {string} [opts.title='乂  *ᴍᴇɴᴜ*']
 * @param {string} [opts.footer]
 * @param {string} [opts.emptyLabel='—']
 * @returns {string}
 */
export function buildMenuText({
    items,
    prefix = '.',
    title = '乂  *ᴍᴇɴᴜ*',
    footer = '',
    emptyLabel = '—',
}) {
    const grouped = groupByCategory(items);

    const lines = [title, ''];
    for (const [cat, list] of Object.entries(grouped)) {
        lines.push(`╭─「 *${cat.toUpperCase()}* 」`);
        for (const item of list) {
            const cmd0 = item.cmd[0];
            const desc = item.description || emptyLabel;
            lines.push(`│ ◦ ${prefix}${cmd0} — ${desc}`);
        }
        lines.push('╰───────☉');
        lines.push('');
    }

    if (footer) {
        lines.push(footer);
    }

    return lines.join('\n');
}