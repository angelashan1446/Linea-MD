// libx/grup_db.js
// Database grup: menyimpan status fitur per grup + bahasa grup (grup_lang).

import fs from 'fs';
import path from 'path';

const DB_DIR = path.join(process.cwd(), 'db');
const DB_FILE = path.join(DB_DIR, 'grups.json');

// ============================================================
// BAHASA
// ============================================================
const VALID_LANGS = ['id', 'ch', 'uk'];
const DEFAULT_GROUP_LANG = 'uk'; // ✅ Default sekarang UK (English)

// ============================================================
// DAFTAR FITUR DEFAULT
// ============================================================
const DEFAULT_FEATURES = {
  // Anti (hapus pesan)
  anti_crash: true,
  anti_link: false,
  anti_link_wa: false,
  anti_badword: false,
  anti_image: false,
  anti_audio: false,
  anti_video: false,
  anti_sticker: false,
  anti_bot: false,

  // Additional (kirim pesan)
  welcome: false,
  left: false,
};

// ============================================================
// DEFAULT DATA GRUP
// ============================================================
const DEFAULT_GROUP_DATA = {
  id_grup: null,
  rent: null,
  bot_service: 'dynamic',
  grup_lang: DEFAULT_GROUP_LANG, // ✅ BAHASA GRUP (default: uk)
  feature: { ...DEFAULT_FEATURES },
};

function ensureDir() {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ groups: {} }, null, 2));
}

function readDb() {
  ensureDir();
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch {
    return { groups: {} };
  }
}

function writeDb(data) {
  ensureDir();
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

export function getGroup(groupId) {
  const db = readDb();
  if (!db.groups[groupId]) {
    db.groups[groupId] = {
      ...DEFAULT_GROUP_DATA,
      id_grup: groupId,
      feature: { ...DEFAULT_FEATURES },
    };
    writeDb(db);
  } else {
    let changed = false;

    // Pastikan field bot_service ada
    if (db.groups[groupId].bot_service === undefined) {
      db.groups[groupId].bot_service = DEFAULT_GROUP_DATA.bot_service;
      changed = true;
    }

    // Pastikan field grup_lang ada (migrasi dari grup lama)
    if (db.groups[groupId].grup_lang === undefined) {
      db.groups[groupId].grup_lang = DEFAULT_GROUP_LANG;
      changed = true;
    }

    // Pastikan object feature ada
    if (!db.groups[groupId].feature) {
      db.groups[groupId].feature = {};
      changed = true;
    }

    // Pastikan semua fitur default ada
    for (const key of Object.keys(DEFAULT_FEATURES)) {
      if (db.groups[groupId].feature[key] === undefined) {
        db.groups[groupId].feature[key] = DEFAULT_FEATURES[key];
        changed = true;
      }
    }

    if (changed) writeDb(db);
  }
  return db.groups[groupId];
}

export function isFeatureEnabled(groupId, featureName) {
  const group = getGroup(groupId);
  return group.feature?.[featureName] === true;
}

export function setFeature(groupId, featureName, status) {
  const db = readDb();
  if (!db.groups[groupId]) {
    db.groups[groupId] = {
      ...DEFAULT_GROUP_DATA,
      id_grup: groupId,
      feature: { ...DEFAULT_FEATURES },
    };
  }
  if (!db.groups[groupId].feature) {
    db.groups[groupId].feature = { ...DEFAULT_FEATURES };
  }
  db.groups[groupId].feature[featureName] = !!status;
  writeDb(db);
  return true;
}

export function getAllFeatures() {
  return Object.keys(DEFAULT_FEATURES);
}

// ============================================================
// KATEGORI FITUR
// ============================================================
export function getFeatureCategories() {
  return {
    'Anti Link': [
      'anti_link', 'anti_link_wa',
    ],
    'Anti Media': [
      'anti_image', 'anti_audio', 'anti_video', 'anti_sticker',
    ],
    'Anti Teks': [
      'anti_badword', 'anti_promosi', 'anti_nsfw',
    ],
    'Anti Crash': [
      'anti_crash',
    ],
    'Anti Bot': [
      'anti_bot',
    ],
    'Additional': [
      'welcome', 'left',
    ],
  };
}

/**
 * Mendapatkan nama tampilan (display name) sebuah JID.
 */
export async function getDisplayName(sock, jid) {
  try {
    if (!jid) return 'User';

    const contact = sock.contacts?.[jid];
    if (contact?.name || contact?.notify) {
      return contact.name || contact.notify;
    }

    let finalJid = jid;
    if (jid.endsWith('@lid')) {
      const pn = await sock?.signalRepository?.lidMapping?.getPNForLID?.(jid);
      if (pn) {
        finalJid = pn;
        const contactPn = sock.contacts?.[finalJid];
        if (contactPn?.name || contactPn?.notify) {
          return contactPn.name || contactPn.notify;
        }
      }
    }

    return '+' + finalJid.split('@')[0];
  } catch {
    return 'User';
  }
}

// ============================================================
// RENT (Sewa Bot)
// ============================================================
export function setRent(groupId, untilIso) {
  const db = readDb();
  if (!db.groups[groupId]) {
    db.groups[groupId] = {
      ...DEFAULT_GROUP_DATA,
      id_grup: groupId,
      feature: { ...DEFAULT_FEATURES },
    };
  }
  db.groups[groupId].rent = untilIso;
  writeDb(db);
  return true;
}

export function isRentActive(groupId) {
  const group = getGroup(groupId);
  if (!group.rent) return true;
  return new Date(group.rent).getTime() > Date.now();
}

export function hasRent(groupId) {
  const group = getGroup(groupId);
  return !!group.rent;
}

export function getRentExpired(groupId) {
  const group = getGroup(groupId);
  return group.rent || null;
}

// ============================================================
// BOT SERVICE
// ============================================================
export function setBotService(groupId, botNumber) {
  const db = readDb();
  if (!db.groups[groupId]) {
    db.groups[groupId] = {
      ...DEFAULT_GROUP_DATA,
      id_grup: groupId,
      feature: { ...DEFAULT_FEATURES },
    };
  }

  if (!botNumber || String(botNumber).toLowerCase() === 'dynamic') {
    db.groups[groupId].bot_service = 'dynamic';
  } else {
    db.groups[groupId].bot_service = String(botNumber).replace(/\D/g, '');
  }

  writeDb(db);
  return true;
}

export function getBotService(groupId) {
  const group = getGroup(groupId);
  return group.bot_service || 'dynamic';
}

// ============================================================
// ✅ GRUP LANG (BAHASA GRUP)
// ============================================================

/**
 * Cek apakah kode bahasa grup valid.
 * @param {string} code
 */
export function isValidGroupLang(code) {
  return VALID_LANGS.includes(String(code || '').toLowerCase().trim());
}

/**
 * Ambil bahasa grup.
 * @param {string} groupId
 * @returns {'id'|'ch'|'uk'}
 */
export function getGroupLang(groupId) {
  const group = getGroup(groupId);
  const l = String(group.grup_lang || '').toLowerCase().trim();
  return VALID_LANGS.includes(l) ? l : DEFAULT_GROUP_LANG;
}

/**
 * Set bahasa grup.
 * @param {string} groupId
 * @param {string} lang - 'id' | 'ch' | 'uk'
 * @returns {{ok:boolean, lang?:string, reason?:string}}
 */
export function setGroupLang(groupId, lang) {
  const code = String(lang || '').toLowerCase().trim();
  if (!VALID_LANGS.includes(code)) {
    return { ok: false, reason: 'Kode bahasa tidak valid (pilih: id / ch / uk)' };
  }

  const db = readDb();
  if (!db.groups[groupId]) {
    db.groups[groupId] = {
      ...DEFAULT_GROUP_DATA,
      id_grup: groupId,
      feature: { ...DEFAULT_FEATURES },
    };
  }
  db.groups[groupId].grup_lang = code;
  writeDb(db);

  return { ok: true, lang: code };
}

/**
 * Reset bahasa grup ke default ('uk').
 */
export function resetGroupLang(groupId) {
  return setGroupLang(groupId, DEFAULT_GROUP_LANG);
}

export const GROUP_LANGS = VALID_LANGS;
export const DEFAULT_GROUP_LANG_EXPORT = DEFAULT_GROUP_LANG;