// libx/startup.js
// Tempat utility: Logger, Error Handler, Plugin Loader, dll.

import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import config from '../config.js'; // ✅ Import config

const PREFIX = config.prefix; // ✅ Ambil dari config

// ============================================================
// UI HELPERS
// ============================================================
export const log = {
  banner: (text) => console.log(chalk.cyan.bold(`\n╭─── ${text} ───╮`)),
  info: (text) => console.log(chalk.blue(`  ℹ ${text}`)),
  success: (text) => console.log(chalk.green(`  ✅ ${text}`)),
  warn: (text) => console.log(chalk.yellow(`  ⚠️  ${text}`)),
  error: (text) => console.log(chalk.red(`  ❌ ${text}`)),
  divider: () => console.log(chalk.cyan.bold('╰────────────────╯')),
  blank: () => console.log(''),
};

// ============================================================
// 🛡️ GLOBAL ERROR HANDLER (Anti-Crash)
// ============================================================
export function setupGlobalErrorHandlers() {
  process.on('unhandledRejection', (reason) => {
    const msg = reason?.message || String(reason);
    if (msg.includes('negative publish ack') || msg.includes('error=463')) {
      log.warn(`[SKIP] Reachout Timelock (463). Bot tetap jalan.`);
      return;
    }
    log.error(`Unhandled Rejection: ${msg}`);
  });

  process.on('uncaughtException', (err) => {
    const msg = err?.message || String(err);
    if (msg.includes('negative publish ack') || msg.includes('error=463')) {
      log.warn(`[SKIP] Uncaught 463. Bot tetap jalan.`);
      return;
    }
    log.error(`Uncaught Exception: ${msg}`);
  });
}

// ============================================================
// 🛡️ LOAD EXTRA HANDLERS (Antilink, dll)
// ============================================================
export async function loadExtraHandlers() {
  const folders = [
    path.join(process.cwd(), 'libx', 'handlers'),
    path.join(process.cwd(), 'handler'),
  ];

  log.banner(`🛡️  LOADING EXTRA HANDLERS`);
  let count = 0;

  for (const folder of folders) {
    if (!fs.existsSync(folder)) continue;

    const files = fs.readdirSync(folder).filter((f) => f.endsWith('.js'));
    for (const file of files) {
      try {
        const filePath = path.join(folder, file);
        const fileUrl = new URL(`file://${filePath.replace(/\\/g, '/')}`).href;
        await import(fileUrl);
        log.success(`Handler loaded: ${file}`);
        count++;
      } catch (e) {
        log.error(`Gagal load handler ${file}: ${e?.message || e}`);
      }
    }
  }

  if (count === 0) log.warn('Tidak ada handler tambahan yang di-load.');
  log.divider();
}

// ============================================================
// 🔌 PLUGIN LOADER (Scan folder plugins/)
// ============================================================
export const plugins = new Map();

function pathToFileUrl(p) {
  const u = new URL('file://');
  u.pathname = p.replace(/\\/g, '/').replace(/^\/?/, '/');
  return u.href;
}

function validateAndRegister(mod, file) {
  const required = ['cmd', 'only_owner', 'only_premium', 'token_usage'];
  const missing = required.filter((k) => mod[k] === undefined);
  if (missing.length) {
    log.warn(`SKIP ${path.basename(file)} - kurang: ${missing.join(', ')}`);
    return;
  }

  if (typeof mod.default !== 'function') {
    log.warn(`SKIP ${path.basename(file)} - tidak ada export default handler`);
    return;
  }

  const cmds = Array.isArray(mod.cmd) ? mod.cmd : [mod.cmd];
  const registered = [];

  for (const c of cmds) {
    const key = String(c).toLowerCase();
    if (plugins.has(key)) {
      log.warn(`SKIP ${key} sudah ada (${path.basename(file)})`);
      continue;
    }
    plugins.set(key, {
      cmd: key,
      handler: mod.default,
      only_owner: !!mod.only_owner,
      only_premium: !!mod.only_premium,
      token_usage: Number(mod.token_usage) || 0,
      file: path.basename(file),
    });
    registered.push(key);
  }
  
  if (registered.length > 0) {
    log.success(`LOAD ${path.basename(file)} → ${registered.map(r => chalk.cyan(PREFIX + r)).join(', ')}`);
  }
}

export async function scanPlugins() {
  const dir = path.join(process.cwd(), 'plugins');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const files = [];
  function walk(d) {
    for (const entry of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, entry.name);
      if (entry.isDirectory()) walk(p);
      else if (entry.isFile() && entry.name.endsWith('.js')) files.push(p);
    }
  }
  walk(dir);

  for (const file of files) {
    try {
      const mod = await import(pathToFileUrl(file));
      validateAndRegister(mod, file);
    } catch (e) {
      log.error(`Plugin gagal load ${file}: ${e?.message || e}`);
    }
  }
}

// ============================================================
// 🚀 GRACEFUL SHUTDOWN
// ============================================================
let shuttingDown = false;
export async function gracefulShutdown(disconnectFn, signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(chalk.yellow(`\n⚠️ ${signal} diterima. Menutup semua sesi...`));
  try {
    await disconnectFn();
  } catch (e) {
    log.error(`Error shutdown: ${e?.message || e}`);
  }
  log.success(`Semua sesi ditutup. Bye. 👋`);
  process.exit(0);
}