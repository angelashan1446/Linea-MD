// libx/engine/end-points/fakeffgirl.js
export default async function fakeffgirlEndpoint(params, fetchWithRotate) {
    if (!params.username) throw new Error('Parameter "username" wajib diisi');
    
    const res = await fetchWithRotate('/v1/fakeffgirl', 'POST', { username: params.username });
    if (!res.success) throw new Error(res.message);
    
    return { 
        url: res.data.url, 
        username: res.data.username,
        expires_in: res.data.expires_in,
        remaining_token: res.token?.remaining 
    };
}