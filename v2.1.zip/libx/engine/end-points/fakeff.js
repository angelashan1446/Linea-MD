export default async function fakeffEndpoint(params, fetchWithRotate) {
    if (!params.name) throw new Error('Parameter "name" wajib diisi');
    if (params.name.length > 20) throw new Error('Nama maksimal 20 karakter');
    
    const res = await fetchWithRotate('/v1/fakeff', 'POST', { name: params.name });
    if (!res.success) throw new Error(res.message);
    
    return {
        url: res.data.url,
        format: res.data.format,
        name: res.data.name,
        expired_at: res.data.expired_at,
        expires_in: res.data.expires_in,
        remaining_token: res.token?.remaining,
    };
}