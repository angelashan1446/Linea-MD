// libx/engine/end-points/deepseek.js
export default async function deepseekEndpoint(params, fetchWithRotate) {
    if (!params.text) throw new Error('Parameter "text" wajib diisi');
    
    const res = await fetchWithRotate('/v1/deepseek', 'POST', { text: params.text });
    if (!res.success) throw new Error(res.message);
    
    return { 
        response: res.data.response, 
        model: res.data.model,
        remaining_token: res.token?.remaining 
    };
}