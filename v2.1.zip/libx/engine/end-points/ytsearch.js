export default async function ytsearchEndpoint(params, fetchWithRotate) {
    if (!params.q) throw new Error('Parameter "q" wajib diisi');
    const res = await fetchWithRotate('/v1/ytsearch', 'POST', { query: params.q });
    if (!res.success) throw new Error(res.message);
    return { results: res.data.results, remaining_token: res.token?.remaining };
}