// libx/engine/end-points/hdimage.js
export default async function hdimageEndpoint(params, fetchWithRotate) {
    if (!params.url) throw new Error('Parameter "url" (link gambar) wajib diisi');
    
    const res = await fetchWithRotate('/v1/hdimage', 'POST', { url: params.url });
    if (!res.success) throw new Error(res.message);
    
    return { 
        url: res.data.url, 
        original_url: res.data.original_url,
        expires_in: res.data.expires_in,
        remaining_token: res.token?.remaining 
    };
}