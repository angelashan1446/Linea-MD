export default async function tiktokEndpoint(params, fetchWithRotate) {
    if (!params.url && !params.query) throw new Error('Isi "url" atau "query"');
    const res = await fetchWithRotate('/v1/tiktok', 'POST', { url: params.url, query: params.query });
    if (!res.success) throw new Error(res.message);
    return { 
        title: res.data.title, 
        cover: res.data.cover, 
        video: res.data.video_no_watermark, 
        remaining_token: res.token?.remaining 
    };
}