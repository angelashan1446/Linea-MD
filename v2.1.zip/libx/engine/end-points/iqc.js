export default async function iqcEndpoint(params, fetchWithRotate) {
    if (!params.text) throw new Error('Parameter "text" wajib diisi');
    const res = await fetchWithRotate('/v1/iqc', 'POST', { text: params.text });
    if (!res.success) throw new Error(res.message);
    return { url: res.data.url, text: params.text, remaining_token: res.token?.remaining };
}