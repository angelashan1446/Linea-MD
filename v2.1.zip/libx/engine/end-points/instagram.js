export default async function instagramEndpoint(params, fetchWithRotate) {
    if (!params.url) throw new Error('Parameter "url" wajib diisi');
    const res = await fetchWithRotate('/v1/instagram', 'POST', { url: params.url });
    if (!res.success) throw new Error(res.message);
    return {
        creator: res.data.creator,
        type: res.data.type,
        videos: res.data.videos,
        images: res.data.images,
        thumb: res.data.thumb,
        remaining_token: res.token?.remaining,
    };
}