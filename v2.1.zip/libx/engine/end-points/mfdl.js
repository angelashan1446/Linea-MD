export default async function mfdlEndpoint(params, fetchWithRotate) {
    if (!params.url) throw new Error('Parameter "url" wajib diisi');
    const res = await fetchWithRotate('/v1/mfdl', 'POST', { url: params.url });
    if (!res.success) throw new Error(res.message);
    return { 
        link: res.data.link, 
        name: res.data.name, 
        size: res.data.size, 
        remaining_token: res.token?.remaining 
    };
}