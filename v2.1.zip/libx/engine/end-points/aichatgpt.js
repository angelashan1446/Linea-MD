// libx/engine/end-points/aichatgpt.js
export default async function aichatgptEndpoint(params, fetchWithRotate) {
    if (!params.text) throw new Error('Parameter "text" wajib diisi');
    
    const res = await fetchWithRotate('/v1/aichatgpt', 'POST', { text: params.text });
    if (!res.success) throw new Error(res.message);
    
    return { 
        response: res.data.response, 
        model: res.data.model,
        question: res.data.question,
        remaining_token: res.token?.remaining 
    };
}