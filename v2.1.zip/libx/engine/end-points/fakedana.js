export default async function fakedanaEndpoint(params, fetchWithRotate) {
    if (!params.amount) throw new Error('Parameter "amount" wajib diisi');
    const res = await fetchWithRotate('/v1/fakedana', 'POST', { amount: params.amount });
    if (!res.success) throw new Error(res.message);
    return { url: res.data.url, amount: params.amount, remaining_token: res.token?.remaining };
}