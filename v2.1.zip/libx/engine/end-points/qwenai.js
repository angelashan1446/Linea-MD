// libx/engine/end-points/qwenai.js
export default async function qwenaiEndpoint(params, fetchWithRotate) {
    if (!params.text) throw new Error('Parameter "text" wajib diisi');
    
    const res = await fetchWithRotate('/v1/qwenai', 'POST', { text: params.text });
    if (!res.success) throw new Error(res.message);
    
    return { 
        response: res.data.response, 
        model: res.data.model,
        remaining_token: res.token?.remaining 
    };
}