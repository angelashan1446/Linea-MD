export default async function ytmp3Endpoint(params, fetchWithRotate) {
    if (!params.url) throw new Error('Parameter "url" wajib diisi');
    const res = await fetchWithRotate('/v1/ytmp3', 'POST', { url: params.url });
    if (!res.success) throw new Error(res.message);
    return { url: res.data.url, title: res.data.title, remaining_token: res.token?.remaining };
}