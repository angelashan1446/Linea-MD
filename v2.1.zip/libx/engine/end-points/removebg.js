export default async function removebgEndpoint(params, fetchWithRotate) {
    if (!params.url) throw new Error('Parameter "url" wajib diisi');
    const res = await fetchWithRotate('/v1/removebg', 'POST', { url: params.url });
    if (!res.success) throw new Error(res.message);
    return { url: res.data.url, remaining_token: res.token?.remaining };
}