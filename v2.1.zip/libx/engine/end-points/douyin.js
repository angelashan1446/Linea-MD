export default async function douyinEndpoint(params, fetchWithRotate) {
    if (!params.url) throw new Error('Parameter "url" wajib diisi');
    const res = await fetchWithRotate('/v1/douyin', 'POST', { url: params.url });
    if (!res.success) throw new Error(res.message);
    return {
        title: res.data.title,
        platform: res.data.platform,
        thumbnail: res.data.thumbnail,
        video: res.data.video,
        audio: res.data.audio,
        remaining_token: res.token?.remaining,
    };
}