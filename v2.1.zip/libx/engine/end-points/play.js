export default async function playEndpoint(params, fetchWithRotate) {
    if (!params.q) throw new Error('Parameter "q" wajib diisi');
    const res = await fetchWithRotate(`/v1/play?q=${encodeURIComponent(params.q)}`, 'GET');
    if (!res.success) throw new Error(res.message);
    return { url: res.data.url, title: res.data.video.title, thumb: res.data.video.thumbnail, remaining_token: res.token?.remaining };
}