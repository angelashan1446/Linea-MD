export default async function pinEndpoint(params, fetchWithRotate) {
    if (!params.query) throw new Error('Parameter "query" wajib diisi');
    const body = { query: params.query };
    if (params.limit) body.limit = params.limit;
    
    const res = await fetchWithRotate('/v1/pin', 'POST', body);
    if (!res.success) throw new Error(res.message);
    
    return {
        query: res.data.query,
        total: res.data.total,
        results: res.data.results,
        remaining_token: res.token?.remaining,
    };
}