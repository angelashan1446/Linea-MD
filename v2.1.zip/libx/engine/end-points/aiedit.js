// libx/engine/end-points/aiedit.js
export default async function aieditEndpoint(params, fetchWithRotate) {
    if (!params.image) throw new Error('Parameter "image" (link gambar) wajib diisi');
    
    const res = await fetchWithRotate('/v1/aiedit', 'POST', { image: params.image });
    if (!res.success) throw new Error(res.message);
    
    return { 
        url: res.data.url, 
        original_image: res.data.original_image,
        expires_in: res.data.expires_in,
        remaining_token: res.token?.remaining 
    };
}