// libx/engine/end-points/fakeffduo.js
export default async function fakeffduoEndpoint(params, fetchWithRotate) {
    if (!params.name1 || !params.name2) throw new Error('Parameter "name1" dan "name2" wajib diisi');
    
    const res = await fetchWithRotate('/v1/fakeffduo', 'POST', { 
        name1: params.name1, 
        name2: params.name2 
    });
    
    if (!res.success) throw new Error(res.message);
    
    return { 
        url: res.data.url, 
        name1: res.data.name1,
        name2: res.data.name2,
        expires_in: res.data.expires_in,
        remaining_token: res.token?.remaining 
    };
}