// libx/engine/index.js
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import config from '../../config.js';
import axios from 'axios';
import { Uploader } from './libs/uploader.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ENDPOINTS_DIR = path.join(__dirname, 'end-points');
const BASE_URL = 'https://linea.zone.id';

// ==========================================
// CACHE ENDPOINTS (Hasil Scan)
// ==========================================
let endpoints = {};

export async function loadEndpoints() {
    endpoints = {};
    if (!fs.existsSync(ENDPOINTS_DIR)) fs.mkdirSync(ENDPOINTS_DIR, { recursive: true });

    const files = fs.readdirSync(ENDPOINTS_DIR).filter(f => f.endsWith('.js'));

    console.log(`[Engine] 🔍 Scanning ${files.length} endpoint...`);

    for (const file of files) {
        const name = file.replace('.js', '');
        const fileUrl = pathToFileURL(path.join(ENDPOINTS_DIR, file)).href;
        
        try {
            const mod = await import(`${fileUrl}?update=${Date.now()}`);
            if (typeof mod.default !== 'function') {
                console.warn(`[Engine] ⚠️ Skip ${file}: tidak export default function`);
                continue;
            }
            endpoints[name] = mod.default;
            console.log(`[Engine] ✅ Loaded: /${name}`);
        } catch (err) {
            console.error(`[Engine] ❌ Gagal load ${file}:`, err.message);
        }
    }
    return endpoints;
}

// ==========================================
// CORE REQUEST + AUTO ROTATE TOKEN
// ==========================================
let currentTokenIndex = 0;

async function _fetchWithRotate(endpoint, method = 'GET', body = null) {
    if (!config.api_tokens || config.api_tokens.length === 0) {
        throw new Error('Token API belum diisi di config.js');
    }

    for (let i = 0; i < config.api_tokens.length; i++) {
        const token = config.api_tokens[currentTokenIndex];
        
        try {
            const ping = await axios.get(`${BASE_URL}/v1/ping`, { headers: { 'X-API-Key': token } });
            if (!ping.data.success || !ping.data.data.api_key.valid) {
                throw new Error('Token invalid');
            }

            const res = await axios({
                method,
                url: `${BASE_URL}${endpoint}`,
                headers: { 
                    'X-API-Key': token,
                    ...(body ? { 'Content-Type': 'application/json' } : {})
                },
                data: body
            });

            return res.data;

        } catch (err) {
            console.warn(`[Engine] ⚠️ Token index ${currentTokenIndex} gagal. Rotasi...`);
            currentTokenIndex = (currentTokenIndex + 1) % config.api_tokens.length;
            
            if (i === config.api_tokens.length - 1) {
                throw new Error(err.response?.data?.message || err.message || 'Semua token gagal');
            }
        }
    }
}

// ==========================================
// PUBLIC API
// ==========================================
export const engine = {
    // ==========================================
    // ✅ INFO DEVELOPER & KONTAK
    // ==========================================
    dev: 'Angela Shan',
    contact: 'https://t.me/angelashan14',
    
    // ✅ Channel WhatsApp
    channel: 'https://whatsapp.com/channel/0029Vb9K8eRHAdNa40CqGm21',

    // ==========================================
    // ✅ ASET MEDIA DEFAULT
    // ==========================================
    mainImage: 'https://linea.zone.id/cdn/jpg/CK5pJ3fsG9Vd.jpg',
    mainAudio: 'https://linea.zone.id/cdn/m4a/aF5Hk96wpEsd.m4a',

    // ==========================================
    // RUN ENDPOINT
    // ==========================================
    run: async (endpointName, params = {}) => {
        const fn = endpoints[endpointName];
        if (!fn) throw new Error(`Endpoint "${endpointName}" tidak ditemukan`);
        return await fn(params, _fetchWithRotate);
    },

    // ==========================================
    // UPLOAD HELPER
    // ==========================================
    upload: {
        fromUrl: async (url, format) => {
            const token = config.api_tokens[currentTokenIndex];
            const up = new Uploader(BASE_URL, token);
            return up.fromUrl(url, format);
        },
        fromBuffer: async (buffer, format) => {
            const token = config.api_tokens[currentTokenIndex];
            const up = new Uploader(BASE_URL, token);
            return up.fromBuffer(buffer, format);
        },
        fromFile: async (path, format) => {
            const token = config.api_tokens[currentTokenIndex];
            const up = new Uploader(BASE_URL, token);
            return up.fromFile(path, format);
        }
    }
};

await loadEndpoints();

export default engine;