// libx/box.js
// Storage "box" per user.
// Struktur:
//   storage/box/<nomor>/box.json   → index item (id, alias, type, mediaFilename, mediaMeta, ...)
//   storage/box/<nomor>/<id>.<ext> → file media

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// ============================================================
// KONFIG
// ============================================================
const ROOT = process.cwd();
const STORAGE_DIR = path.join(ROOT, 'storage', 'box');

const MAX_ITEMS = 30;
const MAX_MEDIA_MB = 10;
const ALIAS_MAX = 30;
const ID_LENGTH = 6;

// ============================================================
// HELPER: NORMALISASI USER
// ============================================================
function normalizeUser(userId) {
  if (!userId) return '';
  return String(userId).replace(/\D/g, '').split(':')[0];
}

function ensureUserDir(userId) {
  const norm = normalizeUser(userId);
  if (!norm) throw new Error('userId tidak valid');

  const dir = path.join(STORAGE_DIR, norm);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const boxFile = path.join(dir, 'box.json');
  if (!fs.existsSync(boxFile)) {
    fs.writeFileSync(boxFile, JSON.stringify({ items: [] }, null, 2));
  }

  return { dir, boxFile, norm };
}

function readBoxIndex(userId) {
  const { dir, boxFile } = ensureUserDir(userId);
  try {
    const raw = fs.readFileSync(boxFile, 'utf8');
    const data = JSON.parse(raw);
    return {
      items: Array.isArray(data.items) ? data.items : [],
      dir,
      boxFile,
    };
  } catch {
    return { items: [], dir, boxFile };
  }
}

function writeBoxIndex(userId, items) {
  const { boxFile } = ensureUserDir(userId);
  fs.writeFileSync(boxFile, JSON.stringify({ items }, null, 2));
}

// ============================================================
// HELPER: GENERATE ID
// ============================================================
function generateId() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let id = '';
  const bytes = crypto.randomBytes(ID_LENGTH);
  for (let i = 0; i < ID_LENGTH; i++) {
    id += chars[bytes[i] % chars.length];
  }
  return id;
}

function generateUniqueId(items) {
  for (let i = 0; i < 50; i++) {
    const id = generateId();
    if (!items.some((x) => x.id === id)) return id;
  }
  return crypto.randomBytes(4).toString('hex').slice(0, ID_LENGTH);
}

// ============================================================
// HELPER: MIMETYPE → EXT
// ============================================================
function mimetypeToExt(mimetype, fallback = 'bin') {
  if (!mimetype) return fallback;
  const m = String(mimetype).toLowerCase();

  if (m.includes('jpeg') || m.includes('jpg')) return 'jpg';
  if (m.includes('png')) return 'png';
  if (m.includes('webp')) return 'webp';
  if (m.includes('gif')) return 'gif';
  if (m.includes('mp4')) return 'mp4';
  if (m.includes('quicktime')) return 'mov';
  if (m.includes('webm')) return 'webm';
  if (m.includes('mp3')) return 'mp3';
  if (m.includes('m4a')) return 'm4a';
  if (m.includes('ogg')) return 'ogg';
  if (m.includes('opus')) return 'opus';
  if (m.includes('wav')) return 'wav';
  if (m.includes('pdf')) return 'pdf';
  if (m.includes('zip')) return 'zip';

  return fallback;
}

// ============================================================
// HELPER: DETEKSI TIPE MEDIA
// ============================================================
function detectMediaType(mimetype) {
  if (!mimetype) return 'text';
  const m = String(mimetype).toLowerCase();
  if (m.startsWith('image/')) return 'image';
  if (m.startsWith('video/')) return 'video';
  if (m.startsWith('audio/')) return 'audio';
  return 'document';
}

// ============================================================
// ✅ HELPER BARU: REBUILD MEDIA OPTS
// ============================================================
/**
 * Rebuild opsi kirim media dari `mediaMeta` yang tersimpan,
 * supaya saat `get` benar-benar identik dengan saat `save`:
 *   - Sticker tetap sticker
 *   - Voice note tetap PTT
 *   - View once → dikirim biasa (WA gak bisa re-view-once)
 *   - Caption & dimensi sama
 *
 * @param {object} item - item dari box
 * @param {Buffer} buffer - buffer media
 * @returns {object} opts untuk sendMedia
 */
function rebuildMediaOpts(item, buffer) {
  const meta = item.mediaMeta || {};
  const opts = {
    buffer,
    mimetype: item.mimetype || 'application/octet-stream',
    fileName: item.originalName || item.mediaFilename,
    caption: item.text || '',
  };

  // Sticker
  if (meta.isSticker) {
    opts.isSticker = true;
    // Sticker WA butuh webp
    opts.mimetype = 'image/webp';
  }

  // Voice note
  if (meta.ptt) {
    opts.ptt = true;
  }

  // Audio biasa (bukan ptt)
  if (item.type === 'audio' && !meta.ptt) {
    opts.audioAsDocument = false;
  }

  // Video: bawa duration & dimensi
  if (item.type === 'video') {
    if (meta.width) opts.width = meta.width;
    if (meta.height) opts.height = meta.height;
    if (meta.seconds) opts.seconds = meta.seconds;
  }

  // Image: bawa dimensi
  if (item.type === 'image' && !meta.isSticker) {
    if (meta.width) opts.width = meta.width;
    if (meta.height) opts.height = meta.height;
  }

  // Gif play (video/gif)
  if (meta.gifPlayback) {
    opts.gifPlayback = true;
  }

  return opts;
}

// ============================================================
// API: SAVE TEXT
// ============================================================
function saveText(userId, text, alias = null) {
  if (!text || !String(text).trim()) {
    return { ok: false, reason: 'Teks kosong' };
  }

  const { items, dir } = readBoxIndex(userId);
  if (items.length >= MAX_ITEMS) {
    return { ok: false, reason: `Box penuh (maks ${MAX_ITEMS} item)` };
  }

  const trimmedAlias = alias ? String(alias).trim().slice(0, ALIAS_MAX) : null;

  if (trimmedAlias && items.some((x) => x.alias && x.alias.toLowerCase() === trimmedAlias.toLowerCase())) {
    return { ok: false, reason: `Alias "${trimmedAlias}" sudah dipakai` };
  }

  const id = generateUniqueId(items);
  const item = {
    id,
    alias: trimmedAlias,
    type: 'text',
    text: String(text).slice(0, 10000),
    mediaFilename: null,
    mimetype: null,
    mediaMeta: null,
    createdAt: new Date().toISOString(),
  };

  items.push(item);
  writeBoxIndex(userId, items);

  return { ok: true, item };
}

// ============================================================
// API: SAVE MEDIA
// ============================================================
/**
 * Simpan media ke box.
 * @param {Buffer} buffer
 * @param {object} opts
 *   - mimetype, fileName, caption, alias
 *   - mediaMeta: metadata asli dari WA message (imageMessage/videoMessage/...)
 */
function saveMedia(userId, buffer, opts = {}) {
  if (!buffer || !Buffer.isBuffer(buffer) || buffer.length === 0) {
    return { ok: false, reason: 'Media kosong' };
  }

  const sizeMb = buffer.length / 1024 / 1024;
  if (sizeMb > MAX_MEDIA_MB) {
    return { ok: false, reason: `Media terlalu besar (${sizeMb.toFixed(1)} MB, maks ${MAX_MEDIA_MB} MB)` };
  }

  const { items, dir } = readBoxIndex(userId);
  if (items.length >= MAX_ITEMS) {
    return { ok: false, reason: `Box penuh (maks ${MAX_ITEMS} item)` };
  }

  const trimmedAlias = opts.alias ? String(opts.alias).trim().slice(0, ALIAS_MAX) : null;

  if (trimmedAlias && items.some((x) => x.alias && x.alias.toLowerCase() === trimmedAlias.toLowerCase())) {
    return { ok: false, reason: `Alias "${trimmedAlias}" sudah dipakai` };
  }

  const id = generateUniqueId(items);
  const mimetype = opts.mimetype || 'application/octet-stream';
  const ext = mimetypeToExt(mimetype);
  const mediaFilename = `${id}.${ext}`;
  const mediaPath = path.join(dir, mediaFilename);

  try {
    fs.writeFileSync(mediaPath, buffer);
  } catch (err) {
    return { ok: false, reason: `Gagal simpan media: ${err.message}` };
  }

  const type = detectMediaType(mimetype);

  const item = {
    id,
    alias: trimmedAlias,
    type,
    text: opts.caption ? String(opts.caption).slice(0, 2000) : null,
    mediaFilename,
    mimetype,
    originalName: opts.fileName || null,
    size: buffer.length,
    mediaMeta: opts.mediaMeta || null, // ✅ simpan metadata asli
    createdAt: new Date().toISOString(),
  };

  items.push(item);
  writeBoxIndex(userId, items);

  return { ok: true, item };
}

// ============================================================
// API: LIST
// ============================================================
function listItems(userId) {
  const { items } = readBoxIndex(userId);
  return [...items].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

// ============================================================
// API: GET
// ============================================================
function getItem(userId, key) {
  if (!key) return { ok: false, reason: 'Key kosong' };

  const { items, dir } = readBoxIndex(userId);
  const strKey = String(key).trim();

  let item = items.find(
    (x) => x.id === strKey || (x.alias && x.alias.toLowerCase() === strKey.toLowerCase())
  );

  if (!item && /^\d+$/.test(strKey)) {
    const idx = parseInt(strKey, 10) - 1;
    const sorted = [...items].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    item = sorted[idx] || null;
  }

  if (!item) return { ok: false, reason: 'Item tidak ditemukan' };

  let buffer = null;
  if (item.mediaFilename) {
    const mediaPath = path.join(dir, item.mediaFilename);
    if (fs.existsSync(mediaPath)) {
      try {
        buffer = fs.readFileSync(mediaPath);
      } catch {}
    }
  }

  return { ok: true, item, buffer };
}

// ============================================================
// API: DELETE
// ============================================================
function deleteItem(userId, key) {
  const { items, dir } = readBoxIndex(userId);
  const strKey = String(key).trim();

  const idx = items.findIndex(
    (x) => x.id === strKey || (x.alias && x.alias.toLowerCase() === strKey.toLowerCase())
  );
  if (idx === -1) return { ok: false, reason: 'Item tidak ditemukan' };

  const item = items[idx];

  if (item.mediaFilename) {
    try {
      const mediaPath = path.join(dir, item.mediaFilename);
      if (fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath);
    } catch {}
  }

  items.splice(idx, 1);
  writeBoxIndex(userId, items);

  return { ok: true, item };
}

// ============================================================
// API: CLEAR
// ============================================================
function clearBox(userId) {
  const { items, dir } = readBoxIndex(userId);
  const count = items.length;

  for (const item of items) {
    if (item.mediaFilename) {
      try {
        const mediaPath = path.join(dir, item.mediaFilename);
        if (fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath);
      } catch {}
    }
  }

  writeBoxIndex(userId, []);
  return { ok: true, count };
}

// ============================================================
// API: STATS
// ============================================================
function getBoxStats(userId) {
  const { items } = readBoxIndex(userId);
  const total = items.length;
  const maxItems = MAX_ITEMS;
  const free = maxItems - total;

  let totalSize = 0;
  for (const item of items) {
    if (item.size) totalSize += item.size;
  }

  return { total, max: maxItems, free, totalSize, totalSizeMb: (totalSize / 1024 / 1024).toFixed(2) };
}

// ============================================================
// EXPORT
// ============================================================
export {
  saveText,
  saveMedia,
  listItems,
  getItem,
  deleteItem,
  clearBox,
  getBoxStats,
  rebuildMediaOpts, // ✅ export helper baru

  MAX_ITEMS,
  MAX_MEDIA_MB,
  ALIAS_MAX,
  STORAGE_DIR,
};