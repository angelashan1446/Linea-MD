// libx/filters.js
// Storage "filter" per grup.
// Struktur:
//   storage/filters/<groupId>/filters.json       → index item (id, alias, type, mediaFilename, mediaMeta, ...)
//   storage/filters/<groupId>/<id>.<ext>         → file media

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// ============================================================
// KONFIG
// ============================================================
const ROOT = process.cwd();
const STORAGE_DIR = path.join(ROOT, 'storage', 'filters');

const MAX_ITEMS = 30;         // maks item per grup
const MAX_MEDIA_MB = 30;
const ALIAS_MAX = 30;
const ID_LENGTH = 6;

// ============================================================
// HELPER: NORMALISASI GRUP
// ============================================================
function normalizeGroup(groupId) {
  if (!groupId) return '';
  return String(groupId).replace(/\D/g, '').split('@')[0];
}

function ensureGroupDir(groupId) {
  const norm = normalizeGroup(groupId);
  if (!norm) throw new Error('groupId tidak valid');

  const dir = path.join(STORAGE_DIR, norm);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const filtersFile = path.join(dir, 'filters.json');
  if (!fs.existsSync(filtersFile)) {
    fs.writeFileSync(filtersFile, JSON.stringify({ items: [] }, null, 2));
  }

  return { dir, filtersFile, norm };
}

// ============================================================
// READ / WRITE INDEX
// ============================================================
function readIndex(groupId) {
  const { dir, filtersFile } = ensureGroupDir(groupId);
  try {
    const raw = fs.readFileSync(filtersFile, 'utf8');
    const data = JSON.parse(raw);
    return {
      items: Array.isArray(data.items) ? data.items : [],
      dir,
      filtersFile,
    };
  } catch {
    return { items: [], dir, filtersFile };
  }
}

function writeIndex(groupId, items) {
  const { filtersFile } = ensureGroupDir(groupId);
  fs.writeFileSync(filtersFile, JSON.stringify({ items }, null, 2));
}

// ============================================================
// ID GENERATOR
// ============================================================
function generateId() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let id = '';
  const bytes = crypto.randomBytes(ID_LENGTH);
  for (let i = 0; i < ID_LENGTH; i++) {
    id += chars[bytes[i] % chars.length];
  }
  return id;
}

function generateUniqueId(items) {
  for (let i = 0; i < 50; i++) {
    const id = generateId();
    if (!items.some((x) => x.id === id)) return id;
  }
  return crypto.randomBytes(4).toString('hex').slice(0, ID_LENGTH);
}

// ============================================================
// MIMETYPE → EXT
// ============================================================
function mimetypeToExt(mimetype, fallback = 'bin') {
  if (!mimetype) return fallback;
  const m = String(mimetype).toLowerCase();

  if (m.includes('jpeg') || m.includes('jpg')) return 'jpg';
  if (m.includes('png')) return 'png';
  if (m.includes('webp')) return 'webp';
  if (m.includes('gif')) return 'gif';
  if (m.includes('mp4')) return 'mp4';
  if (m.includes('quicktime')) return 'mov';
  if (m.includes('webm')) return 'webm';
  if (m.includes('mp3')) return 'mp3';
  if (m.includes('m4a')) return 'm4a';
  if (m.includes('ogg')) return 'ogg';
  if (m.includes('opus')) return 'opus';
  if (m.includes('wav')) return 'wav';
  if (m.includes('pdf')) return 'pdf';
  if (m.includes('zip')) return 'zip';

  return fallback;
}

function detectMediaType(mimetype) {
  if (!mimetype) return 'text';
  const m = String(mimetype).toLowerCase();
  if (m.startsWith('image/')) return 'image';
  if (m.startsWith('video/')) return 'video';
  if (m.startsWith('audio/')) return 'audio';
  return 'document';
}

// ============================================================
// REBUILD MEDIA OPTS (persis seperti aslinya)
// ============================================================
function rebuildMediaOpts(item, buffer) {
  const meta = item.mediaMeta || {};
  const opts = {
    buffer,
    mimetype: item.mimetype || 'application/octet-stream',
    fileName: item.originalName || item.mediaFilename,
    caption: item.text || '',
  };

  if (meta.isSticker) {
    opts.isSticker = true;
    opts.mimetype = 'image/webp';
  }

  if (meta.ptt) opts.ptt = true;

  if (item.type === 'video') {
    if (meta.width) opts.width = meta.width;
    if (meta.height) opts.height = meta.height;
    if (meta.seconds) opts.seconds = meta.seconds;
  }

  if (item.type === 'image' && !meta.isSticker) {
    if (meta.width) opts.width = meta.width;
    if (meta.height) opts.height = meta.height;
  }

  if (meta.gifPlayback) opts.gifPlayback = true;

  return opts;
}

// ============================================================
// SAVE TEXT
// ============================================================
function saveText(groupId, text, alias = null, creator = null) {
  if (!text || !String(text).trim()) {
    return { ok: false, reason: 'Teks kosong' };
  }

  const { items } = readIndex(groupId);
  if (items.length >= MAX_ITEMS) {
    return { ok: false, reason: `Filter penuh (maks ${MAX_ITEMS} item)` };
  }

  const trimmedAlias = alias ? String(alias).trim().slice(0, ALIAS_MAX) : null;

  if (trimmedAlias && items.some((x) => x.alias && x.alias.toLowerCase() === trimmedAlias.toLowerCase())) {
    return { ok: false, reason: `Alias "${trimmedAlias}" sudah dipakai di grup ini` };
  }

  const id = generateUniqueId(items);
  const item = {
    id,
    alias: trimmedAlias,
    type: 'text',
    text: String(text).slice(0, 10000),
    mediaFilename: null,
    mimetype: null,
    mediaMeta: null,
    creator: creator || null,
    createdAt: new Date().toISOString(),
  };

  items.push(item);
  writeIndex(groupId, items);

  return { ok: true, item };
}

// ============================================================
// SAVE MEDIA
// ============================================================
function saveMedia(groupId, buffer, opts = {}) {
  if (!buffer || !Buffer.isBuffer(buffer) || buffer.length === 0) {
    return { ok: false, reason: 'Media kosong' };
  }

  const sizeMb = buffer.length / 1024 / 1024;
  if (sizeMb > MAX_MEDIA_MB) {
    return { ok: false, reason: `Media terlalu besar (${sizeMb.toFixed(1)} MB, maks ${MAX_MEDIA_MB} MB)` };
  }

  const { items, dir } = readIndex(groupId);
  if (items.length >= MAX_ITEMS) {
    return { ok: false, reason: `Filter penuh (maks ${MAX_ITEMS} item)` };
  }

  const trimmedAlias = opts.alias ? String(opts.alias).trim().slice(0, ALIAS_MAX) : null;

  if (trimmedAlias && items.some((x) => x.alias && x.alias.toLowerCase() === trimmedAlias.toLowerCase())) {
    return { ok: false, reason: `Alias "${trimmedAlias}" sudah dipakai di grup ini` };
  }

  const id = generateUniqueId(items);
  const mimetype = opts.mimetype || 'application/octet-stream';
  const ext = mimetypeToExt(mimetype);
  const mediaFilename = `${id}.${ext}`;
  const mediaPath = path.join(dir, mediaFilename);

  try {
    fs.writeFileSync(mediaPath, buffer);
  } catch (err) {
    return { ok: false, reason: `Gagal simpan media: ${err.message}` };
  }

  const type = detectMediaType(mimetype);

  const item = {
    id,
    alias: trimmedAlias,
    type,
    text: opts.caption ? String(opts.caption).slice(0, 2000) : null,
    mediaFilename,
    mimetype,
    originalName: opts.fileName || null,
    size: buffer.length,
    mediaMeta: opts.mediaMeta || null,
    creator: opts.creator || null,
    createdAt: new Date().toISOString(),
  };

  items.push(item);
  writeIndex(groupId, items);

  return { ok: true, item };
}

// ============================================================
// LIST
// ============================================================
function listItems(groupId) {
  const { items } = readIndex(groupId);
  return [...items].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

// ============================================================
// GET
// ============================================================
function getItem(groupId, key) {
  if (!key) return { ok: false, reason: 'Key kosong' };

  const { items, dir } = readIndex(groupId);
  const strKey = String(key).trim();

  let item = items.find(
    (x) => x.id === strKey || (x.alias && x.alias.toLowerCase() === strKey.toLowerCase())
  );

  if (!item && /^\d+$/.test(strKey)) {
    const idx = parseInt(strKey, 10) - 1;
    const sorted = [...items].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    item = sorted[idx] || null;
  }

  if (!item) return { ok: false, reason: 'Item tidak ditemukan' };

  let buffer = null;
  if (item.mediaFilename) {
    const mediaPath = path.join(dir, item.mediaFilename);
    if (fs.existsSync(mediaPath)) {
      try {
        buffer = fs.readFileSync(mediaPath);
      } catch {}
    }
  }

  return { ok: true, item, buffer };
}

// ============================================================
// DELETE
// ============================================================
function deleteItem(groupId, key) {
  const { items, dir } = readIndex(groupId);
  const strKey = String(key).trim();

  const idx = items.findIndex(
    (x) => x.id === strKey || (x.alias && x.alias.toLowerCase() === strKey.toLowerCase())
  );
  if (idx === -1) return { ok: false, reason: 'Item tidak ditemukan' };

  const item = items[idx];

  if (item.mediaFilename) {
    try {
      const mediaPath = path.join(dir, item.mediaFilename);
      if (fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath);
    } catch {}
  }

  items.splice(idx, 1);
  writeIndex(groupId, items);

  return { ok: true, item };
}

// ============================================================
// CLEAR
// ============================================================
function clearFilters(groupId) {
  const { items, dir } = readIndex(groupId);
  const count = items.length;

  for (const item of items) {
    if (item.mediaFilename) {
      try {
        const mediaPath = path.join(dir, item.mediaFilename);
        if (fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath);
      } catch {}
    }
  }

  writeIndex(groupId, []);
  return { ok: true, count };
}

// ============================================================
// STATS
// ============================================================
function getFilterStats(groupId) {
  const { items } = readIndex(groupId);
  const total = items.length;
  const maxItems = MAX_ITEMS;
  const free = maxItems - total;

  let totalSize = 0;
  for (const item of items) {
    if (item.size) totalSize += item.size;
  }

  return { total, max: maxItems, free, totalSize, totalSizeMb: (totalSize / 1024 / 1024).toFixed(2) };
}

// ============================================================
// EXPORT
// ============================================================
export {
  saveText,
  saveMedia,
  listItems,
  getItem,
  deleteItem,
  clearFilters,
  getFilterStats,
  rebuildMediaOpts,

  MAX_ITEMS,
  MAX_MEDIA_MB,
  ALIAS_MAX,
  STORAGE_DIR,
};