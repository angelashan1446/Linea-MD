// libx/additional.js
// Event Bus untuk fitur additional (welcome, left, promote, demote, dll).
// Multi-bahasa: pakai grup_lang (default 'uk').

import chalk from 'chalk';
import config from '../config.js';
import {
  isFeatureEnabled,
  getDisplayName,
  getBotService,
  getGroupLang,
} from './grup_db.js';
import { sendText } from './whatsapp/sendmsg.js';
import { isValidLang, DEFAULT_LANG } from './lang.js';

// ============================================================
// LOCK UNTUK CEGAH DOBEL DARI SESI LAIN
// ============================================================
const eventLocks = new Map();

function tryLockEvent(eventKey, folder) {
  if (!eventKey) return true;
  const lock = eventLocks.get(eventKey);
  const now = Date.now();

  if (lock && lock.folder !== folder && lock.releaseAt > now) {
    return false;
  }

  eventLocks.set(eventKey, {
    folder,
    releaseAt: now + 30000,
  });

  setTimeout(() => {
    const current = eventLocks.get(eventKey);
    if (current && current.folder === folder) {
      eventLocks.delete(eventKey);
    }
  }, 30000);

  return true;
}

// ============================================================
// KAMUS BAHASA
// ============================================================
const TEXT = {
  id: {
    welcome:
      '👋 Selamat datang *{name}* di *{group}*!\n\n' +
      'Semoga betah di sini ya! 🎉',
    left:
      '👋 Selamat jalan *{name}*! Semoga sukses selalu. 🌟',
  },
  ch: {
    welcome:
      '👋 欢迎 *{name}* 加入 *{group}*！\n\n' +
      '希望你在这里过得愉快！🎉',
    left:
      '👋 再见 *{name}*！祝你一切顺利。🌟',
  },
  uk: {
    welcome:
      '👋 Welcome *{name}* to *{group}*!\n\n' +
      'Enjoy your stay here! 🎉',
    left:
      '👋 Goodbye *{name}*! Wishing you all the best. 🌟',
  },
};

function T(lang, key, vars = {}) {
  const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
  let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
  for (const [k, v] of Object.entries(vars)) {
    str = str.replaceAll(`{${k}}`, String(v));
  }
  return str;
}

/**
 * Ambil bahasa grup (fallback 'uk').
 */
function groupLang(groupId) {
  try {
    const gl = getGroupLang(groupId);
    return isValidLang(gl) ? gl : 'uk';
  } catch {
    return 'uk';
  }
}

// ============================================================
// EMIT: PARTICIPANTS UPDATE
// ============================================================
/**
 * Dipanggil oleh connect.js setiap ada event group-participants.update.
 */
export async function emitParticipantsUpdate(sock, m, folder) {
  const { id: remoteJid, participants, action, author } = m;
  if (!remoteJid || !participants?.length) return;

  const groupId = remoteJid.split('@')[0];

  // Cek bot service
  const botService = getBotService(groupId);
  const myBotNumber = sock.user?.id?.split(':')[0]?.split('@')[0];

  if (botService !== 'dynamic' && botService !== myBotNumber) {
    if (config.mode === 'development') {
      console.log(chalk.gray(`[ADDITIONAL] Skip ${groupId} — grup milik bot +${botService}`));
    }
    return;
  }

  // Lock event
  const eventKey = `${groupId}:${action}:${[...participants].sort().join(',')}`;
  if (!tryLockEvent(eventKey, folder)) {
    if (config.mode === 'development') {
      console.log(chalk.gray(`[ADDITIONAL] Skip event ${action} di ${groupId} — di-lock sesi lain`));
    }
    return;
  }

  // 1. WELCOME
  if (action === 'add' && isFeatureEnabled(groupId, 'welcome')) {
    try {
      await handleWelcome(sock, remoteJid, groupId, participants);
    } catch (e) {
      console.log(chalk.red(`[ADDITIONAL] Welcome error: ${e.message}`));
    }
  }

  // 2. LEFT
  if (action === 'remove' && isFeatureEnabled(groupId, 'left')) {
    try {
      await handleLeft(sock, remoteJid, groupId, participants);
    } catch (e) {
      console.log(chalk.red(`[ADDITIONAL] Left error: ${e.message}`));
    }
  }

  // 3. FITUR BARU DI SINI
  // if (action === 'promote' && isFeatureEnabled(groupId, 'notif_promote')) {
  //   await handlePromote(sock, remoteJid, groupId, participants);
  // }
}

// ============================================================
// HELPER: nama tampilan peserta
// ============================================================
function getParticipantName(jid) {
  if (!jid) return 'Seseorang';
  return jid.split('@')[0];
}

// ============================================================
// HANDLER: WELCOME
// ============================================================
async function handleWelcome(sock, remoteJid, groupId, participants) {
  let groupName = 'Grup';
  try {
    const metadata = await sock.groupMetadata(remoteJid);
    groupName = metadata.subject || 'Grup';
  } catch (e) {
    console.log(chalk.yellow(`[WELCOME] Gagal ambil metadata: ${e.message}`));
  }

  const lang = groupLang(groupId);

  for (const jid of participants) {
    try {
      const nama = getParticipantName(jid);
      await sendText(
        sock,
        remoteJid,
        T(lang, 'welcome', { name: nama, group: groupName })
      );
    } catch (e) {
      console.log(chalk.red(`[WELCOME] Gagal kirim ke ${jid}: ${e.message}`));
    }
  }
}

// ============================================================
// HANDLER: LEFT
// ============================================================
async function handleLeft(sock, remoteJid, groupId, participants) {
  const lang = groupLang(groupId);

  for (const jid of participants) {
    try {
      const nama = getParticipantName(jid);
      await sendText(
        sock,
        remoteJid,
        T(lang, 'left', { name: nama })
      );
    } catch (e) {
      console.log(chalk.red(`[LEFT] Gagal kirim ke ${jid}: ${e.message}`));
    }
  }
}

// ============================================================
// HANDLER BARU (contoh)
// ============================================================
// async function handlePromote(sock, remoteJid, groupId, participants) {
//   const lang = groupLang(groupId);
//   for (const jid of participants) {
//     const nama = getParticipantName(jid);
//     await sendText(sock, remoteJid, T(lang, 'promote', { name: nama }));
//   }
// }