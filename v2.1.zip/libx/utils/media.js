// libx/utils/media.js
// Helper universal buat download media dari quoted message (termasuk View Once)

/**
 * Buka semua bungkus pesan (View Once, Ephemeral, Document Caption)
 * sampai dapet objek media aslinya.
 */
export function resolveMediaMessage(quotedMessage) {
    let content = quotedMessage;
    
    for (let i = 0; i < 5; i++) {
        const next =
            content?.ephemeralMessage?.message ||
            content?.viewOnceMessage?.message ||
            content?.viewOnceMessageV2?.message ||
            content?.viewOnceMessageV2Extension?.message ||
            content?.documentWithCaptionMessage?.message ||
            null;
        
        if (!next) break;
        content = next;
    }
    
    return content;
}

/**
 * Download media dari pesan yang di-reply (quoted), termasuk View Once.
 * @param {object} sock - Socket WA (Baileys/Zapo)
 * @param {object} msg - Objek pesan (messageInfo / ctx.msg)
 * @returns {Promise<{buffer: Buffer, type: string, mimetype: string, label: string} | null>}
 */
export async function downloadQuotedMedia(sock, msg) {
    const quotedInfo = msg.message?.extendedTextMessage?.contextInfo;
    if (!quotedInfo?.quotedMessage) return null;

    const innerContent = resolveMediaMessage(quotedInfo.quotedMessage);
    if (!innerContent) return null;

    const mediaTypes = [
        { key: 'imageMessage', label: 'Gambar' },
        { key: 'videoMessage', label: 'Video' },
        { key: 'audioMessage', label: 'Audio' },
        { key: 'stickerMessage', label: 'Sticker' },
        { key: 'documentMessage', label: 'Dokumen' },
    ];

    let mediaType = null;
    let mediaObject = null;
    let mediaLabel = '';

    for (const t of mediaTypes) {
        if (innerContent[t.key]) {
            mediaType = t.key;
            mediaObject = innerContent[t.key];
            mediaLabel = t.label;
            break;
        }
    }

    if (!mediaObject) return null;

    // Trik "fake message" biar Baileys/Zapo mau download
    const fakeMsg = {
        ...msg,
        message: { [mediaType]: mediaObject }
    };

    const buffer = await sock.downloadMediaMessage(fakeMsg);
    if (!buffer || buffer.length === 0) return null;

    return {
        buffer,
        type: mediaType,
        mimetype: mediaObject.mimetype || 'application/octet-stream',
        label: mediaLabel,
    };
}