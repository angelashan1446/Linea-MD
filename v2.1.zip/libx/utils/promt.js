// libx/utils/promt.js
// Kumpulan prompt preset buat AI edit gambar.
// Tinggal dipanggil via: getPrompt('figura') atau PROMPTS.figura

export const PROMPTS = {
    // ==========================================
    // 🎨 GAYA SENI / VISUAL
    // ==========================================
    figura: 'ubah gambar ini menjadi action figure / figur mainan dengan detail tinggi, pencahayaan studio, background blur, dan gaya fotografi produk',
    anime: 'ubah gambar ini menjadi gaya anime Jepang berkualitas tinggi, warna vibrant, detail tajam, gaya studio Ghibli',
    kartun: 'ubah gambar ini menjadi gaya kartun modern dengan warna cerah, garis tegas, dan ekspresi lucu',
    realis: 'ubah gambar ini menjadi foto realistis dengan detail tinggi, pencahayaan natural, dan tekstur kulit yang halus',
    '3d': 'ubah gambar ini menjadi rendering 3D berkualitas tinggi, gaya Pixar/Disney, pencahayaan dramatis, dan detail material realistis',
    '3dchibi': 'ubah gambar ini menjadi karakter 3D chibi lucu, proporsi kepala besar, mata besar, gaya cute dan menggemaskan',
    pixelart: 'ubah gambar ini menjadi pixel art retro 16-bit, gaya game klasik, warna terbatas, dan detail blok',
    cyberpunk: 'ubah gambar ini menjadi gaya cyberpunk futuristik dengan neon lights, warna ungu-biru, dan atmosfer sci-fi',
    vintage: 'ubah gambar ini menjadi gaya foto vintage tahun 80-an, warna pudar, grain film, dan nuansa nostalgia',
    watercolor: 'ubah gambar ini menjadi lukisan cat air dengan sapuan kuas lembut, warna pastel, dan gaya artistik',
    oilpainting: 'ubah gambar ini menjadi lukisan minyak klasik dengan tekstur kuas tebal dan warna mendalam',
    sketch: 'ubah gambar ini menjadi sketsa pensil hitam putih dengan garis halus dan shading detail',
    comic: 'ubah gambar ini menjadi gaya komik Amerika dengan garis tegas, warna bold, dan efek bayangan dramatis',
    korean: 'ubah gambar ini menjadi gaya foto ala Korea (K-beauty), cahaya soft, warna pastel, dan kulit glowing',

    // ==========================================
    // 👤 GENDER / USIA
    // ==========================================
    cowok: 'ubah gambar ini menjadi pria tampan, gaya kasual modern, ekspresi ramah, pencahayaan natural',
    cewek: 'ubah gambar ini menjadi wanita cantik, gaya elegan, senyum manis, pencahayaan soft',
    anak: 'ubah gambar ini menjadi anak kecil ceria, ekspresi lucu, gaya kartun colorful',
    tua: 'ubah gambar ini menjadi orang tua yang bijak, rambut beruban, ekspresi tenang, detail kerutan natural',
    balita: 'ubah gambar ini menjadi bayi balita yang menggemaskan, mata besar bulat, pipi tembem',

    // ==========================================
    // 🎭 PROFESI / KARAKTER
    // ==========================================
    chef: 'ubah gambar ini menjadi chef profesional dengan seragam putih, background dapur modern',
    dokter: 'ubah gambar ini menjadi dokter profesional dengan jas putih, stetoskop, background rumah sakit',
    pilot: 'ubah gambar ini menjadi pilot maskapai dengan seragam biru, topi pilot, background pesawat',
    polisi: 'ubah gambar ini menjadi polisi dengan seragam resmi, ekspresi tegas dan profesional',
    tentara: 'ubah gambar ini menjadi tentara dengan seragam militer lengkap, ekspresi gagah dan disiplin',
    preman: 'ubah gambar ini menjadi preman jalanan dengan gaya kasual, ekspresi tegas, background gang kota',
    kiyowo: 'ubah gambar ini menjadi karakter kawaii/kiyowo ala Jepang, mata besar, blush pink, ekspresi menggemaskan',
    ganteng: 'ubah gambar ini menjadi pria yang sangat ganteng, proporsi wajah ideal, kulit glowing, gaya K-pop',
    barbie: 'ubah gambar ini menjadi boneka Barbie cantik dengan gaun pink, rambut pirang, background mewah',
    cyber: 'ubah gambar ini menjadi karakter cyberpunk dengan implan teknologi, neon lights, dan gaya futuristik',

    // ==========================================
    // 🌍 BUDAYA / NEGARA
    // ==========================================
    jepang: 'ubah gambar ini menjadi karakter bergaya Jepang, kimono, background sakura, estetik Jepang',
    korea: 'ubah gambar ini menjadi karakter bergaya Korea, hanbok modern, background Seoul, estetik K-culture',
    arab: 'ubah gambar ini menjadi karakter bergaya Arab, pakaian tradisional, background gurun, pencahayaan hangat',
    india: 'ubah gambar ini menjadi karakter bergaya India, sari colorful, background Taj Mahal, warna vibrant',
    bali: 'ubah gambar ini menjadi karakter bergaya Bali, pakaian adat, background Pura, suasana tropis',

    // ==========================================
    // 🎬 AKSI / ATMOSFER
    // ==========================================
    superhero: 'ubah gambar ini menjadi karakter superhero dengan kostum keren, cape berkibar, background kota futuristik',
    penjahat: 'ubah gambar ini menjadi karakter villain/penjahat dengan ekspresi jahat, kostum gelap, atmosphere dark',
    'zombie': 'ubah gambar ini menjadi karakter zombie dengan kulit pucat, mata merah, background apokaliptik',
    'vampir': 'ubah gambar ini menjadi karakter vampir elegan, kulit pucat, gigi taring, background kastil gelap',
    robot: 'ubah gambar ini menjadi robot humanoid dengan metal mengkilap, lampu LED, background futuristik',
    alien: 'ubah gambar ini menjadi makhluk alien dengan bentuk unik, kulit hijau, mata besar, background space',

    // ==========================================
    // 🎨 EFEK / FILTER
    // ==========================================
    glow: 'tambahkan efek glow ke gambar ini, sinar lembut, pencahayaan dramatis, aura bercahaya',
    blur: 'tambahkan efek blur artistik ke gambar ini, bokeh halus, background blur, fokus di subject',
    fire: 'tambahkan efek api/nyala di sekitar gambar ini, api realistis, glow oranye, atmosfer epik',
    ice: 'tambahkan efek es/beku ke gambar ini, kristal es, warna biru-putih, suasana dingin',
    light: 'tambahkan efek light trail/cahaya bergerak ke gambar ini, neon glow, atmosfer futuristik',
    shadow: 'tambahkan efek shadow dramatis ke gambar ini, bayangan gelap, kontras tinggi, suasana misterius',

    // ==========================================
    // 🎯 LAINNYA
    // ==========================================
    hd: 'tingkatkan kualitas gambar ini ke resolusi tinggi (HD/4K), detail tajam, tanpa noise',
    'removebg': 'hapus background gambar ini, hasil PNG transparan, tepi halus',
    'bgpantai': 'ganti background gambar ini dengan pantai tropis, pasir putih, laut biru, langit cerah',
    'bgkota': 'ganti background gambar ini dengan kota modern malam hari, gedung tinggi, lampu neon',
    'bgstudio': 'ganti background gambar ini dengan studio foto profesional, backdrop polos, pencahayaan sempurna',
    'bgalam': 'ganti background gambar ini dengan pemandangan alam pegunungan, hijau, udara segar',
};

/**
 * Ambil prompt berdasarkan tag
 * @param {string} tag - Nama tag (contoh: 'figura', 'anime', 'cowok')
 * @param {string} customPrompt - Kalau tag tidak ditemukan, pakai custom prompt ini
 * @returns {string} - Prompt yang siap dikirim ke AI
 */
export function getPrompt(tag, customPrompt = null) {
    if (!tag) return customPrompt || 'tingkatkan kualitas gambar';
    
    const key = String(tag).toLowerCase().trim();
    return PROMPTS[key] || customPrompt || `ubah gambar ini menjadi ${tag}`;
}

/**
 * Cek apakah tag tersedia
 */
export function isValidTag(tag) {
    if (!tag) return false;
    return !!PROMPTS[String(tag).toLowerCase().trim()];
}

/**
 * Ambil semua tag yang tersedia
 */
export function getAllTags() {
    return Object.keys(PROMPTS);
}

/**
 * Ambil tag berdasarkan kategori (untuk help menu)
 */
export function getTagsByCategory() {
    return {
        'Gaya Seni': ['figura', 'anime', 'kartun', 'realis', '3d', '3dchibi', 'pixelart', 'cyberpunk', 'vintage', 'watercolor', 'oilpainting', 'sketch', 'comic', 'korean'],
        'Gender/Usia': ['cowok', 'cewek', 'anak', 'tua', 'balita'],
        'Profesi': ['chef', 'dokter', 'pilot', 'polisi', 'tentara', 'preman', 'kiyowo', 'ganteng', 'barbie', 'cyber'],
        'Budaya': ['jepang', 'korea', 'arab', 'india', 'bali'],
        'Aksi': ['superhero', 'penjahat', 'zombie', 'vampir', 'robot', 'alien'],
        'Efek': ['glow', 'blur', 'fire', 'ice', 'light', 'shadow'],
        'Lainnya': ['hd', 'removebg', 'bgpantai', 'bgkota', 'bgstudio', 'bgalam'],
    };
}

export default {
    PROMPTS,
    getPrompt,
    isValidTag,
    getAllTags,
    getTagsByCategory,
};