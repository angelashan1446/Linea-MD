// libx/utils/lock.js

// Nyimpen ID pesan yang lagi diproses
// Format: Map<msgId, { lid, nomor, source, timestamp }>
const processingMessages = new Map();

/**
 * Coba kunci pesan. Return true kalau berhasil (bot ini yang jalan).
 * Return false kalau pesan udah dikunci bot lain.
 */
export function tryLockMessage(msgId, metadata = {}) {
    if (!msgId) return true; // Kalau ga ada ID, biarin jalan aja (safety)

    // Kalau udah ada yang pegang, skip
    if (processingMessages.has(msgId)) {
        return false;
    }

    // Kunci pesan
    processingMessages.set(msgId, {
        ...metadata,
        lockedAt: Date.now()
    });

    return true;
}

/**
 * Lepas kunci pesan (dipanggil setelah selesai diproses / error).
 */
export function releaseLockMessage(msgId) {
    if (!msgId) return;
    processingMessages.delete(msgId);
}

/**
 * (Opsional) Cek siapa yang lagi megang pesan ini.
 */
export function getLockInfo(msgId) {
    return processingMessages.get(msgId) || null;
}

// ============================================================
// 🧹 AUTO CLEANUP
// ============================================================
// Kadang bot mati di tengah jalan / crash, jadi kunci ga kelepas.
// Kita bersihin kunci yang umurnya lebih dari 1 menit setiap 30 detik.
setInterval(() => {
    const now = Date.now();
    const TIMEOUT = 60 * 1000; // 1 menit

    for (const [msgId, info] of processingMessages.entries()) {
        if (now - info.lockedAt > TIMEOUT) {
            processingMessages.delete(msgId);
            console.log(`[LOCK] Auto-release pesan ${msgId.substring(0, 10)} (timeout)`);
        }
    }
}, 30 * 1000);