// libx/utils/alias_numberbot.js
// "Buku Telepon" Bot: Menerjemahkan Alias <-> Nomor (Analogi DNS)
// + Validasi nomor via connect.js (harus bot aktif)

import fs from 'fs';
import path from 'path';
// ✅ Import fungsi validasi dari connect.js
import { getActiveBotNumbers } from '../whatsapp/connect.js';

const ALIAS_FILE = path.join(process.cwd(), 'db', 'bot_aliases.json');

// ============================================================
// INTERNAL HELPER (Baca/Tulis Database JSON)
// ============================================================
function readDb() {
    try {
        if (!fs.existsSync(ALIAS_FILE)) {
            const dir = path.dirname(ALIAS_FILE);
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
            fs.writeFileSync(ALIAS_FILE, JSON.stringify({}, null, 2));
            return {};
        }
        return JSON.parse(fs.readFileSync(ALIAS_FILE, 'utf8'));
    } catch {
        return {};
    }
}

function writeDb(data) {
    try {
        const dir = path.dirname(ALIAS_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(ALIAS_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[Alias] Gagal tulis database:', e.message);
    }
}

// ============================================================
// FUNGSI UTAMA
// ============================================================

/**
 * 1. Daftarkan Alias (Set DNS Record)
 * Mengubah nama "linea1" menjadi terhubung ke nomor "628xxx"
 * 
 * @param {string} alias - Nama pengganti (misal: linea1)
 * @param {string} nomor - Nomor bot (misal: 6281234567890)
 * @returns {{ok: boolean, message: string}}
 */
export function setAlias(alias, nomor) {
    const cleanAlias = String(alias).toLowerCase().trim();
    const cleanNomor = String(nomor).replace(/\D/g, '');

    if (!cleanAlias || !cleanNomor) {
        return { ok: false, message: 'Alias dan nomor tidak boleh kosong.' };
    }

    if (!/^[a-z0-9_-]+$/.test(cleanAlias)) {
        return { ok: false, message: 'Alias hanya boleh huruf kecil, angka, strip, dan underscore.' };
    }

    // ✅ VALIDASI: Cek apakah nomor ini beneran bot yang aktif
    const activeBots = getActiveBotNumbers();
    if (!activeBots.includes(cleanNomor)) {
        return { 
            ok: false, 
            message: `Nomor +${cleanNomor} bukan bot yang aktif.\n\n_Bot yang aktif: ${activeBots.map(n => `+${n}`).join(', ') || '-'}_` 
        };
    }

    const db = readDb();

    // Cek apakah alias sudah dipakai nomor lain
    for (const [n, a] of Object.entries(db)) {
        if (n !== cleanNomor && a === cleanAlias) {
            return { ok: false, message: `Alias "${cleanAlias}" sudah dipakai bot +${n}` };
        }
    }

    // Simpan (Key: Nomor, Value: Alias)
    db[cleanNomor] = cleanAlias;
    writeDb(db);

    return { ok: true, message: `Berhasil! Bot +${cleanNomor} sekarang bernama "${cleanAlias}".` };
}

/**
 * 2. Resolve Alias (Lookup DNS)
 * Mengubah nama "linea1" menjadi nomor "628xxx"
 * 
 * @param {string} alias - Nama alias yang mau dicari
 * @returns {string|null} - Nomor bot, atau null kalau ga ketemu
 */
export function resolveAlias(alias) {
    if (!alias) return null;
    const cleanAlias = String(alias).toLowerCase().trim();
    const db = readDb();

    // Cari di database
    for (const [nomor, al] of Object.entries(db)) {
        if (al === cleanAlias) return nomor;
    }

    return null;
}

/**
 * 3. Reverse Lookup (Cek Alias dari Nomor)
 * Nanya: "Nomor 628xxx ini namanya siapa?"
 * 
 * @param {string} nomor - Nomor bot
 * @returns {string|null} - Alias, atau null kalau belum diberi nama
 */
export function getAliasByNumber(nomor) {
    if (!nomor) return null;
    const cleanNomor = String(nomor).replace(/\D/g, '');
    const db = readDb();
    return db[cleanNomor] || null;
}

/**
 * 4. Hapus Alias (Delete DNS Record)
 * 
 * @param {string} identifier - Bisa pakai Alias atau Nomor
 */
export function deleteAlias(identifier) {
    const db = readDb();
    const cleanNomor = String(identifier).replace(/\D/g, '');
    
    if (db[cleanNomor]) {
        delete db[cleanNomor];
        writeDb(db);
        return true;
    }
    
    // Kalau yang diinput adalah alias, cari dulu nomornya
    const nomorDariAlias = resolveAlias(identifier);
    if (nomorDariAlias && db[nomorDariAlias]) {
        delete db[nomorDariAlias];
        writeDb(db);
        return true;
    }

    return false;
}

/**
 * 5. List Semua Alias (Lihat semua DNS Record)
 * 
 * @returns {Array<{nomor: string, alias: string|null}>}
 */
export function listAliases() {
    const db = readDb();
    return Object.entries(db).map(([nomor, alias]) => ({
        nomor,
        alias
    }));
}