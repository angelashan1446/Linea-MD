// libx/db.js
// Database JSON sederhana untuk users.

import fs from 'fs';
import path from 'path';
import config from '../config.js';
import { nowIso, formatTanggal, isExpired } from './date.js';

const ROOT = process.cwd();
const DB_DIR = path.join(ROOT, 'db');
const USERS_FILE = path.join(DB_DIR, 'users.json');
const SESSIONS_DIR = path.join(DB_DIR, 'sessions');

// Default bahasa
const DEFAULT_LANG = 'id';

// ============ SETUP ============
function ensureDirs() {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
  if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });
  if (!fs.existsSync(USERS_FILE))
    fs.writeFileSync(USERS_FILE, JSON.stringify({ users: [] }, null, 2));
}

// ============ READ / WRITE ============
function readDb() {
  ensureDirs();
  try {
    return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
  } catch {
    return { users: [] };
  }
}

function writeDb(data) {
  ensureDirs();
  fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 2));
}

// ============ USER HELPERS ============
function normalize(nomor) {
  if (!nomor) return '';
  return String(nomor).replace(/\D/g, '');
}

/**
 * Cari user berdasarkan LID atau nomor HP.
 * Prioritas: LID > nomor
 */
function findUser({ lid, nomor } = {}) {
  const db = readDb();
  if (lid) {
    const u = db.users.find((x) => x.lid === lid);
    if (u) return u;
  }
  if (nomor) {
    const n = normalize(nomor);
    return db.users.find((x) => normalize(x.nomor) === n) || null;
  }
  return null;
}

/**
 * Cari by nomor saja
 */
function findByNomor(nomor) {
  const n = normalize(nomor);
  if (!n) return null;
  const db = readDb();
  return db.users.find((x) => normalize(x.nomor) === n) || null;
}

/**
 * Cek apakah nomor adalah owner (dari config)
 */
function isConfigOwner(nomor) {
  const n = normalize(nomor);
  return config.owners.map(normalize).includes(n);
}

/**
 * Cek apakah user adalah owner (dari DB atau config)
 */
function isOwner({ lid, nomor } = {}) {
  const user = findUser({ lid, nomor });
  if (user?.owner) return true;
  return isConfigOwner(nomor);
}

/**
 * Cek apakah user premium dan belum expired
 */
function isPremium({ lid, nomor } = {}) {
  const user = findUser({ lid, nomor });
  if (!user) return false;
  if (!user.premium) return false;
  return !isExpired(user.premium);
}

/**
 * Daftarkan user baru
 */
function registerUser({ nomor, lid = null }) {
  const db = readDb();
  const n = normalize(nomor);
  if (!n) return { ok: false, reason: 'Nomor tidak valid' };
  if (db.users.find((u) => normalize(u.nomor) === n)) {
    return { ok: false, reason: 'Nomor sudah terdaftar' };
  }
  if (lid && db.users.find((u) => u.lid === lid)) {
    return { ok: false, reason: 'LID sudah terdaftar' };
  }

  const user = {
    nomor: n,
    lid: lid || null,
    token: 1000,
    premium: null,
    owner: isConfigOwner(n),
    lang: DEFAULT_LANG,  // ✅ default bahasa
    create_at: nowIso(),
    sessions: [],
  };
  db.users.push(user);
  writeDb(db);
  return { ok: true, user };
}

/**
 * Isi LID user yang sudah ada
 */
function setUserLid(nomor, lid) {
  const db = readDb();
  const n = normalize(nomor);
  const user = db.users.find((u) => normalize(u.nomor) === n);
  if (!user) return false;
  if (db.users.find((u) => u.lid === lid && normalize(u.nomor) !== n)) return false;
  user.lid = lid;
  writeDb(db);
  return true;
}

/**
 * Kurangi token user
 */
function useToken({ lid, nomor }, amount = 1) {
  const db = readDb();
  const n = normalize(nomor);
  const user = db.users.find(
    (u) => (lid && u.lid === lid) || (n && normalize(u.nomor) === n),
  );
  if (!user) return { ok: false, reason: 'User tidak ditemukan' };
  if (user.token < amount) return { ok: false, reason: 'Token tidak cukup', sisa: user.token };
  user.token -= amount;
  writeDb(db);
  return { ok: true, sisa: user.token };
}

/**
 * Set premium user
 */
function setPremium(nomor, untilIso) {
  const db = readDb();
  const n = normalize(nomor);
  const user = db.users.find((u) => normalize(u.nomor) === n);
  if (!user) return false;
  user.premium = untilIso;
  writeDb(db);
  return true;
}

// ============ ✅ LANGUAGE ============

/**
 * Ambil bahasa user (default 'id').
 * @returns {string} kode bahasa: 'id' | 'en' | ...
 */
function getUserLang({ lid, nomor } = {}) {
  const user = findUser({ lid, nomor });
  if (!user) return DEFAULT_LANG;
  return user.lang || DEFAULT_LANG;
}

/**
 * Set bahasa user.
 * @param {{ lid?, nomor? }} target
 * @param {string} lang - kode bahasa
 * @returns {{ ok: boolean, reason?: string }}
 */
function setUserLang({ lid, nomor } = {}, lang) {
  if (!lang || typeof lang !== 'string') {
    return { ok: false, reason: 'Kode bahasa tidak valid' };
  }
  const db = readDb();
  const n = normalize(nomor);
  const user = db.users.find(
    (u) => (lid && u.lid === lid) || (n && normalize(u.nomor) === n),
  );
  if (!user) return { ok: false, reason: 'User tidak ditemukan' };
  user.lang = lang.toLowerCase().trim();
  writeDb(db);
  return { ok: true, lang: user.lang };
}

// ============ SESSION OWNERSHIP ============

function addSessionOwner(nomorUser, folder) {
  const db = readDb();
  const n = normalize(nomorUser);
  const user = db.users.find((u) => normalize(u.nomor) === n);
  if (!user) return false;
  if (!Array.isArray(user.sessions)) user.sessions = [];
  if (!user.sessions.includes(folder)) {
    user.sessions.push(folder);
    writeDb(db);
  }
  return true;
}

function removeSessionOwner(folder) {
  const db = readDb();
  let changed = false;
  for (const user of db.users) {
    if (Array.isArray(user.sessions) && user.sessions.includes(folder)) {
      user.sessions = user.sessions.filter((s) => s !== folder);
      changed = true;
    }
  }
  if (changed) writeDb(db);
}

function findSessionOwner(folder) {
  const db = readDb();
  return db.users.find((u) => Array.isArray(u.sessions) && u.sessions.includes(folder)) || null;
}

// ============ BOOTSTRAP ============
function bootstrapOwners() {
  const db = readDb();
  let changed = false;
  for (const nomor of config.owners) {
    const n = normalize(nomor);
    if (!n) continue;
    if (!db.users.find((u) => normalize(u.nomor) === n)) {
      db.users.push({
        nomor: n,
        lid: null,
        token: 3000,
        premium: null,
        owner: true,
        lang: DEFAULT_LANG,  // ✅ default bahasa untuk owner
        create_at: nowIso(),
        sessions: [],
      });
      changed = true;
    } else {
      const u = db.users.find((u) => normalize(u.nomor) === n);
      // Pastikan field sessions ada
      if (!Array.isArray(u.sessions)) {
        u.sessions = [];
        changed = true;
      }
      // ✅ Migrasi: pastikan field lang ada
      if (!u.lang) {
        u.lang = DEFAULT_LANG;
        changed = true;
      }
    }
  }
  if (changed) writeDb(db);
}

// ============ EXPORT SEMUA ============
export {
  // Core
  readDb,
  writeDb,
  normalize,

  // User CRUD
  findUser,
  findByNomor,
  registerUser,
  setUserLid,
  setPremium,
  useToken,

  // Role Check
  isConfigOwner,
  isOwner,
  isPremium,

  // ✅ Language
  DEFAULT_LANG,
  getUserLang,
  setUserLang,

  // Session Ownership
  addSessionOwner,
  removeSessionOwner,
  findSessionOwner,

  // Bootstrap
  bootstrapOwners,

  // Paths & Dirs
  DB_DIR,
  USERS_FILE,
  SESSIONS_DIR,
};