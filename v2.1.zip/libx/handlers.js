// libx/handlers.js
// Event Bus: Menyebarkan pesan masuk ke semua handler terdaftar.
// Patuh jadibot.json (selft_bot & mode_chat).

import chalk from 'chalk';
import fs from 'fs';
import path from 'path';
import config from '../config.js';
import { sendText, sendMedia } from './whatsapp/sendmsg.js';
import { getBotService, isFeatureEnabled, getGroupLang } from './grup_db.js';
import { isOwner, findUser } from './db.js';
import { isValidLang, DEFAULT_LANG } from './lang.js';

// ============================================================
// JADIBOT DB (cache)
// ============================================================
const JADIBOT_FILE = path.join(process.cwd(), 'db', 'jadibot.json');

function readJadibotReadonlyDb() {
  try {
    if (!fs.existsSync(JADIBOT_FILE)) return { bots: {} };
    return JSON.parse(fs.readFileSync(JADIBOT_FILE, 'utf8'));
  } catch {
    return { bots: {} };
  }
}

function getBotSelfConfig(botNumber) {
  if (!botNumber) return null;
  const db = readJadibotReadonlyDb();
  const bots = db.bots || {};

  // Exact match
  if (bots[botNumber]) return bots[botNumber];

  // Fallback: normalisasi (mis. key "628xxx:12@s.whatsapp.net" vs "628xxx")
  const clean = String(botNumber).replace(/\D/g, '');
  for (const [key, cfg] of Object.entries(bots)) {
    const keyClean = String(key).replace(/\D/g, '').split(':')[0];
    if (keyClean === clean) return cfg;
  }
  return null;
}

// ============================================================
// ARRAY HANDLER
// ============================================================
const messageHandlers = [];

// ============================================================
// LOCK HANDLER (cegah dobel dari sesi lain)
// ============================================================
const handlerLocks = new Map();

function tryLockHandler(msgId, folder) {
  if (!msgId) return true;
  const lock = handlerLocks.get(msgId);
  const now = Date.now();

  if (lock && lock.folder !== folder && lock.releaseAt > now) {
    return false;
  }

  handlerLocks.set(msgId, {
    folder,
    releaseAt: now + 15000,
  });

  setTimeout(() => {
    const current = handlerLocks.get(msgId);
    if (current && current.folder === folder) {
      handlerLocks.delete(msgId);
    }
  }, 15000);

  return true;
}

/**
 * Mendaftarkan handler baru.
 */
export function registerHandler(name, callback, options = {}) {
  messageHandlers.push({
    name,
    callback,
    priority: options.priority || 10,
  });
  messageHandlers.sort((a, b) => a.priority - b.priority);
  console.log(
    chalk.magenta(`[HOOK] `) +
    chalk.white(name) +
    chalk.gray(` (Priority: ${options.priority || 10})`)
  );
}

/**
 * Dipanggil oleh main.js untuk setiap pesan yang masuk.
 */
export async function emitMessage(sock, msg, folder) {
  const key = msg.key || {};
  const remoteJid = key.remoteJid || '';
  const isGroup = remoteJid.endsWith('@g.us');

  const myBotNumber = sock.user?.id?.split(':')[0]?.split('@')[0];

  // ============================================================
  // ✅ 0. EKSTRAK SENDER (dibutuhkan untuk cek selft_bot)
  // ============================================================
  const rawJid = isGroup ? key.participant : remoteJid;
  const isLid = rawJid?.endsWith('@lid');
  const isPn = rawJid?.endsWith('@s.whatsapp.net');

  let lid = isLid ? rawJid : (key.senderLid || null);
  let nomor = null;
  if (isPn) nomor = rawJid.split('@')[0];
  else if (key.senderPn) nomor = key.senderPn.split('@')[0];
  else if (key.participantAlt?.endsWith('@s.whatsapp.net')) nomor = key.participantAlt.split('@')[0];
  else if (key.remoteJidAlt?.endsWith('@s.whatsapp.net')) nomor = key.remoteJidAlt.split('@')[0];

  const isOwnerSender = isOwner({ lid, nomor });

  // ============================================================
  // ✅ 1. CEK BOT SERVICE (SIAPA YANG BERHAK DI GRUP INI)
  // ============================================================
  if (isGroup) {
    const groupId = remoteJid.split('@')[0];
    const botService = getBotService(groupId);
    
    // ✅ FIX: Normalisasi tipe data agar perbandingan string vs number tidak meleset
    const botServiceStr = String(botService || '').replace(/\D/g, '');
    const myBotStr = String(myBotNumber || '').replace(/\D/g, '');

    if (botService !== 'dynamic' && botServiceStr !== myBotStr) {
      if (config.mode === 'development') {
        console.log(chalk.gray(`[HOOK] Skip semua handler — grup ${groupId} milik bot +${botService}`));
      }
      return false;
    }
  }

  // ============================================================
  // ✅ 2. CEK JADIBOT CONFIG (SELFT_BOT + MODE_CHAT)
  // ============================================================
  // ✅ FIX: Kecualikan bot utama dari pengecekan jadibot.json
  const PRIMARY_BOT = String(config.phone_number_bot || '').replace(/\D/g, '');
  const currentBotStr = String(myBotNumber || '').replace(/\D/g, '');
  const isPrimaryBot = currentBotStr === PRIMARY_BOT;

  if (!isPrimaryBot) {
    const botSelf = getBotSelfConfig(myBotNumber);

    if (botSelf) {
      // 2.a. Selft bot
      if (botSelf.selft_bot === true) {
        const ownerOfBot = botSelf.nomor_owner
          ? String(botSelf.nomor_owner).replace(/\D/g, '')
          : null;

        const senderNomorClean = nomor ? String(nomor).replace(/\D/g, '') : null;
        const isBotOwner =
          (ownerOfBot && senderNomorClean && ownerOfBot === senderNomorClean) ||
          (botSelf.lid && lid && botSelf.lid === lid) ||
          isOwnerSender;

        if (!isBotOwner) {
          if (config.mode === 'development') {
            console.log(chalk.gray(`[HOOK] Skip semua handler — selft_bot aktif untuk bot +${myBotNumber}`));
          }
          return false;
        }
      }

      // 2.b. Mode chat
      if (botSelf.mode_chat === 'private' && isGroup && !isOwnerSender) {
        if (config.mode === 'development') {
          console.log(chalk.gray(`[HOOK] Skip semua handler — bot +${myBotNumber} mode private, pesan dari grup`));
        }
        return false;
      }
      if (botSelf.mode_chat === 'grup' && !isGroup && !isOwnerSender) {
        if (config.mode === 'development') {
          console.log(chalk.gray(`[HOOK] Skip semua handler — bot +${myBotNumber} mode grup, pesan dari private`));
        }
        return false;
      }
    }
    // Fallback: bot secondary tak terdaftar & di grup → skip
    else if (isGroup) {
      if (config.mode === 'development') {
        console.log(chalk.gray(`[HOOK] Skip semua handler — bot +${myBotNumber} tidak ada di jadibot.json`));
      }
      return false;
    }
  }

  // ============================================================
  // ✅ 3. LOCK PESAN
  // ============================================================
  const msgId = msg.key?.id;
  if (!tryLockHandler(msgId, folder)) {
    if (config.mode === 'development') {
      console.log(chalk.gray(`[HOOK] Skip ${msgId?.substring(0, 8)} — sedang diproses sesi lain.`));
    }
    return false;
  }

  // ============================================================
  // 4. Ekstrak teks
  // ============================================================
  const text =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption ||
    '';

  // ============================================================
  // 5. Bangun Context
  // ============================================================
  const ctx = {
    sock,
    msg,
    text,
    remoteJid,
    isGroup,
    sender: {
      lid,
      nomor,
      rawJid,
      pushName: msg.pushName,
      isOwner: isOwnerSender,
    },
    folder,
    prefix: config.prefix,
    config,
    isStopped: false,
    stop: () => { ctx.isStopped = true; },
    reply: async (teks, opts = {}) => {
      return sendText(sock, remoteJid, teks, { quoted: msg, ...opts });
    },
    replyMedia: async (media, opts = {}) => {
      return sendMedia(sock, remoteJid, media, { quoted: msg, ...opts });
    },
  };

  // ============================================================
  // 6. Jalankan handler berurutan
  // ============================================================
  for (const handler of messageHandlers) {
    try {
      await handler.callback(ctx);

      if (ctx.isStopped) {
        // Log ini bisa dimatikan kalau terlalu berisik
        // console.log(chalk.yellow(`[HOOK] Rantai dihentikan oleh: ${handler.name}`));
        return true;
      }
    } catch (error) {
      console.error(chalk.red(`[HOOK ERROR] ${handler.name}:`), error);
    }
  }

  return false;
}