// libx/auto_backup.js
// Auto backup database (db/) → zip → kirim ke owner.
//   - backup(sock, opts)      : backup manual (langsung kirim)
//   - autobackup(sock, opts)  : mulai timer auto (3 jam sekali)
//   - stopAutoBackup()        : hentikan timer

import fs from 'fs';
import path from 'path';
import os from 'os';
import { spawn } from 'child_process';
import chalk from 'chalk';
import config from '../config.js';
import { sendMedia, sendText } from './whatsapp/sendmsg.js';
// ✅ Import Map 'sessions' langsung dari connect.js
import { sessions } from './whatsapp/connect.js';

// ============================================================
// KONFIG
// ============================================================
const DB_DIR = path.join(process.cwd(), 'db');
const BACKUP_INTERVAL_MS = 3 * 60 * 60 * 1000; // 3 jam
const TMP_DIR = os.tmpdir();

const PRIMARY_BOT = String(config.phone_number_bot || '').replace(/\D/g, '');

// ============================================================
// STATE AUTO BACKUP
// ============================================================
let _autoTimer = null;
let _autoSock = null;
let _autoRunning = false;

// ============================================================
// ✅ HELPER: CARI SOCK BOT UTAMA
// ============================================================
/**
 * Memastikan backup selalu dikirim dari Bot Utama (config.phone_number_bot).
 * Jika sock yang diberikan bukan bot utama, cari dari Map 'sessions' di connect.js.
 */
function resolvePrimarySock(providedSock) {
  if (!providedSock) return null;

  const providedNumber = String(providedSock.user?.id?.split(':')[0]?.split('@')[0] || '').replace(/\D/g, '');
  
  // 1. Jika sock yang diberikan SUDAH bot utama, langsung pakai
  if (providedNumber === PRIMARY_BOT) {
    return providedSock;
  }

  // 2. Jika BUKAN bot utama, cari di Map 'sessions'
  if (sessions && sessions.size > 0) {
    for (const [folder, sockObj] of sessions.entries()) {
      const num = String(sockObj?.user?.id?.split(':')[0]?.split('@')[0] || '').replace(/\D/g, '');
      if (num === PRIMARY_BOT) {
        return sockObj;
      }
    }
  }

  // 3. Fallback: kalau tidak ketemu, terpaksa pakai yang ada (biar ga crash)
  console.log(chalk.yellow(`[AUTO-BACKUP] ⚠️ Sock bot utama tidak ditemukan, pakai sock yang tersedia.`));
  return providedSock;
}

// ============================================================
// HELPER: ZIP folder db/ → file .zip
// ============================================================
async function zipDbFolder() {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const zipName = `backup-db-${stamp}.zip`;
  const zipPath = path.join(TMP_DIR, zipName);

  try { if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath); } catch {}

  const isWin = process.platform === 'win32';

  if (isWin) {
    await new Promise((resolve, reject) => {
      const psScript = `
        if (Test-Path "${zipPath}") { Remove-Item "${zipPath}" -Force }
        Compress-Archive -Path "${DB_DIR}\\*" -DestinationPath "${zipPath}" -Force
      `;
      const proc = spawn('powershell.exe', ['-NoProfile', '-Command', psScript], {
        windowsHide: true,
      });
      let stderr = '';
      proc.stderr.on('data', (d) => { stderr += d.toString(); });
      proc.on('error', (err) => reject(new Error(`PowerShell error: ${err.message}`)));
      proc.on('close', (code) => {
        if (code === 0) resolve();
        else reject(new Error(`PowerShell exit ${code}: ${stderr}`));
      });
    });
  } else {
    await new Promise((resolve, reject) => {
      const proc = spawn('zip', ['-r', zipPath, '.'], {
        cwd: DB_DIR,
        windowsHide: true,
      });
      let stderr = '';
      proc.stderr.on('data', (d) => { stderr += d.toString(); });
      proc.on('error', (err) => reject(new Error(`zip error: ${err.message}`)));
      proc.on('close', (code) => {
        if (code === 0) resolve();
        else reject(new Error(`zip exit ${code}: ${stderr}`));
      });
    });
  }

  if (!fs.existsSync(zipPath)) {
    throw new Error('File zip tidak terbuat (cek permission / disk).');
  }

  return zipPath;
}

// ============================================================
// HELPER: KIRIM ZIP KE OWNER
// ============================================================
async function sendZipToOwners(sock, zipPath, isAuto = false) {
  const buffer = fs.readFileSync(zipPath);
  const sizeKb = (buffer.length / 1024).toFixed(1);
  const sizeMb = (buffer.length / 1024 / 1024).toFixed(2);
  const fileName = path.basename(zipPath);

  const header = isAuto
    ? `乂  *ᴀᴜᴛᴏ ʙᴀᴄᴋᴜᴘ* 🤖\n\n` +
      `📦 File  : ${fileName}\n` +
      `📊 Ukuran: ${sizeKb} KB (${sizeMb} MB)\n` +
      `⏰ Interval: Setiap 3 jam\n\n` +
      `_Backup otomatis folder db/_`
    : `乂  *ʙᴀᴄᴋᴜᴘ ᴅᴀᴛᴀʙᴀsᴇ* 📦\n\n` +
      `📦 File  : ${fileName}\n` +
      `📊 Ukuran: ${sizeKb} KB (${sizeMb} MB)\n\n` +
      `_Backup manual folder db/_`;

  let sent = 0;
  for (const ownerNumber of config.owners) {
    const clean = String(ownerNumber).replace(/\D/g, '');
    if (!clean) continue;

    const targetJid = `${clean}@s.whatsapp.net`;

    try {
      await sendText(sock, targetJid, header);
      await sendMedia(sock, targetJid, {
        buffer,
        mimetype: 'application/zip',
        fileName,
      });

      sent++;
      console.log(chalk.green(`[BACKUP] ✅ Terkirim ke +${clean}`));
    } catch (err) {
      console.log(chalk.red(`[BACKUP] ❌ Gagal kirim ke +${clean}: ${err.message}`));
    }
  }

  return sent;
}

// ============================================================
// BACKUP (MANUAL)
// ============================================================
export async function backup(sock, opts = {}) {
  const { chatJid, msg } = opts;

  if (!fs.existsSync(DB_DIR)) {
    const err = 'Folder db/ tidak ditemukan';
    if (chatJid) {
      await sendText(sock, chatJid, `❌ Backup gagal: ${err}`, msg ? { quoted: msg } : {});
    }
    return { ok: false, error: err };
  }

  // ✅ Pastikan pakai bot utama
  const primarySock = resolvePrimarySock(sock);

  let zipPath = null;
  try {
    zipPath = await zipDbFolder();
    const sent = await sendZipToOwners(primarySock, zipPath, false);

    console.log(chalk.green(`[BACKUP] ✅ Selesai — terkirim ke ${sent} owner`));

    if (chatJid && msg) {
      try {
        await sendText(sock, chatJid, `✅ Backup selesai. Terkirim ke ${sent} owner.`, { quoted: msg });
      } catch {}
    }

    return { ok: true, count: sent };
  } catch (err) {
    console.error(chalk.red(`[BACKUP] ❌ ${err.message}`));
    if (chatJid && msg) {
      try {
        await sendText(sock, chatJid, `❌ Backup gagal: ${err.message}`, { quoted: msg });
      } catch {}
    }
    return { ok: false, error: err.message };
  } finally {
    try { if (zipPath && fs.existsSync(zipPath)) fs.unlinkSync(zipPath); } catch {}
  }
}

// ============================================================
// AUTO BACKUP (OTOMATIS)
// ============================================================
export function autobackup(sock, opts = {}) {
  if (_autoTimer) {
    console.log(chalk.yellow(`[AUTO-BACKUP] ⚠️ Timer sudah jalan, skip init`));
    return false;
  }

  // ✅ Pastikan pakai bot utama saat inisialisasi
  _autoSock = resolvePrimarySock(sock);

  const intervalMs = opts.intervalMs || BACKUP_INTERVAL_MS;

  console.log(chalk.cyan(`[AUTO-BACKUP] 🚀 Started — interval ${Math.round(intervalMs / 60000)} menit`));

  if (opts.startChatJid) {
    sendText(_autoSock, opts.startChatJid, `🤖 Auto backup aktif — setiap ${Math.round(intervalMs / 60000)} menit.`)
      .catch(() => {});
  }

  _autoTimer = setInterval(async () => {
    if (_autoRunning) return;

    _autoRunning = true;
    try {
      console.log(chalk.cyan(`[AUTO-BACKUP] 🔄 Running...`));

      // 🔄 Cek ulang sock: kalau bot utama baru connect belakangan, ambil yang terbaru
      const currentSock = resolvePrimarySock(_autoSock);

      if (!fs.existsSync(DB_DIR)) {
        console.log(chalk.red(`[AUTO-BACKUP] ❌ Folder db/ tidak ditemukan`));
        return;
      }

      const zipPath = await zipDbFolder();
      const sent = await sendZipToOwners(currentSock, zipPath, true);
      console.log(chalk.green(`[AUTO-BACKUP] ✅ Selesai — terkirim ke ${sent} owner`));

      try { fs.unlinkSync(zipPath); } catch {}
    } catch (err) {
      console.error(chalk.red(`[AUTO-BACKUP] ❌ ${err.message}`));
    } finally {
      _autoRunning = false;
    }
  }, intervalMs);

  _autoTimer.unref?.();

  return true;
}

export function stopAutoBackup() {
  if (_autoTimer) {
    clearInterval(_autoTimer);
    _autoTimer = null;
    _autoSock = null;
    _autoRunning = false;
    console.log(chalk.yellow(`[AUTO-BACKUP] 🛑 Stopped`));
    return true;
  }
  return false;
}

export function isAutoBackupRunning() {
  return !!_autoTimer;
}