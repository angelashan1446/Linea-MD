// libx/session_plugins.js
import chalk from 'chalk';
import config from '../config.js';
import { getBotService } from './grup_db.js';

// Map: messageId -> session object
const sessions = new Map();

// Map: chatJid -> Set<messageId>
const chatSessions = new Map();

// Map: chatJid -> messageId terakhir
const lastPromptByChat = new Map();

// ============================================================
// LOCK REPLY (cegah dobel dari sesi lain)
// ============================================================
const replyLocks = new Map();

function tryLockReply(quotedId, folder) {
  if (!quotedId) return true;
  const lock = replyLocks.get(quotedId);
  const now = Date.now();

  if (lock && lock.folder !== folder && lock.releaseAt > now) {
    return false;
  }

  replyLocks.set(quotedId, {
    folder,
    releaseAt: now + 15000,
  });

  setTimeout(() => {
    const current = replyLocks.get(quotedId);
    if (current && current.folder === folder) {
      replyLocks.delete(quotedId);
    }
  }, 15000);

  return true;
}

// ============================================================
// REGISTER SESSION
// ============================================================
export function registerSession(messageId, chatJid, handler, meta = {}, opts = {}) {
  if (!messageId || !chatJid || typeof handler !== 'function') {
    console.log(chalk.red(`[SESSION] registerSession gagal: argumen tidak valid`));
    return null;
  }

  if (chatJid.endsWith('@g.us')) {
    const groupId = chatJid.split('@')[0];
    const botService = getBotService(groupId);
    const myBotNumber = opts.myBotNumber;

    if (botService !== 'dynamic' && myBotNumber && botService !== myBotNumber) {
      if (config.mode === 'development') {
        console.log(chalk.gray(`[SESSION] Skip ${messageId.substring(0, 8)} — bukan bot_service`));
      }
      return null;
    }
  }

  const {
    once = true,
    timeoutMs = 10 * 60 * 1000,
    senderJid = null,
    senderJids = null,
    validateSender = false,
    tag = null,
    onExpire = null,
  } = opts;

  if (sessions.has(messageId)) {
    _clearSessionInternal(messageId);
  }

  // ✅ Kumpulkan semua identifier sender (array)
  const finalSenderJids = Array.isArray(senderJids) && senderJids.length > 0
    ? senderJids.filter(Boolean)
    : (senderJid ? [senderJid] : []);

  const now = Date.now();
  const session = {
    id: messageId,
    chatJid,
    senderJid,
    senderJids: finalSenderJids,
    handler,
    meta,
    once,
    validateSender,
    tag,
    onExpire,
    createdAt: now,
    expireAt: now + timeoutMs,
    timeoutId: null,
  };

  if (timeoutMs > 0) {
    session.timeoutId = setTimeout(() => {
      _expireSession(messageId);
    }, timeoutMs);
  }

  sessions.set(messageId, session);

  if (!chatSessions.has(chatJid)) chatSessions.set(chatJid, new Set());
  chatSessions.get(chatJid).add(messageId);
  lastPromptByChat.set(chatJid, messageId);

  console.log(
    chalk.magenta(`[SESSION] `) +
    chalk.white(messageId.substring(0, 12)) +
    chalk.gray(` (${chatJid.split('@')[0]})`) +
    (tag ? chalk.cyan(` [${tag}]`) : '') +
    chalk.gray(` once=${once} validate=${validateSender}`) +
    (finalSenderJids.length > 0 ? chalk.gray(` ids=${finalSenderJids.length}`) : '')
  );

  return messageId;
}

// ============================================================
// HANDLE REPLY
// ============================================================
export async function handleReply(sock, msg, folder) {
  const key = msg.key || {};
  const ctxInfo = msg.message?.extendedTextMessage?.contextInfo;

  if (!ctxInfo?.quotedMessage) return false;

  const quotedId = ctxInfo.stanzaId;
  if (!quotedId) return false;

  const session = sessions.get(quotedId);
  if (!session) return false;

  // Cek bot service
  if (session.chatJid.endsWith('@g.us')) {
    const groupId = session.chatJid.split('@')[0];
    const botService = getBotService(groupId);
    const myBotNumber = sock.user?.id?.split(':')[0]?.split('@')[0];

    if (botService !== 'dynamic' && botService !== myBotNumber) {
      if (config.mode === 'development') {
        console.log(chalk.gray(`[SESSION] Skip reply ${quotedId.substring(0, 8)} — bukan bot_service`));
      }
      return false;
    }
  }

  // Lock reply
  if (!tryLockReply(quotedId, folder)) {
    if (config.mode === 'development') {
      console.log(chalk.gray(`[SESSION] Skip reply ${quotedId.substring(0, 8)} — sedang diproses sesi lain`));
    }
    return false;
  }

  const text = _extractText(msg);
  if (!text) return false;

  // ✅ VALIDASI SENDER — support array senderJids
  const identity = _getSenderIdentity(msg);
  if (session.validateSender) {
    const storedIds = session.senderJids?.length
      ? session.senderJids
      : (session.senderJid ? [session.senderJid] : []);

    const matched = storedIds.length === 0
      ? true // kalau tidak ada ID tersimpan → izinkan (backward compat)
      : storedIds.some((id) => _matchesSender(id, identity));

    if (!matched) {
      if (config.mode === 'development') {
        console.log(chalk.yellow(`[SESSION] Reject sender mismatch:`), {
          expected: storedIds,
          gotNomor: identity.nomor,
          gotLid: identity.lid,
          gotRaw: identity.rawJid,
        });
      }
      return false;
    }
  }

  const ctx = {
    sock,
    msg,
    text,
    folder,
    meta: session.meta,
    session: {
      id: session.id,
      chatJid: session.chatJid,
      tag: session.tag,
      createdAt: session.createdAt,
      expireAt: session.expireAt,
    },
    reply: (teks, opts = {}) => _safeReply(sock, key.remoteJid, teks, msg, opts),
    replyMedia: (media, opts = {}) => _safeReplyMedia(sock, key.remoteJid, media, msg, opts),
    register: (newMsgId, handler, meta, opts) =>
      registerSession(newMsgId, session.chatJid, handler, meta, {
        ...opts,
        myBotNumber: sock.user?.id?.split(':')[0]?.split('@')[0],
      }),
    clear: () => clearSession(session.id),
  };

  try {
    await session.handler(ctx);
  } catch (err) {
    console.error(chalk.red(`[SESSION ERROR]`), err?.message || err);
  }

  if (session.once) {
    _clearSessionInternal(quotedId);
  }

  return true;
}

// ============================================================
// HANDLE NO-REPLY (dimatikan)
// ============================================================
export async function handleNoReply(sock, msg, folder) {
  return false;
}

// ============================================================
// PUBLIC HELPERS
// ============================================================
export function clearSession(messageId) {
  _clearSessionInternal(messageId);
}

export function clearChatSessions(chatJid) {
  const set = chatSessions.get(chatJid);
  if (!set) return 0;
  let count = 0;
  for (const id of [...set]) {
    _clearSessionInternal(id);
    count++;
  }
  return count;
}

export function hasActiveSession(chatJid) {
  const set = chatSessions.get(chatJid);
  return !!(set && set.size > 0);
}

export function isActiveSession(messageId) {
  return sessions.has(messageId);
}

export function getSession(messageId) {
  return sessions.get(messageId) || null;
}

export function getSessionStats() {
  return {
    total: sessions.size,
    chats: chatSessions.size,
    lastPromptChats: lastPromptByChat.size,
    details: [...sessions.values()].map(s => ({
      id: s.id.substring(0, 12),
      chat: s.chatJid.split('@')[0],
      tag: s.tag,
      once: s.once,
      age: Math.round((Date.now() - s.createdAt) / 1000) + 's',
      ttl: Math.round((s.expireAt - Date.now()) / 1000) + 's',
    })),
  };
}

// ============================================================
// INTERNAL
// ============================================================
function _clearSessionInternal(messageId) {
  const s = sessions.get(messageId);
  if (!s) return;

  if (s.timeoutId) clearTimeout(s.timeoutId);
  sessions.delete(messageId);

  const set = chatSessions.get(s.chatJid);
  if (set) {
    set.delete(messageId);
    if (set.size === 0) chatSessions.delete(s.chatJid);
  }

  if (lastPromptByChat.get(s.chatJid) === messageId) {
    const remaining = chatSessions.get(s.chatJid);
    if (remaining && remaining.size > 0) {
      let newestId = null;
      let newestTime = 0;
      for (const id of remaining) {
        const ss = sessions.get(id);
        if (ss && ss.createdAt > newestTime) {
          newestTime = ss.createdAt;
          newestId = id;
        }
      }
      if (newestId) lastPromptByChat.set(s.chatJid, newestId);
      else lastPromptByChat.delete(s.chatJid);
    } else {
      lastPromptByChat.delete(s.chatJid);
    }
  }
}

function _expireSession(messageId) {
  const s = sessions.get(messageId);
  if (!s) return;

  console.log(
    chalk.gray(`[SESSION EXPIRED] `) +
    chalk.white(messageId.substring(0, 12)) +
    chalk.gray(` (${s.chatJid.split('@')[0]})`)
  );

  if (typeof s.onExpire === 'function') {
    try {
      Promise.resolve(s.onExpire({ meta: s.meta, chatJid: s.chatJid })).catch(() => {});
    } catch (_) {}
  }

  _clearSessionInternal(messageId);
}

function _extractText(msg) {
  const t =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption ||
    msg.message?.buttonsResponseMessage?.selectedButtonId ||
    msg.message?.listResponseMessage?.singleSelectReply?.selectedRowId ||
    '';
  const s = String(t).trim();
  return s.length > 0 ? s : null;
}

// ============================================================
// SENDER IDENTITY (nomor + LID)
// ============================================================
function _getSenderIdentity(msg) {
  const key = msg.key || {};
  const remoteJid = key.remoteJid || '';
  const isGroup = remoteJid.endsWith('@g.us');

  const rawJid = isGroup ? (key.participant || '') : remoteJid;

  let nomor = null;
  let lid = null;

  if (rawJid.endsWith('@s.whatsapp.net')) {
    nomor = rawJid.split('@')[0].split(':')[0];
  } else if (rawJid.endsWith('@lid')) {
    lid = rawJid;
  }

  if (!nomor && key.senderPn?.endsWith('@s.whatsapp.net')) {
    nomor = key.senderPn.split('@')[0].split(':')[0];
  }
  if (!nomor && key.participantAlt?.endsWith('@s.whatsapp.net')) {
    nomor = key.participantAlt.split('@')[0].split(':')[0];
  }
  if (!nomor && key.remoteJidAlt?.endsWith('@s.whatsapp.net')) {
    nomor = key.remoteJidAlt.split('@')[0].split(':')[0];
  }

  if (!lid && key.senderLid?.endsWith('@lid')) {
    lid = key.senderLid;
  }

  return {
    rawJid,
    nomor,
    lid,
    nomorJid: nomor ? `${nomor}@s.whatsapp.net` : null,
  };
}

// ============================================================
// MATCH SENDER (nomor OR LID)
// ============================================================
function _matchesSender(senderJid, identity) {
  if (!senderJid) return false;

  const normalizeJid = (jid) => String(jid).split(':')[0].trim();

  const storedJid = normalizeJid(senderJid);
  const currentNomorJid = identity.nomorJid;
  const currentLid = identity.lid;

  // Match nomor lengkap
  if (currentNomorJid && storedJid === currentNomorJid) return true;

  // Match LID lengkap
  if (currentLid && storedJid === currentLid) return true;

  // Match nomor mentah
  if (identity.nomor && storedJid === identity.nomor) return true;

  // Match LID mentah (tanpa @lid)
  if (currentLid && storedJid === currentLid.split('@')[0]) return true;

  return false;
}

async function _safeReply(sock, jid, teks, quotedMsg, opts = {}) {
  try {
    const { sendText } = await import('./whatsapp/sendmsg.js');
    return await sendText(sock, jid, teks, { quoted: quotedMsg, ...opts });
  } catch (err) {
    const m = err?.message || String(err);
    if (m.includes('negative publish ack') || m.includes('error=463')) {
      console.log(chalk.yellow(`[SESSION SKIP] 463 timelock`));
      return null;
    }
    console.error(chalk.red(`[SESSION reply error]`), m);
    return null;
  }
}

async function _safeReplyMedia(sock, jid, media, quotedMsg, opts = {}) {
  try {
    const { sendMedia } = await import('./whatsapp/sendmsg.js');
    return await sendMedia(sock, jid, media, { quoted: quotedMsg, ...opts });
  } catch (err) {
    const m = err?.message || String(err);
    if (m.includes('negative publish ack') || m.includes('error=463')) {
      console.log(chalk.yellow(`[SESSION SKIP] 463 timelock`));
      return null;
    }
    console.error(chalk.red(`[SESSION media error]`), m);
    return null;
  }
}