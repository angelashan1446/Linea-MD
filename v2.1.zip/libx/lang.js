// libx/lang.js
// Sistem bahasa global: ID (Indonesia), CH (中文), UK (English).
// Kamus teks tetap di masing-masing plugin — file ini cuma helper.

import { getUserLang, setUserLang } from './db.js';
import { getGroupLang } from './grup_db.js';

// ============================================================
// DAFTAR BAHASA
// ============================================================
export const LANGS = {
  id: { code: 'id', label: 'Indonesia 🇮🇩', flag: '🇮🇩' },
  ch: { code: 'ch', label: '中文 🇨🇳',      flag: '🇨🇳' },
  uk: { code: 'uk', label: 'English 🇬🇧',  flag: '🇬🇧' },
};

// ✅ Default bahasa user = UK (English)
export const DEFAULT_LANG = 'uk';

/**
 * Cek apakah kode bahasa valid.
 * @param {string} code
 * @returns {boolean}
 */
export function isValidLang(code) {
  return !!LANGS[String(code || '').toLowerCase().trim()];
}

// ============================================================
// PARSER INPUT BAHASA
// ============================================================
/**
 * Parse input user → kode bahasa.
 * Support: angka (1/2/3), kode (id/ch/uk), alias (indonesia/english/中文/dll).
 * @param {string} input
 * @returns {'id'|'ch'|'uk'|null}
 */
export function parseLangInput(input) {
  const s = String(input || '').toLowerCase().trim();
  if (!s) return null;

  // Angka
  if (s === '1') return 'id';
  if (s === '2') return 'ch';
  if (s === '3') return 'uk';

  // Kode / alias
  if (['id', 'ind', 'indonesia', 'indonesian'].includes(s)) return 'id';
  if (['ch', 'zh', 'cn', 'china', 'chinese', '中文'].includes(s)) return 'ch';
  if (['uk', 'en', 'eng', 'english'].includes(s)) return 'uk';

  return null;
}

// ============================================================
// GETTER: bahasa user dari DB
// ============================================================
/**
 * Ambil bahasa user dari database.
 * Fallback ke DEFAULT_LANG ('uk') kalau user tidak ada / kode tidak valid.
 * @param {{lid?:string, nomor?:string}} sender
 * @returns {'id'|'ch'|'uk'}
 */
export function langOf({ lid, nomor } = {}) {
  const l = getUserLang({ lid, nomor });
  return isValidLang(l) ? l : DEFAULT_LANG;
}

/**
 * Ambil bahasa user, fallback 'uk' (English) kalau belum terdaftar.
 * Cocok untuk plugin yang bisa dipakai sebelum user daftar.
 * @param {{lid?:string, nomor?:string}} sender
 * @returns {'id'|'ch'|'uk'}
 */
export function langOfOrGuest({ lid, nomor } = {}) {
  const l = getUserLang({ lid, nomor });
  if (!l) return 'uk'; // fallback universal
  return isValidLang(l) ? l : DEFAULT_LANG;
}

// ============================================================
// RESOLVE LANG KONTEKSTUAL (user → grup → fallback)
// ============================================================
/**
 * Resolve bahasa kontekstual berdasarkan:
 *   1. user.lang (kalau user terdaftar & valid)
 *   2. grup_lang (kalau di grup & valid)
 *   3. fallback 'uk' (English universal)
 *
 * @param {{ user?: any, isGroup?: boolean, remoteJid?: string }} opts
 * @returns {'id'|'ch'|'uk'}
 */
export function resolveLang({ user, isGroup, remoteJid } = {}) {
  // 1. User personal
  if (user && isValidLang(user.lang)) return user.lang;

  // 2. Bahasa grup
  if (isGroup && remoteJid) {
    try {
      const groupId = remoteJid.split('@')[0];
      const gl = getGroupLang(groupId);
      if (isValidLang(gl)) return gl;
    } catch {}
  }

  // 3. Fallback universal
  return 'uk';
}

// ============================================================
// RE-EXPORT (biar plugin tinggal import dari sini)
// ============================================================
export { getUserLang, setUserLang };