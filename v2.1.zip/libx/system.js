// libx/system.js
// Helper buat baca/tulis db/system.json + sistem anti-spam & rate limit (in-memory).

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SYSTEM_PATH = path.join(__dirname, '..', 'db', 'system.json');

// Default config
const DEFAULT_SYSTEM = {
    selft: false,
    maintenance: false,
    updated_at: new Date().toISOString(),
};

// ==========================================
// HELPER: BACA / TULIS
// ==========================================
function ensureExists() {
    try {
        const dir = path.dirname(SYSTEM_PATH);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        if (!fs.existsSync(SYSTEM_PATH)) {
            fs.writeFileSync(SYSTEM_PATH, JSON.stringify(DEFAULT_SYSTEM, null, 2));
        }
    } catch (err) {
        console.error('[System] ensureExists error:', err.message);
    }
}

export function readSystem() {
    ensureExists();
    try {
        const raw = fs.readFileSync(SYSTEM_PATH, 'utf8');
        const data = JSON.parse(raw);
        return { ...DEFAULT_SYSTEM, ...data };
    } catch (err) {
        console.error('[System] read error:', err.message);
        return { ...DEFAULT_SYSTEM };
    }
}

export function writeSystem(data) {
    try {
        const merged = {
            ...readSystem(),
            ...data,
            updated_at: new Date().toISOString(),
        };
        const tmp = `${SYSTEM_PATH}.tmp.${Date.now()}`;
        fs.writeFileSync(tmp, JSON.stringify(merged, null, 2));
        fs.renameSync(tmp, SYSTEM_PATH);
        return true;
    } catch (err) {
        console.error('[System] write error:', err.message);
        return false;
    }
}

// ==========================================
// PUBLIC GETTERS / SETTERS
// ==========================================
export function isSelft() {
    return readSystem().selft === true;
}

export function setSelft(value) {
    return writeSystem({ selft: Boolean(value) });
}

export function isMaintenance() {
    return readSystem().maintenance === true;
}

export function setMaintenance(value) {
    return writeSystem({ maintenance: Boolean(value) });
}

// ==========================================
// ANTI-SPAM & RATE LIMIT (IN-MEMORY)
// ==========================================
export const SPAM_CONFIG = {
    spamWindowMs: 5_000,             // cmd sama < 5s → spam
    spamPunishMs: 5 * 60 * 1_000,    // punish 5 menit
    userRateMs: 5_000,               // 1 cmd / 5s (private)
    groupRateMs: 3_000,              // 1 cmd / 3s (grup)
};

// Map<userId, { lastCmd, lastCmdAt, punishUntil }>
const userSpamState = new Map();
// Map<userId, { lastAt }>  -- rate limit user
const userRateState = new Map();
// Map<groupId, { lastAt }> -- rate limit grup
const groupRateState = new Map();

function userKey({ lid, nomor }) {
    if (lid) return `lid:${lid}`;
    if (nomor) return `pn:${nomor}`;
    return null;
}

// Cleanup berkala biar Map ga numpuk
setInterval(() => {
    const now = Date.now();
    for (const [k, v] of userSpamState) {
        const stillPunished = v.punishUntil && v.punishUntil > now;
        const recent = v.lastCmdAt && now - v.lastCmdAt < 10 * 60_000;
        if (!stillPunished && !recent) userSpamState.delete(k);
    }
    for (const [k, v] of userRateState) {
        if (now - v.lastAt > 60_000) userRateState.delete(k);
    }
    for (const [k, v] of groupRateState) {
        if (now - v.lastAt > 60_000) groupRateState.delete(k);
    }
}, 60_000).unref?.();

/**
 * Cek apakah user sedang di-punish karena spam.
 */
export function isSpamPunished({ lid, nomor }) {
    const key = userKey({ lid, nomor });
    if (!key) return { punished: false };

    const state = userSpamState.get(key);
    if (!state?.punishUntil) return { punished: false };

    const now = Date.now();
    if (state.punishUntil > now) {
        return { punished: true, sisaMs: state.punishUntil - now };
    }

    // Sudah lewat, reset
    state.punishUntil = null;
    userSpamState.set(key, state);
    return { punished: false };
}

/**
 * Catat command, deteksi spam (cmd + args sama persis < 5s).
 * @returns {{ isSpam: boolean, punishMs?: number }}
 */
export function checkSpam({ lid, nomor }, rawBody) {
    const key = userKey({ lid, nomor });
    if (!key) return { isSpam: false };

    const now = Date.now();
    const state = userSpamState.get(key);

    // Kalau lagi di-punish, skip (ditangani isSpamPunished)
    if (state?.punishUntil && state.punishUntil > now) {
        return { isSpam: false };
    }

    // Spam: rawBody sama persis & < 5s
    if (
        state &&
        state.lastCmd === rawBody &&
        state.lastCmdAt &&
        now - state.lastCmdAt < SPAM_CONFIG.spamWindowMs
    ) {
        userSpamState.set(key, {
            lastCmd: rawBody,
            lastCmdAt: now,
            punishUntil: now + SPAM_CONFIG.spamPunishMs,
        });
        return { isSpam: true, punishMs: SPAM_CONFIG.spamPunishMs };
    }

    // Bukan spam → update state
    userSpamState.set(key, {
        lastCmd: rawBody,
        lastCmdAt: now,
        punishUntil: state?.punishUntil && state.punishUntil > now ? state.punishUntil : null,
    });

    return { isSpam: false };
}

/**
 * Cek rate limit user (private).
 */
export function checkUserRateLimit({ lid, nomor }) {
    const key = userKey({ lid, nomor });
    if (!key) return { limited: false };

    const now = Date.now();
    const state = userRateState.get(key);
    const windowMs = SPAM_CONFIG.userRateMs;

    if (state && now - state.lastAt < windowMs) {
        return { limited: true, sisaMs: windowMs - (now - state.lastAt) };
    }

    userRateState.set(key, { lastAt: now });
    return { limited: false };
}

/**
 * Cek rate limit grup.
 */
export function checkGroupRateLimit(groupId) {
    if (!groupId) return { limited: false };

    const now = Date.now();
    const state = groupRateState.get(groupId);
    const windowMs = SPAM_CONFIG.groupRateMs;

    if (state && now - state.lastAt < windowMs) {
        return { limited: true, sisaMs: windowMs - (now - state.lastAt) };
    }

    groupRateState.set(groupId, { lastAt: now });
    return { limited: false };
}

// Reset (owner / debug)
export function resetUserRateLimit({ lid, nomor }) {
    const key = userKey({ lid, nomor });
    if (key) userRateState.delete(key);
}

export function resetGroupRateLimit(groupId) {
    if (groupId) groupRateState.delete(groupId);
}

export function resetSpamPunish({ lid, nomor }) {
    const key = userKey({ lid, nomor });
    if (!key) return false;
    const state = userSpamState.get(key);
    if (state) {
        state.punishUntil = null;
        userSpamState.set(key, state);
    }
    return true;
}

/**
 * Format durasi ms → string (detik / menit / jam)
 */
export function formatDuration(ms) {
    const s = Math.ceil(ms / 1000);
    if (s < 60) return `${s} detik`;
    const m = Math.floor(s / 60);
    const rs = s % 60;
    if (m < 60) return rs > 0 ? `${m} menit ${rs} detik` : `${m} menit`;
    const h = Math.floor(m / 60);
    const rm = m % 60;
    return rm > 0 ? `${h} jam ${rm} menit` : `${h} jam`;
}

// Auto-create file
ensureExists();

export default {
    // DB system.json
    readSystem,
    writeSystem,
    isSelft,
    setSelft,
    isMaintenance,
    setMaintenance,

    // Anti-spam & rate limit
    SPAM_CONFIG,
    isSpamPunished,
    checkSpam,
    checkUserRateLimit,
    checkGroupRateLimit,
    resetUserRateLimit,
    resetGroupRateLimit,
    resetSpamPunish,
    formatDuration,
};