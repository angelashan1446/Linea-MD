// libx/verify_db.js
import fs from 'fs';
import path from 'path';

const DB_FILE = path.join(process.cwd(), 'db', 'verify.json');
const NOTIF_COOLDOWN_MS = 3 * 60 * 60 * 1000; // 1 jam
const LOCK_MS = 30000; // 5 detik

// Lock di RAM (biar cepet, nggak perlu baca JSON)
const notifyLocks = new Map();

function readDb() {
    try {
        if (!fs.existsSync(DB_FILE)) {
            fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
            fs.writeFileSync(DB_FILE, JSON.stringify({ users: {} }, null, 2));
            return { users: {} };
        }
        const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
        if (!data.users) data.users = {};
        return data;
    } catch {
        return { users: {} };
    }
}

function writeDb(data) {
    try {
        fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[VerifyDB] Gagal tulis:', e.message);
    }
}

// ============================================================
// VERIFIKASI USER
// ============================================================
export function isVerified(userId) {
    const db = readDb();
    return db.users[userId]?.is_bot === false;
}

export function generateCode() {
    return Math.floor(10000000 + Math.random() * 90000000).toString();
}

export function saveVerification(userId, code) {
    const db = readDb();
    db.users[userId] = {
        code: code,
        is_bot: true,
        created_at: new Date().toISOString(),
        last_notif: 0, // ✅ Satu timer untuk semua notif
    };
    writeDb(db);
}

export function getVerification(userId) {
    const db = readDb();
    return db.users[userId] || null;
}

export function markVerified(userId) {
    const db = readDb();
    if (db.users[userId]) {
        db.users[userId].is_bot = false;
        db.users[userId].verified_at = new Date().toISOString();
        writeDb(db);
        return true;
    }
    return false;
}

export function containsCode(userId, text) {
    const db = readDb();
    const code = db.users[userId]?.code;
    if (!code) return false;
    const cleanText = String(text).replace(/\D/g, '');
    return cleanText.includes(code);
}

// ============================================================
// ✅ NOTIF COOLDOWN (SATU TIMER UNTUK SEMUA TIPE)
// ============================================================
/**
 * Cek apakah boleh kirim notif (apapun tipenya).
 * @param {string} userId
 * @returns {boolean}
 */
export function canNotify(userId) {
    const db = readDb();
    const user = db.users[userId];
    if (!user) return true;

    // ✅ Cek lock (cegah dobel dari sesi lain)
    const lockKey = userId;
    const lock = notifyLocks.get(lockKey);
    if (lock && Date.now() - lock < LOCK_MS) {
        return false; // Lagi di-lock bot lain
    }

    const last = user.last_notif || 0;
    return Date.now() - last > NOTIF_COOLDOWN_MS;
}

/**
 * Update waktu notif terakhir (satu timer untuk semua tipe).
 * @param {string} userId
 */
export function updateNotifTime(userId) {
    const db = readDb();
    if (db.users[userId]) {
        db.users[userId].last_notif = Date.now();
        writeDb(db);

        // ✅ Set lock 5 detik (biar bot lain nggak kirim notif yang sama)
        notifyLocks.set(userId, Date.now());
        setTimeout(() => notifyLocks.delete(userId), LOCK_MS);
    }
}

// ============================================================
// CLEANUP (biar JSON nggak numpuk)
// ============================================================
export function cleanupOldNotifs() {
    const db = readDb();
    const now = Date.now();
    const MAX_AGE = 24 * 60 * 60 * 1000; // 24 jam

    let changed = false;
    for (const [uid, user] of Object.entries(db.users)) {
        if (user.is_bot === false) {
            if (user.last_notif && now - user.last_notif > MAX_AGE) {
                delete user.last_notif;
                changed = true;
            }
        }
    }
    if (changed) writeDb(db);
}