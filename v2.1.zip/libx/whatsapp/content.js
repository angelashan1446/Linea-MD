/**
 * Penerjemah konten pesan: bentuk Baileys -> bentuk zapo-js.
 */

import { Readable } from 'stream';
import { fileTypeFromBuffer, fileTypeFromFile } from 'file-type';

const MEDIA_KEYS = {
  image: 'image',
  video: 'video',
  audio: 'audio',
  document: 'document',
  sticker: 'sticker',
  ptv: 'ptv',
};

const OPTION_ONLY_KEYS = new Set([
  'mentions',
  'contextInfo',
  'quoted',
  'ephemeralExpiration',
  'viewOnce',
  'linkPreview',
]);

const isBuffer = (v) => typeof Buffer !== 'undefined' && Buffer.isBuffer(v);
const isStream = (v) => v instanceof Readable;

export function isRawProtoMessage(content) {
  return !!content && typeof content === 'object' && Object.keys(content).length > 0;
}

async function resolveMedia(value) {
  if (value == null) return value;
  if (isBuffer(value) || value instanceof Uint8Array || isStream(value)) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);

  if (typeof value === 'string') return fromUrlOrPath(value);

  if (typeof value === 'object') {
    if (value.url) return fromUrlOrPath(value.url);
    if (value.stream) return value.stream;
    if (value.buffer) return value.buffer;
  }
  return value;
}

async function fromUrlOrPath(str) {
  if (!/^https?:\/\//i.test(str)) return str;
  const res = await fetch(str);
  if (!res.ok) throw new Error(`Gagal mengunduh media (${res.status}): ${str}`);
  return new Uint8Array(await res.arrayBuffer());
}

const FALLBACK_MIMETYPES = {
  image: 'image/jpeg',
  video: 'video/mp4',
  ptv: 'video/mp4',
  audio: 'audio/mpeg',
  sticker: 'image/webp',
  document: 'application/octet-stream',
};

async function resolveMimetype(media, type, content) {
  if (content.mimetype) return content.mimetype;
  if (type === 'audio' && content.ptt) return 'audio/ogg; codecs=opus';

  try {
    if (isBuffer(media) || media instanceof Uint8Array) {
      const detected = await fileTypeFromBuffer(media);
      if (detected?.mime) return detected.mime;
    } else if (typeof media === 'string' && !/^https?:\/\//i.test(media)) {
      const detected = await fileTypeFromFile(media);
      if (detected?.mime) return detected.mime;
    }
  } catch {
    // abaikan error deteksi
  }

  return FALLBACK_MIMETYPES[type] ?? 'application/octet-stream';
}

function copyMediaExtras(source, target) {
  for (const [key, value] of Object.entries(source)) {
    if (value === undefined) continue;
    if (OPTION_ONLY_KEYS.has(key)) continue;
    if (key in MEDIA_KEYS) continue;
    if (key === 'ptt' || key === 'gifPlayback') {
      target[key] = value;
      continue;
    }
    target[key] = value;
  }
}

function isJidValid(jid) {
  return typeof jid === 'string' && /^[^@\s]+@[\w.-]+$/.test(jid);
}

export function buildSendOptions(content, baileysOptions = {}) {
  const options = {};

  const mentions = content?.mentions ?? content?.contextInfo?.mentionedJid;
  const mentionsValid = Array.isArray(mentions) ? mentions.filter(isJidValid) : [];
  if (mentionsValid.length) options.mentions = mentionsValid;

  // ===== FIX QUOTED UNTUK ZAPO =====
  const quoted = baileysOptions.quoted;
  if (quoted && quoted.key) {
    // zapo membutuhkan objek key dan message asli dari pesan yang dibalas
    options.quote = {
      key: quoted.key,
      message: quoted.message
    };
  }

  const rawContext = content?.contextInfo;
  if (rawContext && typeof rawContext === 'object') {
    const raw = Array.isArray(rawContext.mentionedJid)
      ? { ...rawContext, mentionedJid: rawContext.mentionedJid.filter(isJidValid) }
      : rawContext;
    options.contextInfo = { raw };
  }

  const expiration = baileysOptions.ephemeralExpiration ?? content?.ephemeralExpiration;
  if (expiration) options.expirationSeconds = Number(expiration);
  if (baileysOptions.messageId) options.id = baileysOptions.messageId;

  return options;
}

export async function toZapoContent(content) {
  if (typeof content === 'string') return { type: 'text', text: content };
  if (!content || typeof content !== 'object') {
    throw new Error('Konten pesan tidak valid');
  }

  if (content.react) {
    return { type: 'reaction', emoji: content.react.text ?? '', target: content.react.key };
  }
  if (content.delete) {
    return { type: 'revoke', target: content.delete };
  }
  if (content.poll) {
    return {
      type: 'poll',
      name: content.poll.name,
      options: content.poll.values ?? content.poll.options ?? [],
      selectableCount: content.poll.selectableCount ?? 1,
    };
  }
  if (content.pin) {
    return {
      type: content.pin.type === 2 || content.pin.unpin ? 'unpin' : 'pin',
      target: content.pin.key ?? content.pin,
      durationSecs: content.pin.time ?? undefined,
    };
  }
  if (content.location) {
    return { locationMessage: content.location };
  }
  if (content.contacts) {
    const list = content.contacts.contacts ?? [];
    if (list.length === 1) return { contactMessage: list[0] };
    return {
      contactsArrayMessage: {
        displayName: content.contacts.displayName ?? `${list.length} contacts`,
        contacts: list,
      },
    };
  }

  for (const [key, type] of Object.entries(MEDIA_KEYS)) {
    if (content[key] === undefined) continue;

    const out = { type, media: await resolveMedia(content[key]) };
    copyMediaExtras(content, out);
    delete out[key];
    out.mimetype = await resolveMimetype(out.media, type, content);
    return out;
  }

  if (typeof content.text === 'string') {
    const out = { type: 'text', text: content.text };
    if (content.linkPreview === false) out.linkPreview = false;
    return out;
  }
  if (typeof content.caption === 'string') {
    return { type: 'text', text: content.caption };
  }

  if (isRawProtoMessage(content)) return content;

  throw new Error(`Bentuk konten tidak dikenali: ${Object.keys(content).join(', ')}`);
}