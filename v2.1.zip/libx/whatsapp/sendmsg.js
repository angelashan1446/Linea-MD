// libx/whatsapp/sendmsg.js
// Wrapper pengiriman pesan dengan sistem antrean (queue) + rate limit TERPISAH per bot.
// - Setiap bot (folder) punya antreannya sendiri.
// - Bot utama dan jadibot tidak akan saling mengunci (lemot).
// - Status disimpan di db/queue_msg.json agar bisa dilanjutkan setelah restart.

import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import { sessions } from './connect.js';

// ==========================================
// QUEUE CONFIG
// ==========================================
const QUEUE_FILE = path.join(process.cwd(), 'db', 'queue_msg.json');
const MIN_DELAY = 5000; // 8 detik
const MAX_DELAY = 5000; // 15 detik

// ==========================================
// QUEUE INTERNAL STATE
// ==========================================
// Map untuk menyimpan antrean per folder (bot)
// Format: Map<folder, { queue: Array, isProcessing: boolean }>
const queues = new Map();
let queueIdCounter = 0;

// ==========================================
// QUEUE: FILE STORAGE
// ==========================================
function ensureQueueDir() {
    const dir = path.dirname(QUEUE_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(QUEUE_FILE)) fs.writeFileSync(QUEUE_FILE, JSON.stringify({ queues: {} }, null, 2));
}

function saveQueue() {
    ensureQueueDir();
    try {
        const data = { queues: {} };
        for (const [folder, q] of queues.entries()) {
            // Hanya simpan item yang belum terkirim (pending/sending)
            const pendingItems = q.queue.filter(i => i.status === 'pending' || i.status === 'sending');
            if (pendingItems.length > 0) {
                // Hapus properti _resolve & _reject karena tidak bisa di-serialize
                data.queues[folder] = pendingItems.map(item => {
                    const { _resolve, _reject, ...rest } = item;
                    return rest;
                });
            }
        }
        fs.writeFileSync(QUEUE_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error(chalk.red(`[QUEUE] Gagal simpan queue: ${e.message}`));
    }
}

function loadQueueFromDisk() {
    ensureQueueDir();
    try {
        const data = JSON.parse(fs.readFileSync(QUEUE_FILE, 'utf8'));
        // Support format lama (array) dan format baru (object queues)
        if (Array.isArray(data.messages)) return { default: data.messages };
        return data.queues || {};
    } catch {
        return {};
    }
}

// ==========================================
// QUEUE: GET OR CREATE PER FOLDER
// ==========================================
function getQueue(folder) {
    const key = folder || 'default';
    if (!queues.has(key)) {
        queues.set(key, {
            queue: [],
            isProcessing: false,
        });
    }
    return queues.get(key);
}

// ==========================================
// QUEUE: ADD MESSAGE
// ==========================================
/**
 * Tambahkan pesan ke antrean bot tertentu.
 * @param {string} folder - Nama sesi (folder bot)
 * @param {string} jid - Tujuan
 * @param {object} content - Konten pesan (Baileys style)
 * @param {object} opts - Opsi tambahan (quoted, mentions, dll)
 * @returns {Promise<object>} - Resolve saat pesan BENAR-BENAR terkirim
 */
function enqueue(folder, jid, content, opts = {}) {
    return new Promise((resolve, reject) => {
        const id = ++queueIdCounter + '-' + Date.now();
        const item = {
            id,
            folder: folder || 'default',
            jid,
            content,
            opts,
            status: 'pending', // pending | sending | sent | failed
            created_at: new Date().toISOString(),
            sent_at: null,
            error: null,
            _resolve: resolve,
            _reject: reject,
        };

        const q = getQueue(folder);
        q.queue.push(item);
        saveQueue();
        processQueue(folder);
    });
}

// ==========================================
// QUEUE: WORKER (PER FOLDER)
// ==========================================
async function processQueue(folder) {
    const key = folder || 'default';
    const q = getQueue(key);

    if (q.isProcessing) return;
    if (q.queue.length === 0) return;

    q.isProcessing = true;

    while (q.queue.length > 0) {
        // Ambil item pertama yang masih pending
        const item = q.queue.find(i => i.status === 'pending');
        if (!item) break;

        item.status = 'sending';
        saveQueue();

        try {
            // Resolve socket khusus folder ini
            const sock = sessions.get(item.folder);
            if (!sock) throw new Error(`Session "${item.folder}" tidak ditemukan / belum connect`);

            // Kirim pesan
            const result = await sock.sendMessage(item.jid, item.content, item.opts);

            // Tandai sukses
            item.status = 'sent';
            item.sent_at = new Date().toISOString();
            saveQueue();

            // Resolve promise ke pemanggil
            if (item._resolve) item._resolve(result);

            // Hapus item yang sudah terkirim dari queue (setelah delay)
            setTimeout(() => {
                q.queue = q.queue.filter(i => i.id !== item.id);
                saveQueue();
            }, 1000);

        } catch (err) {
            // Tandai gagal
            item.status = 'failed';
            item.error = err?.message || String(err);
            saveQueue();

            console.error(chalk.red(`[QUEUE][${key}] Gagal kirim ke ${item.jid}: ${item.error}`));
            if (item._reject) item._reject(err);

            // Hapus item gagal setelah 5 detik
            setTimeout(() => {
                q.queue = q.queue.filter(i => i.id !== item.id);
                saveQueue();
            }, 5000);
        }

        // Delay antar pesan: random 8-15 detik (HANYA untuk folder ini)
        const delay = MIN_DELAY + Math.random() * (MAX_DELAY - MIN_DELAY);
        await new Promise(r => setTimeout(r, delay));
    }

    q.isProcessing = false;
}

// ==========================================
// QUEUE: RESUME ON STARTUP
// ==========================================
/**
 * Muat ulang queue dari disk saat startup.
 * Panggil ini sekali di main.js setelah koneksi siap.
 */
export function resumeQueue() {
    const saved = loadQueueFromDisk();
    const folders = Object.keys(saved);
    if (folders.length === 0) return;

    let totalResumed = 0;
    
    for (const folder of folders) {
        const savedItems = saved[folder];
        if (!Array.isArray(savedItems) || savedItems.length === 0) continue;

        const q = getQueue(folder);
        for (const item of savedItems) {
            if (item.status === 'sending' || item.status === 'pending') {
                // Reset status & buat promise dummy
                item.status = 'pending';
                item._resolve = () => {};
                item._reject = () => {};
                q.queue.push(item);
                totalResumed++;
            }
        }
        
        if (q.queue.length > 0) {
            processQueue(folder);
        }
    }

    if (totalResumed > 0) {
        console.log(chalk.yellow(`[QUEUE] Melanjutkan ${totalResumed} pesan tertunda di ${folders.length} bot...`));
    }
    saveQueue();
}

// ==========================================
// QUEUE: STATS (untuk debugging)
// ==========================================
export function getQueueStats() {
    const stats = {};
    let totalAll = 0;

    for (const [folder, q] of queues.entries()) {
        const pending = q.queue.filter(i => i.status === 'pending').length;
        const sending = q.queue.filter(i => i.status === 'sending').length;
        const sent = q.queue.filter(i => i.status === 'sent').length;
        const failed = q.queue.filter(i => i.status === 'failed').length;
        
        stats[folder] = {
            total: q.queue.length,
            pending,
            sending,
            sent,
            failed,
            isProcessing: q.isProcessing,
        };
        totalAll += pending + sending;
    }

    return { bots: stats, totalPending: totalAll };
}

// ==========================================
// CORE: RESOLVE SOCK (untuk helper non-send)
// ==========================================
function resolveSock(sockOrFolder) {
    if (typeof sockOrFolder === 'string') {
        const s = sessions.get(sockOrFolder);
        if (!s) throw new Error(`Session "${sockOrFolder}" tidak ditemukan`);
        return s;
    }
    if (sockOrFolder?.sendMessage) return sockOrFolder;
    throw new Error('Socket tidak valid');
}

// ==========================================
// HELPER: Dapatkan folder dari sockOrFolder
// ==========================================
function getFolder(sockOrFolder) {
    if (typeof sockOrFolder === 'string') return sockOrFolder;
    // Cari folder dari sessions Map
    for (const [folder, sock] of sessions.entries()) {
        if (sock === sockOrFolder) return folder;
    }
    return 'default'; // fallback jika tidak ketemu
}

// ==========================================
// 1. TEKS
// ==========================================
export async function sendText(sockOrFolder, jid, text, opts = {}) {
    return enqueue(getFolder(sockOrFolder), jid, { text }, opts);
}

// ==========================================
// 2. MEDIA DARI BUFFER
// ==========================================
export async function sendMedia(sockOrFolder, jid, media = {}, opts = {}) {
    const { buffer, mimetype, filename, caption } = media;
    if (!buffer || buffer.length === 0) throw new Error('Buffer media kosong');

    const mime = mimetype || 'application/octet-stream';
    const payload = { caption, mimetype: mime, fileName: filename };

    // Gambar (kecuali WebP, karena WebP biasanya untuk sticker)
    if (mime.startsWith('image/') && !mime.includes('webp')) {
        return enqueue(getFolder(sockOrFolder), jid, { image: buffer, ...payload }, opts);
    }
    if (mime.startsWith('video/')) {
        return enqueue(getFolder(sockOrFolder), jid, { video: buffer, ...payload }, opts);
    }
    if (mime.startsWith('audio/')) {
        return enqueue(getFolder(sockOrFolder), jid, { audio: buffer, ...payload }, opts);
    }
    
    // Fallback: dokumen
    return enqueue(getFolder(sockOrFolder), jid, { document: buffer, ...payload }, opts);
}

// ==========================================
// 3. MEDIA DARI FILE LOKAL
// ==========================================
export async function sendMediaFile(sockOrFolder, jid, filePath, opts = {}) {
    if (!fs.existsSync(filePath)) throw new Error(`File tidak ada: ${filePath}`);
    const buffer = fs.readFileSync(filePath);
    const filename = path.basename(filePath);
    const ext = path.extname(filename).toLowerCase();
    
    const mimes = {
        '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
        '.webp': 'image/webp', '.gif': 'image/gif', '.mp4': 'video/mp4',
        '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.pdf': 'application/pdf',
    };

    return sendMedia(sockOrFolder, jid, {
        buffer,
        mimetype: mimes[ext] || 'application/octet-stream',
        filename,
        caption: opts.caption,
    }, opts);
}

// ==========================================
// 4. MEDIA DARI URL
// ==========================================
export async function sendMediaUrl(sockOrFolder, jid, url, opts = {}) {
    try {
        const res = await fetch(url);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        
        const buffer = Buffer.from(await res.arrayBuffer());
        let mimetype = res.headers.get('content-type') || 'application/octet-stream';

        if (mimetype.includes('octet-stream') || !mimetype.includes('/')) {
            const ext = url.split('.').pop().split('?')[0].toLowerCase();
            const mimeMap = {
                'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png',
                'webp': 'image/webp', 'gif': 'image/gif', 'mp4': 'video/mp4',
                'mp3': 'audio/mpeg', 'ogg': 'audio/ogg'
            };
            mimetype = mimeMap[ext] || mimetype;
        }

        return sendMedia(sockOrFolder, jid, { buffer, mimetype, caption: opts.caption }, opts);
    } catch (err) {
        throw new Error(`Gagal download media: ${err.message}`);
    }
}

// ==========================================
// 5. STICKER (Khusus WebP)
// ==========================================
export async function sendSticker(sockOrFolder, jid, buffer, opts = {}) {
    if (!buffer || buffer.length === 0) throw new Error('Buffer sticker kosong');
    return enqueue(getFolder(sockOrFolder), jid, { sticker: buffer }, opts);
}

// ==========================================
// 6. VIDEO NOTE (PTV / Bulat)
// ==========================================
export async function sendVideoNote(sockOrFolder, jid, buffer, opts = {}) {
    if (!buffer || buffer.length === 0) throw new Error('Buffer video kosong');
    return enqueue(getFolder(sockOrFolder), jid, { 
        video: buffer, 
        mimetype: 'video/mp4', 
        ptv: true 
    }, opts);
}

// ==========================================
// 7. EDIT PESAN (Langsung, tanpa antrean)
// ==========================================
export async function editMessage(sockOrFolder, jid, key, newText, opts = {}) {
    const sock = resolveSock(sockOrFolder);
    return sock.sendMessage(jid, { text: newText, edit: key }, opts);
}

// ==========================================
// 8. HAPUS PESAN (Langsung, tanpa antrean)
// ==========================================
export async function deleteMessage(sockOrFolder, jid, key, opts = {}) {
    const sock = resolveSock(sockOrFolder);
    return sock.sendMessage(jid, { delete: key }, opts);
}

// ==========================================
// 9. MENTION
// ==========================================
export async function sendWithMention(sockOrFolder, jid, text, mentions = [], opts = {}) {
    return enqueue(getFolder(sockOrFolder), jid, { text, mentions }, opts);
}

// ==========================================
// 10. REACTION (Langsung, tanpa antrean)
// ==========================================
export async function sendReaction(sockOrFolder, jid, key, emoji, opts = {}) {
    const sock = resolveSock(sockOrFolder);
    return sock.sendMessage(jid, { react: { text: emoji, key } }, opts);
}

// ==========================================
// 11. POLL / VOTE
// ==========================================
export async function sendPoll(sockOrFolder, jid, name, options = [], opts = {}) {
    return enqueue(getFolder(sockOrFolder), jid, { 
        poll: { 
            name, 
            values: options, 
            selectableCount: 1 
        } 
    }, opts);
}

// ==========================================
// 12. LOCATION
// ==========================================
export async function sendLocation(sockOrFolder, jid, latitude, longitude, opts = {}) {
    return enqueue(getFolder(sockOrFolder), jid, { 
        location: { 
            degreesLatitude: latitude, 
            degreesLongitude: longitude 
        } 
    }, opts);
}

// ==========================================
// 13. CONTACT (vCard)
// ==========================================
export async function sendContact(sockOrFolder, jid, contactName, contactNumber, opts = {}) {
    const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${contactName}\nTEL;type=CELL;type=VOICE;waid=${contactNumber}:+${contactNumber}\nEND:VCARD`;
    return enqueue(getFolder(sockOrFolder), jid, { 
        contacts: { 
            displayName: contactName, 
            contacts: [{ vcard }] 
        } 
    }, opts);
}