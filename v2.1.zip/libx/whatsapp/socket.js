/**
 * Facade `sock` bergaya Baileys di atas `WaClient` zapo-js.
 */

import { EventEmitter } from 'events';
import { toZapoContent, buildSendOptions } from './content.js';
import { devlog, isDevLogEnabled, summarizeKey } from './devlog.js';
import { isSignalStoreCorruptError, purgeCorruptSignalRows } from './repair.js';

const stripDevice = (jid) => (typeof jid === 'string' ? jid.replace(/:\d+(?=@)/, '') : jid);

function createLidMappingCache() {
  const lidToPn = new Map();
  const pnToLid = new Map();

  return {
    remember(lidJid, pnJid) {
      const lid = stripDevice(lidJid);
      const pn = stripDevice(pnJid);
      if (!lid?.endsWith('@lid') || !pn?.endsWith('@s.whatsapp.net')) return;
      lidToPn.set(lid, pn);
      pnToLid.set(pn, lid);
    },
    getPn: (lidJid) => lidToPn.get(stripDevice(lidJid)) ?? null,
    getLid: (pnJid) => pnToLid.get(stripDevice(pnJid)) ?? null,
    get size() {
      return lidToPn.size;
    },
  };
}

function normalizeGroupMetadata(metadata, lidCache) {
  if (!metadata || typeof metadata !== 'object') return metadata;

  const participants = (metadata.participants ?? []).map((p) => {
    lidCache.remember(p.lid ?? p.jid, p.phoneNumber);
    const phoneNumber = p.phoneNumber ?? lidCache.getPn(p.lid ?? p.jid) ?? undefined;

    return {
      ...p,
      id: p.jid,
      admin: p.isSuperAdmin ? 'superadmin' : p.isAdmin ? 'admin' : null,
      phoneNumber,
    };
  });

  return {
    ...metadata,
    id: metadata.jid,
    isCommunity: !!metadata.isParentGroup,
    participants,
  };
}

const GROUP_SETTINGS = {
  announcement: ['announcement', true],
  not_announcement: ['announcement', false],
  locked: ['restrict', true],
  unlocked: ['restrict', false],
};

const PARTICIPANT_ACTIONS = {
  add: 'addParticipants',
  remove: 'removeParticipants',
  promote: 'promoteParticipants',
  demote: 'demoteParticipants',
};

// Map untuk mendeteksi tipe media
const MEDIA_TYPE_MAP = {
  imageMessage: 'image',
  videoMessage: 'video',
  audioMessage: 'audio',
  stickerMessage: 'sticker',
  documentMessage: 'document',
};

export function createBaileysCompatSocket(client, deps = {}) {
  const ev = new EventEmitter();
  ev.setMaxListeners(0);

  const contacts = deps.contacts ?? {};
  const chats = {};
  const lidCache = createLidMappingCache();

  const sock = {
    zapo: client,
    ev,
    contacts,
    chats,
    user: null,
    authState: { creds: { registered: false } },
    sessionReady: () => !!client.auth?.getCurrentCredentials?.()?.meJid,
    ws: { readyState: 0, close: () => client.disconnect().catch(() => {}) },
  };

  wireEvents(client, sock, contacts, chats, lidCache);

  sock.refreshChats = async () => {
    if (!deps.storeSession?.threads) return chats;
    try {
      const records = await deps.storeSession.threads.list();
      for (const record of records) chats[record.jid] = record;
    } catch (error) {
      console.warn('[CHATS] Gagal memuat daftar chat:', error?.message || error);
    }
    return chats;
  };

  const kirimSekali = (jid, zapoContent, sendOptions, options) => {
    if (jid === 'status@broadcast') {
      const recipients = [...new Set(options.statusJidList ?? [])].filter(
        (target) => typeof target === 'string' && /^[^@\s]+@(s\.whatsapp\.net|lid)$/.test(target),
      );
      if (!recipients.length) {
        throw new Error('Status butuh minimal satu penerima (statusJidList kosong)');
      }
      return client.status.send({ content: zapoContent, recipients, options: sendOptions });
    }
    return client.message.send(jid, zapoContent, sendOptions);
  };

  const pulihkanStoreRusak = async () => {
    if (!deps.storeSession || !deps.sessionDir) return false;
    try {
      const { senderKeys, sessions } = await purgeCorruptSignalRows(
        deps.storeSession,
        deps.sessionDir,
      );
      return senderKeys + sessions > 0;
    } catch (error) {
      console.warn('[STORE RUSAK] Pemindaian gagal:', error?.message || error);
      return false;
    }
  };

  sock.sendMessage = async (jid, content, options = {}) => {
    const zapoContent = await toZapoContent(content);
    const sendOptions = buildSendOptions(content, options);

    let result;
    try {
      try {
        result = await kirimSekali(jid, zapoContent, sendOptions, options);
      } catch (error) {
        if (!isSignalStoreCorruptError(error) || !(await pulihkanStoreRusak())) throw error;
        result = await kirimSekali(jid, zapoContent, sendOptions, options);
      }
    } catch (error) {
      devlog('send', {
        ok: false,
        jid,
        baileysKeys: content && typeof content === 'object' ? Object.keys(content) : typeof content,
        zapoType: zapoContent?.type ?? Object.keys(zapoContent ?? {})[0],
        options: sendOptions,
        error: error?.message ?? String(error),
      });
      throw error;
    }

    devlog('send', {
      ok: true,
      jid,
      baileysKeys: content && typeof content === 'object' ? Object.keys(content) : typeof content,
      zapoType: zapoContent?.type ?? Object.keys(zapoContent ?? {})[0],
      options: sendOptions,
      messageId: result?.id,
    });

    return {
      key: { remoteJid: jid, fromMe: true, id: result?.id },
      message: zapoContent,
      status: 1,
      zapoResult: result,
    };
  };

  sock.relayMessage = async (jid, message, options = {}) =>
    client.message.send(jid, message, buildSendOptions({}, options));

  sock.readMessages = async (keys) => {
    if (!Array.isArray(keys) || !keys.length) return;

    const events = [];
    for (const key of keys) {
      if (!key?.remoteJid || !key?.id) continue;
      const remoteJid = key.remoteJid;
      events.push({
        key: {
          ...key,
          remoteJid,
          isGroup: key.isGroup ?? remoteJid.endsWith('@g.us'),
          isBroadcast: key.isBroadcast ?? remoteJid.endsWith('@broadcast'),
          participant: key.participant ?? key.participantAlt,
        },
      });
    }

    if (!events.length) return;
    await client.message.sendReceipt(events, { type: 'read' });
  };

  sock.sendPresenceUpdate = async (type, jid) => {
    if (type === 'available' || type === 'unavailable') {
      return client.presence.send(type);
    }
    if (!jid) return;
    return client.presence.sendChatstate(jid, { type });
  };

  sock.waUploadToServer = (stream, opts = {}) =>
    client.message.upload(stream, { type: opts.mediaType ?? opts.type ?? 'image', ...opts });

  // ===== FUNGSI HELPER DOWNLOAD MEDIA =====

  const resolveMessageContent = (input) => {
    let content = input?.message ? input.message : input;
    if (!content || typeof content !== 'object') return null;

    for (let i = 0; i < 10; i++) {
      const next =
        content.ephemeralMessage?.message ||
        content.viewOnceMessage?.message ||
        content.viewOnceMessageV2?.message ||
        content.viewOnceMessageV2Extension?.message ||
        content.documentWithCaptionMessage?.message ||
        content.editedMessage?.message ||
        content.protocolMessage?.editedMessage ||
        null;
      if (!next) break;
      content = next;
    }
    return content;
  };

  const extractMediaFromContent = (content) => {
    if (!content || typeof content !== 'object') return null;
    for (const [field, mediaType] of Object.entries(MEDIA_TYPE_MAP)) {
      if (content[field]) {
        return { mediaType, mediaMessage: content[field] };
      }
    }
    return null;
  };

  const getContextInfoFromMsg = (input) => {
    const content = resolveMessageContent(input);
    if (!content) return null;
    for (const key of Object.keys(content)) {
      const ci = content[key]?.contextInfo;
      if (ci) return ci;
    }
    return null;
  };

  // ===== DOWNLOAD MEDIA (VERSI FINAL) =====
  sock.downloadMediaMessage = async (msg, options = {}) => {
    const ctx = getContextInfoFromMsg(msg);
    const quoted = ctx?.quotedMessage;

    let contentToDownload = null;
    let mediaInfo = null;

    if (quoted) {
      contentToDownload = quoted;
      mediaInfo = extractMediaFromContent(quoted);
    } else {
      contentToDownload = resolveMessageContent(msg);
      mediaInfo = extractMediaFromContent(contentToDownload);
    }

    if (!mediaInfo) {
      throw new Error('message has no downloadable media');
    }

    try {
      // PENTING: Kirim contentToDownload (proto message utuh), bukan mediaObj saja
      const buffer = await client.message.downloadBytes(contentToDownload, options);
      return Buffer.from(buffer);
    } catch (primaryErr) {
      try {
        const fullMessage = {
          key: {
            remoteJid: msg.key?.remoteJid,
            fromMe: false,
            id: ctx?.stanzaId,
            participant: ctx?.participant,
          },
          message: quoted || msg.message,
        };

        const retry = await client.message.requestMediaReupload(fullMessage).catch(() => null);
        if (retry?.directPath && mediaInfo.mediaMessage) {
          mediaInfo.mediaMessage.directPath = retry.directPath;
          delete mediaInfo.mediaMessage.url;
          const buffer = await client.message.downloadBytes(contentToDownload, options);
          return Buffer.from(buffer);
        }
        throw primaryErr;
      } catch {
        throw primaryErr;
      }
    }
  };

  /* -------------------------- GRUP ------------------------- */

  sock.groupMetadata = async (jid) => {
    const metadata = await client.group.queryGroupMetadata(jid);
    return normalizeGroupMetadata(metadata, lidCache);
  };
  sock.groupCreate = async (subject, participants) =>
    normalizeGroupMetadata(await client.group.createGroup(subject, participants), lidCache);
  sock.groupLeave = (jid) => client.group.leaveGroup([jid]);
  sock.groupInviteCode = (jid) => client.group.queryInviteCode(jid);
  sock.groupRevokeInvite = (jid) => client.group.revokeInvite(jid);
  sock.groupAcceptInvite = async (code) => (await client.group.joinGroupViaInvite(code))?.jid;
  sock.groupGetInviteInfo = async (code) =>
    normalizeGroupMetadata(await client.group.queryGroupInviteInfo(code), lidCache);
  sock.groupUpdateSubject = (jid, subject) => client.group.setSubject(jid, subject);
  sock.groupUpdateDescription = (jid, description) => client.group.setDescription(jid, description);
  sock.groupToggleEphemeral = (jid, seconds) => client.group.setEphemeralDuration(jid, seconds);

  sock.groupParticipantsUpdate = async (jid, participants, action) => {
    const method = PARTICIPANT_ACTIONS[action];
    if (!method) throw new Error(`Aksi participant tidak dikenal: ${action}`);
    return client.group[method](jid, participants);
  };

  sock.groupSettingUpdate = async (jid, setting) => {
    const mapped = GROUP_SETTINGS[setting];
    if (!mapped) throw new Error(`Setting grup tidak dikenal: ${setting}`);
    return client.group.setSetting(jid, mapped[0], mapped[1]);
  };

  sock.groupFetchAllParticipating = async () => {
    const all = await client.group.queryAllGroups();
    return Object.fromEntries(all.map((g) => [g.jid, normalizeGroupMetadata(g, lidCache)]));
  };

  sock.groupRequestParticipantsList = (jid) => client.group.queryMembershipApprovalRequests(jid);
  sock.groupRequestParticipantsUpdate = async (jid, participants, action) =>
    action === 'approve'
      ? client.group.approveMembershipRequests(jid, participants)
      : client.group.rejectMembershipRequests(jid, participants);

  /* ------------------------ PROFIL ------------------------- */

  sock.profilePictureUrl = async (jid, type = 'preview') => {
    const res = await client.profile.getProfilePicture(jid, type);
    return res?.url ?? null;
  };

  sock.updateProfilePicture = async (jid, image) => {
    const bytes = await toBytes(image);
    const jpeg = await toProfilePictureJpeg(bytes);
    const target = profilePictureTarget(jid);

    return client.profile.setProfilePicture(jpeg, target);
  };

  sock.removeProfilePicture = (jid) =>
    client.profile.deleteProfilePicture(profilePictureTarget(jid));
  sock.updateProfileStatus = (status) => client.profile.setStatus(status);
  sock.updateProfileName = (name) => client.profile.setPushName(name);
  sock.fetchStatus = (jid) => client.profile.getStatus(jid);

  sock.onWhatsApp = async (...jids) => {
    const list = jids.flat().filter(Boolean);
    const results = await client.profile.getLidsByPhoneNumbers(list);
    return results.map((r) => ({
      jid: r.phoneJid,
      lid: r.lidJid,
      exists: r.exists,
    }));
  };

  sock.updateBlockStatus = (jid, action) =>
    action === 'block' ? client.privacy.blockUser(jid) : client.privacy.unblockUser(jid);

  sock.fetchBlocklist = async () => (await client.privacy.getBlocklist())?.jids ?? [];

  /* ------------------------- CHAT -------------------------- */

  sock.chatModify = async (mod, jid) => {
    if (mod.clear) {
      if (Array.isArray(mod.clear.messages)) {
        for (const msg of mod.clear.messages) {
          await client.chat.deleteMessageForMe({ ...msg, remoteJid: jid });
        }
        return;
      }
      return client.chat.clearChat(jid);
    }
    if (mod.delete) return client.chat.deleteChat(jid);
    if ('archive' in mod) return client.chat.setChatArchive(jid, !!mod.archive);
    if ('pin' in mod) return client.chat.setChatPin(jid, !!mod.pin);
    if ('markRead' in mod) return client.chat.setChatRead(jid, !!mod.markRead);
    if ('mute' in mod) return client.chat.setChatMute(jid, mod.mute != null, mod.mute ?? undefined);
    if (mod.star) return client.chat.setMessageStar(mod.star.messages?.[0], !!mod.star.star);
    throw new Error(`chatModify tidak dikenal: ${Object.keys(mod).join(', ')}`);
  };

  /* ---------------------- LEVEL RENDAH --------------------- */

  sock.query = (node, timeoutMs) => client.lowlevel.query(normalizeQueryNode(node), timeoutMs);
  sock.sendNode = (node) => client.lowlevel.sendNode(node);
  sock.logout = () => client.logout();

  sock.requestPairingCode = (phoneNumber, customCode) =>
    client.auth.requestPairingCode(phoneNumber, undefined, customCode);

  sock.signalRepository = {
    lidMapping: {
      getPNForLID: async (lid) => lidCache.getPn(lid),
      getLIDForPN: async (pn) => {
        const cached = lidCache.getLid(pn);
        if (cached) return cached;

        const [hit] = await client.profile.getLidsByPhoneNumbers([pn]);
        if (hit?.lidJid) lidCache.remember(hit.lidJid, hit.phoneJid ?? pn);
        return hit?.lidJid ?? null;
      },
    },
  };

  sock.lidMappingSize = () => lidCache.size;

  return sock;
}

function wireEvents(client, sock, contacts, chats, lidCache) {
  const { ev } = sock;

  client.on('connection', (event) => {
    if (event.status === 'open') {
      sock.ws.readyState = 1;
      sock.authState.creds.registered = true;
      const creds = client.auth?.getCurrentCredentials?.() ?? null;
      if (creds?.meJid) sock.user = { id: creds.meJid, name: creds.pushName };
      sock.refreshChats?.().catch(() => {});
      ev.emit('connection.update', { connection: 'open' });
      return;
    }

    sock.ws.readyState = 3;
    ev.emit('connection.update', {
      connection: 'close',
      lastDisconnect: {
        error: Object.assign(new Error(event.reason), {
          output: { statusCode: event.code ?? event.reason },
        }),
        date: new Date(),
      },
      isLogout: event.isLogout,
    });
  });

  client.on('auth_qr', ({ qr }) => ev.emit('connection.update', { connection: 'connecting', qr }));

  client.on('auth_paired', ({ credentials }) => {
    sock.authState.creds.registered = true;
    if (credentials?.meJid) sock.user = { id: credentials.meJid };
  });

  client.on('message', (event) => {
    const key = event.key ?? {};

    lidCache.remember(key.remoteJid, key.remoteJidAlt);
    lidCache.remember(key.remoteJidAlt, key.remoteJid);
    lidCache.remember(key.participant, key.participantAlt);
    lidCache.remember(key.participantAlt, key.participant);

    const jid = key.remoteJid;
    if (jid && !chats[jid]) chats[jid] = { jid, name: event.pushName };

    if (isDevLogEnabled()) {
      devlog('message', {
        key: summarizeKey(key),
        pushName: event.pushName,
        timestampSeconds: event.timestampSeconds,
        messageTypes: Object.keys(event.message ?? {}),
        text:
          event.message?.conversation ??
          event.message?.extendedTextMessage?.text ??
          event.message?.imageMessage?.caption ??
          event.message?.videoMessage?.caption,
      });
    }

    ev.emit('messages.upsert', {
      messages: [{ ...event, messageTimestamp: event.timestampSeconds }],
      type: 'notify',
    });
  });

  const AKSI_PESERTA_BAILEYS = new Set(['add', 'remove', 'promote', 'demote']);

  client.on('group', (event) => {
    if (!event.groupJid || !event.participants?.length) return;

    for (const p of event.participants) lidCache.remember(p.lidJid, p.phoneJid);

    if (!AKSI_PESERTA_BAILEYS.has(event.action)) return;

    const participants = event.participants
      .map((p) => p.phoneJid ?? p.jid ?? p.lidJid)
      .filter(Boolean);

    if (!participants.length) return;

    ev.emit('group-participants.update', {
      id: event.groupJid,
      author: event.authorJid,
      participants,
      action: event.action,
    });
  });

  client.on('call', (event) => {
    ev.emit('call', [
      {
        id: event.callId,
        from: event.callerPnJid ?? event.callCreatorJid ?? event.senderLidJid,
        status: event.type,
        isVideo: !!event.isVideo,
        isGroup: !!event.groupJid,
      },
    ]);
  });

  client.on('picture', (event) => {
    if (!event?.jid) return;
    contacts[event.jid] = { ...(contacts[event.jid] ?? {}), id: event.jid };
    ev.emit('contacts.update', [contacts[event.jid]]);
  });
}

function normalizeQueryNode(node) {
  const to = node?.attrs?.to;
  if (typeof to !== 'string' || !to.startsWith('@')) return node;

  return { ...node, attrs: { ...node.attrs, to: to.slice(1) } };
}

const PROFILE_PICTURE_SIZE = 640;

function profilePictureTarget(jid) {
  return typeof jid === 'string' && jid.endsWith('@g.us') ? jid : undefined;
}

async function toProfilePictureJpeg(bytes) {
  const { Jimp } = await import('jimp');
  const input = Buffer.from(bytes);

  let image;
  try {
    image = await Jimp.read(input);
  } catch (error) {
    const { normalizeImageBuffer } = await import('./imageNormalizer.js');
    const normalized = await normalizeImageBuffer(input);
    image = await Jimp.read(normalized.buffer);
  }

  const jpeg = await image
    .cover({ w: PROFILE_PICTURE_SIZE, h: PROFILE_PICTURE_SIZE })
    .getBuffer('image/jpeg');

  return new Uint8Array(jpeg);
}

async function toBytes(source) {
  if (!source) return source;
  if (source instanceof Uint8Array) return source;
  const value = typeof source === 'string' ? source : source.url;
  if (!value) throw new Error('Sumber gambar tidak valid');
  if (/^https?:\/\//i.test(value)) {
    const res = await fetch(value);
    return new Uint8Array(await res.arrayBuffer());
  }
  const { readFile } = await import('fs/promises');
  return new Uint8Array(await readFile(value));
}