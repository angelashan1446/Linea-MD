// libx/whatsapp/connect.js
// Manajemen multi-session WhatsApp — FINAL VERSION
// Rule: semua error → reconnect (max 20x). Logout (401) → hapus langsung.

import path from 'path';
import fs from 'fs';
import chalk from 'chalk';
import pino from 'pino';
import qrcode from 'qrcode-terminal';

import config from '../../config.js';
import { SESSIONS_DIR } from '../db.js';

import './polyfill.js';
import { WaClient } from 'zapo-js';
import { createSessionStore } from './store.js';
import { createBaileysCompatSocket } from './socket.js';

// Import Event Bus Additional
import { emitParticipantsUpdate } from '../additional.js';

const logger = pino({ level: 'silent' });

// ============================================================
// KONFIGURASI RECONNECT
// ============================================================
const MAX_RECONNECT = 20;              // batas reconnect
const RECONNECT_BASE_DELAY = 5000;     // 5s
const RECONNECT_MAX_DELAY = 60000;     // max 60s
const HEARTBEAT_INTERVAL = 60000;      // ping tiap 60s
const HEARTBEAT_TIMEOUT = 15000;       // timeout ping 15s
const WATCHDOG_INTERVAL = 5 * 60 * 1000;
const MAX_QR = 5;

const MARKER_FILE = '.connected';      // penanda "pernah connect"

// Map status code WA → deskripsi (hanya untuk log)
const REASON_MAP = {
  401: 'Logged out (session invalid)',
  403: 'Forbidden / banned',
  408: 'Timeout',
  428: 'Connection closed',
  440: 'Conflict (login di tempat lain)',
  500: 'Server error',
  503: 'Service unavailable',
  515: 'Restart required (bukan logout)',
};

// ============================================================
// STATE
// ============================================================
const sessionStates = new Map();
export const sessions = new Map();
export const sessionNumbers = new Map();
export const pairingCodes = new Map();
const sessionOpts = new Map();

function hasMarker(folder) {
  try {
    return fs.existsSync(path.join(SESSIONS_DIR, folder, MARKER_FILE));
  } catch {
    return false;
  }
}

function writeMarker(folder) {
  try {
    const dir = path.join(SESSIONS_DIR, folder);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, MARKER_FILE), Date.now().toString());
  } catch {}
}

function getState(folder) {
  let s = sessionStates.get(folder);
  if (!s) {
    s = {
      reconnecting: false,
      attempts: 0,
      qrCount: 0,
      heartbeatTimer: null,
      connected: false,
      everConnected: hasMarker(folder),
      lastClose: 0,
    };
    sessionStates.set(folder, s);
  }
  if (!s.everConnected && hasMarker(folder)) s.everConnected = true;
  return s;
}

function backoffDelay(attempt) {
  const d = RECONNECT_BASE_DELAY * Math.pow(1.5, Math.max(0, attempt - 1));
  return Math.min(d, RECONNECT_MAX_DELAY);
}

function wipeFolder(folder, alasan) {
  const dir = path.join(SESSIONS_DIR, folder);
  try {
    if (fs.existsSync(dir)) {
      fs.rmSync(dir, { recursive: true, force: true });
      console.log(chalk.yellow(`[${folder}] 🗑️  Folder dihapus (${alasan}).`));
    }
  } catch (e) {
    console.log(chalk.red(`[${folder}] Gagal hapus folder: ${e?.message || e}`));
  }
  sessionStates.delete(folder);
  sessionNumbers.delete(folder);
  sessionOpts.delete(folder);
  pairingCodes.delete(folder);
  sessions.delete(folder);
}

export function listSessionFolders() {
  if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });
  return fs
    .readdirSync(SESSIONS_DIR, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => d.name)
    .sort((a, b) => {
      if (a === 'main') return -1;
      if (b === 'main') return 1;
      return a.localeCompare(b);
    });
}

export function createSessionFolder(name) {
  const dir = path.join(SESSIONS_DIR, name);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

// ============================================================
// HEARTBEAT
// ============================================================
function startHeartbeat(folder, client) {
  const state = getState(folder);
  stopHeartbeat(folder);

  state.heartbeatTimer = setInterval(async () => {
    if (state.reconnecting) return;
    try {
      const pingPromise = client.sendQuery
        ? client.sendQuery({
            tag: 'iq',
            attrs: { type: 'get', to: 's.whatsapp.net', xmlns: 'w:p' },
            content: [{ tag: 'ping', attrs: {} }],
          })
        : Promise.resolve();

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('heartbeat timeout')), HEARTBEAT_TIMEOUT),
      );

      await Promise.race([pingPromise, timeoutPromise]);
    } catch (e) {
      console.log(
        chalk.red(`[${folder}] ❤️ Heartbeat gagal (${e?.message || e}) → force reconnect`),
      );
      try {
        await client.disconnect?.();
      } catch {}
    }
  }, HEARTBEAT_INTERVAL);

  if (state.heartbeatTimer.unref) state.heartbeatTimer.unref();
}

function stopHeartbeat(folder) {
  const state = getState(folder);
  if (state.heartbeatTimer) {
    clearInterval(state.heartbeatTimer);
    state.heartbeatTimer = null;
  }
}

// ============================================================
// RECONNECT CORE
// ============================================================
async function scheduleReconnect(folder, opts, reason = 'unknown') {
  const state = getState(folder);
  if (state.reconnecting) return;

  state.reconnecting = true;
  state.attempts++;
  state.connected = false;

  const now = Date.now();
  if (now - state.lastClose < 1000) {
    await new Promise((r) => setTimeout(r, 1000));
  }
  state.lastClose = Date.now();

  const desc = REASON_MAP[reason] || String(reason);
  const pernahConnect = state.everConnected || hasMarker(folder);

  if (reason === 401) {
    state.reconnecting = false;
    stopHeartbeat(folder);
    console.log(chalk.red(`[${folder}] ⛔ Logout terdeteksi → hapus session.`));
    wipeFolder(folder, 'logout');
    return;
  }

  if (reason === 515) {
    console.log(chalk.cyan(`[${folder}] ♻️  Restart required (515) → reconnect 2s...`));
    await new Promise((r) => setTimeout(r, 2000));
    state.reconnecting = false;
    try {
      await connectToWhatsApp(folder, opts);
    } catch (e) {
      console.log(chalk.red(`[${folder}] Reconnect 515 gagal:`), e?.message || e);
      scheduleReconnect(folder, opts, 'connect-throw').catch(() => {});
    }
    return;
  }

  if (state.attempts >= MAX_RECONNECT) {
    state.reconnecting = false;
    stopHeartbeat(folder);
    const alasan = pernahConnect
      ? 'session lama mati (reconnect habis)'
      : 'new session gagal connect (reconnect habis)';
    console.log(
      chalk.red(
        `[${folder}] ⛔ Stop reconnect (${state.attempts}/${MAX_RECONNECT}) — ${alasan}`,
      ),
    );
    wipeFolder(folder, alasan);
    return;
  }

  const delay = backoffDelay(state.attempts);
  console.log(
    chalk.yellow(
      `[${folder}] Close (${desc}) — reconnect ${state.attempts}/${MAX_RECONNECT} dalam ${(
        delay / 1000
      ).toFixed(1)}s`,
    ),
  );

  await new Promise((r) => setTimeout(r, delay));
  state.reconnecting = false;

  try {
    await connectToWhatsApp(folder, opts);
  } catch (e) {
    console.log(chalk.red(`[${folder}] Reconnect gagal:`), e?.message || e);
    scheduleReconnect(folder, opts, 'connect-throw').catch(() => {});
  }
}

// ============================================================
// CONNECT
// ============================================================
export async function connectToWhatsApp(folder = 'main', opts = {}) {
  const state = getState(folder);
  const dir = createSessionFolder(folder);
  const store = createSessionStore(dir);

  sessionOpts.set(folder, opts);

  // ✅ FIX: Jadibot (bukan 'main') dipaksa selalu pakai Pairing
  const isPairing = folder !== 'main' ? true : (config.type_connection === 'pairing');

  const client = new WaClient(
    {
      store,
      sessionId: 'default',
      auth: { deviceBrowser: 'chrome', deviceOsDisplayName: 'Ubuntu' },
      connectTimeoutMs: 30000,
      iqTimeoutMs: 30000,
      nodeQueryTimeoutMs: 30000,
      signalFetchKeyBundlesTimeoutMs: 30000,
      history: { enabled: false },
      keepAliveIntervalMs: 15000,
      markOnlineOnConnect: true,
    },
    logger,
  );

  const sock = createBaileysCompatSocket(client, {
    storeSession: store.session('default'),
    sessionDir: dir,
  });

  sessions.set(folder, sock);

  // ===== Pairing (per folder) =====
  if (isPairing) { // ✅ GUNAKAN isPairing, BUKAN config.type_connection
    let requested = false;
    const askCode = async () => {
      if (requested) return;
      requested = true;
      try {
        const nomor = folder === 'main' ? config.phone_number_bot : folder;
        const code = await client.auth.requestPairingCode(nomor);
        const fmt = code.slice(0, 4) + '-' + code.slice(4);
        pairingCodes.set(folder, fmt);
        console.log(chalk.blue(`[${folder}] PHONE:`), chalk.yellow(nomor));
        console.log(chalk.blue(`[${folder}] PAIRING CODE:`), chalk.yellow(fmt));
      } catch (e) {
        requested = false;
        console.log(chalk.red(`[${folder}] Pairing gagal:`), e?.message || e);
      }
    };
    client.on('auth_qr', askCode);
    client.on('auth_pairing_required', ({ forceManual } = {}) => {
      if (!forceManual) return;
      requested = false;
      askCode();
    });
  }

  // ===== Events =====
  sock.ev.on('messages.upsert', async (m) => {
    try {
      if (!m?.messages?.length) return;
      const msg = m.messages[0];
      if (!msg?.message) return;
      if (m.type === 'append') return;

      if (typeof opts.onMessage === 'function') {
        await opts.onMessage(sock, msg, folder);
      }
    } catch (e) {
      console.log(chalk.red(`[${folder}] messages.upsert:`), e?.message || e);
    }
  });

  sock.ev.on('group-participants.update', async (m) => {
    try {
      await emitParticipantsUpdate(sock, m, folder);
    } catch (e) {
      console.log(chalk.red(`[${folder}] group-participants.update:`), e?.message || e);
    }
  });

  // ===== Connection Update =====
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (sock?.user?.id) {
      const nomor = sock.user.id.split(':')[0].split('@')[0];
      sessionNumbers.set(folder, nomor);
    }

    // ===== QR =====
    // ✅ HANYA izinkan QR muncul jika isPairing = false (artinya bot utama pakai QR)
    if (qr && !isPairing) {
      state.qrCount++;
      console.log(chalk.yellow(`[${folder}] QR (${state.qrCount}/${MAX_QR}) - scan di WhatsApp`));
      qrcode.generate(qr, { small: true });
      if (state.qrCount >= MAX_QR) {
        console.log(chalk.red(`[${folder}] Terlalu banyak QR. Stop sesi ini.`));
        stopHeartbeat(folder);
        sessions.delete(folder);
        try {
          await client.disconnect().catch(() => {});
        } catch {}
        return;
      }
    }

    // ===== OPEN =====
    if (connection === 'open') {
      state.attempts = 0;
      state.reconnecting = false;
      state.qrCount = 0;
      state.connected = true;
      state.everConnected = true;
      pairingCodes.delete(folder);

      writeMarker(folder);

      console.log(chalk.green(`✅ [${folder}] Terhubung`));
      startHeartbeat(folder, client);

      if (typeof opts.onConnected === 'function') {
        try {
          await opts.onConnected(sock, folder);
        } catch (e) {
          console.log(chalk.red(`[${folder}] onConnected error:`), e?.message || e);
        }
      }
      return;
    }

    // ===== CLOSE =====
    if (connection === 'close') {
      if (state.reconnecting) return;

      state.connected = false;
      stopHeartbeat(folder);

      const reason = lastDisconnect?.error?.output?.statusCode ?? 'unknown';

      sessions.delete(folder);
      pairingCodes.delete(folder);

      if (typeof opts.onDisconnected === 'function') {
        try {
          opts.onDisconnected(folder);
        } catch (e) {
          console.log(chalk.red(`[${folder}] onDisconnected error:`), e?.message || e);
        }
      }

      try {
        sock.ev.removeAllListeners?.();
        client.removeAllListeners?.();
        await client.disconnect().catch(() => {});
      } catch {}

      await scheduleReconnect(folder, opts, reason).catch((e) => {
        console.log(chalk.red(`[${folder}] scheduleReconnect error:`), e?.message || e);
      });
    }
  });

  // ===== CONNECT (retry kalau gagal) =====
  client.connect().catch(async (e) => {
    console.log(chalk.red(`[${folder}] connect() gagal:`), e?.message || e);
    scheduleReconnect(folder, opts, 'connect-throw').catch(() => {});
  });

  return sock;
}

/**
 * Connect semua session
 */
export async function connectAllSessions(opts = {}, concurrency) {
  createSessionFolder('main');
  const folders = listSessionFolders();
  const limit = concurrency || config.session_concurrency || 3;

  for (let i = 0; i < folders.length; i += limit) {
    const batch = folders.slice(i, i + limit);
    await Promise.all(
      batch.map((folder) =>
        connectToWhatsApp(folder, opts).catch((e) => {
          console.log(chalk.red(`[${folder}] connect gagal:`), e?.message || e);
        }),
      ),
    );
    if (i + limit < folders.length) {
      await new Promise((r) => setTimeout(r, 800));
    }
  }
}

/**
 * Buat sesi baru (folder + connect).
 */
export async function createNewSession(nomor, opts = {}) {
  const clean = String(nomor).replace(/\D/g, '');
  if (!clean) throw new Error('Nomor tidak valid');

  const dir = path.join(SESSIONS_DIR, clean);
  const existsOnDisk = fs.existsSync(dir);
  const existsInMemory = sessions.has(clean);

  if (existsOnDisk || existsInMemory) {
    console.log(chalk.yellow(`[${clean}] Sesi sudah ada. Menghapus dan membuat ulang...`));
    await removeSession(clean);
    await new Promise((r) => setTimeout(r, 1500));
  }

  createSessionFolder(clean);
  return connectToWhatsApp(clean, opts);
}

/**
 * Ambil kode pairing berdasarkan nama folder/nomor.
 */
export function getPairingCode(nomor) {
  const clean = String(nomor).replace(/\D/g, '');
  return pairingCodes.get(clean) || null;
}

/**
 * Hapus sesi manual.
 */
export async function removeSession(folder) {
  stopHeartbeat(folder);
  const sock = sessions.get(folder);
  if (sock) {
    try {
      await sock.logout();
    } catch (e) {
      console.log(chalk.yellow(`[${folder}] Logout gagal:`), e?.message || e);
    }
    try {
      await sock.ws.close();
    } catch {}
    sessions.delete(folder);
    sessionNumbers.delete(folder);
  }
  sessionStates.delete(folder);
  pairingCodes.delete(folder);
  sessionOpts.delete(folder);

  const dir = path.join(SESSIONS_DIR, folder);
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

/**
 * Disconnect semua sesi
 */
export async function disconnectAllSessions() {
  const folders = [...sessions.keys()];
  for (const folder of folders) {
    stopHeartbeat(folder);
    const sock = sessions.get(folder);
    try {
      await sock.ws.close();
    } catch {}
    sessions.delete(folder);
    sessionNumbers.delete(folder);
  }
}

/**
 * List sesi aktif
 */
export function listActiveSessions() {
  return [...sessions.keys()].map((folder) => ({
    folder,
    nomor: sessionNumbers.get(folder) || null,
    connected: !!sessions.get(folder) && getState(folder).connected === true,
  }));
}

/**
 * Ambil semua nomor bot yang aktif (dari memori + folder session).
 * @returns {string[]} - Array nomor bot (contoh: ['628xxx', '628yyy'])
 */
export function getActiveBotNumbers() {
  const numbers = new Set();
  for (const nomor of sessionNumbers.values()) {
    if (nomor) numbers.add(nomor);
  }
  for (const folder of listSessionFolders()) {
    if (folder === 'main') continue;
    if (/^\d{6,}$/.test(folder)) numbers.add(folder);
  }
  return [...numbers];
}

// ============================================================
// WATCHDOG
// ============================================================
let _watchdogTimer = null;

export function startWatchdog() {
  if (_watchdogTimer) return;
  _watchdogTimer = setInterval(() => {
    try {
      const folders = listSessionFolders();
      for (const folder of folders) {
        const state = getState(folder);
        const sock = sessions.get(folder);
        const hasOpts = sessionOpts.has(folder);

        if (!sock && !state.reconnecting && hasOpts) {
          console.log(chalk.magenta(`[watchdog] ${folder} mati → reconnect`));
          connectToWhatsApp(folder, sessionOpts.get(folder)).catch((e) => {
            console.log(chalk.red(`[watchdog] ${folder} reconnect gagal:`), e?.message || e);
          });
        }
      }
    } catch (e) {
      console.log(chalk.red(`[watchdog] error:`), e?.message || e);
    }
  }, WATCHDOG_INTERVAL);

  if (_watchdogTimer.unref) _watchdogTimer.unref();
  console.log(chalk.cyan('🐕 Watchdog aktif (cek tiap 5 menit).'));
}

export function stopWatchdog() {
  if (_watchdogTimer) {
    clearInterval(_watchdogTimer);
    _watchdogTimer = null;
  }
}