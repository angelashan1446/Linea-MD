// libx/handle_cmd.js
// Handle logika command masuk: cek user, owner, premium, token, dll.

import config from '../config.js';
import chalk from 'chalk';
import fs from 'fs';
import path from 'path';
import {
  findUser,
  findByNomor,
  isOwner,
  isPremium,
  useToken,
  registerUser,
} from './db.js';
import { sendText, sendMedia } from './whatsapp/sendmsg.js';
import { log } from './startup.js';
import { hasRent, isRentActive, getBotService, getGroupLang } from './grup_db.js';
import {
  isSelft,
  isMaintenance,
  isSpamPunished,
  checkSpam,
  checkUserRateLimit,
  checkGroupRateLimit,
  formatDuration,
} from './system.js';
import { isValidLang, DEFAULT_LANG, LANGS } from './lang.js';

const PREFIX = config.prefix;
const WHITELIST_COMMANDS = ['daftar', 'jadibot', 'box'];

// ============================================================
// ✅ MAP UNTUK MULTI-BOT RACE CONDITION (DYNAMIC)
// ============================================================
const groupLocks = new Map();

// ============================================================
// ✅ DB JADIBOT (untuk enforce selft & mode chat per bot)
// ============================================================
const JADIBOT_FILE = path.join(process.cwd(), 'db', 'jadibot.json');
let _jadibotCache = null;
let _jadibotCacheAt = 0;
const JADIBOT_CACHE_TTL = 15 * 1000;

function readJadibotReadonlyDb() {
  try {
    if (!fs.existsSync(JADIBOT_FILE)) return { bots: {} };
    return JSON.parse(fs.readFileSync(JADIBOT_FILE, 'utf8'));
  } catch {
    return { bots: {} };
  }
}

function readJadibotDb() {
  const now = Date.now();
  if (_jadibotCache && now - _jadibotCacheAt < JADIBOT_CACHE_TTL) {
    return _jadibotCache;
  }
  _jadibotCache = readJadibotReadonlyDb();
  _jadibotCacheAt = now;
  return _jadibotCache;
}

/**
 * Ambil config jadibot berdasarkan nomor bot yang sedang jalan.
 */
function getBotSelfConfig(botNumber) {
  if (!botNumber) return null;
  const db = readJadibotReadonlyDb();
  return db.bots?.[botNumber] || null;
}

// ============================================================
// ✅ KAMUS BAHASA UNTUK PESAN SISTEM
// ============================================================
const SYS_TEXT = {
  id: {
    identity_error: '❌ Gagal mendeteksi identitas (Nomor & LID kosong).',
    not_registered_title: '⚠️ *Kamu Belum Terdaftar*',
    not_registered_body:
      'Untuk menggunakan bot, kamu harus daftar dulu.\n\n' +
      '📝 *Cara daftar:*\n' +
      '1. Klik link di bawah ini\n' +
      '2. Kamu akan diarahkan ke chat pribadi bot\n' +
      '3. Kirim pesan yang sudah tersedia',
    not_registered_cta: '🔗 *Klik untuk daftar:*',
    not_registered_footer: '_Atau salin link di atas ke browser._',

    maintenance_header: '╭───「 *MAINTENANCE* 」',
    maintenance_body: '│ 🔧 Bot sedang dalam perawatan',
    maintenance_date: '│ 📅 {date}',
    maintenance_footer:
      'Mohon maaf atas ketidaknyamanannya.\n' +
      'Silakan coba beberapa saat lagi. 🙏',

    spam_title: '🚫 *Anti-Spam*',
    spam_body:
      'Kamu terdeteksi mengirim command yang sama berulang.\n' +
      'Command kamu akan diabaikan selama *{dur}*.',
    spam_footer: '_Hindari spam agar tidak di-punish._',

    only_owner: '❌ Command ini khusus *owner*.',
    only_premium: '❌ Command ini khusus *premium*.',
    token_warn: '⚠️ {reason} (sisa: {sisa})',
    plugin_error: '❌ Terjadi error: {err}',

    selft_bot_active: '🔒 Bot ini sedang *self mode*. Hanya owner bot yang bisa memakai.',
    bot_modechat_private: '📱 Bot ini hanya melayani *chat pribadi*.',
    bot_modechat_grup: '📱 Bot ini hanya melayani *grup*.',
  },
  ch: {
    identity_error: '❌ 无法识别身份（号码和 LID 均为空）。',
    not_registered_title: '⚠️ *您尚未注册*',
    not_registered_body:
      '要使用机器人，您需要先注册。\n\n' +
      '📝 *注册方法：*\n' +
      '1. 点击下方链接\n' +
      '2. 将被引导至机器人私聊\n' +
      '3. 发送已准备好的消息',
    not_registered_cta: '🔗 *点击注册：*',
    not_registered_footer: '_或将上方链接复制到浏览器。_',

    maintenance_header: '╭───「 *维护中* 」',
    maintenance_body: '│ 🔧 机器人正在维护',
    maintenance_date: '│ 📅 {date}',
    maintenance_footer:
      '对带来的不便深表歉意。\n' +
      '请稍后再试。🙏',

    spam_title: '🚫 *反垃圾*',
    spam_body:
      '检测到您重复发送相同的命令。\n' +
      '您的命令将被忽略 *{dur}*。',
    spam_footer: '_请避免刷屏以免被处罚。_',

    only_owner: '❌ 此命令仅限 *主人*。',
    only_premium: '❌ 此命令仅限 *高级会员*。',
    token_warn: '⚠️ {reason}（剩余：{sisa}）',
    plugin_error: '❌ 发生错误：{err}',

    selft_bot_active: '🔒 此机器人正在 *自用模式*。仅限机器人主人使用。',
    bot_modechat_private: '📱 此机器人仅服务 *私聊*。',
    bot_modechat_grup: '📱 此机器人仅服务 *群组*。',
  },
  uk: {
    identity_error: '❌ Failed to detect identity (Number & LID empty).',
    not_registered_title: '⚠️ *You Are Not Registered*',
    not_registered_body:
      'To use the bot, you must register first.\n\n' +
      '📝 *How to register:*\n' +
      '1. Click the link below\n' +
      '2. You will be redirected to the bot\'s private chat\n' +
      '3. Send the prepared message',
    not_registered_cta: '🔗 *Click to register:*',
    not_registered_footer: '_Or copy the link above to your browser._',

    maintenance_header: '╭───「 *MAINTENANCE* 」',
    maintenance_body: '│ 🔧 Bot is under maintenance',
    maintenance_date: '│ 📅 {date}',
    maintenance_footer:
      'We apologize for the inconvenience.\n' +
      'Please try again in a moment. 🙏',

    spam_title: '🚫 *Anti-Spam*',
    spam_body:
      'You were detected sending the same command repeatedly.\n' +
      'Your command will be ignored for *{dur}*.',
    spam_footer: '_Avoid spamming to prevent punishment._',

    only_owner: '❌ This command is *owner*-only.',
    only_premium: '❌ This command is *premium*-only.',
    token_warn: '⚠️ {reason} (remaining: {sisa})',
    plugin_error: '❌ An error occurred: {err}',

    selft_bot_active: '🔒 This bot is in *self mode*. Only the bot owner can use it.',
    bot_modechat_private: '📱 This bot only serves *private chat*.',
    bot_modechat_grup: '📱 This bot only serves *groups*.',
  },
};

function ST(lang, key, vars = {}) {
  const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
  let str = (SYS_TEXT[code] || SYS_TEXT[DEFAULT_LANG])[key] ?? SYS_TEXT[DEFAULT_LANG][key] ?? key;
  for (const [k, v] of Object.entries(vars)) {
    str = str.replaceAll(`{${k}}`, String(v));
  }
  return str;
}

/**
 * Resolve bahasa untuk pesan sistem / reply default.
 */
function resolveLang({ user, isGroup, remoteJid }) {
  if (user && isValidLang(user.lang)) return user.lang;

  if (isGroup) {
    try {
      const groupId = remoteJid.split('@')[0];
      const gl = getGroupLang(groupId);
      if (isValidLang(gl)) return gl;
    } catch {}
  }

  return 'uk';
}

// ============================================================
// HELPER: SENDER INFO
// ============================================================
export function getSenderInfo(msg) {
  const key = msg.key || {};
  const remoteJid = key.remoteJid || '';
  const isGroup = remoteJid.endsWith('@g.us');

  const rawJid = isGroup ? key.participant : remoteJid;
  const isLid = rawJid?.endsWith('@lid');
  const isPn = rawJid?.endsWith('@s.whatsapp.net');

  const lid = isLid ? rawJid : (key.senderLid || null);

  let nomor = null;
  if (isPn) nomor = rawJid.split('@')[0];
  else if (key.senderPn) nomor = key.senderPn.split('@')[0];
  else if (key.participantAlt?.endsWith('@s.whatsapp.net')) nomor = key.participantAlt.split('@')[0];
  else if (key.remoteJidAlt?.endsWith('@s.whatsapp.net')) nomor = key.remoteJidAlt.split('@')[0];

  return { remoteJid, isGroup, rawJid, lid, nomor };
}

// ============================================================
// HELPER: RESOLVE LID → NOMOR
// ============================================================
export async function resolveNomorFromLid(sock, lid) {
  if (!lid || !lid.endsWith('@lid')) return null;
  try {
    const results = await sock.onWhatsApp(lid);
    if (results && results[0] && results[0].jid) {
      return results[0].jid.split('@')[0];
    }
  } catch (error) {
    log.error(`Gagal resolve LID ke Nomor: ${error.message}`);
  }
  return null;
}

// ============================================================
// HELPER: REPLY BELUM DAFTAR
// ============================================================
async function replyNotRegistered(sock, remoteJid, msg, lang) {
  const botNumber = config.phone_number_bot;
  const linkDaftar = `https://wa.me/${botNumber}?text=${encodeURIComponent(PREFIX + 'daftar')}`;

  const text =
    `${ST(lang, 'not_registered_title')}\n\n` +
    `${ST(lang, 'not_registered_body')}\n\n` +
    `${ST(lang, 'not_registered_cta')}\n${linkDaftar}\n\n` +
    `${ST(lang, 'not_registered_footer')}`;

  try {
    await sendText(sock, remoteJid, text, { quoted: msg });
  } catch (err) {
    const errMsg = err?.message || String(err);
    if (errMsg.includes('negative publish ack') || errMsg.includes('error=463')) {
      log.warn(`[SKIP] Gagal kirim link daftar ke ${remoteJid}: Target belum pernah chat (463).`);
      return;
    }
    log.warn(`Gagal kirim link daftar: ${errMsg}`);
  }
}

// ============================================================
// HELPER: REPLY MAINTENANCE
// ============================================================
async function replyMaintenance(sock, remoteJid, msg, lang) {
  const dateStr = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

  const text =
    `${ST(lang, 'maintenance_header')}\n` +
    `│\n` +
    `${ST(lang, 'maintenance_body')}\n` +
    `${ST(lang, 'maintenance_date', { date: dateStr })}\n` +
    `│\n` +
    `╰───────☉\n\n` +
    `${ST(lang, 'maintenance_footer')}\n\n` +
    `_— ${config.bot_name} Team_`;

  try {
    await sendText(sock, remoteJid, text, { quoted: msg });
  } catch (err) {
    const errMsg = err?.message || String(err);
    if (errMsg.includes('negative publish ack') || errMsg.includes('error=463')) {
      log.warn(`[SKIP] Gagal kirim pesan maintenance ke ${remoteJid}: 463.`);
      return;
    }
    log.warn(`Gagal kirim pesan maintenance: ${errMsg}`);
  }
}

// ============================================================
// HELPER: REACTION TOLAK (dipakai untuk spam/rate-limit saja)
// ============================================================
async function reactReject(sock, msg) {
  try {
    await sock.sendMessage(msg.key.remoteJid, {
      react: { text: '❌', key: msg.key },
    });
  } catch {}
}

// ============================================================
// CORE: HANDLE COMMAND
// ============================================================
export async function handleCommand(sock, msg, text, plugin, folder) {
  let { remoteJid, isGroup, lid, nomor } = getSenderInfo(msg);

  const args = text.slice(PREFIX.length).trim().split(/\s+/);
  const command = (args.shift() || '').toLowerCase();

  // Nomor bot yang sedang jalan
  const myBotNumber = sock.user?.id?.split(':')[0]?.split('@')[0];

  // ============================================================
  // 1. PENENTUAN OWNER & PREMIUM (LID-first)
  // ============================================================
  let isOwnerSender = isOwner({ lid, nomor });
  let isPremiumSender = isPremium({ lid, nomor });

  if (!isOwnerSender && !nomor && lid) {
    nomor = await resolveNomorFromLid(sock, lid);
    isOwnerSender = isOwner({ lid, nomor });
    isPremiumSender = isPremium({ lid, nomor });
  }

  // Cari user DB sekali
  let user = null;
  try { user = findUser({ lid, nomor }) || findByNomor(nomor); } catch {}

  // Resolve bahasa default untuk pesan sistem
  const sysLang = resolveLang({ user, isGroup, remoteJid });

  if (!nomor && !lid) {
    const reply = (teks) => sendText(sock, remoteJid, teks, { quoted: msg });
    return reply(ST(sysLang, 'identity_error'));
  }

  // ============================================================
  // 2. ✅ LOGIKA MULTI-BOT (SPESIFIK / DYNAMIC) — DULUAN
  // ============================================================
  // Kalau bukan wilayah bot ini → DIAM TOTAL (silent)
  // ============================================================
  if (isGroup) {
    const groupId = remoteJid.split('@')[0];
    const botService = getBotService(groupId);
    const now = Date.now();
    const lock = groupLocks.get(groupId);

    // --- KONDISI A: SPESIFIK (grup milik bot tertentu) ---
    if (botService !== 'dynamic') {
      if (botService !== myBotNumber) {
        if (config.mode === 'development') {
          log.warn(`[MULTIBOT] Skip ${command} — grup ${groupId} milik bot +${botService}`);
        }
        return; // ⛔ silent
      }

      // Bot ini yang ditugaskan → ambil lock
      groupLocks.set(groupId, { folder, releaseAt: now + 30000 });
      setTimeout(() => {
        const currentLock = groupLocks.get(groupId);
        if (currentLock && currentLock.folder === folder) {
          groupLocks.delete(groupId);
        }
      }, 30000);
    }
    // --- KONDISI B: DYNAMIC (siapa cepat dia dapat) ---
    else {
      if (lock && lock.folder !== folder && lock.releaseAt > now) {
        if (config.mode === 'development') {
          log.warn(`[MULTIBOT] Skip ${command} — grup ${groupId} di-lock oleh ${lock.folder}`);
        }
        return; // ⛔ silent
      }

      groupLocks.set(groupId, { folder, releaseAt: now + 30000 });
      setTimeout(() => {
        const currentLock = groupLocks.get(groupId);
        if (currentLock && currentLock.folder === folder) {
          groupLocks.delete(groupId);
        }
      }, 30000);
    }
  }

  // ============================================================
  // 3. ✅ JADIBOT CONFIG (SELFT_BOT + MODE_CHAT) — SETELAH MULTI-BOT
  // ============================================================
  // ✅ FIX: BOT UTAMA DIKECUALIKAN DARI JADIBOT.JSON
  // ============================================================
  const PRIMARY_BOT = String(config.phone_number_bot || '').replace(/\D/g, '');
  const currentBotStr = String(myBotNumber || '').replace(/\D/g, '');
  const isPrimaryBot = currentBotStr === PRIMARY_BOT;

  // Jika BUKAN bot utama (berarti jadibot), maka jalankan pengecekan jadibot.json
  if (!isPrimaryBot) {
    const botSelf = getBotSelfConfig(myBotNumber);

    if (botSelf) {
      // 3.a. Cek selft_bot
      if (botSelf.selft_bot === true) {
        const ownerOfBot = botSelf.nomor_owner
          ? String(botSelf.nomor_owner).replace(/\D/g, '')
          : null;

        const senderNomorClean = nomor ? String(nomor).replace(/\D/g, '') : null;
        const isBotOwner =
          (ownerOfBot && senderNomorClean && ownerOfBot === senderNomorClean) ||
          (botSelf.lid && lid && botSelf.lid === lid) ||
          isOwnerSender;

        if (!isBotOwner) {
          if (config.mode === 'development') {
            log.warn(`[SELFT_BOT] Abaikan ${command} dari ${nomor || lid} — self mode aktif untuk bot +${myBotNumber}`);
          }
          return; // ⛔ silent
        }
      }

      // 3.b. Cek mode_chat
      if (botSelf.mode_chat === 'private' && isGroup && !isOwnerSender) {
        if (config.mode === 'development') {
          log.warn(`[MODE_CHAT] Bot +${myBotNumber} mode private — abaikan ${command} dari grup`);
        }
        return; // ⛔ silent
      }
      if (botSelf.mode_chat === 'grup' && !isGroup && !isOwnerSender) {
        if (config.mode === 'development') {
          log.warn(`[MODE_CHAT] Bot +${myBotNumber} mode grup — abaikan ${command} dari private`);
        }
        return; // ⛔ silent
      }
    }
    // Fallback: bot secondary tak terdaftar di jadibot.json & di grup → diam total
    else if (isGroup) {
      if (config.mode === 'development') {
        log.warn(`[JADIBOT_UNKNOWN] Bot +${myBotNumber} tidak ada di jadibot.json — abaikan command grup`);
      }
      return; // ⛔ silent
    }
  }

  // ============================================================
  // 4. CEK MAINTENANCE
  // ============================================================
  if (isMaintenance() && !isOwnerSender) {
    if (config.mode === 'development') {
      log.warn(`[MAINT] Bot maintenance, abaikan ${command} dari ${nomor || lid}`);
    }
    return replyMaintenance(sock, remoteJid, msg, sysLang);
  }

  // ============================================================
  // 5. CEK SELFT MODE (GLOBAL)
  // ============================================================
  if (isSelft() && !isOwnerSender) {
    if (config.mode === 'development') {
      log.warn(`[SELFT] Abaikan ${command} dari ${nomor || lid} (bukan owner)`);
    }
    return;
  }

  // ============================================================
  // 6. ANTI-SPAM & RATE LIMIT (reaction ❌ dipakai di sini)
  // ============================================================
  if (!isOwnerSender) {
    const senderKey = { lid, nomor };

    // 6.1. Cek punish aktif
    const punished = isSpamPunished(senderKey);
    if (punished.punished) {
      if (config.mode === 'development') {
        log.warn(`[SPAM] ${nomor || lid} di-punish, abaikan ${command} (sisa ${formatDuration(punished.sisaMs)})`);
      }
      await reactReject(sock, msg);
      return;
    }

    // 6.2. Deteksi spam
    const rawBody = text.slice(PREFIX.length).trim();
    const spamCheck = checkSpam(senderKey, rawBody);

    if (spamCheck.isSpam) {
      if (config.mode === 'development') {
        log.warn(`[SPAM] ${nomor || lid} SPAM (${rawBody}), punish ${formatDuration(spamCheck.punishMs)}`);
      }
      await reactReject(sock, msg);

      const durLabel = formatDuration(spamCheck.punishMs);
      const warnText =
        `${ST(sysLang, 'spam_title')}\n\n` +
        `${ST(sysLang, 'spam_body', { dur: durLabel })}\n\n` +
        `${ST(sysLang, 'spam_footer')}`;
      try {
        await sendText(sock, remoteJid, warnText, { quoted: msg });
      } catch {}
      return;
    }

    // 6.3. Rate limit
    let rateHit;
    if (isGroup) {
      const groupId = remoteJid.split('@')[0];
      rateHit = checkGroupRateLimit(groupId);
    } else {
      rateHit = checkUserRateLimit(senderKey);
    }

    if (rateHit.limited) {
      if (config.mode === 'development') {
        log.warn(`[RATE] ${isGroup ? 'Grup' : 'User'} limit — ${command} dari ${nomor || lid} (sisa ${Math.ceil(rateHit.sisaMs)}ms)`);
      }
      await reactReject(sock, msg);
      return;
    }
  }

  // ============================================================
  // 7. FILTER MODE CHAT GLOBAL & RENT
  // ============================================================
  const modeChat = config.mode_chat || 'both';
  const isWhitelisted = WHITELIST_COMMANDS.includes(command);
  const isBypassFilter = isOwnerSender || isPremiumSender;

  if (!isBypassFilter) {
    if (modeChat === 'grup' && !isGroup && !isWhitelisted) return;
    if (modeChat === 'private' && isGroup && !isWhitelisted) return;

    if (isGroup && config.only_rent_grup && !isWhitelisted) {
      const groupId = remoteJid.split('@')[0];
      const punyaSewa = hasRent(groupId);
      const masihAktif = isRentActive(groupId);

      if (!punyaSewa || !masihAktif) {
        if (config.mode === 'development') {
          const reason = !punyaSewa ? 'grup belum disewa' : 'sewa expired';
          log.warn(`[RENT] Abaikan command dari grup ${groupId} (${reason})`);
        }
        return;
      }
    }
  }

  // ============================================================
  // 8. AUTO-QUOTED REPLY
  // ============================================================
  const reply = async (teks) => {
    try {
      return await sendText(sock, remoteJid, teks, { quoted: msg });
    } catch (err) {
      const errMsg = err?.message || String(err);
      if (errMsg.includes('negative publish ack') || errMsg.includes('error=463')) {
        log.warn(`[SKIP] Gagal kirim teks ke ${remoteJid}: Target belum pernah chat (463).`);
      } else {
        log.error(`Gagal kirim teks: ${errMsg}`);
      }
      return null;
    }
  };

  const replyMedia = async (media, opts = {}) => {
    try {
      return await sendMedia(sock, remoteJid, media, { quoted: msg, ...opts });
    } catch (err) {
      const errMsg = err?.message || String(err);
      if (errMsg.includes('negative publish ack') || errMsg.includes('error=463')) {
        log.warn(`[SKIP] Gagal kirim media ke ${remoteJid}: Target belum pernah chat (463).`);
      } else {
        log.error(`Gagal kirim media: ${errMsg}`);
      }
      return null;
    }
  };

  // ============================================================
  // 9. CEK USER TERDAFTAR
  // ============================================================
  const needsAccount = plugin.token_usage > 0 || plugin.only_premium || plugin.only_owner;

  if (!user && needsAccount && !isOwnerSender) {
    if (command !== 'daftar') {
      return replyNotRegistered(sock, remoteJid, msg, sysLang);
    }
  }

  // ============================================================
  // 10. VALIDASI ROLE (OWNER & PREMIUM)
  // ============================================================
  if (plugin.only_owner && !isOwnerSender) {
    return reply(ST(sysLang, 'only_owner'));
  }
  if (plugin.only_premium && !isPremiumSender && !isOwnerSender) {
    return reply(ST(sysLang, 'only_premium'));
  }

  // ============================================================
  // 11. CEK TOKEN
  // ============================================================
  if (plugin.token_usage > 0 && !isOwnerSender) {
    if (!user) {
      return replyNotRegistered(sock, remoteJid, msg, sysLang);
    }
    const res = useToken({ lid, nomor }, plugin.token_usage);
    if (!res.ok) {
      return reply(ST(sysLang, 'token_warn', {
        reason: res.reason,
        sisa: res.sisa ?? 0,
      }));
    }
  }

  // ============================================================
  // 12. LOG COMMAND
  // ============================================================
  const logSender = lid ? `@${lid.split('@')[0]}` : `@${nomor}`;
  const roleTag = isOwnerSender
    ? chalk.magenta(` [OWNER]`)
    : isPremiumSender
      ? chalk.cyan(` [PREMIUM]`)
      : (!user ? chalk.gray(` (Guest)`) : '');

  console.log(
    chalk.gray(`  [CMD] `) +
    chalk.white(PREFIX + command) +
    chalk.gray(` dari `) +
    chalk.yellow(logSender) +
    (isGroup ? chalk.gray(` di grup`) : '') +
    roleTag
  );

  // ============================================================
  // 13. EKSEKUSI PLUGIN
  // ============================================================
  try {
    await plugin.handler({
      sock,
      msg,
      reply,
      replyMedia,
      text: args.join(' '),
      args,
      command,
      prefix: PREFIX,
      sender: {
        nomor,
        lid,
        isOwner: isOwnerSender,
        isPremium: isPremiumSender,
        user,
      },
      isGroup,
      remoteJid,
      folder,
      db: { registerUser, findUser, isOwner, isPremium },
    });
  } catch (e) {
    log.error(`Plugin ${command} error: ${e?.message || e}`);
    sendText(sock, remoteJid, ST(sysLang, 'plugin_error', { err: e?.message || e }), { quoted: msg }).catch(() => {});
  }
}