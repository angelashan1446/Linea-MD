// libx/date.js
// Helper tanggal zona Asia/Jakarta

const TZ = 'Asia/Jakarta';

/**
 * Sekarang dalam zona Asia/Jakarta, format ISO untuk database
 */
export function nowIso() {
  return new Date().toLocaleString('sv-SE', { timeZone: TZ }).replace(' ', 'T');
}

/**
 * Date object sekarang (JS Date tetap pakai zona server, tapi helper di bawah
 * yang menampilkan/membandingkan sudah dipaksa Jakarta)
 */
export function nowDate() {
  return new Date();
}

/**
 * Format tampilan: "26 Oktober 2026, 14:30 WIB"
 */
export function formatTanggal(input) {
  const d = input instanceof Date ? input : new Date(input);
  if (isNaN(d.getTime())) return '-';

  const tanggal = d.toLocaleDateString('id-ID', {
    timeZone: TZ,
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const jam = d.toLocaleTimeString('id-ID', {
    timeZone: TZ,
    hour: '2-digit',
    minute: '2-digit',
  });
  return `${tanggal}, ${jam} WIB`;
}

/**
 * Cek apakah tanggal `input` sudah lewat dibanding sekarang (Asia/Jakarta)
 */
export function isExpired(input) {
  const d = input instanceof Date ? input : new Date(input);
  if (isNaN(d.getTime())) return true;
  return d.getTime() < Date.now();
}

/**
 * Tambah hari dari sekarang (untuk premium, dll), kembalikan ISO string
 */
export function addDays(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString();
}