// main.js
// Entry point: koneksi WA, routing pesan, load plugin, auto backup.

import chalk from 'chalk';
import config from './config.js';
import {
  connectAllSessions,
  disconnectAllSessions,
} from './libx/whatsapp/connect.js';
import { bootstrapOwners } from './libx/db.js';
import { emitMessage } from './libx/handlers.js';
import { handleReply, handleNoReply, getSessionStats } from './libx/session_plugins.js';

// ✅ IMPORT DARI FILE BARU
import { handleCommand } from './libx/handle_cmd.js';
import {
  log,
  setupGlobalErrorHandlers,
  loadExtraHandlers,
  scanPlugins,
  plugins,
  gracefulShutdown,
} from './libx/startup.js';

// ✅ AUTO BACKUP
import { autobackup, stopAutoBackup } from './libx/auto_backup.js';

const PREFIX = config.prefix;

// Setup Error Handler Global
setupGlobalErrorHandlers();

// ============================================================
// MESSAGE HANDLER (Cuma Routing Doang)
// ============================================================
export async function handleMessage(sock, msg, folder) {
  const text =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption ||
    '';

  // 1. JALANKAN EVENT BUS (Antilink, dll)
  try {
    const stopped = await emitMessage(sock, msg, folder);
    if (stopped) return;
  } catch (e) {
    log.error(`Emit error: ${e?.message || e}`);
  }

  // 2. CEK SESSION PLUGIN (Jawaban game)
  try {
    const handledByReply = await handleReply(sock, msg, folder);
    if (handledByReply) return;
  } catch (e) {
    log.error(`Session reply error: ${e?.message || e}`);
  }

  try {
    const handledByNoReply = await handleNoReply(sock, msg, folder);
    if (handledByNoReply) return;
  } catch (e) {
    log.error(`Session no-reply error: ${e?.message || e}`);
  }

  // 3. CEK APAKAH INI COMMAND
  if (!text.startsWith(PREFIX)) return;

  const args = text.slice(PREFIX.length).trim().split(/\s+/);
  const command = (args.shift() || '').toLowerCase();
  if (!command) return;

  // 4. CARI PLUGIN
  const plugin = plugins.get(command);
  if (!plugin) return;

  // 5. LEMPAR KE handle_cmd.js
  await handleCommand(sock, msg, text, plugin, folder);
}

// Expose untuk plugin (mis. addbot)
global.__handleMessage = handleMessage;
global.__sessionStats = getSessionStats;

// ============================================================
// START BOT
// ============================================================
async function start() {
  log.blank();
  console.log(chalk.cyan.bold(`  ╭────────────────────────────────╮`));
  console.log(chalk.cyan.bold(`  │                                │`));
  console.log(chalk.cyan.bold(`  │      `) + chalk.white.bold(`🤖 ${config.bot_name}`) + chalk.cyan.bold(`        │`));
  console.log(chalk.cyan.bold(`  │      `) + chalk.gray(`WhatsApp Bot`) + chalk.cyan.bold(`        │`));
  console.log(chalk.cyan.bold(`  │                                │`));
  console.log(chalk.cyan.bold(`  ╰────────────────────────────────╯`));
  log.blank();

  bootstrapOwners();

  await loadExtraHandlers();

  log.banner(`🔌  LOADING PLUGINS`);
  await scanPlugins();

  log.info(`Total command: ${chalk.green.bold(plugins.size)}`);
  log.info(`Mode chat: ${chalk.yellow.bold(config.mode_chat || 'both')}`);
  log.info(`Only Rent Grup: ${chalk.yellow.bold(config.only_rent_grup ? 'YA' : 'TIDAK')}`);
  log.divider();
  log.blank();

  log.banner(`📱  CONNECTING WA SESSIONS`);

  await connectAllSessions({
    onMessage: handleMessage,
    onConnected: (sock, folder) => {
      log.success(`[READY] ${folder}`);

      // ✅ Start auto backup (3 jam sekali) — hanya sekali per proses
      try {
        autobackup(sock);
        log.info(`[AUTO-BACKUP] ✅ Aktif — interval 3 jam`);
      } catch (e) {
        log.warn(`[AUTO-BACKUP] Gagal start: ${e?.message || e}`);
      }
    },
    onDisconnected: (folder) => {
      log.warn(`[OFF] ${folder}`);
    },
  });
}

// ============================================================
// GRACEFUL SHUTDOWN (+ stop auto backup)
// ============================================================
function shutdownWrapper(signal) {
  // Stop auto backup dulu
  try {
    stopAutoBackup();
    log.info(`[AUTO-BACKUP] 🛑 Dihentikan`);
  } catch {}

  // Lanjut graceful shutdown
  return gracefulShutdown(disconnectAllSessions, signal);
}

process.on('SIGINT', () => shutdownWrapper('SIGINT'));
process.on('SIGTERM', () => shutdownWrapper('SIGTERM'));

start().catch((e) => {
  log.error(`Startup error: ${e?.message || e}`);
  console.error(e);
  process.exit(1);
});