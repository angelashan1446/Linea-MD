// plugins/tools/qrscan.js
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { createCanvas, loadImage } from '@napi-rs/canvas';
import jsQR from 'jsqr';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['qrscan', 'readqr', 'scanqr'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 1;

export const description_id = 'Scan / baca QR code dari gambar yang di-reply';
export const description_ch = '扫描/读取所回复图片中的 QR 码';
export const description_uk = 'Scan / read QR code from the replied image';
export const description = description_id;

const TEXT = {
    id: {
        no_image:
            '⚠️ Balas sebuah gambar QR code!\n\n' +
            '*Cara pakai:*\n' +
            '1. Kirim/reply gambar QR code\n' +
            '2. Ketik *.qrscan*',
        not_found:
            '❌ *QR code tidak terdeteksi!*\n\n' +
            'Pastikan:\n' +
            '• Gambar jelas & fokus\n' +
            '• QR code tidak terpotong\n' +
            '• Tidak terlalu blur\n' +
            '• Resolusi cukup (min. 200x200px)',
        header: `乂  *ᴀɴɢᴇʟ's - ǫʀ sᴄᴀɴ*`,
        label_result: 'Hasil',
        label_info: 'Info',
        label_type: 'Tipe',
        label_length: 'Panjang',
        label_size: 'Ukuran Gambar',
        type_value: 'QR Code',
        type_version: 'QR v{v}',
        length_value: '{n} karakter',
        fail: '❌ Gagal scan QR: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        no_image:
            '⚠️ 请回复一张 QR 码图片！\n\n' +
            '*使用方法：*\n' +
            '1. 发送/回复 QR 码图片\n' +
            '2. 输入 *.qrscan*',
        not_found:
            '❌ *未检测到 QR 码！*\n\n' +
            '请确保：\n' +
            '• 图片清晰且对焦\n' +
            '• QR 码未被裁切\n' +
            '• 不太模糊\n' +
            '• 分辨率足够（至少 200x200px）',
        header: `乂  *ᴀɴɢᴇʟ's - ǫʀ sᴄᴀɴ*`,
        label_result: '结果',
        label_info: '信息',
        label_type: '类型',
        label_length: '长度',
        label_size: '图片大小',
        type_value: 'QR 码',
        type_version: 'QR v{v}',
        length_value: '{n} 个字符',
        fail: '❌ 扫描 QR 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        no_image:
            '⚠️ Reply to a QR code image!\n\n' +
            '*How to use:*\n' +
            '1. Send/reply a QR code image\n' +
            '2. Type *.qrscan*',
        not_found:
            '❌ *QR code not detected!*\n\n' +
            'Make sure:\n' +
            '• Image is clear & focused\n' +
            '• QR code is not cropped\n' +
            '• Not too blurry\n' +
            '• Resolution is enough (min. 200x200px)',
        header: `乂  *ᴀɴɢᴇʟ's - ǫʀ sᴄᴀɴ*`,
        label_result: 'Result',
        label_info: 'Info',
        label_type: 'Type',
        label_length: 'Length',
        label_size: 'Image Size',
        type_value: 'QR Code',
        type_version: 'QR v{v}',
        length_value: '{n} characters',
        fail: '❌ Failed to scan QR: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directImage = msg.message?.imageMessage;
    const quotedImage = quoted?.imageMessage;
    if (!quotedImage && !directImage) return reply(T(lang, 'no_image'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        const image = await loadImage(buffer);
        const canvas = createCanvas(image.width, image.height);
        const ctx2d = canvas.getContext('2d');
        ctx2d.drawImage(image, 0, 0);
        const imageData = ctx2d.getImageData(0, 0, canvas.width, canvas.height);

        const qrResult = jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: 'attemptBoth',
        });

        if (!qrResult || !qrResult.data) {
            await sendReaction(sock, remoteJid, msg.key, '❌');
            return reply(T(lang, 'not_found'));
        }

        const result = qrResult.data;
        const typeLabel = qrResult.version
            ? T(lang, 'type_version', { v: qrResult.version })
            : T(lang, 'type_value');

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_result')}* :\n${result}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦ ${T(lang, 'label_type')} : ${typeLabel}\n` +
            `   ◦ ${T(lang, 'label_length')} : ${T(lang, 'length_value', { n: result.length })}\n` +
            `   ◦ ${T(lang, 'label_size')} : ${image.width}x${image.height}px\n\n` +
            `${T(lang, 'footer')}`;

        await reply(caption);
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[qrscan]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}