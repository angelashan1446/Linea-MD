// plugins/tools/pdftoimg.js
// Convert PDF jadi gambar (semua halaman) — support multi-bahasa.

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { createCanvas } from '@napi-rs/canvas';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['pdftoimg', 'pdf2img', 'pdfimg'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 3;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Convert PDF jadi gambar (semua halaman)';
export const description_ch = '将 PDF 转换为图片（所有页面）';
export const description_uk = 'Convert PDF to images (all pages)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_pdf_reply:
            '⚠️ Balas sebuah file *PDF* yang ingin diubah ke gambar!\n\n' +
            '*Cara pakai:*\n' +
            '1. Reply file PDF\n' +
            '2. Ketik *.pdftoimg*\n\n' +
            '*Opsi:*\n' +
            '• *.pdftoimg* → semua halaman\n' +
            '• *.pdftoimg 1-3* → halaman 1 sampai 3\n' +
            '• *.pdftoimg 5* → halaman 5 aja',
        not_pdf: '❌ File yang di-reply bukan PDF.',
        too_large: '❌ PDF terlalu besar (maks 20 MB).',
        page_range_label: 'Halaman {range}',
        page_range_invalid:
            '❌ Range halaman tidak valid. PDF ini punya {total} halaman.',
        too_many_pages:
            '❌ Terlalu banyak halaman ({n}). Maksimal 10 halaman sekali kirim.\n\n' +
            'Contoh: *.pdftoimg 1-10*',
        header: `乂  *ᴀɴɢᴇʟ's - ᴘᴅꜰ ᴛᴏ ɪᴍɢ*`,
        label_info: 'Info',
        label_file: 'File',
        label_page: 'Halaman',
        label_size: 'Ukuran',
        label_resolution: 'Resolusi',
        fail_render_all: 'Gagal render semua halaman.',
        fail: '❌ Gagal convert PDF: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        no_pdf_reply:
            '⚠️ 请回复要转换为图片的 *PDF* 文件！\n\n' +
            '*使用方法：*\n' +
            '1. 回复 PDF 文件\n' +
            '2. 输入 *.pdftoimg*\n\n' +
            '*选项：*\n' +
            '• *.pdftoimg* → 所有页面\n' +
            '• *.pdftoimg 1-3* → 第 1 页到第 3 页\n' +
            '• *.pdftoimg 5* → 仅第 5 页',
        not_pdf: '❌ 所回复的文件不是 PDF。',
        too_large: '❌ PDF 文件太大（最大 20 MB）。',
        page_range_label: '第 {range} 页',
        page_range_invalid:
            '❌ 页面范围无效。此 PDF 共有 {total} 页。',
        too_many_pages:
            '❌ 页面太多（{n} 页）。一次最多发送 10 页。\n\n' +
            '示例：*.pdftoimg 1-10*',
        header: `乂  *ᴀɴɢᴇʟ's - ᴘᴅꜰ ᴛᴏ ɪᴍɢ*`,
        label_info: '信息',
        label_file: '文件',
        label_page: '页面',
        label_size: '大小',
        label_resolution: '分辨率',
        fail_render_all: '所有页面渲染失败。',
        fail: '❌ 转换 PDF 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        no_pdf_reply:
            '⚠️ Reply to a *PDF* file you want to convert to images!\n\n' +
            '*How to use:*\n' +
            '1. Reply a PDF file\n' +
            '2. Type *.pdftoimg*\n\n' +
            '*Options:*\n' +
            '• *.pdftoimg* → all pages\n' +
            '• *.pdftoimg 1-3* → pages 1 to 3\n' +
            '• *.pdftoimg 5* → only page 5',
        not_pdf: '❌ The replied file is not a PDF.',
        too_large: '❌ PDF is too large (max 20 MB).',
        page_range_label: 'Page {range}',
        page_range_invalid:
            '❌ Invalid page range. This PDF has {total} pages.',
        too_many_pages:
            '❌ Too many pages ({n}). Max 10 pages per send.\n\n' +
            'Example: *.pdftoimg 1-10*',
        header: `乂  *ᴀɴɢᴇʟ's - ᴘᴅꜰ ᴛᴏ ɪᴍɢ*`,
        label_info: 'Info',
        label_file: 'File',
        label_page: 'Page',
        label_size: 'Size',
        label_resolution: 'Resolution',
        fail_render_all: 'Failed to render any page.',
        fail: '❌ Failed to convert PDF: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

let pdfjsLib = null;
async function loadPdfJs() {
    if (pdfjsLib) return pdfjsLib;
    pdfjsLib = await import('pdfjs-dist/legacy/build/pdf.mjs');
    return pdfjsLib;
}

async function renderPageToBuffer(page, scale = 2.0) {
    const viewport = page.getViewport({ scale });
    const canvas = createCanvas(viewport.width, viewport.height);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, viewport.width, viewport.height);

    await page.render({ canvasContext: ctx, viewport }).promise;

    return canvas.toBuffer('image/png');
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, msg, reply, replyMedia, remoteJid, args, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    // 1. Cek PDF yang di-reply
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedDoc =
        quoted?.documentMessage ||
        quoted?.documentWithCaptionMessage?.message?.documentMessage;

    if (!quotedDoc) {
        return reply(T(lang, 'no_pdf_reply'));
    }

    const mimetype = quotedDoc.mimetype || '';
    if (!mimetype.includes('pdf')) {
        return reply(T(lang, 'not_pdf'));
    }

    const fileLength = quotedDoc.fileLength || 0;
    if (fileLength > 20 * 1024 * 1024) {
        return reply(T(lang, 'too_large'));
    }

    // Parse range halaman
    const rangeArg = args[0]?.trim();
    let pageStart = null, pageEnd = null;

    if (rangeArg) {
        if (rangeArg.includes('-')) {
            const [start, end] = rangeArg.split('-').map(s => parseInt(s.trim()));
            if (!isNaN(start) && !isNaN(end) && start > 0 && end >= start) {
                pageStart = start;
                pageEnd = end;
            }
        } else {
            const num = parseInt(rangeArg);
            if (!isNaN(num) && num > 0) {
                pageStart = num;
                pageEnd = num;
            }
        }
    }

    await sendReaction(sock, remoteJid, msg.key, '📄');

    try {
        const pdfBuffer = await sock.downloadMediaMessage(msg);
        await sendReaction(sock, remoteJid, msg.key, '⏳');

        const pdfjs = await loadPdfJs();
        const loadingTask = pdfjs.getDocument({
            data: new Uint8Array(pdfBuffer),
            useWorkerFetch: false,
            isEvalSupported: false,
            useSystemFonts: true,
        });

        const pdf = await loadingTask.promise;
        const totalPages = pdf.numPages;

        let start = pageStart || 1;
        let end = pageEnd || totalPages;

        if (start < 1) start = 1;
        if (end > totalPages) end = totalPages;
        if (start > end) {
            return reply(T(lang, 'page_range_invalid', { total: totalPages }));
        }

        const pagesToRender = [];
        for (let i = start; i <= end; i++) pagesToRender.push(i);

        if (pagesToRender.length > 10) {
            return reply(T(lang, 'too_many_pages', { n: pagesToRender.length }));
        }

        await sendReaction(sock, remoteJid, msg.key, '🖼️');

        const fileName = quotedDoc.fileName?.replace(/\.pdf$/i, '') || 'pdf';
        let sentCount = 0;

        for (const pageNum of pagesToRender) {
            try {
                const page = await pdf.getPage(pageNum);
                const imgBuffer = await renderPageToBuffer(page, 2.0);
                const sizeKb = (imgBuffer.length / 1024).toFixed(1);

                const caption =
                    `${T(lang, 'header')}\n\n` +
                    `*${T(lang, 'label_info')}* :\n` +
                    `   ◦ ${T(lang, 'label_file')} : ${fileName}.pdf\n` +
                    `   ◦ ${T(lang, 'label_page')} : ${pageNum} / ${totalPages}\n` +
                    `   ◦ ${T(lang, 'label_size')} : ${sizeKb} KB\n` +
                    `   ◦ ${T(lang, 'label_resolution')} : 2x\n\n` +
                    `${T(lang, 'footer')}`;

                await replyMedia({
                    buffer: imgBuffer,
                    mimetype: 'image/png',
                    caption,
                });

                sentCount++;
                page.cleanup();

                if (sentCount < pagesToRender.length) {
                    await new Promise(r => setTimeout(r, 1000));
                }
            } catch (pageErr) {
                console.warn(`[pdftoimg] Gagal render halaman ${pageNum}:`, pageErr.message);
            }
        }

        if (sentCount === 0) {
            throw new Error(T(lang, 'fail_render_all'));
        }

        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error('[pdftoimg]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}