// plugins/tools/upload.js
import { engine } from '../../libx/engine/index.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['upload', 'cdn'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 1;

export const description_id = 'Upload media (gambar/video/audio/dokumen) ke CDN';
export const description_ch = '将媒体（图片/视频/音频/文档）上传到 CDN';
export const description_uk = 'Upload media (image/video/audio/document) to CDN';
export const description = description_id;

const TEXT = {
    id: {
        no_reply: '⚠️ Balas gambar/video/dokumen yang ingin diupload!',
        only_types: '❌ Hanya bisa mengupload gambar, video, audio, atau dokumen.',
        header: `乂  *ᴀɴɢᴇʟs - ᴜᴘʟᴏᴀᴅ ᴄᴅɴ*`,
        label_url: 'URL',
        label_info: 'Info',
        label_format: 'Format',
        label_size: 'Ukuran',
        label_expired: 'Kedaluwarsa',
        fail: '❌ Gagal upload: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        no_reply: '⚠️ 请回复要上传的图片/视频/文档！',
        only_types: '❌ 仅支持上传图片、视频、音频或文档。',
        header: `乂  *ᴀɴɢᴇʟs - ᴄᴅɴ 上传*`,
        label_url: 'URL',
        label_info: '信息',
        label_format: '格式',
        label_size: '大小',
        label_expired: '过期时间',
        fail: '❌ 上传失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        no_reply: '⚠️ Reply to an image/video/document you want to upload!',
        only_types: '❌ Only image, video, audio, or document can be uploaded.',
        header: `乂  *ᴀɴɢᴇʟs - ᴜᴘʟᴏᴀᴅ ᴄᴅɴ*`,
        label_url: 'URL',
        label_info: 'Info',
        label_format: 'Format',
        label_size: 'Size',
        label_expired: 'Expires',
        fail: '❌ Failed to upload: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (!quoted) return reply(T(lang, 'no_reply'));

    const type = Object.keys(quoted)[0];
    const allowedTypes = ['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage'];
    if (!allowedTypes.includes(type)) return reply(T(lang, 'only_types'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        const mediaObj = quoted[type];
        const mimetype = mediaObj.mimetype || 'application/octet-stream';

        let format = 'bin';
        if (mimetype.includes('jpeg')) format = 'jpg';
        else if (mimetype.includes('png')) format = 'png';
        else if (mimetype.includes('mp4')) format = 'mp4';
        else if (mimetype.includes('mp3')) format = 'mp3';
        else if (mimetype.includes('webp')) format = 'webp';
        else if (mimetype.includes('pdf')) format = 'pdf';

        await sendReaction(sock, remoteJid, msg.key, '⬆️');

        const res = await engine.upload.fromBuffer(buffer, format);

        await sendReaction(sock, remoteJid, msg.key, '✅');

        const fileSizeKb = (buffer.length / 1024).toFixed(1);
        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_url')}* : ${res.url}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦ ${T(lang, 'label_format')} : ${format.toUpperCase()}\n` +
            `   ◦ ${T(lang, 'label_size')} : ${fileSizeKb} KB\n` +
            `   ◦ ${T(lang, 'label_expired')} : ${res.expires_in}\n\n` +
            `${T(lang, 'footer')}`;

        await reply(caption);
    } catch (err) {
        console.error(err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}