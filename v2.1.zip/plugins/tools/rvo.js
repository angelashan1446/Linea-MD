// plugins/tools/rvo.js
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { downloadQuotedMedia } from '../../libx/utils/media.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['rvo', 'readviewonce', 'buka'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 1;

export const description_id = 'Buka media sekali lihat (View Once) yang di-reply';
export const description_ch = '打开所回复的"查看一次"（View Once）媒体';
export const description_uk = 'Open the replied "View Once" media';
export const description = description_id;

const TEXT = {
    id: {
        no_reply: '⚠️ Balas media *sekali lihat* (View Once) dengan command *.rvo*',
        download_fail: 'Gagal download media (kemungkinan sudah dihapus WA).',
        header: `乂  *ᴀɴɢᴇʟ's - ᴠɪᴇᴡ ᴏɴᴄᴇ*`,
        success: '✅ Berhasil dibuka!',
        label_info: 'Info',
        label_type: 'Tipe',
        label_size: 'Ukuran',
        fail: '❌ Gagal membuka View Once: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        no_reply: '⚠️ 请回复"查看一次"媒体并使用 *.rvo*',
        download_fail: '下载媒体失败（可能已被 WhatsApp 删除）。',
        header: `乂  *ᴀɴɢᴇʟ's - ᴠɪᴇᴡ ᴏɴᴄᴇ*`,
        success: '✅ 已成功打开！',
        label_info: '信息',
        label_type: '类型',
        label_size: '大小',
        fail: '❌ 打开 View Once 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        no_reply: '⚠️ Reply to a "View Once" media with *.rvo*',
        download_fail: 'Failed to download media (maybe already deleted by WA).',
        header: `乂  *ᴀɴɢᴇʟ's - ᴠɪᴇᴡ ᴏɴᴄᴇ*`,
        success: '✅ Successfully opened!',
        label_info: 'Info',
        label_type: 'Type',
        label_size: 'Size',
        fail: '❌ Failed to open View Once: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, replyMedia, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quotedInfo = msg.message?.extendedTextMessage?.contextInfo;
    if (!quotedInfo?.quotedMessage) return reply(T(lang, 'no_reply'));

    await sendReaction(sock, remoteJid, msg.key, '⏰');

    try {
        const media = await downloadQuotedMedia(sock, msg);
        if (!media) throw new Error(T(lang, 'download_fail'));

        const sizeKb = (media.buffer.length / 1024).toFixed(1);

        if (media.type === 'audioMessage') {
            await replyMedia({ buffer: media.buffer, mimetype: media.mimetype, ptt: true });
        } else {
            const caption =
                `${T(lang, 'header')}\n\n` +
                `${T(lang, 'success')}\n\n` +
                `*${T(lang, 'label_info')}* :\n` +
                `   ◦ ${T(lang, 'label_type')} : ${media.label}\n` +
                `   ◦ ${T(lang, 'label_size')} : ${sizeKb} KB\n\n` +
                `${T(lang, 'footer')}`;
            await replyMedia({ buffer: media.buffer, mimetype: media.mimetype, caption });
        }

        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[rvo]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}