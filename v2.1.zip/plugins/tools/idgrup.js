// plugins/tools/idgrup.js
// Cek ID grup WhatsApp (khusus di dalam grup) — support multi-bahasa.

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['idgrup', 'idg', 'gcid', 'grup'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Cek ID grup WhatsApp (khusus di dalam grup)';
export const description_ch = '查看 WhatsApp 群组 ID（仅限群组内）';
export const description_uk = 'Check WhatsApp group ID (only inside a group)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        only_group: '❌ Command ini hanya bisa dipakai di dalam grup.',
    },
    ch: {
        only_group: '❌ 此命令仅可在群组内使用。',
    },
    uk: {
        only_group: '❌ This command can only be used inside a group.',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    await sendReaction(sock, remoteJid, msg.key, '🆔');

    if (!remoteJid.endsWith('@g.us')) {
        return reply(T(lang, 'only_group'));
    }

    const groupId = remoteJid.split('@')[0];

    await reply(`🆔 *${groupId}*`);
    await sendReaction(sock, remoteJid, msg.key, '✅');
}