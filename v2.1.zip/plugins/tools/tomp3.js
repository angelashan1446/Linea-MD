// plugins/tools/tomp3.js
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegPath from 'ffmpeg-static';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

ffmpeg.setFfmpegPath(ffmpegPath);

export const cmd = ['tomp3', 'mp3'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 1;

export const description_id = 'Convert video/audio jadi MP3 (reply media)';
export const description_ch = '将视频/音频转换为 MP3（回复媒体）';
export const description_uk = 'Convert video/audio to MP3 (reply media)';
export const description = description_id;

const TEXT = {
    id: {
        no_reply: '⚠️ Balas video/audio yang ingin diubah ke MP3!',
        only_av: '❌ Hanya bisa video atau audio.',
        header: `乂  *ᴀɴɢᴇʟs - ᴛᴏ ᴍᴘ3*`,
        label_size: 'Ukuran',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        no_reply: '⚠️ 请回复要转换为 MP3 的视频/音频！',
        only_av: '❌ 仅支持视频或音频。',
        header: `乂  *ᴀɴɢᴇʟs - ᴛᴏ ᴍᴘ3*`,
        label_size: '大小',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        no_reply: '⚠️ Reply to a video/audio you want to convert to MP3!',
        only_av: '❌ Only video or audio is supported.',
        header: `乂  *ᴀɴɢᴇʟs - ᴛᴏ ᴍᴘ3*`,
        label_size: 'Size',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, msg, reply, replyMedia, remoteJid, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (!quoted) return reply(T(lang, 'no_reply'));

    const type = Object.keys(quoted)[0];
    if (!['videoMessage', 'audioMessage'].includes(type)) {
        return reply(T(lang, 'only_av'));
    }

    await sendReaction(sock, remoteJid, msg.key, '🎵');

    const tmpIn = path.join(os.tmpdir(), `in_${Date.now()}.tmp`);
    const tmpOut = path.join(os.tmpdir(), `out_${Date.now()}.mp3`);

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        fs.writeFileSync(tmpIn, buffer);

        await sendReaction(sock, remoteJid, msg.key, '⏳');

        await new Promise((resolve, reject) => {
            ffmpeg(tmpIn)
                .toFormat('mp3')
                .audioBitrate('128k')
                .on('end', resolve)
                .on('error', reject)
                .save(tmpOut);
        });

        const result = fs.readFileSync(tmpOut);
        const sizeKb = (result.length / 1024).toFixed(1);

        await replyMedia({
            buffer: result,
            mimetype: 'audio/mpeg',
            fileName: `audio_${Date.now()}.mp3`,
            caption: `${T(lang, 'header')}\n\n*${T(lang, 'label_size')}* : ${sizeKb} KB\n\n${T(lang, 'footer')}`,
        });

        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[tomp3]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    } finally {
        try { fs.unlinkSync(tmpIn); } catch {}
        try { fs.unlinkSync(tmpOut); } catch {}
    }
}