// plugins/tools/togif.js
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegPath from 'ffmpeg-static';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

ffmpeg.setFfmpegPath(ffmpegPath);

export const cmd = ['togif', 'gif'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 3;

export const description_id = 'Convert video jadi GIF (buat share di grup)';
export const description_ch = '将视频转换为 GIF（用于群组分享）';
export const description_uk = 'Convert video to GIF (for sharing in groups)';
export const description = description_id;

const TEXT = {
    id: {
        no_video:
            '⚠️ Balas sebuah *video* atau *stiker animasi*!\n\n' +
            '*Format:* {prefix}togif [detik]\n\n' +
            '*Contoh:*\n' +
            '• {prefix}togif (default 5 detik)\n' +
            '• {prefix}togif 3 (3 detik pertama)\n' +
            '• {prefix}togif 10 (10 detik pertama)\n\n' +
            '_Keterangan: GIF max 10 detik biar ukuran nggak kegedean_',
        too_large: '❌ Video terlalu besar (maks 50 MB).',
        empty_gif: 'GIF kosong.',
        gif_too_large:
            '❌ GIF terlalu besar ({size} MB).\n\n' +
            'Coba pakai durasi lebih pendek:\n' +
            '• {prefix}togif 3\n' +
            '• {prefix}togif 5',
        header: `乂  *ᴀɴɢᴇʟ's - ᴛᴏ ɢɪꜰ*`,
        label_info: 'Info',
        label_duration: 'Durasi',
        label_fps: 'FPS',
        label_resolution: 'Resolusi',
        label_size: 'Ukuran',
        label_loop: 'Loop',
        duration_value: '{d} detik',
        fail: '❌ Gagal convert: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        no_video:
            '⚠️ 请回复一段*视频*或*动态贴纸*！\n\n' +
            '*格式：* {prefix}togif [秒]\n\n' +
            '*示例：*\n' +
            '• {prefix}togif（默认 5 秒）\n' +
            '• {prefix}togif 3（前 3 秒）\n' +
            '• {prefix}togif 10（前 10 秒）\n\n' +
            '_说明：GIF 最长 10 秒，避免文件过大_',
        too_large: '❌ 视频太大（最大 50 MB）。',
        empty_gif: 'GIF 为空。',
        gif_too_large:
            '❌ GIF 太大（{size} MB）。\n\n' +
            '请尝试更短的时长：\n' +
            '• {prefix}togif 3\n' +
            '• {prefix}togif 5',
        header: `乂  *ᴀɴɢᴇʟ's - ᴛᴏ ɢɪꜰ*`,
        label_info: '信息',
        label_duration: '时长',
        label_fps: '帧率',
        label_resolution: '分辨率',
        label_size: '大小',
        label_loop: '循环',
        duration_value: '{d} 秒',
        fail: '❌ 转换失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        no_video:
            '⚠️ Reply to a *video* or *animated sticker*!\n\n' +
            '*Format:* {prefix}togif [seconds]\n\n' +
            '*Example:*\n' +
            '• {prefix}togif (default 5 seconds)\n' +
            '• {prefix}togif 3 (first 3 seconds)\n' +
            '• {prefix}togif 10 (first 10 seconds)\n\n' +
            '_Note: GIF max 10 seconds to keep size small_',
        too_large: '❌ Video is too large (max 50 MB).',
        empty_gif: 'GIF is empty.',
        gif_too_large:
            '❌ GIF is too large ({size} MB).\n\n' +
            'Try a shorter duration:\n' +
            '• {prefix}togif 3\n' +
            '• {prefix}togif 5',
        header: `乂  *ᴀɴɢᴇʟ's - ᴛᴏ ɢɪꜰ*`,
        label_info: 'Info',
        label_duration: 'Duration',
        label_fps: 'FPS',
        label_resolution: 'Resolution',
        label_size: 'Size',
        label_loop: 'Loop',
        duration_value: '{d} seconds',
        fail: '❌ Failed to convert: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function videoToGif(inputBuffer, opts = {}) {
    return new Promise((resolve, reject) => {
        const { duration = 5, fps = 12, width = 480, startTime = 0 } = opts;
        const tmpIn = path.join(os.tmpdir(), `in_${Date.now()}.mp4`);
        const tmpOut = path.join(os.tmpdir(), `out_${Date.now()}.gif`);

        try { fs.writeFileSync(tmpIn, inputBuffer); }
        catch (err) { return reject(new Error(`Gagal tulis temp file: ${err.message}`)); }

        const cleanup = () => {
            try { fs.unlinkSync(tmpIn); } catch {}
            try { fs.unlinkSync(tmpOut); } catch {}
        };

        ffmpeg(tmpIn)
            .setStartTime(startTime)
            .duration(duration)
            .outputOptions([
                '-vf', `fps=${fps},scale=${width}:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=128[p];[s1][p]paletteuse=dither=bayer`,
                '-loop', '0',
                '-y',
            ])
            .on('end', () => {
                try { const gif = fs.readFileSync(tmpOut); cleanup(); resolve(gif); }
                catch (err) { cleanup(); reject(new Error(`Gagal baca GIF: ${err.message}`)); }
            })
            .on('error', (err) => { cleanup(); reject(new Error(`FFmpeg error: ${err.message}`)); })
            .save(tmpOut);
    });
}

export default async function handler(ctx) {
    const { sock, msg, reply, replyMedia, remoteJid, args, prefix, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directVideo = msg.message?.videoMessage;
    const quotedVideo = quoted?.videoMessage;
    const quotedSticker = quoted?.stickerMessage;
    if (!quotedVideo && !directVideo && !quotedSticker) {
        return reply(T(lang, 'no_video', { prefix }));
    }

    let duration = 5;
    if (args[0]) {
        const d = parseFloat(args[0]);
        if (!isNaN(d) && d > 0 && d <= 10) duration = d;
    }

    await sendReaction(sock, remoteJid, msg.key, '🎬');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        if (buffer.length > 50 * 1024 * 1024) return reply(T(lang, 'too_large'));

        await sendReaction(sock, remoteJid, msg.key, '⏳');

        const gifBuffer = await videoToGif(buffer, { duration, fps: 12, width: 480 });
        if (!gifBuffer || gifBuffer.length === 0) throw new Error(T(lang, 'empty_gif'));

        const sizeKb = (gifBuffer.length / 1024).toFixed(1);
        const sizeMb = (gifBuffer.length / 1024 / 1024).toFixed(2);

        if (gifBuffer.length > 16 * 1024 * 1024) {
            return reply(T(lang, 'gif_too_large', { size: sizeMb, prefix }));
        }

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦ ${T(lang, 'label_duration')} : ${T(lang, 'duration_value', { d: duration })}\n` +
            `   ◦ ${T(lang, 'label_fps')} : 12\n` +
            `   ◦ ${T(lang, 'label_resolution')} : 480px\n` +
            `   ◦ ${T(lang, 'label_size')} : ${sizeKb} KB (${sizeMb} MB)\n` +
            `   ◦ ${T(lang, 'label_loop')} : ∞\n\n` +
            `${T(lang, 'footer')}`;

        await replyMedia({ buffer: gifBuffer, mimetype: 'image/gif', caption });
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[togif]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}