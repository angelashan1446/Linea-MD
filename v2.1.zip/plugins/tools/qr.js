// plugins/tools/qr.js
// Generate QR code dari teks — support multi-bahasa.

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import QRCode from 'qrcode';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['qr', 'qrcode'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 1;

export const description_id = 'Generate QR code dari teks';
export const description_ch = '根据文本生成 QR 码';
export const description_uk = 'Generate a QR code from text';
export const description = description_id;

const TEXT = {
    id: {
        no_text:
            '⚠️ Masukkan teks yang ingin dijadikan QR!\n\n' +
            '*Contoh:*\n' +
            '• {prefix}qr https://google.com\n' +
            '• {prefix}qr Halo Dunia\n' +
            '• {prefix}qr 6281234567890',
        too_long: '❌ Teks terlalu panjang (maks 1000 karakter).',
        header: `乂  *ᴀɴɢᴇʟ's - ǫʀ ᴄᴏᴅᴇ*`,
        label_content: 'Isi',
        label_info: 'Info',
        label_type: 'Tipe',
        label_size: 'Ukuran',
        label_ec: 'Koreksi Error',
        type_value: 'QR Code',
        ec_value: 'High (H)',
        fail: '❌ Gagal generate QR: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        no_text:
            '⚠️ 请输入要生成 QR 码的文本！\n\n' +
            '*示例：*\n' +
            '• {prefix}qr https://google.com\n' +
            '• {prefix}qr 你好世界\n' +
            '• {prefix}qr 6281234567890',
        too_long: '❌ 文本太长（最多 1000 字符）。',
        header: `乂  *ᴀɴɢᴇʟ's - ǫʀ ᴄᴏᴅᴇ*`,
        label_content: '内容',
        label_info: '信息',
        label_type: '类型',
        label_size: '大小',
        label_ec: '纠错级别',
        type_value: 'QR 码',
        ec_value: '高 (H)',
        fail: '❌ 生成 QR 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        no_text:
            '⚠️ Enter the text you want to turn into a QR!\n\n' +
            '*Example:*\n' +
            '• {prefix}qr https://google.com\n' +
            '• {prefix}qr Hello World\n' +
            '• {prefix}qr 6281234567890',
        too_long: '❌ Text is too long (max 1000 characters).',
        header: `乂  *ᴀɴɢᴇʟ's - ǫʀ ᴄᴏᴅᴇ*`,
        label_content: 'Content',
        label_info: 'Info',
        label_type: 'Type',
        label_size: 'Size',
        label_ec: 'Error Correction',
        type_value: 'QR Code',
        ec_value: 'High (H)',
        fail: '❌ Failed to generate QR: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, msg, reply, replyMedia, remoteJid, args, prefix, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const text = args.join(' ').trim();
    if (!text) return reply(T(lang, 'no_text', { prefix }));
    if (text.length > 1000) return reply(T(lang, 'too_long'));

    await sendReaction(sock, remoteJid, msg.key, '📱');

    try {
        const buffer = await QRCode.toBuffer(text, {
            type: 'png',
            width: 512,
            margin: 2,
            color: { dark: '#0F172A', light: '#FFFFFF' },
            errorCorrectionLevel: 'H',
        });

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_content')}* :\n${text}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦ ${T(lang, 'label_type')} : ${T(lang, 'type_value')}\n` +
            `   ◦ ${T(lang, 'label_size')} : ${(buffer.length / 1024).toFixed(1)} KB\n` +
            `   ◦ ${T(lang, 'label_ec')} : ${T(lang, 'ec_value')}\n\n` +
            `${T(lang, 'footer')}`;

        await replyMedia({ buffer, mimetype: 'image/png', caption });
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[qr]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}