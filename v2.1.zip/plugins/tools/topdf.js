// plugins/tools/topdf.js
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import PDFDocument from 'pdfkit';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['topdf', 'pdf'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 2;

export const description_id = 'Konversi gambar jadi PDF';
export const description_ch = '将图片转换为 PDF';
export const description_uk = 'Convert image to PDF';
export const description = description_id;

const TEXT = {
    id: {
        no_image:
            '⚠️ Balas sebuah *gambar* yang ingin diubah ke PDF!\n\n' +
            '*Cara pakai:*\n' +
            '1. Reply gambar\n' +
            '2. Ketik *.topdf*\n\n' +
            '_Support: JPG, PNG, WEBP_',
        too_large: '❌ Gambar terlalu besar (maks 20 MB).',
        empty_pdf: 'PDF kosong atau gagal dibuat.',
        header: `乂  *ᴀɴɢᴇʟ's - ɪᴍɢ ᴛᴏ ᴘᴅꜰ*`,
        label_info: 'Info',
        label_filename: 'Nama File',
        label_img_size: 'Ukuran Gambar',
        label_pdf_size: 'Ukuran PDF',
        label_format: 'Format',
        format_value: 'PDF (A4)',
        fail: '❌ Gagal convert: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        no_image:
            '⚠️ 请回复要转换为 PDF 的*图片*！\n\n' +
            '*使用方法：*\n' +
            '1. 回复图片\n' +
            '2. 输入 *.topdf*\n\n' +
            '_支持：JPG、PNG、WEBP_',
        too_large: '❌ 图片太大（最大 20 MB）。',
        empty_pdf: 'PDF 为空或生成失败。',
        header: `乂  *ᴀɴɢᴇʟ's - 图片转 ᴘᴅꜰ*`,
        label_info: '信息',
        label_filename: '文件名',
        label_img_size: '图片大小',
        label_pdf_size: 'PDF 大小',
        label_format: '格式',
        format_value: 'PDF (A4)',
        fail: '❌ 转换失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        no_image:
            '⚠️ Reply to an *image* you want to convert to PDF!\n\n' +
            '*How to use:*\n' +
            '1. Reply an image\n' +
            '2. Type *.topdf*\n\n' +
            '_Supported: JPG, PNG, WEBP_',
        too_large: '❌ Image is too large (max 20 MB).',
        empty_pdf: 'PDF is empty or failed to generate.',
        header: `乂  *ᴀɴɢᴇʟ's - ɪᴍɢ ᴛᴏ ᴘᴅꜰ*`,
        label_info: 'Info',
        label_filename: 'Filename',
        label_img_size: 'Image Size',
        label_pdf_size: 'PDF Size',
        label_format: 'Format',
        format_value: 'PDF (A4)',
        fail: '❌ Failed to convert: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function imageToPdf(imageBuffer) {
    return new Promise((resolve, reject) => {
        try {
            const doc = new PDFDocument({ autoFirstPage: false, size: 'A4', margin: 0 });
            const chunks = [];
            doc.on('data', (chunk) => chunks.push(chunk));
            doc.on('end', () => resolve(Buffer.concat(chunks)));
            doc.on('error', reject);

            const img = doc.openImage(imageBuffer);
            const A4_WIDTH = 595.28;
            const A4_HEIGHT = 841.89;
            const ratio = Math.min(A4_WIDTH / img.width, A4_HEIGHT / img.height);
            const drawWidth = img.width * ratio;
            const drawHeight = img.height * ratio;
            const x = (A4_WIDTH - drawWidth) / 2;
            const y = (A4_HEIGHT - drawHeight) / 2;

            doc.addPage({ size: 'A4', margin: 0 });
            doc.image(imageBuffer, x, y, { width: drawWidth, height: drawHeight });
            doc.end();
        } catch (err) {
            reject(err);
        }
    });
}

export default async function handler(ctx) {
    const { sock, msg, reply, replyMedia, remoteJid, args, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directImage = msg.message?.imageMessage;
    const quotedImage = quoted?.imageMessage;

    if (!quotedImage && !directImage) return reply(T(lang, 'no_image'));

    const fileName = args.join(' ').trim() || `image_${Date.now()}`;

    await sendReaction(sock, remoteJid, msg.key, '📄');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        if (buffer.length > 20 * 1024 * 1024) return reply(T(lang, 'too_large'));

        await sendReaction(sock, remoteJid, msg.key, '⏳');

        const pdfBuffer = await imageToPdf(buffer);
        if (!pdfBuffer || pdfBuffer.length === 0) throw new Error(T(lang, 'empty_pdf'));

        const pdfSizeKb = (pdfBuffer.length / 1024).toFixed(1);
        const imgSizeKb = (buffer.length / 1024).toFixed(1);

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦ ${T(lang, 'label_filename')} : ${fileName}.pdf\n` +
            `   ◦ ${T(lang, 'label_img_size')} : ${imgSizeKb} KB\n` +
            `   ◦ ${T(lang, 'label_pdf_size')} : ${pdfSizeKb} KB\n` +
            `   ◦ ${T(lang, 'label_format')} : ${T(lang, 'format_value')}\n\n` +
            `${T(lang, 'footer')}`;

        await replyMedia({
            buffer: pdfBuffer,
            mimetype: 'application/pdf',
            fileName: `${fileName}.pdf`,
            caption,
        });

        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[topdf]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}