// plugins/tools/topptx.js
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import pptxgen from 'pptxgenjs';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['topptx', 'ppt', 'pptx'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 2;

export const description_id = 'Konversi gambar jadi file presentasi PPTX';
export const description_ch = '将图片转换为 PPTX 演示文件';
export const description_uk = 'Convert image to PPTX presentation file';
export const description = description_id;

const TEXT = {
    id: {
        no_image:
            '⚠️ Balas sebuah *gambar* yang ingin diubah ke PPTX!\n\n' +
            '*Cara pakai:*\n' +
            '1. Reply gambar\n' +
            '2. Ketik *.topptx*\n\n' +
            '_Support: JPG, PNG, WEBP_',
        too_large: '❌ Gambar terlalu besar (maks 20 MB).',
        header: `乂  *ᴀɴɢᴇʟ's - ɪᴍɢ ᴛᴏ ᴘᴘᴛx*`,
        label_info: 'Info',
        label_filename: 'Nama File',
        label_img_size: 'Ukuran Gambar',
        label_pptx_size: 'Ukuran PPTX',
        label_format: 'Format',
        label_slide: 'Slide',
        format_value: 'PPTX (16:9)',
        fail: '❌ Gagal convert: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        no_image:
            '⚠️ 请回复要转换为 PPTX 的*图片*！\n\n' +
            '*使用方法：*\n' +
            '1. 回复图片\n' +
            '2. 输入 *.topptx*\n\n' +
            '_支持：JPG、PNG、WEBP_',
        too_large: '❌ 图片太大（最大 20 MB）。',
        header: `乂  *ᴀɴɢᴇʟ's - 图片转 ᴘᴘᴛx*`,
        label_info: '信息',
        label_filename: '文件名',
        label_img_size: '图片大小',
        label_pptx_size: 'PPTX 大小',
        label_format: '格式',
        label_slide: '幻灯片',
        format_value: 'PPTX (16:9)',
        fail: '❌ 转换失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        no_image:
            '⚠️ Reply to an *image* you want to convert to PPTX!\n\n' +
            '*How to use:*\n' +
            '1. Reply an image\n' +
            '2. Type *.topptx*\n\n' +
            '_Supported: JPG, PNG, WEBP_',
        too_large: '❌ Image is too large (max 20 MB).',
        header: `乂  *ᴀɴɢᴇʟ's - ɪᴍɢ ᴛᴏ ᴘᴘᴛx*`,
        label_info: 'Info',
        label_filename: 'Filename',
        label_img_size: 'Image Size',
        label_pptx_size: 'PPTX Size',
        label_format: 'Format',
        label_slide: 'Slide',
        format_value: 'PPTX (16:9)',
        fail: '❌ Failed to convert: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, msg, reply, replyMedia, remoteJid, args, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directImage = msg.message?.imageMessage;
    const quotedImage = quoted?.imageMessage;

    if (!quotedImage && !directImage) return reply(T(lang, 'no_image'));

    const fileName = args.join(' ').trim() || `presentasi_${Date.now()}`;

    await sendReaction(sock, remoteJid, msg.key, '📊');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        if (buffer.length > 20 * 1024 * 1024) return reply(T(lang, 'too_large'));

        await sendReaction(sock, remoteJid, msg.key, '⏳');

        const pptx = new pptxgen();
        pptx.layout = 'LAYOUT_16x9';

        const slide = pptx.addSlide();
        const base64 = buffer.toString('base64');
        const dataUri = `data:image/png;base64,${base64}`;

        slide.addImage({ data: dataUri, x: 0, y: 0, w: '100%', h: '100%' });

        const pptxBuffer = await pptx.write({ outputType: 'nodebuffer' });

        const pptxSizeKb = (pptxBuffer.length / 1024).toFixed(1);
        const imgSizeKb = (buffer.length / 1024).toFixed(1);

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦ ${T(lang, 'label_filename')} : ${fileName}.pptx\n` +
            `   ◦ ${T(lang, 'label_img_size')} : ${imgSizeKb} KB\n` +
            `   ◦ ${T(lang, 'label_pptx_size')} : ${pptxSizeKb} KB\n` +
            `   ◦ ${T(lang, 'label_format')} : ${T(lang, 'format_value')}\n` +
            `   ◦ ${T(lang, 'label_slide')} : 1\n\n` +
            `${T(lang, 'footer')}`;

        await replyMedia({
            buffer: pptxBuffer,
            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            fileName: `${fileName}.pptx`,
            caption,
        });

        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[topptx]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}