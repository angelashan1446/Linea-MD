// plugins/tools/id.js
// Cek ID/LID pengirim, target reply, atau nomor tertentu — support multi-bahasa.

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['id', 'lid', 'cekid', 'myid'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Cek ID/LID pengirim, target reply, atau nomor tertentu';
export const description_ch = '查看发送者、回复目标或指定号码的 ID/LID';
export const description_uk = 'Check sender / replied / specific number ID/LID';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_id: '❌ Gagal mendeteksi ID.',
    },
    ch: {
        no_id: '❌ 无法检测到 ID。',
    },
    uk: {
        no_id: '❌ Failed to detect ID.',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, args, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    await sendReaction(sock, remoteJid, msg.key, '🆔');

    // 1. Tentukan target
    const ctxInfo = msg.message?.extendedTextMessage?.contextInfo;
    const quotedSender = ctxInfo?.participant;

    let targetJid = null;

    if (args[0]) {
        let raw = args[0].trim();
        if (raw.includes('@')) targetJid = raw;
        else targetJid = `${raw}@lid`;
    } else if (quotedSender) {
        targetJid = quotedSender;
    } else {
        targetJid = sender.lid || sender.nomor;
    }

    if (!targetJid) {
        return reply(T(lang, 'no_id'));
    }

    // 2. Ambil angka LID saja
    const lidNumber = targetJid.split('@')[0];

    // 3. Kirim hasil
    await reply(`🆔 *${lidNumber}*`);
    await sendReaction(sock, remoteJid, msg.key, '✅');
}