// plugins/admin/setbot.js
// Set bot mana yang jaga grup ini (admin grup / owner) — support multi-bahasa.

import { setBotService, getBotService } from '../../libx/grup_db.js';
import { getActiveBotNumbers } from '../../libx/whatsapp/connect.js';
import { getAliasByNumber, resolveAlias } from '../../libx/utils/alias_numberbot.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['setbot', 'setbotservice'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Set bot mana yang jaga grup ini (admin grup / owner)';
export const description_ch = '设置哪个机器人管理此群组（群组管理员 / 主人）';
export const description_uk = 'Set which bot manages this group (group admin / owner)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        only_group: '❌ Command ini hanya bisa digunakan di grup.',
        metadata_fail: '❌ Gagal ambil data grup.',
        only_admin_or_owner: '❌ Command ini khusus *admin grup* atau *owner bot*.',

        header: `乂  *sᴇᴛ ʙᴏᴛ ᴅɪ ɢʀᴜᴘ ɪɴɪ*`,
        status: 'Status',
        status_dynamic: '🔄 *DYNAMIC*',
        status_specific: '🔒 *SPESIFIK*',
        status_dynamic_desc:
            '_Siapa cepat, dia yang jawab (bot manapun yang merespon duluan)_',
        status_specific_desc: '_Bot yang bertugas:_ {bot}',
        active_bots_title: '📋 *Bot yang aktif saat ini:*',
        no_active_bots: '_(Belum ada bot aktif)_',
        how_to: '📖 *Cara pakai:*',
        how_to_number: '• `.setbot <nomor>` → Set bot spesifik',
        how_to_alias: '• `.setbot <alias>` → Set via alias',
        how_to_dynamic: '• `.setbot dynamic` → Reset ke mode Dynamic',
        example_title: '*Contoh:*',
        example_number: '• `.setbot 6281111111111`',
        example_alias: '• `.setbot linea1`',
        example_dynamic: '• `.setbot dynamic`',

        dynamic_success:
            '✅ *Mode grup di-set ke DYNAMIC*\n\n' +
            '_Semua bot yang aktif sekarang bisa merespon di grup ini._\n' +
            '_Siapa yang paling cepat jawab, dia yang berhak._',
        alias_not_found:
            '❌ Alias *{arg}* tidak ditemukan.\n\n_Coba cek daftar bot dengan .setbot tanpa argumen._',
        bot_not_active:
            '❌ Bot +{nomor} tidak aktif saat ini.\n\n' +
            '*Bot yang aktif:*\n{list}',
        no_active_list: '_(Tidak ada)_',
        set_success:
            '✅ *Bot berhasil di-set!*\n\n' +
            '📌 Grup ini sekarang dijaga oleh:\n' +
            '🔒 {bot}\n\n' +
            '_Hanya bot ini yang akan merespon command di grup ini._\n' +
            '_Kalau bot ini offline, grup akan diam sampai di-set ulang._',
    },
    ch: {
        only_group: '❌ 此命令仅可在群组中使用。',
        metadata_fail: '❌ 无法获取群组数据。',
        only_admin_or_owner: '❌ 此命令仅限 *群组管理员* 或 *机器人主人* 使用。',

        header: `乂  *在本群设置机器人*`,
        status: '状态',
        status_dynamic: '🔄 *动态*',
        status_specific: '🔒 *指定*',
        status_dynamic_desc:
            '_最快响应者获胜（任何机器人先响应即可）_',
        status_specific_desc: '_负责的机器人：_ {bot}',
        active_bots_title: '📋 *当前活跃的机器人：*',
        no_active_bots: '_（暂无活跃机器人）_',
        how_to: '📖 *使用方法：*',
        how_to_number: '• `.setbot <号码>` → 设置指定机器人',
        how_to_alias: '• `.setbot <别名>` → 通过别名设置',
        how_to_dynamic: '• `.setbot dynamic` → 重置为动态模式',
        example_title: '*示例：*',
        example_number: '• `.setbot 6281111111111`',
        example_alias: '• `.setbot linea1`',
        example_dynamic: '• `.setbot dynamic`',

        dynamic_success:
            '✅ *群组已设置为动态模式*\n\n' +
            '_现在所有活跃的机器人都可以在本群响应。_\n' +
            '_最快响应的机器人获胜。_',
        alias_not_found:
            '❌ 未找到别名 *{arg}*。\n\n_请在不带参数的情况下使用 .setbot 查看机器人列表。_',
        bot_not_active:
            '❌ 机器人 +{nomor} 当前未激活。\n\n' +
            '*活跃的机器人：*\n{list}',
        no_active_list: '_（无）_',
        set_success:
            '✅ *机器人设置成功！*\n\n' +
            '📌 本群现在由以下机器人负责：\n' +
            '🔒 {bot}\n\n' +
            '_只有该机器人会响应本群中的命令。_\n' +
            '_如果该机器人离线，群组将保持沉默直到重新设置。_',
    },
    uk: {
        only_group: '❌ This command can only be used in a group.',
        metadata_fail: '❌ Failed to fetch group data.',
        only_admin_or_owner: '❌ This command is for *group admins* or *bot owner* only.',

        header: `乂  *ꜱᴇᴛ ʙᴏᴛ ɪɴ ᴛʜɪꜱ ɢʀᴏᴜᴘ*`,
        status: 'Status',
        status_dynamic: '🔄 *DYNAMIC*',
        status_specific: '🔒 *SPECIFIC*',
        status_dynamic_desc:
            '_First come, first served (any bot that responds first)_',
        status_specific_desc: '_Assigned bot:_ {bot}',
        active_bots_title: '📋 *Currently active bots:*',
        no_active_bots: '_(No active bots yet)_',
        how_to: '📖 *How to use:*',
        how_to_number: '• `.setbot <number>` → Set a specific bot',
        how_to_alias: '• `.setbot <alias>` → Set by alias',
        how_to_dynamic: '• `.setbot dynamic` → Reset to Dynamic mode',
        example_title: '*Examples:*',
        example_number: '• `.setbot 6281111111111`',
        example_alias: '• `.setbot linea1`',
        example_dynamic: '• `.setbot dynamic`',

        dynamic_success:
            '✅ *Group mode set to DYNAMIC*\n\n' +
            '_All active bots can now respond in this group._\n' +
            '_The fastest responder wins._',
        alias_not_found:
            '❌ Alias *{arg}* not found.\n\n_Try listing bots with .setbot without arguments._',
        bot_not_active:
            '❌ Bot +{nomor} is not active right now.\n\n' +
            '*Active bots:*\n{list}',
        no_active_list: '_(None)_',
        set_success:
            '✅ *Bot successfully set!*\n\n' +
            '📌 This group is now managed by:\n' +
            '🔒 {bot}\n\n' +
            '_Only this bot will respond to commands in this group._\n' +
            '_If this bot goes offline, the group will stay silent until re-set._',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, isGroup, sender, args } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    // 1. Harus di grup
    if (!isGroup) {
        return reply(T(lang, 'only_group'));
    }

    // 2. Cek admin grup atau owner
    const groupMetadata = await sock.groupMetadata(remoteJid).catch(() => null);
    if (!groupMetadata) {
        return reply(T(lang, 'metadata_fail'));
    }

    const me = groupMetadata.participants.find(p =>
        p.id === sender.rawJid || p.id === sender.lid || p.phoneNumber === sender.nomor
    );
    const isAdmin = me?.admin === 'admin' || me?.admin === 'superadmin';

    if (!isAdmin && !sender.isOwner) {
        return reply(T(lang, 'only_admin_or_owner'));
    }

    const groupId = remoteJid.split('@')[0];
    const currentService = getBotService(groupId);
    const activeBots = getActiveBotNumbers();

    const formatBot = (nomor) => {
        const alias = getAliasByNumber(nomor);
        return alias ? `${alias} (+${nomor})` : `+${nomor}`;
    };

    // ============================================================
    // TANPA ARGUMEN → info + pilihan
    // ============================================================
    if (!args[0]) {
        let text = `${T(lang, 'header')}\n\n`;

        if (currentService === 'dynamic') {
            text += `📌 ${T(lang, 'status')}: ${T(lang, 'status_dynamic')}\n`;
            text += `${T(lang, 'status_dynamic_desc')}\n\n`;
        } else {
            text += `📌 ${T(lang, 'status')}: ${T(lang, 'status_specific')}\n`;
            text += `${T(lang, 'status_specific_desc', { bot: formatBot(currentService) })}\n\n`;
        }

        text += `${T(lang, 'active_bots_title')}\n`;
        if (activeBots.length === 0) {
            text += `${T(lang, 'no_active_bots')}\n`;
        } else {
            activeBots.forEach((b) => {
                const isCurrent = b === currentService;
                text += `${isCurrent ? '✅' : '•'} ${formatBot(b)}\n`;
            });
        }

        text += `\n${T(lang, 'how_to')}\n`;
        text += `${T(lang, 'how_to_number')}\n`;
        text += `${T(lang, 'how_to_alias')}\n`;
        text += `${T(lang, 'how_to_dynamic')}\n\n`;
        text += `${T(lang, 'example_title')}\n`;
        text += `${T(lang, 'example_number')}\n`;
        text += `${T(lang, 'example_alias')}\n`;
        text += `${T(lang, 'example_dynamic')}`;

        return reply(text);
    }

    // ============================================================
    // DENGAN ARGUMEN → set bot
    // ============================================================
    const arg = args[0].toLowerCase().trim();

    // Mode dynamic
    if (arg === 'dynamic' || arg === 'reset' || arg === 'auto') {
        setBotService(groupId, 'dynamic');
        await sendReaction(sock, remoteJid, msg.key, '🔄');
        return reply(T(lang, 'dynamic_success'));
    }

    // Cari nomor bot (argumen langsung atau alias)
    let targetNumber = null;

    if (/^\d{6,}$/.test(arg)) {
        targetNumber = arg;
    } else {
        targetNumber = resolveAlias(arg);
        if (!targetNumber) {
            return reply(T(lang, 'alias_not_found', { arg }));
        }
    }

    // Validasi: harus bot aktif
    if (!activeBots.includes(targetNumber)) {
        const list = activeBots.length > 0
            ? activeBots.map(b => `• ${formatBot(b)}`).join('\n')
            : T(lang, 'no_active_list');
        return reply(T(lang, 'bot_not_active', { nomor: targetNumber, list }));
    }

    // Set bot
    setBotService(groupId, targetNumber);
    await sendReaction(sock, remoteJid, msg.key, '🔒');

    return reply(T(lang, 'set_success', { bot: formatBot(targetNumber) }));
}