// plugins/admin/on.js
// Hidupkan fitur tertentu di grup (khusus admin grup) — support multi-bahasa.

import { setFeature, getAllFeatures } from '../../libx/grup_db.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['on'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Hidupkan fitur tertentu di grup (khusus admin grup)';
export const description_ch = '开启群组中的特定功能（仅限群组管理员）';
export const description_uk = 'Enable a specific group feature (group admins only)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        only_group: '❌ Command ini hanya bisa digunakan di grup.',
        usage_header: '📖 *Format:* .on <fitur>',
        usage_features: 'Fitur tersedia:',
        metadata_fail: '❌ Gagal mengambil data grup.',
        only_admin: '❌ Command ini hanya bisa digunakan oleh *admin grup*.',
        invalid_feature: '❌ Fitur *{fitur}* tidak dikenal.',
        features_list: 'Fitur tersedia:',
        success: '✅ Fitur *{fitur}* berhasil di *NYALAKAN* di grup ini.',
    },
    ch: {
        only_group: '❌ 此命令仅可在群组中使用。',
        usage_header: '📖 *格式：* .on <功能>',
        usage_features: '可用功能：',
        metadata_fail: '❌ 无法获取群组数据。',
        only_admin: '❌ 此命令仅可由 *群组管理员* 使用。',
        invalid_feature: '❌ 未知功能 *{fitur}*。',
        features_list: '可用功能：',
        success: '✅ 功能 *{fitur}* 已在本群组中成功 *开启*。',
    },
    uk: {
        only_group: '❌ This command can only be used in a group.',
        usage_header: '📖 *Format:* .on <feature>',
        usage_features: 'Available features:',
        metadata_fail: '❌ Failed to fetch group data.',
        only_admin: '❌ This command can only be used by *group admins*.',
        invalid_feature: '❌ Unknown feature *{fitur}*.',
        features_list: 'Available features:',
        success: '✅ Feature *{fitur}* has been successfully *ENABLED* in this group.',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk'; // universal
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, reply, remoteJid, isGroup, args, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!isGroup) {
        return reply(T(lang, 'only_group'));
    }

    const validFeatures = getAllFeatures();
    const featureList = validFeatures.map(f => `• ${f}`).join('\n');

    const fitur = args[0]?.toLowerCase();
    if (!fitur) {
        return reply(
            `${T(lang, 'usage_header')}\n\n` +
            `${T(lang, 'usage_features')}\n` +
            featureList
        );
    }

    // Cek admin
    const groupId = remoteJid.split('@')[0];
    let groupMetadata;
    try {
        groupMetadata = await sock.groupMetadata(remoteJid);
    } catch (e) {
        return reply(T(lang, 'metadata_fail'));
    }

    const participant = groupMetadata.participants.find(p =>
        p.id === sender.rawJid ||
        p.id === sender.lid ||
        p.phoneNumber === sender.nomor
    );
    const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
    if (!isAdmin) {
        return reply(T(lang, 'only_admin'));
    }

    // Cek fitur valid
    if (!validFeatures.includes(fitur)) {
        return reply(
            `${T(lang, 'invalid_feature', { fitur })}\n\n` +
            `${T(lang, 'features_list')}\n` +
            featureList
        );
    }

    // Nyalakan
    setFeature(groupId, fitur, true);
    return reply(T(lang, 'success', { fitur }));
}