// plugins/admin/setlang.js
// Set bahasa grup via picker interaktif (mode pilih kaya game).
// - Admin grup only
// - Tampilkan pilihan bahasa (English sebagai picker universal)
// - User reply angka/kode → simpan ke grup_lang
// - Timeout 60 detik

import { sendReaction, sendText } from '../../libx/whatsapp/sendmsg.js';
import { registerSession } from '../../libx/session_plugins.js';
import { getGroupLang, setGroupLang, GROUP_LANGS } from '../../libx/grup_db.js';
import { findUser } from '../../libx/db.js';
import { LANGS, parseLangInput, isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['setlang', 'setbahasa', 'grouplang'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Ubah bahasa grup via picker interaktif (khusus admin grup)';
export const description_ch = '通过交互选择器更改群组语言（仅限群组管理员）';
export const description_uk = 'Change group language via interactive picker (group admins only)';
export const description = description_id;

// ============================================================
// PICKER AWAL SELALU ENGLISH
// ============================================================
const PICKER_LANG = 'uk';
const TIMEOUT_PICK_LANG = 60 * 1000;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        only_group: '❌ Command ini hanya bisa digunakan di grup.',
        metadata_fail: '❌ Gagal mengambil data grup.',
        only_admin: '❌ Command ini hanya bisa digunakan oleh *admin grup*.',

        current_lang: '🌐 Bahasa grup saat ini: *{lang}*',
        header: `乂  *sᴇᴛ ʙᴀʜᴀsᴀ ɢʀᴜᴘ*`,
        picker_intro: 'Silakan pilih bahasa yang ingin digunakan di grup ini:\n',
        picker_footer:
            '📌 Reply pesan ini dengan angka (1/2/3) atau kode bahasa (id/ch/uk).\n' +
            '⏱️ _Batas waktu: 60 detik_',
        invalid_pick: '❌ Kode bahasa tidak valid. Pilih: id / ch / uk',
        success: '✅ Bahasa grup berhasil diubah ke *{lang}*.',
        already_same: '⚠️ Bahasa grup sudah *{lang}* dari tadi.',
        timeout_msg: '⏱️ Waktu habis. Bahasa grup *tidak* diubah.\nKetik *.setlang* lagi kalau mau ganti.',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        only_group: '❌ 此命令仅可在群组中使用。',
        metadata_fail: '❌ 无法获取群组数据。',
        only_admin: '❌ 此命令仅可由 *群组管理员* 使用。',

        current_lang: '🌐 当前群组语言：*{lang}*',
        header: `乂  *设置群组语言*`,
        picker_intro: '请选择本群组要使用的语言：\n',
        picker_footer:
            '📌 请回复数字 (1/2/3) 或语言代码 (id/ch/uk)。\n' +
            '⏱️ _时限：60 秒_',
        invalid_pick: '❌ 语言代码无效。请选择：id / ch / uk',
        success: '✅ 群组语言已成功更改为 *{lang}*。',
        already_same: '⚠️ 群组语言此前已是 *{lang}*。',
        timeout_msg: '⏱️ 时间到。群组语言*未更改*。\n如需更改，请再次输入 *.setlang*。',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        only_group: '❌ This command can only be used in a group.',
        metadata_fail: '❌ Failed to fetch group data.',
        only_admin: '❌ This command can only be used by *group admins*.',

        current_lang: '🌐 Current group language: *{lang}*',
        header: `乂  *ꜱᴇᴛ ɢʀᴏᴜᴘ ʟᴀɴɢᴜᴀɢᴇ*`,
        picker_intro: 'Please choose the language to use in this group:\n',
        picker_footer:
            '📌 Reply to this message with a number (1/2/3) or language code (id/ch/uk).\n' +
            '⏱️ _Time limit: 60 seconds_',
        invalid_pick: '❌ Invalid language code. Choose: id / ch / uk',
        success: '✅ Group language successfully changed to *{lang}*.',
        already_same: '⚠️ Group language was already *{lang}*.',
        timeout_msg: '⏱️ Time\'s up. Group language *NOT* changed.\nType *.setlang* again to change it.',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return PICKER_LANG;
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function buildPicker(lang) {
    const lines = [];
    lines.push(T(lang, 'header'));
    lines.push('');
    lines.push(T(lang, 'picker_intro'));
    lines.push(`*1.* ${LANGS.id.label}`);
    lines.push(`*2.* ${LANGS.ch.label}`);
    lines.push(`*3.* ${LANGS.uk.label}`);
    lines.push('');
    lines.push(T(lang, 'picker_footer'));
    lines.push('');
    lines.push(T(lang, 'footer'));
    return lines.join('\n');
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, isGroup, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!isGroup) {
        return reply(T(lang, 'only_group'));
    }

    const groupMetadata = await sock.groupMetadata(remoteJid).catch(() => null);
    if (!groupMetadata) {
        return reply(T(lang, 'metadata_fail'));
    }

    const me = groupMetadata.participants.find(p =>
        p.id === sender.rawJid ||
        p.id === sender.lid ||
        p.phoneNumber === sender.nomor
    );
    const isAdmin = me?.admin === 'admin' || me?.admin === 'superadmin';
    if (!isAdmin) {
        return reply(T(lang, 'only_admin'));
    }

    const groupId = remoteJid.split('@')[0];
    const currentLang = getGroupLang(groupId);

    // Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '🌐');

    // ============================================================
    // Tampilkan picker bahasa (English sebagai universal)
    // ============================================================
    const pickerText = buildPicker(PICKER_LANG);
    const currentInfo = T(PICKER_LANG, 'current_lang', {
        lang: LANGS[currentLang]?.label || currentLang,
    });

    const pickerMsg = await reply(`${currentInfo}\n\n${pickerText}`);
    if (!pickerMsg?.key?.id) return;

    // ============================================================
    // Dengerin balasan user untuk pilihan bahasa
    // ============================================================
    const onLangReply = async (replyCtx) => {
        const code = parseLangInput(replyCtx.text);

        // Kode salah → tetap di session
        if (!code) {
            await replyCtx.reply(T(PICKER_LANG, 'invalid_pick'));
            return;
        }

        // Cek apakah sama dengan bahasa saat ini
        if (code === currentLang) {
            await replyCtx.reply(T(code, 'already_same', { lang: LANGS[code].label }));
            return;
        }

        // Simpan ke DB
        const res = setGroupLang(groupId, code);
        if (!res.ok) {
            await replyCtx.reply(T(code, 'invalid_pick'));
            return;
        }

        // Konfirmasi
        await replyCtx.reply(T(code, 'success', { lang: LANGS[code].label }));
        await sendReaction(sock, remoteJid, replyCtx.msg.key, '✅');
    };

    registerSession(
        pickerMsg.key.id,
        remoteJid,
        onLangReply,
        { pickedLang: null },
        {
            once: true,
            timeoutMs: TIMEOUT_PICK_LANG,
            senderJid: sender?.lid || (sender?.nomor ? `${sender.nomor}@s.whatsapp.net` : null),
            validateSender: true,
            tag: 'setlang_grup',
            onExpire: async ({ chatJid }) => {
                try {
                    await sendText(sock, chatJid, T(PICKER_LANG, 'timeout_msg'));
                } catch (_) {}
            },
        }
    );
}