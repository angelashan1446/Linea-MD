// plugins/admin/delete.js
// Hapus pesan yang di-reply (admin grup / owner) — support multi-bahasa.

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['del', 'delete', 'hapus'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Hapus pesan yang di-reply (admin grup / owner)';
export const description_ch = '删除被回复的消息（群组管理员 / 主人）';
export const description_uk = 'Delete the replied message (group admin / owner)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_reply: '⚠️ Balas pesan yang ingin dihapus dengan command *.del*',
        no_quoted_id: '❌ Gagal mengambil ID pesan yang di-reply.',
        metadata_fail: '❌ Gagal mengambil data grup.',
        only_admin_or_owner: '❌ Command ini hanya untuk *admin grup* atau *owner bot*.',
        only_admin_group: '❌ Command ini hanya bisa digunakan oleh *admin grup*.',
        bot_not_admin: '❌ Bot harus jadi *admin grup* dulu biar bisa hapus pesan.',
        bot_verify_fail: '❌ Gagal verifikasi bot sebagai admin.',
        success: '✅ Pesan berhasil dihapus.',
        err_not_authorized: '❌ Bot bukan admin atau pesan sudah terlalu lama (WA batasi ~2 hari).',
        err_not_found: '❌ Pesan tidak ditemukan (mungkin sudah dihapus duluan).',
        err_generic: '❌ Gagal menghapus: {err}',
    },
    ch: {
        no_reply: '⚠️ 请回复要删除的消息并输入 *.del*',
        no_quoted_id: '❌ 无法获取被回复消息的 ID。',
        metadata_fail: '❌ 无法获取群组数据。',
        only_admin_or_owner: '❌ 此命令仅限 *群组管理员* 或 *机器人主人* 使用。',
        only_admin_group: '❌ 此命令仅可由 *群组管理员* 使用。',
        bot_not_admin: '❌ 机器人必须先成为 *群组管理员* 才能删除消息。',
        bot_verify_fail: '❌ 无法验证机器人是否为管理员。',
        success: '✅ 消息已成功删除。',
        err_not_authorized: '❌ 机器人不是管理员，或消息太旧（WhatsApp 限制约 2 天）。',
        err_not_found: '❌ 未找到该消息（可能已被删除）。',
        err_generic: '❌ 删除失败：{err}',
    },
    uk: {
        no_reply: '⚠️ Reply to the message you want to delete with *.del*',
        no_quoted_id: '❌ Failed to get the replied message ID.',
        metadata_fail: '❌ Failed to fetch group data.',
        only_admin_or_owner: '❌ This command is for *group admins* or *bot owner* only.',
        only_admin_group: '❌ This command can only be used by *group admins*.',
        bot_not_admin: '❌ The bot must be a *group admin* first to delete messages.',
        bot_verify_fail: '❌ Failed to verify the bot as admin.',
        success: '✅ Message deleted successfully.',
        err_not_authorized: '❌ The bot is not an admin or the message is too old (WA limit ~2 days).',
        err_not_found: '❌ Message not found (maybe already deleted).',
        err_generic: '❌ Failed to delete: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk'; // universal
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, reply, remoteJid, isGroup, msg, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    // 1. Cek ada pesan yang di-reply
    const quotedInfo = msg.message?.extendedTextMessage?.contextInfo;
    if (!quotedInfo?.quotedMessage) {
        return reply(T(lang, 'no_reply'));
    }

    // 2. Ambil info pesan yang di-reply
    const quotedParticipant = quotedInfo.participant;
    const quotedId = quotedInfo.stanzaId;

    if (!quotedId) {
        return reply(T(lang, 'no_quoted_id'));
    }

    // 3. Cek hak akses
    let canDelete = false;

    if (sender.isOwner) {
        canDelete = true;
    } else if (isGroup) {
        try {
            const groupMetadata = await sock.groupMetadata(remoteJid);
            const me = groupMetadata.participants.find(p =>
                p.id === sender.rawJid ||
                p.id === sender.lid ||
                p.phoneNumber === sender.nomor
            );
            const isAdmin = me?.admin === 'admin' || me?.admin === 'superadmin';
            if (isAdmin) canDelete = true;
        } catch (e) {
            return reply(T(lang, 'metadata_fail'));
        }
    } else {
        // Private chat & bukan owner
        return reply(T(lang, 'only_admin_or_owner'));
    }

    if (!canDelete) {
        return reply(T(lang, 'only_admin_group'));
    }

    // 4. Cek bot juga admin (kalau di grup)
    if (isGroup) {
        try {
            const groupMetadata = await sock.groupMetadata(remoteJid);
            const botJid = sock.user?.id;
            const botParticipant = groupMetadata.participants.find(p =>
                p.id === botJid ||
                p.id?.includes(sock.user?.id?.split(':')[0])
            );
            const botIsAdmin =
                botParticipant?.admin === 'admin' ||
                botParticipant?.admin === 'superadmin';
            if (!botIsAdmin) {
                return reply(T(lang, 'bot_not_admin'));
            }
        } catch (e) {
            return reply(T(lang, 'bot_verify_fail'));
        }
    }

    // 5. Coba hapus pesan
    await sendReaction(sock, remoteJid, msg.key, '🗑️');

    try {
        await sock.sendMessage(remoteJid, {
            delete: {
                remoteJid: remoteJid,
                fromMe: false,
                id: quotedId,
                participant: quotedParticipant,
            },
        });

        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error('[delete]', err.message);
        const errMsg = err?.message || String(err);

        if (errMsg.includes('not-authorized') || errMsg.includes('not authorized')) {
            await reply(T(lang, 'err_not_authorized'));
        } else if (errMsg.includes('item-not-found')) {
            await reply(T(lang, 'err_not_found'));
        } else {
            await reply(T(lang, 'err_generic', { err: errMsg }));
        }

        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}