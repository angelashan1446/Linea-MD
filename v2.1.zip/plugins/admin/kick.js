// plugins/admin/kick.js
// Kick member dari grup (khusus admin grup) — support multi-bahasa.

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['kick', 'tendang', 'keluarkan'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Kick member dari grup (khusus admin grup)';
export const description_ch = '从群组中移除成员（仅限群组管理员）';
export const description_uk = 'Kick a member from the group (group admins only)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        only_group: '❌ Command ini hanya bisa digunakan di grup.',
        metadata_fail: '❌ Gagal mengambil data grup.',
        only_admin: '❌ Command ini hanya bisa digunakan oleh *admin grup*.',

        usage:
            '⚠️ *Cara pakai .kick:*\n\n' +
            '1. Reply pesan member + .kick\n' +
            '2. Tag member + .kick @member\n' +
            '3. .kick 6281234567890',
        no_valid_target:
            '❌ Tidak bisa kick admin, bot sendiri, atau diri sendiri.',
        success: '✅ {n} member berhasil di-kick.',
        partial:
            '⚠️ *Partial Success*\n\n✅ Berhasil: {ok}\n❌ Gagal: {fail}\n\n*Error:* {err}',
        fail: '❌ Gagal kick: {err}',

        hint_bot_not_admin: '\n\n_💡 Kemungkinan: bot bukan admin._',
        hint_member_left: '\n\n_💡 Kemungkinan: member sudah keluar grup._',
    },
    ch: {
        only_group: '❌ 此命令仅可在群组中使用。',
        metadata_fail: '❌ 无法获取群组数据。',
        only_admin: '❌ 此命令仅可由 *群组管理员* 使用。',

        usage:
            '⚠️ *.kick 使用方法：*\n\n' +
            '1. 回复成员消息 + .kick\n' +
            '2. 标记成员 + .kick @member\n' +
            '3. .kick 6281234567890',
        no_valid_target:
            '❌ 不能移除管理员、机器人自己或你自己。',
        success: '✅ {n} 位成员已成功移除。',
        partial:
            '⚠️ *部分成功*\n\n✅ 成功：{ok}\n❌ 失败：{fail}\n\n*错误：* {err}',
        fail: '❌ 移除失败：{err}',

        hint_bot_not_admin: '\n\n_💡 可能原因：机器人不是管理员。_',
        hint_member_left: '\n\n_💡 可能原因：该成员已退出群组。_',
    },
    uk: {
        only_group: '❌ This command can only be used in a group.',
        metadata_fail: '❌ Failed to fetch group data.',
        only_admin: '❌ This command can only be used by *group admins*.',

        usage:
            '⚠️ *How to use .kick:*\n\n' +
            '1. Reply to a member message + .kick\n' +
            '2. Mention a member + .kick @member\n' +
            '3. .kick 6281234567890',
        no_valid_target:
            '❌ Cannot kick an admin, the bot itself, or yourself.',
        success: '✅ {n} member(s) successfully kicked.',
        partial:
            '⚠️ *Partial Success*\n\n✅ Success: {ok}\n❌ Failed: {fail}\n\n*Error:* {err}',
        fail: '❌ Failed to kick: {err}',

        hint_bot_not_admin: '\n\n_💡 Possible reason: the bot is not an admin._',
        hint_member_left: '\n\n_💡 Possible reason: the member has already left the group._',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk'; // universal
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, reply, remoteJid, isGroup, msg, args, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!isGroup) return reply(T(lang, 'only_group'));

    const groupMetadata = await sock.groupMetadata(remoteJid).catch(() => null);
    if (!groupMetadata) return reply(T(lang, 'metadata_fail'));

    const me = groupMetadata.participants.find(p =>
        p.id === sender.rawJid ||
        p.id === sender.lid ||
        p.phoneNumber === sender.nomor
    );
    const isAdmin = me?.admin === 'admin' || me?.admin === 'superadmin';
    if (!isAdmin) return reply(T(lang, 'only_admin'));

    const quoted = msg.message?.extendedTextMessage?.contextInfo;
    const mentionedJids = quoted?.mentionedJid || [];
    const quotedSender = quoted?.participant;

    let targets = [];
    if (mentionedJids.length > 0) targets = mentionedJids;
    else if (quotedSender) targets = [quotedSender];
    else if (args[0] && /^\d{6,}$/.test(args[0])) targets = [`${args[0]}@s.whatsapp.net`];

    if (targets.length === 0) {
        return reply(T(lang, 'usage'));
    }

    const botNumber = sock.user?.id?.split(':')[0]?.split('@')[0];

    const targetClean = targets.filter(jid => {
        const pNumber = jid.split('@')[0];
        if (pNumber === botNumber) return false;
        if (jid === me?.id) return false;
        const target = groupMetadata.participants.find(p =>
            p.id === jid || p.id?.split('@')[0] === pNumber
        );
        if (!target) return false;
        if (target.admin === 'admin' || target.admin === 'superadmin') return false;
        return true;
    });

    if (targetClean.length === 0) {
        return reply(T(lang, 'no_valid_target'));
    }

    await sendReaction(sock, remoteJid, msg.key, '👢');

    const results = [];
    for (const jid of targetClean) {
        try {
            await sock.groupParticipantsUpdate(remoteJid, [jid], 'remove');
            results.push({ jid, ok: true });
        } catch (err) {
            results.push({ jid, ok: false, error: err?.message || String(err) });
        }
    }

    const success = results.filter(r => r.ok);
    const failed = results.filter(r => !r.ok);

    if (success.length > 0 && failed.length === 0) {
        await reply(T(lang, 'success', { n: success.length }));
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } else if (success.length > 0 && failed.length > 0) {
        await reply(T(lang, 'partial', {
            ok: success.length,
            fail: failed.length,
            err: failed[0]?.error || 'Unknown',
        }));
        await sendReaction(sock, remoteJid, msg.key, '⚠️');
    } else {
        const errMsg = failed[0]?.error || 'Unknown';
        let hint = '';
        if (errMsg.includes('not-authorized') || errMsg.includes('403')) {
            hint = T(lang, 'hint_bot_not_admin');
        } else if (errMsg.includes('item-not-found') || errMsg.includes('404')) {
            hint = T(lang, 'hint_member_left');
        }
        await reply(T(lang, 'fail', { err: errMsg }) + hint);
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}