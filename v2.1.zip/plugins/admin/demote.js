// plugins/admin/demote.js
// Turunkan admin jadi member biasa (khusus admin grup) — support multi-bahasa.

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['demote', 'turunkan'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Turunkan admin jadi member biasa (khusus admin grup)';
export const description_ch = '将管理员降为普通成员（仅限群组管理员）';
export const description_uk = 'Demote admin to regular member (group admins only)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        only_group: '❌ Command ini hanya bisa digunakan di grup.',
        metadata_fail: '❌ Gagal mengambil data grup.',
        only_admin: '❌ Command ini hanya bisa digunakan oleh *admin grup*.',

        all_no_target:
            '⚠️ Tidak ada admin yang bisa di-demote.\n\n_Admin lain sudah member biasa, atau cuma bot & kamu yang admin._',
        all_success:
            '✅ {n} admin berhasil di-*demote*.\n\n_Bot dan kamu tidak ikut di-demote._',
        all_partial:
            '⚠️ *Partial Success*\n\n✅ Berhasil: {ok}\n❌ Gagal: {fail}\n\n*Error:* {err}',
        all_fail: '❌ Gagal demote semua admin: {err}',

        usage:
            '⚠️ *Cara pakai .demote:*\n\n' +
            '1. Reply pesan admin + .demote\n' +
            '2. Tag admin + .demote @admin\n' +
            '3. .demote 6281234567890\n' +
            '4. .demote all → demote semua admin',
        no_valid_target:
            '❌ Tidak ada target valid.\n\n*Alasan:* bot sendiri, kamu sendiri, bukan admin, atau bukan member.',
        success: '✅ {n} admin berhasil di-*demote* jadi member.',
        partial:
            '⚠️ *Partial Success*\n\n✅ Berhasil: {ok}\n❌ Gagal: {fail}',
        fail: '❌ Gagal demote: {err}',

        hint_bot_not_admin: '\n\n_💡 Kemungkinan: bot bukan admin._',
    },
    ch: {
        only_group: '❌ 此命令仅可在群组中使用。',
        metadata_fail: '❌ 无法获取群组数据。',
        only_admin: '❌ 此命令仅可由 *群组管理员* 使用。',

        all_no_target:
            '⚠️ 没有可以降级的管理员。\n\n_其他管理员已经是普通成员，或者只有机器人和你是管理员。_',
        all_success:
            '✅ {n} 位管理员已成功*降级*。\n\n_机器人和你未被降级。_',
        all_partial:
            '⚠️ *部分成功*\n\n✅ 成功：{ok}\n❌ 失败：{fail}\n\n*错误：* {err}',
        all_fail: '❌ 降级所有管理员失败：{err}',

        usage:
            '⚠️ *.demote 使用方法：*\n\n' +
            '1. 回复管理员消息 + .demote\n' +
            '2. 标记管理员 + .demote @admin\n' +
            '3. .demote 6281234567890\n' +
            '4. .demote all → 降级所有管理员',
        no_valid_target:
            '❌ 没有有效的目标。\n\n*原因：* 机器人自己、你自己、不是管理员，或不是成员。',
        success: '✅ {n} 位管理员已成功*降级*为普通成员。',
        partial:
            '⚠️ *部分成功*\n\n✅ 成功：{ok}\n❌ 失败：{fail}',
        fail: '❌ 降级失败：{err}',

        hint_bot_not_admin: '\n\n_💡 可能原因：机器人不是管理员。_',
    },
    uk: {
        only_group: '❌ This command can only be used in a group.',
        metadata_fail: '❌ Failed to fetch group data.',
        only_admin: '❌ This command can only be used by *group admins*.',

        all_no_target:
            '⚠️ No admins to demote.\n\n_Other admins are already regular members, or only the bot and you are admins._',
        all_success:
            '✅ {n} admin(s) successfully *demoted*.\n\n_The bot and you are not demoted._',
        all_partial:
            '⚠️ *Partial Success*\n\n✅ Success: {ok}\n❌ Failed: {fail}\n\n*Error:* {err}',
        all_fail: '❌ Failed to demote all admins: {err}',

        usage:
            '⚠️ *How to use .demote:*\n\n' +
            '1. Reply to an admin message + .demote\n' +
            '2. Mention an admin + .demote @admin\n' +
            '3. .demote 6281234567890\n' +
            '4. .demote all → demote all admins',
        no_valid_target:
            '❌ No valid target.\n\n*Reason:* it\'s the bot itself, yourself, not an admin, or not a member.',
        success: '✅ {n} admin(s) successfully *demoted* to member.',
        partial:
            '⚠️ *Partial Success*\n\n✅ Success: {ok}\n❌ Failed: {fail}',
        fail: '❌ Failed to demote: {err}',

        hint_bot_not_admin: '\n\n_💡 Possible reason: the bot is not an admin._',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk'; // universal
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, reply, remoteJid, isGroup, msg, args, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!isGroup) return reply(T(lang, 'only_group'));

    const groupMetadata = await sock.groupMetadata(remoteJid).catch(() => null);
    if (!groupMetadata) return reply(T(lang, 'metadata_fail'));

    const me = groupMetadata.participants.find(p =>
        p.id === sender.rawJid ||
        p.id === sender.lid ||
        p.phoneNumber === sender.nomor
    );
    const isAdmin = me?.admin === 'admin' || me?.admin === 'superadmin';
    if (!isAdmin) return reply(T(lang, 'only_admin'));

    const botNumber = sock.user?.id?.split(':')[0]?.split('@')[0];

    // ── MODE: .demote all ──
    if (args[0]?.toLowerCase() === 'all') {
        const adminsToDemote = groupMetadata.participants
            .filter(p => {
                const isAdminUser = p.admin === 'admin' || p.admin === 'superadmin';
                if (!isAdminUser) return false;
                const pNumber = p.id?.split('@')[0];
                if (pNumber === botNumber) return false;
                if (p.id === me?.id || p.phoneNumber === sender.nomor) return false;
                return true;
            })
            .map(p => p.id);

        if (adminsToDemote.length === 0) {
            return reply(T(lang, 'all_no_target'));
        }

        await sendReaction(sock, remoteJid, msg.key, '⬇️');

        const results = [];
        for (const jid of adminsToDemote) {
            try {
                await sock.groupParticipantsUpdate(remoteJid, [jid], 'demote');
                results.push({ jid, ok: true });
                await new Promise(r => setTimeout(r, 800));
            } catch (err) {
                results.push({ jid, ok: false, error: err?.message || String(err) });
            }
        }

        const success = results.filter(r => r.ok);
        const failed = results.filter(r => !r.ok);

        if (success.length > 0 && failed.length === 0) {
            await reply(T(lang, 'all_success', { n: success.length }));
            await sendReaction(sock, remoteJid, msg.key, '✅');
        } else if (success.length > 0 && failed.length > 0) {
            await reply(T(lang, 'all_partial', {
                ok: success.length,
                fail: failed.length,
                err: failed[0]?.error || 'Unknown',
            }));
            await sendReaction(sock, remoteJid, msg.key, '⚠️');
        } else {
            const errMsg = failed[0]?.error || 'Unknown';
            const hint = (errMsg.includes('not-authorized') || errMsg.includes('403'))
                ? T(lang, 'hint_bot_not_admin')
                : '';
            await reply(T(lang, 'all_fail', { err: errMsg }) + hint);
            await sendReaction(sock, remoteJid, msg.key, '❌');
        }
        return;
    }

    // ── MODE: .demote <target> ──
    const quoted = msg.message?.extendedTextMessage?.contextInfo;
    const mentionedJids = quoted?.mentionedJid || [];
    const quotedSender = quoted?.participant;

    let targets = [];
    if (mentionedJids.length > 0) targets = mentionedJids;
    else if (quotedSender) targets = [quotedSender];
    else if (args[0] && /^\d{6,}$/.test(args[0])) targets = [`${args[0]}@s.whatsapp.net`];

    if (targets.length === 0) {
        return reply(T(lang, 'usage'));
    }

    const targetClean = targets.filter(jid => {
        const pNumber = jid.split('@')[0];
        if (pNumber === botNumber) return false;
        if (jid === me?.id) return false;
        const target = groupMetadata.participants.find(p =>
            p.id === jid || p.id?.split('@')[0] === pNumber
        );
        if (!target) return false;
        if (target.admin !== 'admin' && target.admin !== 'superadmin') return false;
        return true;
    });

    if (targetClean.length === 0) {
        return reply(T(lang, 'no_valid_target'));
    }

    await sendReaction(sock, remoteJid, msg.key, '⬇️');

    const results = [];
    for (const jid of targetClean) {
        try {
            await sock.groupParticipantsUpdate(remoteJid, [jid], 'demote');
            results.push({ jid, ok: true });
        } catch (err) {
            results.push({ jid, ok: false, error: err?.message || String(err) });
        }
    }

    const success = results.filter(r => r.ok);
    const failed = results.filter(r => !r.ok);

    if (success.length > 0 && failed.length === 0) {
        await reply(T(lang, 'success', { n: success.length }));
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } else if (success.length > 0 && failed.length > 0) {
        await reply(T(lang, 'partial', {
            ok: success.length,
            fail: failed.length,
        }));
        await sendReaction(sock, remoteJid, msg.key, '⚠️');
    } else {
        const errMsg = failed[0]?.error || 'Unknown';
        const hint = (errMsg.includes('not-authorized') || errMsg.includes('403'))
            ? T(lang, 'hint_bot_not_admin')
            : '';
        await reply(T(lang, 'fail', { err: errMsg }) + hint);
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}