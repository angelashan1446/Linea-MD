// plugins/admin/closegc.js
// Tutup grup (hanya admin yang bisa kirim pesan) — support multi-bahasa.

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['closegc', 'tutup', 'close'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Tutup grup (hanya admin yang bisa kirim pesan)';
export const description_ch = '关闭群组（仅管理员可以发送消息）';
export const description_uk = 'Close group (only admins can send messages)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        only_group: '❌ Command ini hanya bisa digunakan di grup.',
        metadata_fail: '❌ Gagal mengambil data grup.',
        only_admin: '❌ Command ini hanya bisa digunakan oleh *admin grup*.',
        already_closed: '⚠️ Grup sudah *DITUTUP* dari tadi.',
        success:
            '🔒 Grup berhasil *DITUTUP*.\n\nSekarang hanya admin yang bisa kirim pesan.',
        fail: '❌ Gagal tutup grup: {err}',
        hint_not_admin: '\n\n_💡 Kemungkinan: bot bukan admin grup._',
    },
    ch: {
        only_group: '❌ 此命令仅可在群组中使用。',
        metadata_fail: '❌ 无法获取群组数据。',
        only_admin: '❌ 此命令仅可由 *群组管理员* 使用。',
        already_closed: '⚠️ 群组此前已处于 *关闭* 状态。',
        success:
            '🔒 群组已成功 *关闭*。\n\n现在仅管理员可以发送消息。',
        fail: '❌ 关闭群组失败：{err}',
        hint_not_admin: '\n\n_💡 可能原因：机器人不是群组管理员。_',
    },
    uk: {
        only_group: '❌ This command can only be used in a group.',
        metadata_fail: '❌ Failed to fetch group data.',
        only_admin: '❌ This command can only be used by *group admins*.',
        already_closed: '⚠️ The group was already *CLOSED*.',
        success:
            '🔒 Group has been successfully *CLOSED*.\n\nNow only admins can send messages.',
        fail: '❌ Failed to close group: {err}',
        hint_not_admin: '\n\n_💡 Possible reason: the bot is not a group admin._',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk'; // universal
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, reply, remoteJid, isGroup, msg, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!isGroup) return reply(T(lang, 'only_group'));

    const groupMetadata = await sock.groupMetadata(remoteJid).catch(() => null);
    if (!groupMetadata) return reply(T(lang, 'metadata_fail'));

    const me = groupMetadata.participants.find(p =>
        p.id === sender.rawJid ||
        p.id === sender.lid ||
        p.phoneNumber === sender.nomor
    );
    const isAdmin = me?.admin === 'admin' || me?.admin === 'superadmin';
    if (!isAdmin) return reply(T(lang, 'only_admin'));

    if (groupMetadata.announce === true) {
        return reply(T(lang, 'already_closed'));
    }

    await sendReaction(sock, remoteJid, msg.key, '🔒');

    try {
        await sock.groupSettingUpdate(remoteJid, 'announcement');
        await reply(T(lang, 'success'));
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        const errMsg = err?.message || String(err);
        let hint = '';
        if (errMsg.includes('not-authorized') || errMsg.includes('403')) {
            hint = T(lang, 'hint_not_admin');
        }
        await reply(T(lang, 'fail', { err: errMsg }) + hint);
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}