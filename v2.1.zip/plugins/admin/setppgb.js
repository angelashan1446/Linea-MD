// plugins/admin/setppgb.js
// Ganti foto profil grup (khusus admin grup) — support multi-bahasa.

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['setppgb', 'setppgc', 'setgrouppp'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Ganti foto profil grup (khusus admin grup)';
export const description_ch = '更改群组头像（仅限群组管理员）';
export const description_uk = 'Change group profile picture (group admins only)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        only_group: '❌ Command ini hanya bisa digunakan di grup.',
        usage:
            '⚠️ *Cara pakai .setppgb:*\n\n' +
            '1. Reply gambar + .setppgb\n' +
            '2. Kirim gambar dengan caption .setppgb',
        metadata_fail: '❌ Gagal mengambil data grup.',
        only_admin: '❌ Command ini hanya bisa digunakan oleh *admin grup*.',
        download_fail: 'Gagal download gambar.',
        too_large: '❌ Gambar terlalu besar (maks 5 MB).',
        success:
            '✅ Foto profil grup berhasil diubah!\n\n' +
            '*Info* :\n' +
            '   ◦ Grup : {subject}\n' +
            '   ◦ Ukuran : {size} KB',
        fail: '❌ Gagal ubah foto profil: {err}',
        hint_bot_not_admin:
            '\n\n_💡 Kemungkinan: bot bukan admin grup, atau grup membatasi perubahan foto._',
        hint_too_large:
            '\n\n_💡 Gambar terlalu besar. WA maksimal 1 MB untuk foto profil grup._',
    },
    ch: {
        only_group: '❌ 此命令仅可在群组中使用。',
        usage:
            '⚠️ *.setppgb 使用方法：*\n\n' +
            '1. 回复图片 + .setppgb\n' +
            '2. 发送图片并配文 .setppgb',
        metadata_fail: '❌ 无法获取群组数据。',
        only_admin: '❌ 此命令仅可由 *群组管理员* 使用。',
        download_fail: '下载图片失败。',
        too_large: '❌ 图片太大（最大 5 MB）。',
        success:
            '✅ 群组头像已成功更改！\n\n' +
            '*信息* ：\n' +
            '   ◦ 群组 ：{subject}\n' +
            '   ◦ 大小 ：{size} KB',
        fail: '❌ 更改头像失败：{err}',
        hint_bot_not_admin:
            '\n\n_💡 可能原因：机器人不是群组管理员，或群组限制更改头像。_',
        hint_too_large:
            '\n\n_💡 图片太大。WhatsApp 群组头像最大 1 MB。_',
    },
    uk: {
        only_group: '❌ This command can only be used in a group.',
        usage:
            '⚠️ *How to use .setppgb:*\n\n' +
            '1. Reply to an image + .setppgb\n' +
            '2. Send an image with caption .setppgb',
        metadata_fail: '❌ Failed to fetch group data.',
        only_admin: '❌ This command can only be used by *group admins*.',
        download_fail: 'Failed to download image.',
        too_large: '❌ Image is too large (max 5 MB).',
        success:
            '✅ Group profile picture has been successfully changed!\n\n' +
            '*Info* :\n' +
            '   ◦ Group : {subject}\n' +
            '   ◦ Size  : {size} KB',
        fail: '❌ Failed to change profile picture: {err}',
        hint_bot_not_admin:
            '\n\n_💡 Possible reason: the bot is not a group admin, or the group restricts profile picture changes._',
        hint_too_large:
            '\n\n_💡 Image is too large. WhatsApp limits group profile pictures to 1 MB._',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, reply, remoteJid, isGroup, msg, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!isGroup) return reply(T(lang, 'only_group'));

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedImage = quoted?.imageMessage;
    const directImage = msg.message?.imageMessage;

    if (!quotedImage && !directImage) {
        return reply(T(lang, 'usage'));
    }

    const groupMetadata = await sock.groupMetadata(remoteJid).catch(() => null);
    if (!groupMetadata) return reply(T(lang, 'metadata_fail'));

    const me = groupMetadata.participants.find(p =>
        p.id === sender.rawJid ||
        p.id === sender.lid ||
        p.phoneNumber === sender.nomor
    );
    const isAdmin = me?.admin === 'admin' || me?.admin === 'superadmin';
    if (!isAdmin) return reply(T(lang, 'only_admin'));

    await sendReaction(sock, remoteJid, msg.key, '🖼️');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        if (!buffer || buffer.length === 0) throw new Error(T(lang, 'download_fail'));
        if (buffer.length > 5 * 1024 * 1024) {
            return reply(T(lang, 'too_large'));
        }

        await sendReaction(sock, remoteJid, msg.key, '⏳');

        await sock.updateProfilePicture(remoteJid, buffer);

        await reply(T(lang, 'success', {
            subject: groupMetadata.subject,
            size: (buffer.length / 1024).toFixed(1),
        }));
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        const errMsg = err?.message || String(err);
        let hint = '';
        if (errMsg.includes('not-authorized') || errMsg.includes('403')) {
            hint = T(lang, 'hint_bot_not_admin');
        } else if (errMsg.includes('too large')) {
            hint = T(lang, 'hint_too_large');
        }
        await reply(T(lang, 'fail', { err: errMsg }) + hint);
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}