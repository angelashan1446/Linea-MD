// plugins/info.js
// Info akun pengirim — support multi-bahasa (ID / CH / UK).

import { findUser } from '../../libx/db.js';
import { formatTanggal, isExpired } from '../../libx/date.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { isValidLang, DEFAULT_LANG, LANGS } from '../../libx/lang.js';

export const cmd = ['info'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Lihat info akun kamu';
export const description_ch = '查看您的账户信息';
export const description_uk = 'View your account info';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        header: `乂  *ᴀɴɢᴇʟ's - ɪɴꜰᴏ ᴀᴋᴜɴ*`,
        not_registered:
            '⚠️ Kamu belum terdaftar.\nKetik *{prefix}daftar* di chat pribadi.',
        field_number: 'Nomor',
        field_lid: 'LID',
        field_token: 'Token',
        field_premium: 'Premium',
        field_owner: 'Owner',
        field_lang: 'Bahasa',
        field_registered: 'Terdaftar',
        premium_no: 'Tidak',
        premium_expired: 'Expired ({date})',
        premium_active: 'Aktif s/d {date}',
        yes: 'Ya',
        no: 'Tidak',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        header: `乂  *ᴀɴɢᴇʟ's - 账户信息*`,
        not_registered:
            '⚠️ 您尚未注册。\n请在私聊中输入 *{prefix}daftar*。',
        field_number: '号码',
        field_lid: 'LID',
        field_token: '代币',
        field_premium: '高级会员',
        field_owner: '主人',
        field_lang: '语言',
        field_registered: '注册时间',
        premium_no: '否',
        premium_expired: '已过期（{date}）',
        premium_active: '有效期至 {date}',
        yes: '是',
        no: '否',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        header: `乂  *ᴀɴɢᴇʟ's - ᴀᴄᴄᴏᴜɴᴛ ɪɴꜰᴏ*`,
        not_registered:
            '⚠️ You are not registered yet.\nType *{prefix}daftar* in private chat.',
        field_number: 'Number',
        field_lid: 'LID',
        field_token: 'Token',
        field_premium: 'Premium',
        field_owner: 'Owner',
        field_lang: 'Language',
        field_registered: 'Registered',
        premium_no: 'No',
        premium_expired: 'Expired ({date})',
        premium_active: 'Active until {date}',
        yes: 'Yes',
        no: 'No',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

// ============================================================
// HELPER: t(lang, key, vars)
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { reply, sender, sock, remoteJid, msg, prefix } = ctx;
    const { lid, nomor } = sender;

    // Reaction loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    const user = findUser({ lid, nomor });
    if (!user) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        // Belum terdaftar → pakai bahasa default picker (EN) biar universal
        return reply(T('uk', 'not_registered', { prefix }));
    }

    // Tentukan bahasa user
    const lang = isValidLang(user.lang) ? user.lang : DEFAULT_LANG;

    // Premium text
    let premiumText = T(lang, 'premium_no');
    if (user.premium) {
        const date = formatTanggal(user.premium);
        premiumText = isExpired(user.premium)
            ? T(lang, 'premium_expired', { date })
            : T(lang, 'premium_active', { date });
    }

    // Reaction sukses
    await sendReaction(sock, remoteJid, msg.key, '✅');

    // Build caption
    const caption =
        `${T(lang, 'header')}\n\n` +
        `*${T(lang, 'field_number')}* : ${user.nomor}\n` +
        `*${T(lang, 'field_lid')}* : ${user.lid ? user.lid.split('@')[0] : '-'}\n` +
        `*${T(lang, 'field_token')}* : ${user.token}\n` +
        `*${T(lang, 'field_premium')}* : ${premiumText}\n` +
        `*${T(lang, 'field_owner')}* : ${user.owner ? T(lang, 'yes') : T(lang, 'no')}\n` +
        `*${T(lang, 'field_lang')}* : ${LANGS[lang].label}\n` +
        `*${T(lang, 'field_registered')}* : ${formatTanggal(user.create_at)}\n\n` +
        `${T(lang, 'footer')}`;

    return reply(caption);
}