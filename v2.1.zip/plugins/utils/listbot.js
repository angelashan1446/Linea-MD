// plugins/owner/listbot.js
// Lihat daftar semua bot & statusnya — support multi-bahasa (ID / CH / UK).

import { getActiveBotNumbers } from '../../libx/whatsapp/connect.js';
import { getAliasByNumber } from '../../libx/utils/alias_numberbot.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['listbot', 'botlist', 'daftarbot'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Lihat daftar semua bot dan statusnya (khusus owner)';
export const description_ch = '查看所有机器人及其状态（仅限主人）';
export const description_uk = 'View all bots and their status (owner only)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        header: `乂  *ʟɪsᴛ ʙᴏᴛ*`,
        empty:
            `乂  *ʟɪsᴛ ʙᴏᴛ*\n\n` +
            `⚠️ Belum ada bot yang aktif.\n\n` +
            `_Pastikan session sudah connect di folder db/sessions/_`,
        total: 'Total: {n} bot',
        alias: 'Alias',
        alias_none: '_belum di-set_',
        current: '_(bot ini)_',
        tips: '💡 *Tips:*',
        tip_setname: '• `.setname <nomor>,<alias>` → Kasih nama bot',
        tip_setbot: '• `.setbot <alias>` → Pilih bot di grup',
    },
    ch: {
        header: `乂  *机器人列表*`,
        empty:
            `乂  *机器人列表*\n\n` +
            `⚠️ 暂无活动的机器人。\n\n` +
            `_请确保会话已在 db/sessions/ 文件夹中连接_`,
        total: '总计：{n} 个机器人',
        alias: '别名',
        alias_none: '_未设置_',
        current: '_(当前机器人)_',
        tips: '💡 *提示：*',
        tip_setname: '• `.setname <号码>,<别名>` → 为机器人命名',
        tip_setbot: '• `.setbot <别名>` → 在群组中选择机器人',
    },
    uk: {
        header: `乂  *ʙᴏᴛ ʟɪsᴛ*`,
        empty:
            `乂  *ʙᴏᴛ ʟɪsᴛ*\n\n` +
            `⚠️ No active bots yet.\n\n` +
            `_Make sure sessions are connected in db/sessions/_`,
        total: 'Total: {n} bot(s)',
        alias: 'Alias',
        alias_none: '_not set_',
        current: '_(this bot)_',
        tips: '💡 *Tips:*',
        tip_setname: '• `.setname <number>,<alias>` → Name the bot',
        tip_setbot: '• `.setbot <alias>` → Select bot in group',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

/**
 * Ambil bahasa user (fallback 'uk' kalau belum terdaftar — biar universal).
 */
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    await sendReaction(sock, remoteJid, msg.key, '🤖');

    // 1. Ambil nomor bot yang aktif
    const activeBots = getActiveBotNumbers();

    // 2. Bot yang lagi jalan sekarang
    const currentBotNumber = sock.user?.id?.split(':')[0]?.split('@')[0];

    if (activeBots.length === 0) {
        return reply(T(lang, 'empty'));
    }

    // 3. Urutkan
    activeBots.sort();

    // 4. Build teks
    let text = `${T(lang, 'header')}\n\n`;
    text += `📊 *${T(lang, 'total', { n: activeBots.length })}*\n\n`;

    let count = 0;
    for (const nomor of activeBots) {
        count++;
        const alias = getAliasByNumber(nomor);
        const isCurrent = nomor === currentBotNumber;

        const statusIcon = isCurrent ? '🟢' : '⚪';
        const currentLabel = isCurrent ? ` ${T(lang, 'current')}` : '';

        text += `${count}. ${statusIcon} *+${nomor}*\n`;

        if (alias) {
            text += `   📛 ${T(lang, 'alias')}: \`${alias}\`\n`;
        } else {
            text += `   📛 ${T(lang, 'alias')}: ${T(lang, 'alias_none')}\n`;
        }

        text += `${currentLabel}\n`;
    }

    text += `\n${T(lang, 'tips')}\n`;
    text += `${T(lang, 'tip_setname')}\n`;
    text += `${T(lang, 'tip_setbot')}\n`;

    return reply(text);
}