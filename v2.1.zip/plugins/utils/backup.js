// plugins/owner/backup.js
// Command backup manual — zip folder db/ & kirim ke owner.

import { backup } from '../../libx/auto_backup.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['backup', 'backupdb'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Backup database (folder db/) sebagai file zip';
export const description_ch = '将数据库（db/ 文件夹）备份为 zip 文件';
export const description_uk = 'Backup the database (db/ folder) as a zip file';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        processing: '⏳ Memproses backup...\n\n_Menyiapkan file zip dari folder db/_',
        success: '✅ *Backup Berhasil!*\n\nFile zip telah dikirim ke owner.',
        fail: '❌ *Backup Gagal*\n\n{alasan}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        processing: '⏳ 正在处理备份...\n\n_正在将 db/ 文件夹压缩为 zip_',
        success: '✅ *备份成功！*\n\nzip 文件已发送给主人。',
        fail: '❌ *备份失败*\n\n{alasan}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        processing: '⏳ Processing backup...\n\n_Packing db/ folder into zip_',
        success: '✅ *Backup Successful!*\n\nThe zip file has been sent to the owner.',
        fail: '❌ *Backup Failed*\n\n{alasan}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    // Reaction loading
    await sendReaction(sock, remoteJid, msg.key, '📦');

    // Kirim pesan "processing" (bisa lama karena zip + kirim ke owner)
    await reply(T(lang, 'processing'));

    try {
        const res = await backup(sock, { chatJid: null, msg: null });

        if (res.ok) {
            await sendReaction(sock, remoteJid, msg.key, '✅');
            return reply(
                `${T(lang, 'success')}\n\n` +
                `📊 Terkirim ke: *${res.count}* owner\n\n` +
                `${T(lang, 'footer')}`
            );
        } else {
            await sendReaction(sock, remoteJid, msg.key, '❌');
            return reply(T(lang, 'fail', { alasan: res.error || 'Unknown error' }));
        }
    } catch (err) {
        console.error('[BACKUP]', err.message);
        await sendReaction(sock, remoteJid, msg.key, '❌');
        return reply(T(lang, 'fail', { alasan: err.message }));
    }
}