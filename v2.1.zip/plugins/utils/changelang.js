// plugins/tools/changelang.js
// Atur bahasa pribadi user via picker interaktif.
// - Bisa di grup / private
// - Picker awal pakai English (universal)
// - User reply angka/kode → setUserLang
// - Timeout 60 detik

import { sendReaction, sendText } from '../../libx/whatsapp/sendmsg.js';
import { registerSession } from '../../libx/session_plugins.js';
import { findUser, setUserLang } from '../../libx/db.js';
import {
    LANGS,
    DEFAULT_LANG,
    isValidLang,
    parseLangInput,
} from '../../libx/lang.js';

export const cmd = ['changelang', 'ubahbahasa', 'clang'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Ubah bahasa pribadi kamu';
export const description_ch = '更改你的个人语言';
export const description_uk = 'Change your personal language';
export const description = description_id;

// ============================================================
// PICKER AWAL SELALU ENGLISH
// ============================================================
const PICKER_LANG = 'uk';
const TIMEOUT_PICK_LANG = 60 * 1000;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        not_registered:
            '⚠️ Kamu belum terdaftar.\nKetik *.daftar* dulu untuk memilih bahasa saat registrasi.',
        current_lang: '🌐 Bahasa kamu saat ini: *{lang}*',
        header: `乂  *ᴘɪʟɪʜ ʙᴀʜᴀsᴀ*`,
        picker_intro: 'Silakan pilih bahasa yang ingin kamu gunakan:\n',
        picker_footer:
            '📌 Reply pesan ini dengan angka (1/2/3) atau kode bahasa (id/ch/uk).\n' +
            '⏱️ _Batas waktu: 60 detik_',
        invalid_pick: '❌ Kode bahasa tidak valid. Pilih: id / ch / uk',
        success: '✅ Bahasa kamu berhasil diubah ke *{lang}*.',
        already_same: '⚠️ Bahasa kamu sudah *{lang}* dari tadi.',
        timeout_msg: '⏱️ Waktu habis. Bahasa kamu *tidak* diubah.\nKetik *.changelang* lagi kalau mau ganti.',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        not_registered:
            '⚠️ 您尚未注册。\n请先输入 *.daftar* 在注册时选择语言。',
        current_lang: '🌐 您当前的语言：*{lang}*',
        header: `乂  *选择语言*`,
        picker_intro: '请选择您想使用的语言：\n',
        picker_footer:
            '📌 请回复数字 (1/2/3) 或语言代码 (id/ch/uk)。\n' +
            '⏱️ _时限：60 秒_',
        invalid_pick: '❌ 语言代码无效。请选择：id / ch / uk',
        success: '✅ 您的语言已成功更改为 *{lang}*。',
        already_same: '⚠️ 您当前的语言已是 *{lang}*。',
        timeout_msg: '⏱️ 时间到。您的语言*未更改*。\n如需更改，请再次输入 *.changelang*。',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        not_registered:
            '⚠️ You are not registered yet.\nType *.daftar* first to choose your language at registration.',
        current_lang: '🌐 Your current language: *{lang}*',
        header: `乂  *ᴄʜᴏᴏꜱᴇ ʟᴀɴɢᴜᴀɢᴇ*`,
        picker_intro: 'Please choose the language you want to use:\n',
        picker_footer:
            '📌 Reply to this message with a number (1/2/3) or language code (id/ch/uk).\n' +
            '⏱️ _Time limit: 60 seconds_',
        invalid_pick: '❌ Invalid language code. Choose: id / ch / uk',
        success: '✅ Your language successfully changed to *{lang}*.',
        already_same: '⚠️ Your language was already *{lang}*.',
        timeout_msg: '⏱️ Time\'s up. Your language was *NOT* changed.\nType *.changelang* again to change it.',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return PICKER_LANG;
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function buildPicker(lang) {
    const lines = [];
    lines.push(T(lang, 'header'));
    lines.push('');
    lines.push(T(lang, 'picker_intro'));
    lines.push(`*1.* ${LANGS.id.label}`);
    lines.push(`*2.* ${LANGS.ch.label}`);
    lines.push(`*3.* ${LANGS.uk.label}`);
    lines.push('');
    lines.push(T(lang, 'picker_footer'));
    lines.push('');
    lines.push(T(lang, 'footer'));
    return lines.join('\n');
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, sender } = ctx;
    const { lid, nomor } = sender;

    // 1. Cek user terdaftar
    const user = findUser({ lid, nomor });
    if (!user) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        return reply(T(PICKER_LANG, 'not_registered'));
    }

    // 2. Bahasa user saat ini
    const currentLang = isValidLang(user.lang) ? user.lang : DEFAULT_LANG;

    await sendReaction(sock, remoteJid, msg.key, '🌐');

    // 3. Tampilkan picker bahasa (English universal)
    const pickerText = buildPicker(PICKER_LANG);
    const currentInfo = T(PICKER_LANG, 'current_lang', {
        lang: LANGS[currentLang]?.label || currentLang,
    });

    const pickerMsg = await reply(`${currentInfo}\n\n${pickerText}`);
    if (!pickerMsg?.key?.id) return;

    // 4. Dengerin balasan user untuk pilihan bahasa
    const onLangReply = async (replyCtx) => {
        const code = parseLangInput(replyCtx.text);

        if (!code) {
            await replyCtx.reply(T(PICKER_LANG, 'invalid_pick'));
            return;
        }

        if (code === currentLang) {
            await replyCtx.reply(T(code, 'already_same', { lang: LANGS[code].label }));
            return;
        }

        const res = setUserLang({ lid, nomor }, code);
        if (!res.ok) {
            await replyCtx.reply(T(code, 'invalid_pick'));
            return;
        }

        await replyCtx.reply(T(code, 'success', { lang: LANGS[code].label }));
        await sendReaction(sock, remoteJid, replyCtx.msg.key, '✅');
    };

    registerSession(
        pickerMsg.key.id,
        remoteJid,
        onLangReply,
        { pickedLang: null },
        {
            once: true,
            timeoutMs: TIMEOUT_PICK_LANG,
            senderJid: lid || (nomor ? `${nomor}@s.whatsapp.net` : null),
            validateSender: true,
            tag: 'user_lang',
            onExpire: async ({ chatJid }) => {
                try {
                    await sendText(sock, chatJid, T(PICKER_LANG, 'timeout_msg'));
                } catch (_) {}
            },
        }
    );
}