// plugins/tools/box.js
// Box pribadi per user: simpan teks / media / media+caption — PERSIS seperti aslinya.
//   .box save [alias]          → save (reply/caption = teks/media/caption)
//   .box get <alias|id|index>  → ambil item (langsung kirim)
//   .box get                   → tampil list picker
//   .box list                  → daftar item
//   .box del <alias|id|index>  → hapus item
//   .box clear                 → hapus semua (dengan konfirmasi)
//   .box stats                 → lihat penggunaan

import { sendReaction, sendText, sendMedia } from '../../libx/whatsapp/sendmsg.js';
import { registerSession } from '../../libx/session_plugins.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';
import {
  saveText,
  saveMedia,
  listItems,
  getItem,
  deleteItem,
  clearBox,
  getBoxStats,
  rebuildMediaOpts,
  MAX_ITEMS,
} from '../../libx/box.js';

export const cmd = ['box'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Box pribadi: simpan teks / media / media+caption, ambil kapan saja';
export const description_ch = '私人盒子：保存文本/媒体/媒体+说明，随时获取';
export const description_uk = 'Personal box: save text/media/media+caption, get anytime';
export const description = description_id;

// ============================================================
// KONFIG
// ============================================================
const TIMEOUT_PICK = 60 * 1000;

// ============================================================
// KAMUS BAHASA
// ============================================================
const TEXT = {
  id: {
    usage:
      `乂  *ʙᴏx ᴘʀɪʙᴀᴅɪ*\n\n` +
      `📖 *Format:*\n` +
      `• .box save [alias] → simpan (reply media/teks, atau caption)\n` +
      `• .box get [alias/id] → ambil item\n` +
      `• .box get → pilih dari list\n` +
      `• .box list → daftar item\n` +
      `• .box del <alias/id> → hapus item\n` +
      `• .box clear → hapus semua\n` +
      `• .box stats → lihat penggunaan`,
    invalid_sub:
      '❌ Subcommand tidak valid.\nGunakan: save / get / list / del / clear / stats',

    save_no_content:
      '⚠️ *Tidak ada konten untuk disimpan.*\n\n' +
      'Reply sebuah pesan (teks/media) atau kirim dengan caption, lalu ketik:\n' +
      '• *.box save* → tanpa alias\n' +
      '• *.box save nama_ku* → dengan alias',
    save_success_text: '✅ *Tersimpan!*\n\n◦ ID    : `{id}`\n◦ Alias : {alias}\n◦ Tipe  : Teks',
    save_success_media: '✅ *Tersimpan!*\n\n◦ ID    : `{id}`\n◦ Alias : {alias}\n◦ Tipe  : {type}',
    save_alias_none: '_tanpa alias_',
    save_fail: '❌ Gagal simpan: {reason}',

    get_not_found: '❌ Item *{key}* tidak ditemukan di box kamu.',
    get_no_key: '❌ Masukkan alias atau ID.\nContoh: *.box get nama_ku*',
    get_empty:
      '📭 Box kamu masih kosong.\n\nSimpan dulu dengan:\n' +
      '• *.box save nama_ku* (reply media/teks)',

    pick_header: `乂  *ᴘɪʟɪʜ ɪᴛᴇᴍ ʙᴏx*`,
    pick_intro: 'Reply pesan ini dengan angka untuk mengambil item:\n',
    pick_item_text: '📝',
    pick_item_image: '🖼️',
    pick_item_video: '🎬',
    pick_item_audio: '🎵',
    pick_item_sticker: '🎨',
    pick_item_document: '📄',
    pick_footer_hint: '📌 Reply angka (1-{n})\n⏱️ _Batas waktu: 60 detik_',
    pick_invalid: '❌ Nomor tidak valid. Reply angka 1 sampai {n}.',
    pick_timeout: '⏱️ Waktu habis. Pilihan dibatalkan.',

    list_header: `乂  *ʟɪsᴛ ʙᴏx*`,
    list_empty: '📭 Box kamu masih kosong.',
    list_total: 'Total: {n} / {max} item',
    list_hint: 'Ketik *.box get <alias/id>* untuk ambil item.',
    list_alias_none: 'tanpa alias',

    del_success: '✅ Item *{key}* berhasil dihapus.',
    del_fail: '❌ Gagal hapus: {reason}',
    del_no_key: '❌ Format: *.box del <alias/id>*',

    clear_confirm: '⚠️ *Hapus semua item box?*\n\nTotal: {n} item\n\nReply *1* untuk konfirmasi, atau abaikan untuk batal.',
    clear_invalid: '❌ Balasan tidak valid. Reply *1* untuk konfirmasi.',
    clear_success: '✅ Semua item box dihapus ({n} item).',
    clear_empty: '📭 Box kamu sudah kosong.',

    stats_header: `乂  *sᴛᴀᴛs ʙᴏx*`,
    stats_total: 'Item terpakai',
    stats_free: 'Slot tersisa',
    stats_size: 'Total media',
    stats_hint: 'Maks item: {max}',

    footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    type_text: 'Teks',
    type_image: 'Gambar',
    type_video: 'Video',
    type_audio: 'Audio',
    type_sticker: 'Sticker',
    type_document: 'Dokumen',

    fail_send: '❌ Gagal kirim: {err}',
    no_number: '❌ Nomor tidak terdeteksi.',
  },
  ch: {
    usage:
      `乂  *私人盒子*\n\n` +
      `📖 *格式：*\n` +
      `• .box save [别名] → 保存（回复媒体/文本，或说明）\n` +
      `• .box get [别名/ID] → 获取项目\n` +
      `• .box get → 从列表选择\n` +
      `• .box list → 列出项目\n` +
      `• .box del <别名/ID> → 删除项目\n` +
      `• .box clear → 全部删除\n` +
      `• .box stats → 查看使用情况`,
    invalid_sub:
      '❌ 子命令无效。\n请使用：save / get / list / del / clear / stats',

    save_no_content:
      '⚠️ *没有可保存的内容。*\n\n' +
      '请回复一条消息（文本/媒体）或使用说明发送，然后输入：\n' +
      '• *.box save* → 无别名\n' +
      '• *.box save 名称* → 带别名',
    save_success_text: '✅ *已保存！*\n\n◦ ID    : `{id}`\n◦ 别名 : {alias}\n◦ 类型  : 文本',
    save_success_media: '✅ *已保存！*\n\n◦ ID    : `{id}`\n◦ 别名 : {alias}\n◦ 类型  : {type}',
    save_alias_none: '_无别名_',
    save_fail: '❌ 保存失败：{reason}',

    get_not_found: '❌ 未找到项目 *{key}*。',
    get_no_key: '❌ 请输入别名或 ID。\n示例：*.box get 名称*',
    get_empty:
      '📭 您的盒子还是空的。\n\n先保存：\n' +
      '• *.box save 名称*（回复媒体/文本）',

    pick_header: `乂  *选择盒子项目*`,
    pick_intro: '请回复数字选择要获取的项目：\n',
    pick_item_text: '📝',
    pick_item_image: '🖼️',
    pick_item_video: '🎬',
    pick_item_audio: '🎵',
    pick_item_sticker: '🎨',
    pick_item_document: '📄',
    pick_footer_hint: '📌 回复数字 (1-{n})\n⏱️ _时限：60 秒_',
    pick_invalid: '❌ 号码无效。请回复 1 到 {n}。',
    pick_timeout: '⏱️ 时间到。已取消选择。',

    list_header: `乂  *盒子列表*`,
    list_empty: '📭 您的盒子还是空的。',
    list_total: '总计：{n} / {max} 项',
    list_hint: '输入 *.box get <别名/ID>* 获取项目。',
    list_alias_none: '无别名',

    del_success: '✅ 项目 *{key}* 已成功删除。',
    del_fail: '❌ 删除失败：{reason}',
    del_no_key: '❌ 格式：*.box del <别名/ID>*',

    clear_confirm: '⚠️ *删除所有项目？*\n\n总计：{n} 项\n\n回复 *1* 确认，或忽略以取消。',
    clear_invalid: '❌ 回复无效。请回复 *1* 确认。',
    clear_success: '✅ 已删除所有项目（{n} 项）。',
    clear_empty: '📭 您的盒子已经是空的。',

    stats_header: `乂  *盒子统计*`,
    stats_total: '已用项目',
    stats_free: '剩余槽位',
    stats_size: '媒体总大小',
    stats_hint: '最大项目：{max}',

    footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    type_text: '文本',
    type_image: '图片',
    type_video: '视频',
    type_audio: '音频',
    type_sticker: '贴纸',
    type_document: '文档',

    fail_send: '❌ 发送失败：{err}',
    no_number: '❌ 未检测到号码。',
  },
  uk: {
    usage:
      `乂  *ᴘᴇʀꜱᴏɴᴀʟ ʙᴏx*\n\n` +
      `📖 *Format:*\n` +
      `• .box save [alias] → save (reply media/text, or caption)\n` +
      `• .box get [alias/id] → get item\n` +
      `• .box get → pick from list\n` +
      `• .box list → list items\n` +
      `• .box del <alias/id> → delete item\n` +
      `• .box clear → delete all\n` +
      `• .box stats → usage info`,
    invalid_sub:
      '❌ Invalid subcommand.\nUse: save / get / list / del / clear / stats',

    save_no_content:
      '⚠️ *Nothing to save.*\n\n' +
      'Reply to a message (text/media) or send with caption, then type:\n' +
      '• *.box save* → no alias\n' +
      '• *.box save my_name* → with alias',
    save_success_text: '✅ *Saved!*\n\n◦ ID    : `{id}`\n◦ Alias : {alias}\n◦ Type  : Text',
    save_success_media: '✅ *Saved!*\n\n◦ ID    : `{id}`\n◦ Alias : {alias}\n◦ Type  : {type}',
    save_alias_none: '_no alias_',
    save_fail: '❌ Failed to save: {reason}',

    get_not_found: '❌ Item *{key}* not found in your box.',
    get_no_key: '❌ Enter alias or ID.\nExample: *.box get my_name*',
    get_empty:
      '📭 Your box is still empty.\n\nSave first with:\n' +
      '• *.box save my_name* (reply media/text)',

    pick_header: `乂  *ᴄʜᴏᴏꜱᴇ ʙᴏx ɪᴛᴇᴍ*`,
    pick_intro: 'Reply to this message with a number to get the item:\n',
    pick_item_text: '📝',
    pick_item_image: '🖼️',
    pick_item_video: '🎬',
    pick_item_audio: '🎵',
    pick_item_sticker: '🎨',
    pick_item_document: '📄',
    pick_footer_hint: '📌 Reply a number (1-{n})\n⏱️ _Time limit: 60 seconds_',
    pick_invalid: '❌ Invalid number. Reply a number from 1 to {n}.',
    pick_timeout: '⏱️ Time\'s up. Selection cancelled.',

    list_header: `乂  *ʙᴏx ʟɪꜱᴛ*`,
    list_empty: '📭 Your box is still empty.',
    list_total: 'Total: {n} / {max} item(s)',
    list_hint: 'Type *.box get <alias/id>* to get an item.',
    list_alias_none: 'no alias',

    del_success: '✅ Item *{key}* deleted successfully.',
    del_fail: '❌ Failed to delete: {reason}',
    del_no_key: '❌ Format: *.box del <alias/id>*',

    clear_confirm: '⚠️ *Delete all box items?*\n\nTotal: {n} item(s)\n\nReply *1* to confirm, or ignore to cancel.',
    clear_invalid: '❌ Invalid reply. Reply *1* to confirm.',
    clear_success: '✅ All box items deleted ({n} item(s)).',
    clear_empty: '📭 Your box is already empty.',

    stats_header: `乂  *ʙᴏx ꜱᴛᴀᴛꜱ*`,
    stats_total: 'Used items',
    stats_free: 'Free slots',
    stats_size: 'Total media',
    stats_hint: 'Max items: {max}',

    footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    type_text: 'Text',
    type_image: 'Image',
    type_video: 'Video',
    type_audio: 'Audio',
    type_sticker: 'Sticker',
    type_document: 'Document',

    fail_send: '❌ Failed to send: {err}',
    no_number: '❌ Number not detected.',
  },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
  const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
  let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
  for (const [k, v] of Object.entries(vars)) {
    str = str.replaceAll(`{${k}}`, String(v));
  }
  return str;
}

function langOfSender({ lid, nomor }) {
  const user = findUser({ lid, nomor });
  if (!user) return 'uk';
  return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function typeIcon(lang, type) {
  if (type === 'image') return T(lang, 'pick_item_image');
  if (type === 'video') return T(lang, 'pick_item_video');
  if (type === 'audio') return T(lang, 'pick_item_audio');
  if (type === 'sticker') return T(lang, 'pick_item_sticker');
  if (type === 'document') return T(lang, 'pick_item_document');
  return T(lang, 'pick_item_text');
}

function typeLabel(lang, type) {
  if (type === 'image') return T(lang, 'type_image');
  if (type === 'video') return T(lang, 'type_video');
  if (type === 'audio') return T(lang, 'type_audio');
  if (type === 'sticker') return T(lang, 'type_sticker');
  if (type === 'document') return T(lang, 'type_document');
  return T(lang, 'type_text');
}

// ============================================================
// HELPER: EKSTRAK MEDIA + METADATA DARI PESAN
// ============================================================
async function extractFromMessage(sock, msg) {
  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

  const quotedMedia =
    quoted?.imageMessage ||
    quoted?.videoMessage ||
    quoted?.audioMessage ||
    quoted?.stickerMessage ||
    quoted?.documentMessage ||
    quoted?.documentWithCaptionMessage?.message?.documentMessage;

  const directMedia =
    msg.message?.imageMessage ||
    msg.message?.videoMessage ||
    msg.message?.audioMessage ||
    msg.message?.stickerMessage ||
    msg.message?.documentMessage;

  const media = quotedMedia || directMedia;

  const quotedText =
    quoted?.conversation ||
    quoted?.extendedTextMessage?.text ||
    null;

  const directText =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    null;

  if (!media) {
    return {
      hasMedia: false,
      text: quotedText || directText || null,
    };
  }

  const isSticker = !!(quoted?.stickerMessage || msg.message?.stickerMessage);
  const isImage = !!(quoted?.imageMessage || msg.message?.imageMessage);
  const isVideo = !!(quoted?.videoMessage || msg.message?.videoMessage);
  const isAudio = !!(quoted?.audioMessage || msg.message?.audioMessage);
  const isDoc = !!(
    quoted?.documentMessage ||
    quoted?.documentWithCaptionMessage?.message?.documentMessage ||
    msg.message?.documentMessage
  );

  let mimetype = media.mimetype || 'application/octet-stream';
  let type = 'document';

  if (isSticker) {
    mimetype = 'image/webp';
    type = 'sticker';
  } else if (isImage) {
    mimetype = media.mimetype || 'image/jpeg';
    type = 'image';
  } else if (isVideo) {
    mimetype = media.mimetype || 'video/mp4';
    type = 'video';
  } else if (isAudio) {
    mimetype = media.mimetype || 'audio/mpeg';
    type = 'audio';
  } else if (isDoc) {
    mimetype = media.mimetype || 'application/octet-stream';
    type = 'document';
  }

  let buffer = null;
  try {
    buffer = await sock.downloadMediaMessage(msg);
  } catch (err) {
    return { hasMedia: false, error: err.message };
  }

  const mediaMeta = {
    isSticker,
    isImage,
    isVideo,
    isAudio,
    isDocument: isDoc,
    ptt: !!media.ptt,
    gifPlayback: !!media.gifPlayback,
    viewOnce: !!media.viewOnce,
    width: media.width || null,
    height: media.height || null,
    seconds: media.seconds || null,
    fileLength: media.fileLength || null,
    mimetype: media.mimetype || null,
  };

  return {
    hasMedia: true,
    buffer,
    mimetype,
    fileName: media.fileName || null,
    caption: media.caption || null,
    mediaMeta,
    type,
  };
}

// ============================================================
// HELPER: KIRIM ITEM DARI BOX (persis seperti aslinya)
// ============================================================
async function sendBoxItem(sock, remoteJid, item, buffer, { quoted } = {}) {
  // Item teks
  if (item.type === 'text' || !buffer) {
    return sendText(sock, remoteJid, item.text || '(kosong)', quoted ? { quoted } : {});
  }

  // Item media → rebuild opts berdasarkan metadata asli
  const opts = rebuildMediaOpts(item, buffer);
  if (quoted) opts.quoted = quoted;

  return sendMedia(sock, remoteJid, opts, quoted ? { quoted } : {});
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
  const { sock, msg, reply, remoteJid, args, sender } = ctx;
  const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

  const userId = sender?.nomor;
  if (!userId) {
    return reply(T(lang, 'no_number'));
  }

  const subcmd = (args[0] || '').toLowerCase();
  const argRest = args.slice(1).join(' ').trim();

  // ============================================================
  // TANPA SUBCOMMAND → usage
  // ============================================================
  if (!subcmd) {
    await sendReaction(sock, remoteJid, msg.key, '📦');
    return reply(T(lang, 'usage') + `\n\n${T(lang, 'footer')}`);
  }

  // ============================================================
  // SAVE
  // ============================================================
  if (subcmd === 'save') {
    await sendReaction(sock, remoteJid, msg.key, '📥');

    const alias = argRest || null;
    const data = await extractFromMessage(sock, msg);

    if (data.hasMedia && data.buffer) {
      const res = saveMedia(userId, data.buffer, {
        mimetype: data.mimetype,
        fileName: data.fileName,
        caption: data.caption || argRest || null,
        alias,
        mediaMeta: data.mediaMeta,
      });

      if (!res.ok) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        return reply(T(lang, 'save_fail', { reason: res.reason }));
      }

      await sendReaction(sock, remoteJid, msg.key, '✅');
      return reply(
        T(lang, 'save_success_media', {
          id: res.item.id,
          alias: res.item.alias ? `\`${res.item.alias}\`` : T(lang, 'save_alias_none'),
          type: typeLabel(lang, res.item.type),
        }) + `\n\n${T(lang, 'footer')}`
      );
    }

    const textContent = data.text || argRest;
    if (!textContent) {
      await sendReaction(sock, remoteJid, msg.key, '❌');
      return reply(T(lang, 'save_no_content'));
    }

    const res = saveText(userId, textContent, alias);
    if (!res.ok) {
      await sendReaction(sock, remoteJid, msg.key, '❌');
      return reply(T(lang, 'save_fail', { reason: res.reason }));
    }

    await sendReaction(sock, remoteJid, msg.key, '✅');
    return reply(
      T(lang, 'save_success_text', {
        id: res.item.id,
        alias: res.item.alias ? `\`${res.item.alias}\`` : T(lang, 'save_alias_none'),
      }) + `\n\n${T(lang, 'footer')}`
    );
  }

  // ============================================================
  // LIST
  // ============================================================
  if (subcmd === 'list') {
    await sendReaction(sock, remoteJid, msg.key, '📋');

    const items = listItems(userId);
    if (items.length === 0) return reply(T(lang, 'list_empty'));

    let out =
      `${T(lang, 'list_header')}\n\n` +
      `📊 *${T(lang, 'list_total', { n: items.length, max: MAX_ITEMS })}*\n\n`;

    items.forEach((item, i) => {
      const icon = typeIcon(lang, item.type);
      const aliasTxt = item.alias ? `\`${item.alias}\`` : T(lang, 'list_alias_none');
      const preview = item.text
        ? item.text.substring(0, 40) + (item.text.length > 40 ? '...' : '')
        : typeLabel(lang, item.type);

      out += `*${i + 1}.* ${icon} ${aliasTxt}\n`;
      out += `   ID: \`${item.id}\`\n`;
      out += `   ${preview}\n\n`;
    });

    out += `_${T(lang, 'list_hint')}_\n\n${T(lang, 'footer')}`;
    await sendReaction(sock, remoteJid, msg.key, '✅');
    return reply(out);
  }

  // ============================================================
  // STATS
  // ============================================================
  if (subcmd === 'stats') {
    await sendReaction(sock, remoteJid, msg.key, '📊');

    const s = getBoxStats(userId);

    const out =
      `${T(lang, 'stats_header')}\n\n` +
      `◦ ${T(lang, 'stats_total')} : *${s.total}* / ${s.max}\n` +
      `◦ ${T(lang, 'stats_free')}  : *${s.free}*\n` +
      `◦ ${T(lang, 'stats_size')}  : *${s.totalSizeMb} MB*\n\n` +
      `_${T(lang, 'stats_hint', { max: s.max })}_\n\n` +
      T(lang, 'footer');

    await sendReaction(sock, remoteJid, msg.key, '✅');
    return reply(out);
  }

  // ============================================================
  // DEL
  // ============================================================
  if (subcmd === 'del') {
    if (!argRest) return reply(T(lang, 'del_no_key'));

    await sendReaction(sock, remoteJid, msg.key, '🗑️');

    const res = deleteItem(userId, argRest);
    if (!res.ok) {
      await sendReaction(sock, remoteJid, msg.key, '❌');
      return reply(T(lang, 'del_fail', { reason: res.reason }));
    }

    await sendReaction(sock, remoteJid, msg.key, '✅');
    return reply(T(lang, 'del_success', { key: argRest }));
  }

  // ============================================================
  // CLEAR
  // ============================================================
  if (subcmd === 'clear') {
    const items = listItems(userId);
    if (items.length === 0) return reply(T(lang, 'clear_empty'));

    await sendReaction(sock, remoteJid, msg.key, '⚠️');

    const confirmMsg = await reply(T(lang, 'clear_confirm', { n: items.length }));
    if (!confirmMsg?.key?.id) return;

    const onConfirm = async (rCtx) => {
      const jawab = String(rCtx.text || '').trim();
      if (jawab !== '1') return rCtx.reply(T(lang, 'clear_invalid'));

      const res = clearBox(userId);
      await sendReaction(sock, remoteJid, rCtx.msg.key, '✅');
      return rCtx.reply(T(lang, 'clear_success', { n: res.count }));
    };

    registerSession(
      confirmMsg.key.id,
      remoteJid,
      onConfirm,
      { step: 'box_clear' },
      {
        once: true,
        timeoutMs: TIMEOUT_PICK,
        senderJid: sender?.lid || (sender?.nomor ? `${sender.nomor}@s.whatsapp.net` : null),
        validateSender: true,
        tag: 'box_clear',
        onExpire: async ({ chatJid }) => {
          try { await sendText(sock, chatJid, T(lang, 'pick_timeout')); } catch {}
        },
      }
    );
    return;
  }

  // ============================================================
  // GET
  // ============================================================
  if (subcmd === 'get') {
    // GET dengan key → langsung kirim (persis seperti aslinya)
    if (argRest) {
      await sendReaction(sock, remoteJid, msg.key, '📤');

      const res = getItem(userId, argRest);
      if (!res.ok) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        return reply(T(lang, 'get_not_found', { key: argRest }));
      }

      try {
        await sendBoxItem(sock, remoteJid, res.item, res.buffer, { quoted: msg });
        await sendReaction(sock, remoteJid, msg.key, '✅');
      } catch (err) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        return reply(T(lang, 'fail_send', { err: err.message }));
      }
      return;
    }

    // GET tanpa key → picker
    const items = listItems(userId);
    if (items.length === 0) {
      return reply(T(lang, 'get_empty'));
    }

    await sendReaction(sock, remoteJid, msg.key, '📦');

    let listText = `${T(lang, 'pick_header')}\n\n${T(lang, 'pick_intro')}\n`;
    items.forEach((item, i) => {
      const icon = typeIcon(lang, item.type);
      const aliasTxt = item.alias ? `\`${item.alias}\`` : T(lang, 'list_alias_none');
      const preview = item.text
        ? item.text.substring(0, 30) + (item.text.length > 30 ? '...' : '')
        : typeLabel(lang, item.type);

      listText += `*${i + 1}.* ${icon} ${aliasTxt}\n   _${preview}_\n\n`;
    });

    listText += `${T(lang, 'pick_footer_hint', { n: items.length })}\n\n${T(lang, 'footer')}`;

    const pickerMsg = await reply(listText);
    if (!pickerMsg?.key?.id) return;

    const onPick = async (rCtx) => {
      const jawab = String(rCtx.text || '').trim();
      const num = parseInt(jawab, 10);

      if (isNaN(num) || num < 1 || num > items.length) {
        return rCtx.reply(T(lang, 'pick_invalid', { n: items.length }));
      }

      const chosen = items[num - 1];
      const res = getItem(userId, chosen.id);

      if (!res.ok) {
        return rCtx.reply(T(lang, 'get_not_found', { key: chosen.id }));
      }

      try {
        await sendBoxItem(sock, remoteJid, res.item, res.buffer, { quoted: msg });
        await sendReaction(sock, remoteJid, rCtx.msg.key, '✅');
      } catch (err) {
        await sendReaction(sock, remoteJid, rCtx.msg.key, '❌');
        return rCtx.reply(T(lang, 'fail_send', { err: err.message }));
      }
    };

    registerSession(
      pickerMsg.key.id,
      remoteJid,
      onPick,
      { step: 'box_pick', items },
      {
        once: true,
        timeoutMs: TIMEOUT_PICK,
        senderJid: sender?.lid || (sender?.nomor ? `${sender.nomor}@s.whatsapp.net` : null),
        validateSender: true,
        tag: 'box_pick',
        onExpire: async ({ chatJid }) => {
          try { await sendText(sock, chatJid, T(lang, 'pick_timeout')); } catch {}
        },
      }
    );
    return;
  }

  // ============================================================
  // Subcommand tidak dikenal
  // ============================================================
  await sendReaction(sock, remoteJid, msg.key, '❌');
  return reply(T(lang, 'invalid_sub'));
}