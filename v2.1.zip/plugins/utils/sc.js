// plugins/tools/sc.js
// Dapatkan link Source Code bot — support multi-bahasa (ID / CH / UK).

import engine from '../../libx/engine/index.js';
import { sendReaction, sendText } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['sc', 'sourcecode', 'script'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Dapatkan link Source Code bot (via channel)';
export const description_ch = '获取机器人源代码链接（通过频道）';
export const description_uk = 'Get the bot Source Code link (via channel)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        header: `乂  *ᴀɴɢᴇʟ's - ꜱᴏᴜʀᴄᴇ ᴄᴏᴅᴇ*`,
        greeting: 'Halo kak! 👋',
        intro:
            'Source Code bot ini dibagikan secara *gratis* di Channel WhatsApp resmi kami.',
        join_channel: '📢 *Join Channel:*',
        how_to: '📌 *Cara mendapatkan:*',
        step_1: '1. Klik link channel di atas',
        step_2: '2. Klik "Follow"',
        step_3: '3. Cari postingan tentang *Source Code Linea*',
        step_4: '4. Download file zip-nya dari sana',
        note_title: '*Note:*',
        note_1: '◦ Jangan lupa baca README.md di dalamnya',
        note_2: '◦ Jangan diperjualbelikan ya kak',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        header: `乂  *ᴀɴɢᴇʟ's - 源代码*`,
        greeting: '你好！👋',
        intro:
            '本机器人的源代码在我们的官方 WhatsApp 频道上*免费*分享。',
        join_channel: '📢 *加入频道：*',
        how_to: '📌 *如何获取：*',
        step_1: '1. 点击上方频道链接',
        step_2: '2. 点击"关注"',
        step_3: '3. 查找关于 *Source Code Linea* 的帖子',
        step_4: '4. 从那里下载 zip 文件',
        note_title: '*注意：*',
        note_1: '◦ 别忘了阅读里面的 README.md',
        note_2: '◦ 请勿倒卖',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        header: `乂  *ᴀɴɢᴇʟ's - ꜱᴏᴜʀᴄᴇ ᴄᴏᴅᴇ*`,
        greeting: 'Hello! 👋',
        intro:
            'The source code of this bot is shared *for free* on our official WhatsApp Channel.',
        join_channel: '📢 *Join Channel:*',
        how_to: '📌 *How to get it:*',
        step_1: '1. Click the channel link above',
        step_2: '2. Click "Follow"',
        step_3: '3. Look for the post about *Source Code Linea*',
        step_4: '4. Download the zip file from there',
        note_title: '*Note:*',
        note_1: '◦ Don\'t forget to read the README.md inside',
        note_2: '◦ Please do not resell it',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk'; // universal
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '📦');

    // 2. Build caption
    const caption =
        `${T(lang, 'header')}\n\n` +
        `${T(lang, 'greeting')}\n\n` +
        `${T(lang, 'intro')}\n\n` +
        `${T(lang, 'join_channel')}\n` +
        `${engine.channel}\n\n` +
        `${T(lang, 'how_to')}\n` +
        `${T(lang, 'step_1')}\n` +
        `${T(lang, 'step_2')}\n` +
        `${T(lang, 'step_3')}\n` +
        `${T(lang, 'step_4')}\n\n` +
        `${T(lang, 'note_title')}\n` +
        `${T(lang, 'note_1')}\n` +
        `${T(lang, 'note_2')}\n\n` +
        `${T(lang, 'footer')}`;

    // 3. Kirim
    await reply(caption);

    // 4. Reaksi sukses
    await sendReaction(sock, remoteJid, msg.key, '✅');
}