// plugins/daftar.js
// Plugin LOGIN/REGISTRASI bot (pintu masuk utama).
// Alur:
//   1. .daftar → cek sudah terdaftar?
//      - Sudah  → tampilkan info akun (bahasa user)
//      - Belum  → tampilkan PICKER BAHASA (English)
//   2. User pilih bahasa → BARU register user dengan lang tersebut
//   3. Timeout / salah kode → TIDAK terdaftar, harus ulang .daftar
//
// Ini penting: bahasa dulu biar user bule ga bingung, baru masuk sistem.

import { findUser, registerUser, setUserLid, isConfigOwner, setUserLang } from '../../libx/db.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { isValidLang, parseLangInput, LANGS, DEFAULT_LANG } from '../../libx/lang.js';
import { registerSession } from '../../libx/session_plugins.js';
import engine from '../../libx/engine/index.js';

export const cmd = ['daftar'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Daftar akun untuk menggunakan bot';
export const description_ch = '注册账户以使用机器人';
export const description_uk = 'Register an account to use the bot';
export const description = description_id;

// ============================================================
// PICKER AWAL SELALU ENGLISH
// ============================================================
const PICKER_LANG = 'uk';

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        identity_error: '❌ Tidak bisa mendeteksi identitas. Coba kirim ulang pesan.',
        number_error:
            '❌ Nomor HP tidak terdeteksi.\nCoba kirim pesan lagi setelah WhatsApp mengirim data nomor.',
        already: '✅ Kamu sudah terdaftar.',
        owner_registered: '*Status* : Owner Terdaftar',
        welcome: 'Halo kak, selamat datang! 🎉',
        header: `乂  *ᴀɴɢᴇʟ's - ᴅᴀꜰᴛᴀʀ*`,
        field_number: 'Nomor',
        field_lid: 'LID',
        field_token: 'Token',
        field_owner: 'Owner',
        field_created: 'Dibuat',
        field_lang: 'Bahasa',
        lid_pending: '(menyusul)',
        yes: 'Ya',
        no: 'Tidak',
        info_hint: '◦  Ketik *{prefix}info* untuk melihat info akun',
        channel_hint: '_Info terbaru, update, dan tips ada di sana._',
        follow_channel: '📢 *Jangan lupa follow channel kita ya:*',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Gagal daftar: {reason}',

        lang_choose:
            '🌐 *PILIH BAHASA*\n\n' +
            'Silakan pilih bahasa yang kamu gunakan:\n\n' +
            '*1.* Indonesia 🇮🇩\n' +
            '*2.* 中文 🇨🇳\n' +
            '*3.* English 🇬🇧\n\n' +
            '📌 Reply pesan ini dengan angka (1/2/3) atau kode bahasa (id/ch/uk).',
        lang_invalid: '❌ Kode bahasa tidak valid. Pilih: id / ch / uk',
        lang_set_ok: '✅ Bahasa berhasil diatur ke *{lang}*.',
        lang_timeout: '⏱️ Waktu habis. Kamu *belum terdaftar*.\nKetik *.daftar* lagi untuk memilih bahasa.',
    },
    ch: {
        identity_error: '❌ 无法识别身份。请重新发送消息。',
        number_error:
            '❌ 未检测到手机号码。\n请在 WhatsApp 发送号码数据后重试。',
        already: '✅ 您已经注册。',
        owner_registered: '*状态* ： 主人已注册',
        welcome: '你好，欢迎！🎉',
        header: `乂  *ᴀɴɢᴇʟ's - 注册*`,
        field_number: '号码',
        field_lid: 'LID',
        field_token: '代币',
        field_owner: '主人',
        field_created: '创建时间',
        field_lang: '语言',
        lid_pending: '(稍后)',
        yes: '是',
        no: '否',
        info_hint: '◦  输入 *{prefix}info* 查看账户信息',
        channel_hint: '_最新资讯、更新和技巧都在这里。_',
        follow_channel: '📢 *别忘了关注我们的频道：*',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ 注册失败：{reason}',

        lang_choose:
            '🌐 *选择语言*\n\n' +
            '请选择您使用的语言：\n\n' +
            '*1.* Indonesia 🇮🇩\n' +
            '*2.* 中文 🇨🇳\n' +
            '*3.* English 🇬🇧\n\n' +
            '📌 请回复数字 (1/2/3) 或语言代码 (id/ch/uk)。',
        lang_invalid: '❌ 语言代码无效。请选择：id / ch / uk',
        lang_set_ok: '✅ 语言已设置为 *{lang}*。',
        lang_timeout: '⏱️ 时间到。您*尚未注册*。\n请再次输入 *.daftar* 以选择语言。',
    },
    uk: {
        identity_error: '❌ Unable to detect identity. Please resend your message.',
        number_error:
            '❌ Phone number not detected.\nPlease try again after WhatsApp sends your number data.',
        already: '✅ You are already registered.',
        owner_registered: '*Status* : Owner Registered',
        welcome: 'Hello, welcome! 🎉',
        header: `乂  *ᴀɴɢᴇʟ's - ʀᴇɢɪsᴛᴇʀ*`,
        field_number: 'Number',
        field_lid: 'LID',
        field_token: 'Token',
        field_owner: 'Owner',
        field_created: 'Created',
        field_lang: 'Language',
        lid_pending: '(pending)',
        yes: 'Yes',
        no: 'No',
        info_hint: '◦  Type *{prefix}info* to see your account info',
        channel_hint: '_Latest news, updates, and tips are there._',
        follow_channel: '📢 *Don\'t forget to follow our channel:*',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Registration failed: {reason}',

        lang_choose:
            '🌐 *CHOOSE LANGUAGE*\n\n' +
            'Please choose the language you use:\n\n' +
            '*1.* Indonesia 🇮🇩\n' +
            '*2.* 中文 🇨🇳\n' +
            '*3.* English 🇬🇧\n\n' +
            '📌 Reply to this message with the number (1/2/3) or the code (id/ch/uk).',
        lang_invalid: '❌ Invalid language code. Choose: id / ch / uk',
        lang_set_ok: '✅ Language has been set to *{lang}*.',
        lang_timeout: '⏱️ Time\'s up. You are *not registered* yet.\nType *.daftar* again to choose a language.',
    },
};

// ============================================================
// HELPER: ambil teks
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

// ============================================================
// HELPER: caption daftar sukses
// ============================================================
function buildRegisteredCaption({ lang, user, lid, isOwnerAcc, prefix }) {
    return (
        `${T(lang, 'header')}\n\n` +
        `${T(lang, 'welcome')}\n\n` +
        `◦  *${T(lang, 'field_number')}* : ${user.nomor}\n` +
        `◦  *${T(lang, 'field_lid')}* : ${lid ? lid.split('@')[0] : T(lang, 'lid_pending')}\n` +
        `◦  *${T(lang, 'field_token')}* : ${user.token}\n` +
        `◦  *${T(lang, 'field_owner')}* : ${isOwnerAcc ? T(lang, 'yes') : T(lang, 'no')}\n` +
        `◦  *${T(lang, 'field_lang')}* : ${LANGS[lang].label}\n` +
        `◦  *${T(lang, 'field_created')}* : ${user.create_at}\n\n` +
        `${T(lang, 'follow_channel')}\n` +
        `${engine.channel}\n\n` +
        `${T(lang, 'channel_hint')}\n\n` +
        `${T(lang, 'info_hint', { prefix })}\n\n` +
        `${T(lang, 'footer')}`
    );
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { reply, sender, sock, remoteJid, msg, prefix } = ctx;
    const { lid, nomor } = sender;

    if (!nomor && !lid) {
        return reply(T(PICKER_LANG, 'identity_error'));
    }

    // Reaction loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    // ============================================================
    // 1. User sudah terdaftar? → tampilkan info akun
    // ============================================================
    const existing = findUser({ lid, nomor });
    if (existing) {
        const lang = isValidLang(existing.lang) ? existing.lang : DEFAULT_LANG;

        // Migrasi: owner belum punya LID tapi sekarang ada LID
        if (existing.owner && !existing.lid && lid) {
            setUserLid(existing.nomor, lid);
            await sendReaction(sock, remoteJid, msg.key, '✅');
            return reply(
                `${T(lang, 'header')}\n\n` +
                `${T(lang, 'owner_registered')}\n` +
                `*LID* : ${lid.split('@')[0]}\n\n` +
                `${T(lang, 'follow_channel')}\n` +
                `${engine.channel}\n\n` +
                `${T(lang, 'footer')}`
            );
        }

        await sendReaction(sock, remoteJid, msg.key, '✅');
        return reply(
            `${T(lang, 'already')}\n\n` +
            `${T(lang, 'follow_channel')}\n` +
            `${engine.channel}\n\n` +
            `${T(lang, 'footer')}`
        );
    }

    // ============================================================
    // 2. Belum terdaftar → cek nomor
    // ============================================================
    if (!nomor) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        return reply(T(PICKER_LANG, 'number_error'));
    }

    // ============================================================
    // 3. Tampilkan PICKER BAHASA (English) — BELUM register
    // ============================================================
    const pickerMsg = await reply(T(PICKER_LANG, 'lang_choose'));
    if (!pickerMsg?.key?.id) return; // gagal kirim picker → stop

    // ============================================================
    // 4. Tunggu user pilih bahasa
    // ============================================================
    const TIMEOUT_PICK_LANG = 60 * 1000;

    const onLangReply = async (replyCtx) => {
        const code = parseLangInput(replyCtx.text);

        // Kode salah → tetap di session, minta ulang
        if (!code) {
            await replyCtx.reply(T(PICKER_LANG, 'lang_invalid'));
            return;
        }

        // ============================================================
        // 5. BARU REGISTER setelah user pilih bahasa
        // ============================================================
        const reg = registerUser({ nomor, lid: lid || null });
        if (!reg.ok) {
            return replyCtx.reply(T(code, 'fail', { reason: reg.reason }));
        }

        // Simpan bahasa ke DB
        setUserLang({ lid, nomor }, code);

        // Konfirmasi bahasa
        await replyCtx.reply(T(code, 'lang_set_ok', { lang: LANGS[code].label }));

        const isOwnerAcc = isConfigOwner(nomor);

        // Reaction sukses
        await sendReaction(sock, remoteJid, replyCtx.msg.key, '✅');

        // Kirim caption daftar sukses
        return replyCtx.reply(buildRegisteredCaption({
            lang: code,
            user: reg.user,
            lid,
            isOwnerAcc,
            prefix,
        }));
    };

    registerSession(
        pickerMsg.key.id,
        remoteJid,
        onLangReply,
        { pickedLang: null },
        {
            once: true,
            timeoutMs: TIMEOUT_PICK_LANG,
            senderJid: lid || (nomor ? `${nomor}@s.whatsapp.net` : null),
            validateSender: true,
            tag: 'daftar_lang',
            onExpire: async ({ chatJid }) => {
                try {
                    const { sendText } = await import('../../libx/whatsapp/sendmsg.js');
                    // Timeout: TIDAK terdaftar
                    await sendText(sock, chatJid, T(DEFAULT_LANG, 'lang_timeout'));
                } catch (_) {}
            },
        }
    );
}