// plugins/maker/fakeffgirl.js
// Buat gambar Fake Free Fire Girl (username palsu) — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['fakeffgirl', 'ffgirl', 'ffcewek'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 5;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Buat gambar Fake Free Fire Girl (username palsu)';
export const description_ch = '生成虚假 Free Fire Girl 图片（伪造用户名）';
export const description_uk = 'Generate a fake Free Fire Girl image (fake username)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_username:
            '⚠️ Masukkan username untuk Fake FF Girl!\n' +
            'Contoh:\n' +
            '• {prefix}fakeffgirl Cantika\n' +
            '• {prefix}ffgirl Rin\n\n' +
            '_Maksimal 20 karakter_',
        too_long: '❌ Username maksimal 20 karakter (kamu: {len}).',
        no_image: '❌ Tidak ada gambar yang dihasilkan.',
        header: `乂  *ᴀɴɢᴇʟ's - ꜰᴀᴋᴇ ꜰꜰ ɢɪʀʟ*`,
        label_username: 'Username',
        label_info: 'Info',
        label_type: 'Tipe',
        label_format: 'Format',
        type_value: 'Image',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Gagal: {err}',
    },
    ch: {
        no_username:
            '⚠️ 请输入虚假 FF Girl 的用户名！\n' +
            '示例：\n' +
            '• {prefix}fakeffgirl Cantika\n' +
            '• {prefix}ffgirl Rin\n\n' +
            '_最多 20 个字符_',
        too_long: '❌ 用户名最多 20 个字符（当前：{len}）。',
        no_image: '❌ 未生成图片。',
        header: `乂  *ᴀɴɢᴇʟ's - 虚假 ꜰꜰ ɢɪʀʟ*`,
        label_username: '用户名',
        label_info: '信息',
        label_type: '类型',
        label_format: '格式',
        type_value: '图片',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ 失败：{err}',
    },
    uk: {
        no_username:
            '⚠️ Enter a username for Fake FF Girl!\n' +
            'Example:\n' +
            '• {prefix}fakeffgirl Cantika\n' +
            '• {prefix}ffgirl Rin\n\n' +
            '_Max 20 characters_',
        too_long: '❌ Username must be at most 20 characters (yours: {len}).',
        no_image: '❌ No image was generated.',
        header: `乂  *ᴀɴɢᴇʟ's - ꜰᴀᴋᴇ ꜰꜰ ɢɪʀʟ*`,
        label_username: 'Username',
        label_info: 'Info',
        label_type: 'Type',
        label_format: 'Format',
        type_value: 'Image',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Failed: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function extractUrl(item) {
    if (!item) return null;
    if (typeof item === 'string') return item;
    return item.url || null;
}

function guessMimetype(url, fallback = 'image/png') {
    if (!url) return fallback;
    const clean = url.split('?')[0].toLowerCase();
    if (clean.endsWith('.jpg') || clean.endsWith('.jpeg')) return 'image/jpeg';
    if (clean.endsWith('.png')) return 'image/png';
    if (clean.endsWith('.webp')) return 'image/webp';
    return fallback;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, prefix, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text || text.trim().length === 0) {
        return reply(T(lang, 'no_username', { prefix }));
    }

    const username = text.trim();
    if (username.length > 20) {
        return reply(T(lang, 'too_long', { len: username.length }));
    }

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        // 2. Panggil API
        const res = await engine.run('fakeffgirl', { username });

        const imageUrl = extractUrl(res.url) || res.url;
        if (!imageUrl) {
            await sendReaction(sock, remoteJid, msg.key, '❌');
            return reply(T(lang, 'no_image'));
        }

        // 3. Caption
        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_username')}* : ${username}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦  *${T(lang, 'label_type')}*   : ${T(lang, 'type_value')}\n` +
            `   ◦  *${T(lang, 'label_format')}* : ${res.format || 'png'}\n\n` +
            `${T(lang, 'footer')}`;

        // 4. Kirim gambar
        const mimetype = guessMimetype(imageUrl, 'image/png');
        await sendMediaUrl(sock, remoteJid, imageUrl, {
            quoted: msg,
            caption,
            mimetype,
        });

        // 5. Reaksi sukses
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error('[FAKEFFGIRL]', err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}