// plugins/maker/fakedana.js
// Buat gambar Fake DANA (saldo palsu) — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['fakedana'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 5;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Buat gambar Fake DANA (saldo palsu)';
export const description_ch = '生成虚假 DANA 图片（虚拟余额）';
export const description_uk = 'Generate a fake DANA image (fake balance)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        invalid: '⚠️ Masukkan nominal angka!\nContoh: .fakedana 2000',
        header: `乂  *ᴀɴɢᴇʟ's - ꜰᴀᴋᴇ ᴅᴀɴᴀ*`,
        label_nominal: 'Nominal',
        label_info: 'Info',
        label_type: 'Tipe',
        type_value: 'Fake Receipt',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Gagal: {err}',
    },
    ch: {
        invalid: '⚠️ 请输入数字金额！\n示例：.fakedana 2000',
        header: `乂  *ᴀɴɢᴇʟ's - 虚假 ᴅᴀɴᴀ*`,
        label_nominal: '金额',
        label_info: '信息',
        label_type: '类型',
        type_value: '虚假收据',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ 失败：{err}',
    },
    uk: {
        invalid: '⚠️ Please enter a numeric amount!\nExample: .fakedana 2000',
        header: `乂  *ᴀɴɢᴇʟ's - ꜰᴀᴋᴇ ᴅᴀɴᴀ*`,
        label_nominal: 'Amount',
        label_info: 'Info',
        label_type: 'Type',
        type_value: 'Fake Receipt',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Failed: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text || isNaN(text)) {
        return reply(T(lang, 'invalid'));
    }

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        // 2. Panggil API
        const res = await engine.run('fakedana', { amount: text });

        // 3. Caption
        const nominal = parseInt(text).toLocaleString('id-ID');
        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_nominal')}* :\nRp ${nominal}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦  *${T(lang, 'label_type')}* : ${T(lang, 'type_value')}\n\n` +
            `${T(lang, 'footer')}`;

        // 4. Kirim gambar + caption
        await sendMediaUrl(sock, remoteJid, res.url, {
            quoted: msg,
            mimetype: 'image/png',
            caption,
        });

        // 5. Reaksi sukses
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error(err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}