// plugins/maker/fakeffduo.js
// Buat gambar Fake Free Fire Duo (2 nama palsu) — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['fakeffduo', 'ffduo'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 5;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Buat gambar Fake Free Fire Duo (2 nama palsu)';
export const description_ch = '生成虚假 Free Fire 双人图片（2 个伪造名字）';
export const description_uk = 'Generate a fake Free Fire Duo image (2 fake names)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_name:
            '⚠️ Masukkan 2 nama untuk Fake FF Duo!\n' +
            'Format: *.fakeffduo nama1 | nama2*\n' +
            'Contoh:\n' +
            '• {prefix}fakeffduo RINAA | OWNER RINA\n' +
            '• {prefix}fakeffduo Player1 | Player2\n\n' +
            '_Maksimal 20 karakter per nama_',
        bad_format:
            '❌ Format salah!\nGunakan: *{prefix}fakeffduo nama1 | nama2*',
        too_long:
            '❌ Nama maksimal 20 karakter.\nNama1: {len1}, Nama2: {len2}',
        no_image: '❌ Tidak ada gambar yang dihasilkan.',
        header: `乂  *ᴀɴɢᴇʟ's - ꜰᴀᴋᴇ ꜰꜰ ᴅᴜᴏ*`,
        label_name1: 'Nama 1',
        label_name2: 'Nama 2',
        label_info: 'Info',
        label_type: 'Tipe',
        label_format: 'Format',
        type_value: 'Image',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Gagal: {err}',
    },
    ch: {
        no_name:
            '⚠️ 请输入 2 个名字用于虚假 FF 双人图片！\n' +
            '格式：*.fakeffduo 名字1 | 名字2*\n' +
            '示例：\n' +
            '• {prefix}fakeffduo RINAA | OWNER RINA\n' +
            '• {prefix}fakeffduo Player1 | Player2\n\n' +
            '_每个名字最多 20 个字符_',
        bad_format:
            '❌ 格式错误！\n请使用：*{prefix}fakeffduo 名字1 | 名字2*',
        too_long:
            '❌ 名字最多 20 个字符。\n名字1：{len1}，名字2：{len2}',
        no_image: '❌ 未生成图片。',
        header: `乂  *ᴀɴɢᴇʟ's - 虚假 ꜰꜰ 双人*`,
        label_name1: '名字 1',
        label_name2: '名字 2',
        label_info: '信息',
        label_type: '类型',
        label_format: '格式',
        type_value: '图片',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ 失败：{err}',
    },
    uk: {
        no_name:
            '⚠️ Enter 2 names for Fake FF Duo!\n' +
            'Format: *.fakeffduo name1 | name2*\n' +
            'Example:\n' +
            '• {prefix}fakeffduo RINAA | OWNER RINA\n' +
            '• {prefix}fakeffduo Player1 | Player2\n\n' +
            '_Max 20 characters per name_',
        bad_format:
            '❌ Wrong format!\nUse: *{prefix}fakeffduo name1 | name2*',
        too_long:
            '❌ Name must be at most 20 characters.\nName1: {len1}, Name2: {len2}',
        no_image: '❌ No image was generated.',
        header: `乂  *ᴀɴɢᴇʟ's - ꜰᴀᴋᴇ ꜰꜰ ᴅᴜᴏ*`,
        label_name1: 'Name 1',
        label_name2: 'Name 2',
        label_info: 'Info',
        label_type: 'Type',
        label_format: 'Format',
        type_value: 'Image',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Failed: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

/**
 * Ambil URL dari item (string atau { url })
 */
function extractUrl(item) {
    if (!item) return null;
    if (typeof item === 'string') return item;
    return item.url || null;
}

/**
 * Deteksi mimetype dari URL
 */
function guessMimetype(url, fallback = 'image/png') {
    if (!url) return fallback;
    const clean = url.split('?')[0].toLowerCase();
    if (clean.endsWith('.jpg') || clean.endsWith('.jpeg')) return 'image/jpeg';
    if (clean.endsWith('.png')) return 'image/png';
    if (clean.endsWith('.webp')) return 'image/webp';
    return fallback;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, prefix, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text || text.trim().length === 0) {
        return reply(T(lang, 'no_name', { prefix }));
    }

    // Parse: pisah pakai "|"
    const parts = text.split('|').map(s => s.trim());
    if (parts.length < 2 || !parts[0] || !parts[1]) {
        return reply(T(lang, 'bad_format', { prefix }));
    }

    const [name1, name2] = parts;

    if (name1.length > 20 || name2.length > 20) {
        return reply(T(lang, 'too_long', {
            len1: name1.length,
            len2: name2.length,
        }));
    }

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        // 2. Panggil API
        const res = await engine.run('fakeffduo', { name1, name2 });

        const imageUrl = extractUrl(res.url) || res.url;
        if (!imageUrl) {
            await sendReaction(sock, remoteJid, msg.key, '❌');
            return reply(T(lang, 'no_image'));
        }

        // 3. Caption
        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_name1')}* : ${name1}\n` +
            `*${T(lang, 'label_name2')}* : ${name2}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦  *${T(lang, 'label_type')}*   : ${T(lang, 'type_value')}\n` +
            `   ◦  *${T(lang, 'label_format')}* : ${res.format || 'png'}\n\n` +
            `${T(lang, 'footer')}`;

        // 4. Kirim gambar
        const mimetype = guessMimetype(imageUrl, 'image/png');
        await sendMediaUrl(sock, remoteJid, imageUrl, {
            quoted: msg,
            caption,
            mimetype,
        });

        // 5. Reaksi sukses
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error('[FAKEFFDUO]', err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}