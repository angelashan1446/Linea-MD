// plugins/maker/fakeff.js
// Buat gambar Fake Free Fire (ss nama palsu) — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['fakeff', 'ff'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 5;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Buat gambar Fake Free Fire (ss nama palsu)';
export const description_ch = '生成虚假 Free Fire 图片（伪造名字截图）';
export const description_uk = 'Generate a fake Free Fire image (fake name screenshot)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_name:
            '⚠️ Masukkan nama untuk Fake Free Fire!\n' +
            'Contoh:\n' +
            '• .fakeff halo1234\n' +
            '• .fakeff MashBurnedead\n\n' +
            '_Maksimal 20 karakter_',
        too_long: '❌ Nama maksimal 20 karakter (kamu: {len}).',
        no_image: '❌ Tidak ada gambar yang dihasilkan.',
        header: `乂  *ᴀɴɢᴇʟ's - ꜰᴀᴋᴇ ꜰʀᴇᴇ ꜰɪʀᴇ*`,
        label_name: 'Nama',
        label_info: 'Info',
        label_type: 'Tipe',
        label_format: 'Format',
        type_value: 'Image',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Gagal: {err}',
    },
    ch: {
        no_name:
            '⚠️ 请输入虚假 Free Fire 的名字！\n' +
            '示例：\n' +
            '• .fakeff halo1234\n' +
            '• .fakeff MashBurnedead\n\n' +
            '_最多 20 个字符_',
        too_long: '❌ 名字最多 20 个字符（当前：{len}）。',
        no_image: '❌ 未生成图片。',
        header: `乂  *ᴀɴɢᴇʟ's - 虚假 ꜰʀᴇᴇ ꜰɪʀᴇ*`,
        label_name: '名字',
        label_info: '信息',
        label_type: '类型',
        label_format: '格式',
        type_value: '图片',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ 失败：{err}',
    },
    uk: {
        no_name:
            '⚠️ Enter a name for Fake Free Fire!\n' +
            'Example:\n' +
            '• .fakeff halo1234\n' +
            '• .fakeff MashBurnedead\n\n' +
            '_Max 20 characters_',
        too_long: '❌ Name must be at most 20 characters (yours: {len}).',
        no_image: '❌ No image was generated.',
        header: `乂  *ᴀɴɢᴇʟ's - ꜰᴀᴋᴇ ꜰʀᴇᴇ ꜰɪʀᴇ*`,
        label_name: 'Name',
        label_info: 'Info',
        label_type: 'Type',
        label_format: 'Format',
        type_value: 'Image',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Failed: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

/**
 * Ambil URL dari item (string atau { url })
 */
function extractUrl(item) {
    if (!item) return null;
    if (typeof item === 'string') return item;
    return item.url || null;
}

/**
 * Deteksi mimetype dari URL
 */
function guessMimetype(url, fallback = 'image/png') {
    if (!url) return fallback;
    const clean = url.split('?')[0].toLowerCase();
    if (clean.endsWith('.jpg') || clean.endsWith('.jpeg')) return 'image/jpeg';
    if (clean.endsWith('.png')) return 'image/png';
    if (clean.endsWith('.webp')) return 'image/webp';
    return fallback;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text || text.trim().length === 0) {
        return reply(T(lang, 'no_name'));
    }

    const name = text.trim();
    if (name.length > 20) {
        return reply(T(lang, 'too_long', { len: name.length }));
    }

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        // 2. Panggil API
        const res = await engine.run('fakeff', { name });

        const imageUrl = extractUrl(res.url) || res.url;
        if (!imageUrl) {
            await sendReaction(sock, remoteJid, msg.key, '❌');
            return reply(T(lang, 'no_image'));
        }

        // 3. Caption
        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_name')}* : ${name}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦  *${T(lang, 'label_type')}*   : ${T(lang, 'type_value')}\n` +
            `   ◦  *${T(lang, 'label_format')}* : ${res.format || 'png'}\n\n` +
            `${T(lang, 'footer')}`;

        // 4. Kirim gambar
        const mimetype = guessMimetype(imageUrl, 'image/png');
        await sendMediaUrl(sock, remoteJid, imageUrl, {
            quoted: msg,
            caption,
            mimetype,
        });

        // 5. Reaksi sukses
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error('[FAKEFF]', err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}