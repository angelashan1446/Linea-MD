// plugins/maker/iqc.js
// Buat gambar iPhone Quote Chat (IQC) dari teks — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['iqc'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 5;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Buat gambar iPhone Quote Chat (IQC) dari teks';
export const description_ch = '根据文本生成 iPhone 聊天引用图片 (IQC)';
export const description_uk = 'Generate an iPhone Quote Chat (IQC) image from text';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_text: '⚠️ Masukkan teks!\nContoh: .iqc Angels API',
        header: `乂  *ᴀɴɢᴇʟs - ɪǫᴄ ᴍᴀᴋᴇʀ*`,
        label_text: 'Teks',
        label_info: 'Info',
        label_type: 'Tipe',
        type_value: 'Image Quote Card',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
        fail: '❌ Gagal: {err}',
    },
    ch: {
        no_text: '⚠️ 请输入文本！\n示例：.iqc Angels API',
        header: `乂  *ᴀɴɢᴇʟs - ɪǫᴄ ᴍᴀᴋᴇʀ*`,
        label_text: '文本',
        label_info: '信息',
        label_type: '类型',
        type_value: '图片引用卡片',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
        fail: '❌ 失败：{err}',
    },
    uk: {
        no_text: '⚠️ Please enter text!\nExample: .iqc Angels API',
        header: `乂  *ᴀɴɢᴇʟs - ɪǫᴄ ᴍᴀᴋᴇʀ*`,
        label_text: 'Text',
        label_info: 'Info',
        label_type: 'Type',
        type_value: 'Image Quote Card',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
        fail: '❌ Failed: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text) {
        return reply(T(lang, 'no_text'));
    }

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        // 2. Panggil API
        const res = await engine.run('iqc', { text });

        // 3. Caption
        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_text')}* :\n${text}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦  *${T(lang, 'label_type')}* : ${T(lang, 'type_value')}\n\n` +
            `${T(lang, 'footer')}`;

        // 4. Kirim gambar + caption
        await sendMediaUrl(sock, remoteJid, res.url, {
            quoted: msg,
            mimetype: 'image/png',
            caption,
        });

        // 5. Reaksi sukses
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error(err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}