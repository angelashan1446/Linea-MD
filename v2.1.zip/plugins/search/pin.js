// plugins/search/pin.js
// Cari gambar di Pinterest berdasarkan kata kunci — multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['pin', 'pinterest'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 10;

export const description_id = 'Cari gambar di Pinterest berdasarkan kata kunci';
export const description_ch = '按关键词在 Pinterest 搜索图片';
export const description_uk = 'Search images on Pinterest by keyword';
export const description = description_id;

const TEXT = {
    id: {
        no_query:
            '⚠️ Masukkan kata kunci pencarian!\n' +
            'Contoh:\n' +
            '• .pin Mash Burnedead\n' +
            '• .pin anime aesthetic\n' +
            '• .pin wallpaper kucing',
        no_result: '❌ Tidak ada hasil untuk "{q}"',
        header: `乂  *ᴀɴɢᴇʟs - ᴘɪɴᴛᴇʀᴇsᴛ*`,
        label_query: 'Query',
        label_total: 'Total',
        sending: '_Mengirim hasil..._',
        partial: '⚠️ {sent}/{total} gambar berhasil dikirim.',
        label_untitled: 'Tanpa judul',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        no_query:
            '⚠️ 请输入搜索关键词！\n' +
            '示例：\n' +
            '• .pin Mash Burnedead\n' +
            '• .pin 动漫 唯美\n' +
            '• .pin 猫咪 壁纸',
        no_result: '❌ 未找到与 "{q}" 相关的结果',
        header: `乂  *ᴀɴɢᴇʟs - ᴘɪɴᴛᴇʀᴇsᴛ*`,
        label_query: '关键词',
        label_total: '总计',
        sending: '_正在发送结果..._',
        partial: '⚠️ {sent}/{total} 张图片发送成功。',
        label_untitled: '无标题',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        no_query:
            '⚠️ Enter a search keyword!\n' +
            'Example:\n' +
            '• .pin Mash Burnedead\n' +
            '• .pin anime aesthetic\n' +
            '• .pin cat wallpaper',
        no_result: '❌ No results for "{q}"',
        header: `乂  *ᴀɴɢᴇʟs - ᴘɪɴᴛᴇʀᴇsᴛ*`,
        label_query: 'Query',
        label_total: 'Total',
        sending: '_Sending results..._',
        partial: '⚠️ {sent}/{total} images sent successfully.',
        label_untitled: 'Untitled',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function extractUrl(item) {
    if (!item) return null;
    if (typeof item === 'string') return item;
    return item.url || null;
}

function guessMimetype(url, fallback = 'image/jpeg') {
    if (!url) return fallback;
    const clean = url.split('?')[0].toLowerCase();
    if (clean.endsWith('.png')) return 'image/png';
    if (clean.endsWith('.webp')) return 'image/webp';
    if (clean.endsWith('.gif')) return 'image/gif';
    if (clean.endsWith('.mp4')) return 'video/mp4';
    return fallback;
}

export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text || text.trim().length === 0) return reply(T(lang, 'no_query'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        const limit = 6;
        const res = await engine.run('pin', { query: text.trim(), limit });

        const results = Array.isArray(res.results) ? res.results : [];
        const total = results.length;

        if (total === 0) {
            await sendReaction(sock, remoteJid, msg.key, '❌');
            return reply(T(lang, 'no_result', { q: text.trim() }));
        }

        const headerText =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_query')}* : ${res.query || text.trim()}\n` +
            `*${T(lang, 'label_total')}* : ${total}\n\n` +
            `${T(lang, 'sending')}\n\n` +
            `${T(lang, 'footer')}`;

        await reply(headerText);

        let sent = 0;
        for (let i = 0; i < results.length; i++) {
            const item = results[i];
            const imgUrl = extractUrl(item.image);
            if (!imgUrl) continue;

            try {
                const title = item.title || T(lang, 'label_untitled');
                const board = item.board || '-';
                const username = item.username || '-';

                const caption =
                    `📌 *${title}*\n` +
                    `👤 ${username}\n` +
                    `📁 ${board}\n\n` +
                    `_${i + 1}/${total}_`;

                await sendMediaUrl(sock, remoteJid, imgUrl, {
                    quoted: msg,
                    caption,
                    mimetype: guessMimetype(imgUrl, 'image/jpeg'),
                });

                sent++;
                if (i < results.length - 1) await new Promise((r) => setTimeout(r, 1500));
            } catch (err) {
                console.error(`[PIN] Gagal kirim gambar ${i + 1}:`, err.message);
            }
        }

        if (sent < total) {
            await reply(T(lang, 'partial', { sent, total }));
        }

        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[PIN]', err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}