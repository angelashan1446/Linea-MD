// plugins/search/playvid.js
// Cari & download video MP4 dari YouTube via judul — multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['playvid'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 25;

export const description_id = 'Cari & download video MP4 dari YouTube via judul';
export const description_ch = '通过标题搜索并下载 YouTube MP4 视频';
export const description_uk = 'Search & download MP4 video from YouTube by title';
export const description = description_id;

const TEXT = {
    id: {
        no_query: '⚠️ Masukkan judul video!\nContoh: .playvid Lathi Weird Genius',
        header: `乂  *ᴀɴɢᴇʟs - ʏᴏᴜᴛᴜʙᴇ ᴠɪᴅᴇᴏ*`,
        label_title: 'Judul',
        label_info: 'Info',
        label_quality: 'Kualitas',
        unknown_title: 'Judul tidak diketahui',
        video_filename: 'video',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        no_query: '⚠️ 请输入视频标题！\n示例：.playvid Lathi Weird Genius',
        header: `乂  *ᴀɴɢᴇʟs - ʏᴏᴜᴛᴜʙᴇ ᴠɪᴅᴇᴏ*`,
        label_title: '标题',
        label_info: '信息',
        label_quality: '画质',
        unknown_title: '未知标题',
        video_filename: '视频',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        no_query: '⚠️ Enter a video title!\nExample: .playvid Lathi Weird Genius',
        header: `乂  *ᴀɴɢᴇʟs - ʏᴏᴜᴛᴜʙᴇ ᴠɪᴅᴇᴏ*`,
        label_title: 'Title',
        label_info: 'Info',
        label_quality: 'Quality',
        unknown_title: 'Unknown Title',
        video_filename: 'video',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text) return reply(T(lang, 'no_query'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        const res = await engine.run('playvid', { q: text });
        const title = res.title || T(lang, 'unknown_title');

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_title')}* : ${title}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦ ${T(lang, 'label_quality')} : 360p\n\n` +
            `${T(lang, 'footer')}`;

        if (res.thumb) {
            await sendMediaUrl(sock, remoteJid, res.thumb, { quoted: msg, caption });
        } else {
            await reply(caption);
        }

        await sendReaction(sock, remoteJid, msg.key, '⬇️');

        await sendMediaUrl(sock, remoteJid, res.url, {
            quoted: msg,
            mimetype: 'video/mp4',
            fileName: `${(res.title || T(lang, 'video_filename')).substring(0, 50)}.mp4`.replace(/[^\w\s.-]/gi, ''),
        });

        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error(err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}