// plugins/download/ytsearch.js
// Cari video di YouTube lalu putar/download — multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl, sendText } from '../../libx/whatsapp/sendmsg.js';
import { registerSession } from '../../libx/session_plugins.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['ytsearch', 'yts', 'youtubesearch'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 2;

export const description_id = 'Cari video di YouTube lalu putar/download';
export const description_ch = '在 YouTube 搜索视频并播放/下载';
export const description_uk = 'Search videos on YouTube then play/download';
export const description = description_id;

const TIMEOUT_MS = 120 * 1000;

const TEXT = {
    id: {
        no_query:
            '⚠️ Masukkan kata kunci pencarian!\n\n' +
            '*Contoh:*\n' +
            '• {prefix}ytsearch faded\n' +
            '• {prefix}yts lathi weird genius',
        no_result: '❌ Tidak ada hasil untuk *"{q}"*.',
        header: `乂  *ʏᴏᴜᴛᴜʙᴇ sᴇᴀʀᴄʜ*`,
        label_query: 'Query',
        label_results: 'Hasil',
        result_count: '{n} video',
        reply_hint: '📌 *Reply pesan ini dengan angka* (1-{max}) untuk memutar lagu.',
        timeout_hint: '⏱️ _Batas waktu: 2 menit_',
        timeout_msg: '⏱️ *Waktu habis!* Sesi pemilihan lagu ditutup.',
        invalid_pick: '❌ Pilihan tidak valid. Masukkan angka 1 sampai {max}.',
        url_not_found: '❌ Link video tidak ditemukan.',
        preparing: '⏳ Sedang menyiapkan lagu *{title}*...',
        play_header: `乂  *ᴀɴɢᴇʟ's - ᴘʟᴀʏ*`,
        label_title: 'Judul',
        label_quality: 'Kualitas',
        unknown_title: 'Judul tidak diketahui',
        audio_filename: 'audio',
        fail_play: '❌ Gagal memutar lagu: {err}',
        fail: '❌ Gagal mencari: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        no_query:
            '⚠️ 请输入搜索关键词！\n\n' +
            '*示例：*\n' +
            '• {prefix}ytsearch faded\n' +
            '• {prefix}yts lathi weird genius',
        no_result: '❌ 未找到与 *"{q}"* 相关的结果。',
        header: `乂  *ʏᴏᴜᴛᴜʙᴇ 搜索*`,
        label_query: '关键词',
        label_results: '结果',
        result_count: '{n} 个视频',
        reply_hint: '📌 *回复此消息并输入数字*（1-{max}）以播放歌曲。',
        timeout_hint: '⏱️ _时限：2 分钟_',
        timeout_msg: '⏱️ *时间到！* 歌曲选择会话已关闭。',
        invalid_pick: '❌ 选择无效。请输入 1 到 {max} 之间的数字。',
        url_not_found: '❌ 未找到视频链接。',
        preparing: '⏳ 正在准备歌曲 *{title}*...',
        play_header: `乂  *ᴀɴɢᴇʟ's - 播放*`,
        label_title: '标题',
        label_quality: '音质',
        unknown_title: '未知标题',
        audio_filename: '音频',
        fail_play: '❌ 播放歌曲失败：{err}',
        fail: '❌ 搜索失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        no_query:
            '⚠️ Enter a search keyword!\n\n' +
            '*Example:*\n' +
            '• {prefix}ytsearch faded\n' +
            '• {prefix}yts lathi weird genius',
        no_result: '❌ No results for *"{q}"*.',
        header: `乂  *ʏᴏᴜᴛᴜʙᴇ ꜱᴇᴀʀᴄʜ*`,
        label_query: 'Query',
        label_results: 'Results',
        result_count: '{n} videos',
        reply_hint: '📌 *Reply this message with a number* (1-{max}) to play the song.',
        timeout_hint: '⏱️ _Time limit: 2 minutes_',
        timeout_msg: '⏱️ *Time\'s up!* Song selection session closed.',
        invalid_pick: '❌ Invalid pick. Enter a number between 1 and {max}.',
        url_not_found: '❌ Video link not found.',
        preparing: '⏳ Preparing song *{title}*...',
        play_header: `乂  *ᴀɴɢᴇʟ's - ᴘʟᴀʏ*`,
        label_title: 'Title',
        label_quality: 'Quality',
        unknown_title: 'Unknown Title',
        audio_filename: 'audio',
        fail_play: '❌ Failed to play song: {err}',
        fail: '❌ Failed to search: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}
function formatViews(num) {
    if (typeof num === 'string') {
        if (/[a-z]/i.test(num)) return num.replace(/\s*views?/i, '').trim();
        num = parseInt(num, 10);
    }
    if (!num || isNaN(num)) return '-';
    if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(1) + 'B';
    if (num >= 1_000_000) return (num / 1_000_000).toFixed(1) + 'M';
    if (num >= 1_000) return (num / 1_000).toFixed(1) + 'K';
    return num.toString();
}

export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, args, prefix, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const query = args.join(' ').trim();
    if (!query) return reply(T(lang, 'no_query', { prefix }));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        const res = await engine.run('ytsearch', { q: query });
        if (!res?.results || res.results.length === 0) {
            return reply(T(lang, 'no_result', { q: query }));
        }

        const results = res.results.slice(0, 10);

        let text = `${T(lang, 'header')}\n\n`;
        text += `🔍 *${T(lang, 'label_query')}:* ${query}\n`;
        text += `📊 *${T(lang, 'label_results')}:* ${T(lang, 'result_count', { n: results.length })}\n\n`;

        results.forEach((v, i) => {
            const durasi = v.duration || v.timestamp || '-';
            const views = v.views ? formatViews(v.views) : (v.viewCount ? formatViews(v.viewCount) : '-');

            text += `*${i + 1}.* ${v.title || 'Untitled'}\n`;
            const channelName = v.author?.name || v.channel?.name || v.channel;
            if (channelName) text += `   👤 ${channelName}\n`;

            text += `   ⏱️ ${durasi}`;
            if (views !== '-') text += `  •  👁️ ${views}`;
            text += `\n\n`;
        });

        text += `${T(lang, 'reply_hint', { max: results.length })}\n`;
        text += `${T(lang, 'timeout_hint')}\n\n`;
        text += `${T(lang, 'footer')}`;

        const sentMsg = await reply(text);
        if (!sentMsg?.key?.id) return;

        const sessionMeta = {
            results,
            query,
            expireAt: Date.now() + TIMEOUT_MS,
        };

        const sessionOpts = {
            once: true,
            timeoutMs: TIMEOUT_MS,
            senderJid: sender?.lid || (sender?.nomor ? sender.nomor + '@s.whatsapp.net' : null),
            validateSender: false,
            tag: 'ytsearch',
            onExpire: async ({ chatJid }) => {
                try {
                    await sendText(sock, chatJid, T(lang, 'timeout_msg'));
                } catch (_) {}
            },
        };

        const handlePilihan = async (rCtx) => {
            const { text: jawaban, reply: rReply } = rCtx;
            const angka = parseInt(jawaban);

            if (isNaN(angka) || angka < 1 || angka > results.length) {
                return rReply(T(lang, 'invalid_pick', { max: results.length }));
            }

            const pilihan = results[angka - 1];
            const videoUrl = pilihan.url || pilihan.link || `https://youtu.be/${pilihan.videoId || pilihan.id}`;

            if (!videoUrl) return rReply(T(lang, 'url_not_found'));

            await sendReaction(sock, remoteJid, msg.key, '🎵');
            await rReply(T(lang, 'preparing', { title: pilihan.title }));

            try {
                const audio = await engine.run('ytmp3', { url: videoUrl });
                const title = audio.title || pilihan.title;

                const caption =
                    `${T(lang, 'play_header')}\n\n` +
                    `*${T(lang, 'label_title')}* : ${title}\n` +
                    `*${T(lang, 'label_quality')}* : 128k\n\n` +
                    `${T(lang, 'footer')}`;

                const thumb = audio.thumb || pilihan.thumbnail || pilihan.thumb;
                if (thumb) {
                    await sendMediaUrl(sock, remoteJid, thumb, { quoted: msg, caption });
                } else {
                    await rReply(caption);
                }

                await sendReaction(sock, remoteJid, msg.key, '⬇️');
                await sendMediaUrl(sock, remoteJid, audio.url, {
                    quoted: msg,
                    mimetype: 'audio/mp4',
                    fileName: `${title.substring(0, 50)}.mp3`.replace(/[^\w\s.-]/gi, ''),
                });

                await sendReaction(sock, remoteJid, msg.key, '✅');
            } catch (err) {
                console.error('[ytsearch-play]', err.message);
                await rReply(T(lang, 'fail_play', { err: err.message }));
            }
        };

        registerSession(sentMsg.key.id, remoteJid, handlePilihan, sessionMeta, sessionOpts);
    } catch (err) {
        console.error('[ytsearch]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}