// plugins/menu.js
import { scanMenu } from '../libx/menu_scanner.js';
import config from '../config.js';
import engine from '../libx/engine/index.js';
import axios from 'axios';
import { findUser } from '../libx/db.js';
import { resolveLang, isValidLang, DEFAULT_LANG } from '../libx/lang.js';
import {
    sendReaction,
    sendMedia,
    sendText
} from '../libx/whatsapp/sendmsg.js';

export const cmd = ['menu', 'allmenu'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Lihat semua menu / command bot';
export const description_ch = '查看所有菜单 / 机器人命令';
export const description_uk = 'View all bot menus / commands';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_plugins: '❌ Belum ada plugin yang terdaftar.',
        invalid_category:
            '❌ Kategori *{cat}* tidak ditemukan.\n\n' +
            'Kategori tersedia:\n{list}\n\n' +
            '_Contoh: *{prefix}menu download*_',

        main_menu: 'MAIN MENU',
        header_name: 'Nama',
        header_role: 'Role',
        header_date: 'Tanggal',
        header_time: 'Waktu',
        header_version: 'Versi',
        header_dev: 'Dev',
        header_contact: 'Kontak',
        role_owner: 'Owner',
        role_premium: 'Premium',
        role_user: 'User',

        hint_allmenu: 'Ketik *.allmenu* untuk melihat semua command.',
        hint_category: 'Ketik *.menu <kategori>* untuk filter per kategori.',
        total_cmd: 'Total: {n} command',
        total_cat_cmd: 'Total: {n} command',
        back_to_main: 'Ketik *{prefix}menu* untuk kembali ke menu utama',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        no_plugins: '❌ 尚未注册任何插件。',
        invalid_category:
            '❌ 未找到分类 *{cat}*。\n\n' +
            '可用分类：\n{list}\n\n' +
            '_示例：*{prefix}menu download*_',

        main_menu: '主菜单',
        header_name: '名称',
        header_role: '身份',
        header_date: '日期',
        header_time: '时间',
        header_version: '版本',
        header_dev: '开发者',
        header_contact: '联系方式',
        role_owner: '主人',
        role_premium: '高级会员',
        role_user: '用户',

        hint_allmenu: '输入 *.allmenu* 查看所有命令。',
        hint_category: '输入 *.menu <分类>* 按分类筛选。',
        total_cmd: '总计：{n} 个命令',
        total_cat_cmd: '总计：{n} 个命令',
        back_to_main: '输入 *{prefix}menu* 返回主菜单',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        no_plugins: '❌ No plugins registered yet.',
        invalid_category:
            '❌ Category *{cat}* not found.\n\n' +
            'Available categories:\n{list}\n\n' +
            '_Example: *{prefix}menu download*_',

        main_menu: 'MAIN MENU',
        header_name: 'Name',
        header_role: 'Role',
        header_date: 'Date',
        header_time: 'Time',
        header_version: 'Version',
        header_dev: 'Dev',
        header_contact: 'Contact',
        role_owner: 'Owner',
        role_premium: 'Premium',
        role_user: 'User',

        hint_allmenu: 'Type *.allmenu* to see all commands.',
        hint_category: 'Type *.menu <category>* to filter by category.',
        total_cmd: 'Total: {n} command(s)',
        total_cat_cmd: 'Total: {n} command(s)',
        back_to_main: 'Type *{prefix}menu* to return to main menu',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

// ============================================================
// HELPER: ambil teks + interpolasi
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

// ============================================================
// FORMAT DATE/TIME (per bahasa)
// ============================================================
const HARI = {
    id: ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'],
    ch: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
    uk: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
};
const BULAN = {
    id: ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'],
    ch: ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'],
    uk: ['January','February','March','April','May','June','July','August','September','October','November','December'],
};

function formatDate(lang) {
    const d = new Date();
    const code = isValidLang(lang) ? lang : 'uk';
    return `${HARI[code][d.getDay()]}, ${d.getDate()} ${BULAN[code][d.getMonth()]} ${d.getFullYear()}`;
}

function formatTime() {
    const d = new Date();
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')} WIB`;
}

// ============================================================
// MAIN HANDLER
// ============================================================
export default async function handler(ctx) {
    const { sock, remoteJid, msg, prefix, sender, command, args, isGroup } = ctx;

    // Resolve bahasa: user → grup → uk
    const userDB = findUser({ lid: sender?.lid, nomor: sender?.nomor });
    const lang = resolveLang({ user: userDB, isGroup, remoteJid });

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '📜');

    // 2. Scan folder plugins/ (pakai bahasa aktif)
    const plugins = await scanMenu(undefined, { lang });

    if (plugins.length === 0) {
        return sendText(sock, remoteJid, T(lang, 'no_plugins'), { quoted: msg });
    }

    // 3. Kelompokkan berdasarkan kategori
    const grouped = {};
    for (const p of plugins) {
        if (!grouped[p.category]) grouped[p.category] = [];
        grouped[p.category].push(...p.cmd);
    }

    // 4. Urutan kategori
    const categoryOrder = ['umum', 'download', 'maker', 'tools', 'owner', 'admin', 'ai'];
    const sortedCategories = Object.keys(grouped).sort((a, b) => {
        const idxA = categoryOrder.indexOf(a);
        const idxB = categoryOrder.indexOf(b);
        if (idxA === -1 && idxB === -1) return a.localeCompare(b);
        if (idxA === -1) return 1;
        if (idxB === -1) return -1;
        return idxA - idxB;
    });

    // 5. Identitas
    let userTag = 'User';
    if (sender.lid) userTag = `@${sender.lid.split('@')[0]}`;
    else if (sender.nomor) userTag = `@${sender.nomor}`;

    const roleUser = sender.isOwner
        ? T(lang, 'role_owner')
        : (sender.isPremium || sender.user?.premium)
            ? T(lang, 'role_premium')
            : T(lang, 'role_user');

    let menuText = '';

    // ============================================================
    // LOGIKA MENU
    // ============================================================
    const catArg = args[0]?.toLowerCase();

    // PRIORITAS 1: .menu <kategori> valid
    if (catArg && grouped[catArg]) {
        menuText += `╔──☉『 *${catArg.toUpperCase()}* 』\n`;
        menuText += grouped[catArg].map(c => `╰⪼ ${prefix}${c}`).join('\n');
        menuText += `\n\n`;
        menuText += `_${T(lang, 'total_cat_cmd', { n: grouped[catArg].length })}_\n\n`;
        menuText += `_${T(lang, 'back_to_main', { prefix })}_`;
    }
    // PRIORITAS 2: .menu <kategori> invalid
    else if (catArg && !grouped[catArg]) {
        return sendText(
            sock,
            remoteJid,
            T(lang, 'invalid_category', {
                cat: catArg,
                list: sortedCategories.map(c => `• ${c}`).join('\n'),
                prefix,
            }),
            { quoted: msg }
        );
    }
    // PRIORITAS 3: .allmenu
    else if (command === 'allmenu') {
        for (const cat of sortedCategories) {
            menuText += `╔──☉『 *${cat.toUpperCase()}* 』\n`;
            menuText += grouped[cat].map(c => `╰⪼ ${prefix}${c}`).join('\n');
            menuText += `\n\n`;
        }
        menuText += `_${T(lang, 'total_cmd', {
            n: plugins.reduce((acc, p) => acc + p.cmd.length, 0),
        })}_\n\n`;
        menuText += T(lang, 'footer');
    }
    // PRIORITAS 4: .menu (default)
    else {
        menuText += `╭───「 *${config.bot_name}* 」\n`;
        menuText += `│ ⬡ ${T(lang, 'header_name')}     : ${userTag}\n`;
        menuText += `│ ⬡ ${T(lang, 'header_role')}     : ${roleUser}\n`;
        menuText += `│ ⬡ ${T(lang, 'header_date')}     : ${formatDate(lang)}\n`;
        menuText += `│ ⬡ ${T(lang, 'header_time')}     : ${formatTime()}\n`;
        menuText += `│ ⬡ ${T(lang, 'header_version')}  : v${config.bot_version || '1.0.0'}\n`;
        menuText += `│ ⬡ ${T(lang, 'header_dev')}      : ${engine.dev}\n`;
        menuText += `│ ⬡ ${T(lang, 'header_contact')}  : ${engine.contact}\n`;
        menuText += `╰───────☉\n\n`;

        menuText += `╔──☉『 *${T(lang, 'main_menu')}* 』\n`;
        menuText += sortedCategories.map(cat => `╰⪼ ${cat.toUpperCase()}`).join('\n');
        menuText += `\n\n`;
        menuText += `_${T(lang, 'hint_allmenu')}_\n`;
        menuText += `_${T(lang, 'hint_category')}_\n`;
        menuText += `_${T(lang, 'total_cmd', {
            n: plugins.reduce((acc, p) => acc + p.cmd.length, 0),
        })}_\n\n`;
        menuText += T(lang, 'footer');
    }

    // ============================================================
    // KIRIM MENU + GAMBAR + AUDIO
    // ============================================================
    const opts = { quoted: msg };
    if (sender.lid) opts.mentions = [sender.lid];

    let menuTerkirim = false;

    // BLOK 1: Gambar (atau fallback teks)
    if (engine.mainImage) {
        try {
            const imgRes = await axios.get(engine.mainImage, {
                responseType: 'arraybuffer',
                timeout: 10000,
            });
            const imageBuffer = Buffer.from(imgRes.data);

            await sendMedia(sock, remoteJid, {
                buffer: imageBuffer,
                mimetype: 'image/jpeg',
                caption: menuText,
            }, opts);

            menuTerkirim = true;
        } catch (e) {
            console.warn('[Menu] Gagal kirim gambar:', e.message);
        }
    }

    if (!menuTerkirim) {
        await sendText(sock, remoteJid, menuText, opts);
    }

    // BLOK 2: Audio
    if (engine.mainAudio) {
        try {
            const audioRes = await axios.get(engine.mainAudio, {
                responseType: 'arraybuffer',
                timeout: 15000,
            });
            const audioBuffer = Buffer.from(audioRes.data);

            await sendMedia(sock, remoteJid, {
                buffer: audioBuffer,
                mimetype: 'audio/mp4',
                ptt: false,
            }, opts);
        } catch (e) {
            console.warn('[Menu] Gagal kirim audio:', e.message);
        }
    }

    // Reaksi sukses
    await sendReaction(sock, remoteJid, msg.key, '✅');
}