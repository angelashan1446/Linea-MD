// plugins/ai/removebg.js
// Hapus background gambar otomatis (RemoveBG) — multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['removebg', 'rbg'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 15;

export const description_id = 'Hapus background gambar otomatis (RemoveBG)';
export const description_ch = '自动去除图片背景（RemoveBG）';
export const description_uk = 'Remove image background automatically (RemoveBG)';
export const description = description_id;

const TEXT = {
    id: {
        no_image: '⚠️ Balas sebuah gambar dengan command *.removebg*',
        header: `乂  *ᴀɴɢᴇʟs - ʀᴇᴍᴏᴠᴇ ʙɢ*`,
        label_status: 'Status',
        status_value: 'Sukses',
        label_info: 'Info',
        label_type: 'Tipe',
        type_value: 'Gambar (PNG)',
        label_bg: 'Background',
        bg_value: 'Dihapus',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        no_image: '⚠️ 请回复一张图片并使用 *.removebg*',
        header: `乂  *ᴀɴɢᴇʟs - 去除背景*`,
        label_status: '状态',
        status_value: '成功',
        label_info: '信息',
        label_type: '类型',
        type_value: '图片（PNG）',
        label_bg: '背景',
        bg_value: '已移除',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        no_image: '⚠️ Reply to an image with *.removebg*',
        header: `乂  *ᴀɴɢᴇʟs - ʀᴇᴍᴏᴠᴇ ʙɢ*`,
        label_status: 'Status',
        status_value: 'Success',
        label_info: 'Info',
        label_type: 'Type',
        type_value: 'Image (PNG)',
        label_bg: 'Background',
        bg_value: 'Removed',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directImage = msg.message?.imageMessage;
    const quotedImage = quoted?.imageMessage;
    if (!quotedImage && !directImage) return reply(T(lang, 'no_image'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        const upload = await engine.upload.fromBuffer(buffer, 'jpg');
        await sendReaction(sock, remoteJid, msg.key, '⬆️');

        const res = await engine.run('removebg', { url: upload.url });

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_status')}* : ${T(lang, 'status_value')}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦ ${T(lang, 'label_type')} : ${T(lang, 'type_value')}\n` +
            `   ◦ ${T(lang, 'label_bg')} : ${T(lang, 'bg_value')}\n\n` +
            `${T(lang, 'footer')}`;

        await sendReaction(sock, remoteJid, msg.key, '⬇️');
        await sendMediaUrl(sock, remoteJid, res.url, { quoted: msg, caption });
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error(err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}