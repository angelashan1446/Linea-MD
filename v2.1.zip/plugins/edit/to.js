// plugins/tools/to.js
// AI edit gambar pakai preset tag atau custom prompt (.to <tag>) — multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { getPrompt, isValidTag, getTagsByCategory } from '../../libx/utils/promt.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';
import axios from 'axios';

export const cmd = ['to'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 25;

export const description_id = 'AI edit gambar pakai preset tag atau custom prompt (.to <tag>)';
export const description_ch = '使用预设标签或自定义提示词进行 AI 编辑图片 (.to <tag>)';
export const description_uk = 'AI edit image using preset tag or custom prompt (.to <tag>)';
export const description = description_id;

const TEXT = {
    id: {
        header_list: `乂  *ᴀɪ ᴇᴅɪᴛ - ᴘʀᴇsᴇᴛ ʟɪsᴛ*`,
        reply_hint: '_Reply gambar + ketik_ `.to <tag>`',
        contoh_title: '💡 *Contoh:*',
        contoh_body:
            'Reply gambar, lalu ketik:\n' +
            '• `.to figura` → jadi action figure\n' +
            '• `.to anime` → gaya anime\n' +
            '• `.to cowok` → ubah jadi cowok',
        custom_hint:
            '_Custom prompt juga bisa:_\n' +
            '• `.to ubah jadi astronaut`',
        no_image:
            '⚠️ Balas sebuah gambar dulu!\n\n' +
            '*Cara pakai:*\n' +
            '1. Reply gambar dengan command\n' +
            '2. Ketik `.to figura`\n\n' +
            '_Ketik `.to` tanpa argumen buat lihat semua preset._',
        api_no_url: 'API tidak mengembalikan URL gambar.',
        header_result: `乂  *ᴀɴɢᴇʟs - ᴀɪ ᴇᴅɪᴛ*`,
        label_prompt: 'Prompt',
        label_type: 'Tipe',
        type_preset: 'Preset',
        type_custom: 'Custom',
        label_status: 'Status',
        status_value: '✅ Sukses',
        fail: '❌ Gagal edit gambar: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        header_list: `乂  *ᴀɪ 编辑 - 预设列表*`,
        reply_hint: '_回复图片 + 输入_ `.to <tag>`',
        contoh_title: '💡 *示例：*',
        contoh_body:
            '回复图片，然后输入：\n' +
            '• `.to figura` → 变成手办\n' +
            '• `.to anime` → 动漫风格\n' +
            '• `.to cowok` → 变成男生',
        custom_hint:
            '_也支持自定义提示词：_\n' +
            '• `.to 变成宇航员`',
        no_image:
            '⚠️ 请先回复一张图片！\n\n' +
            '*使用方法：*\n' +
            '1. 回复图片并发送命令\n' +
            '2. 输入 `.to figura`\n\n' +
            '_输入不带参数的 `.to` 查看所有预设。_',
        api_no_url: 'API 未返回图片链接。',
        header_result: `乂  *ᴀɴɢᴇʟs - ᴀɪ 编辑*`,
        label_prompt: '提示词',
        label_type: '类型',
        type_preset: '预设',
        type_custom: '自定义',
        label_status: '状态',
        status_value: '✅ 成功',
        fail: '❌ 编辑图片失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        header_list: `乂  *ᴀɪ ᴇᴅɪᴛ - ᴘʀᴇsᴇᴛ ʟɪsᴛ*`,
        reply_hint: '_Reply image + type_ `.to <tag>`',
        contoh_title: '💡 *Example:*',
        contoh_body:
            'Reply an image, then type:\n' +
            '• `.to figura` → turn into action figure\n' +
            '• `.to anime` → anime style\n' +
            '• `.to cowok` → turn into a boy',
        custom_hint:
            '_Custom prompt also works:_\n' +
            '• `.to turn into astronaut`',
        no_image:
            '⚠️ Reply to an image first!\n\n' +
            '*How to use:*\n' +
            '1. Reply an image with the command\n' +
            '2. Type `.to figura`\n\n' +
            '_Type `.to` without arguments to see all presets._',
        api_no_url: 'API did not return an image URL.',
        header_result: `乂  *ᴀɴɢᴇʟs - ᴀɪ ᴇᴅɪᴛ*`,
        label_prompt: 'Prompt',
        label_type: 'Type',
        type_preset: 'Preset',
        type_custom: 'Custom',
        label_status: 'Status',
        status_value: '✅ Success',
        fail: '❌ Failed to edit image: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, args, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    // ==========================================
    // 1. Tanpa argumen → tampilkan LIST (dengan gambar)
    // ==========================================
    if (!args[0]) {
        const categories = getTagsByCategory();
        let list = `${T(lang, 'header_list')}\n\n`;
        list += `${T(lang, 'reply_hint')}\n\n`;

        for (const [cat, tags] of Object.entries(categories)) {
            list += `╔──☉『 *${cat.toUpperCase()}* 』\n`;
            list += tags.map(t => `╰⪼ .to ${t}`).join('\n');
            list += `\n\n`;
        }

        list += `${T(lang, 'contoh_title')}\n`;
        list += `${T(lang, 'contoh_body')}\n\n`;
        list += `${T(lang, 'custom_hint')}\n\n`;
        list += `${T(lang, 'footer')}`;

        try {
            if (engine.mainImage) {
                const imgRes = await axios.get(engine.mainImage, {
                    responseType: 'arraybuffer',
                    timeout: 15000,
                });
                Buffer.from(imgRes.data);

                await sendMediaUrl(sock, remoteJid, engine.mainImage, {
                    quoted: msg,
                    caption: list,
                });
            } else {
                await reply(list);
            }
        } catch (e) {
            console.warn('[to] Gagal kirim gambar list:', e.message);
            await reply(list);
        }
        return;
    }

    // ==========================================
    // 2. Ada argumen → cek gambar dulu
    // ==========================================
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directImage = msg.message?.imageMessage;
    const quotedImage = quoted?.imageMessage;
    if (!quotedImage && !directImage) {
        return reply(T(lang, 'no_image'));
    }

    // ==========================================
    // 3. Ambil prompt
    // ==========================================
    const rawPrompt = args.join(' ').trim();
    const isTag = isValidTag(rawPrompt);
    const prompt = getPrompt(rawPrompt, rawPrompt);

    await sendReaction(sock, remoteJid, msg.key, '✏️');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        const upload = await engine.upload.fromBuffer(buffer, 'jpg');
        await sendReaction(sock, remoteJid, msg.key, '⬆️');

        const res = await engine.run('aiedit', {
            image: upload.url,
            prompt,
        });

        if (!res.url) throw new Error(T(lang, 'api_no_url'));

        await sendReaction(sock, remoteJid, msg.key, '⬇️');

        const caption =
            `${T(lang, 'header_result')}\n\n` +
            `*${T(lang, 'label_prompt')}* : ${isTag ? `.to ${rawPrompt}` : rawPrompt}\n` +
            `*${T(lang, 'label_type')}* : ${isTag ? T(lang, 'type_preset') : T(lang, 'type_custom')}\n` +
            `*${T(lang, 'label_status')}* : ${T(lang, 'status_value')}\n\n` +
            `${T(lang, 'footer')}`;

        await sendMediaUrl(sock, remoteJid, res.url, { quoted: msg, caption });
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[to]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}