// plugins/tools/resize.js
// Resize & crop tengah gambar dengan rasio bebas — multi-bahasa.

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import sharp from 'sharp';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['resize', 'crop'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 2;

export const description_id = 'Resize & crop tengah gambar dengan rasio bebas (1:1, 16:9, dll)';
export const description_ch = '按任意比例调整大小并居中裁剪图片（1:1、16:9 等）';
export const description_uk = 'Resize & center-crop image with any ratio (1:1, 16:9, etc)';
export const description = description_id;

const RATIO_PRESETS = {
    '1:1':  { w: 1080, h: 1080, label: 'Square (IG Post)' },
    '4:5':  { w: 1080, h: 1350, label: 'Portrait (IG Feed)' },
    '9:16': { w: 1080, h: 1920, label: 'Story / Reels / TikTok' },
    '16:9': { w: 1920, h: 1080, label: 'Landscape (YouTube / Banner)' },
    '4:3':  { w: 1440, h: 1080, label: 'Classic (Foto)' },
    '3:2':  { w: 1620, h: 1080, label: 'DSLR Standard' },
    '2:1':  { w: 2000, h: 1000, label: 'Wide Banner' },
    '21:9': { w: 2520, h: 1080, label: 'Ultrawide / Cinematic' },
};

const SIZE_PRESETS = {
    'ig-post':   { w: 1080, h: 1080, label: 'Instagram Post' },
    'ig-story':  { w: 1080, h: 1920, label: 'Instagram Story' },
    'yt-thumb':  { w: 1280, h: 720,  label: 'YouTube Thumbnail' },
    'yt-banner': { w: 2560, h: 1440, label: 'YouTube Banner' },
    'fb-cover':  { w: 820,  h: 312,  label: 'Facebook Cover' },
    'tw-post':   { w: 1200, h: 675,  label: 'Twitter Post' },
    'wa-dp':     { w: 640,  h: 640,  label: 'WhatsApp DP' },
    'hd':        { w: 1280, h: 720,  label: 'HD 720p' },
    'fhd':       { w: 1920, h: 1080, label: 'Full HD 1080p' },
    '4k':        { w: 3840, h: 2160, label: '4K UHD' },
};

const TEXT = {
    id: {
        no_image:
            '⚠️ Balas sebuah *gambar* yang ingin di-resize!\n\n' +
            '*Format:* {prefix}resize <rasio/ukuran>\n\n' +
            '*Preset Rasio:*\n' +
            '• 1:1 · 4:5 · 9:16 · 16:9\n' +
            '• 4:3 · 3:2 · 2:1 · 21:9\n\n' +
            '*Preset Ukuran:*\n' +
            '• ig-post · ig-story · yt-thumb\n' +
            '• yt-banner · fb-cover · tw-post\n' +
            '• wa-dp · hd · fhd · 4k\n\n' +
            '*Custom:*\n' +
            '• {prefix}resize 800x600\n' +
            '• {prefix}resize 3:4\n\n' +
            '_Contoh: reply gambar +_ `.resize 1:1`',
        invalid_format:
            '❌ Format *{arg}* tidak valid.\n\n' +
            '*Contoh yang benar:*\n' +
            '• {prefix}resize 1:1\n' +
            '• {prefix}resize 16:9\n' +
            '• {prefix}resize 800x600\n' +
            '• {prefix}resize yt-thumb',
        too_large: '❌ Gambar terlalu besar (maks 20 MB).',
        header: `乂  *ᴀɴɢᴇʟ's - ʀᴇsɪᴢᴇ*`,
        label_info: 'Info',
        label_preset: 'Preset',
        label_original: 'Asli',
        label_result: 'Hasil',
        label_mode: 'Mode',
        label_size: 'Ukuran',
        mode_value: 'Crop Tengah',
        fail: '❌ Gagal resize: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    ch: {
        no_image:
            '⚠️ 请回复要调整大小的*图片*！\n\n' +
            '*格式：* {prefix}resize <比例/尺寸>\n\n' +
            '*比例预设：*\n' +
            '• 1:1 · 4:5 · 9:16 · 16:9\n' +
            '• 4:3 · 3:2 · 2:1 · 21:9\n\n' +
            '*尺寸预设：*\n' +
            '• ig-post · ig-story · yt-thumb\n' +
            '• yt-banner · fb-cover · tw-post\n' +
            '• wa-dp · hd · fhd · 4k\n\n' +
            '*自定义：*\n' +
            '• {prefix}resize 800x600\n' +
            '• {prefix}resize 3:4\n\n' +
            '_示例：回复图片 +_ `.resize 1:1`',
        invalid_format:
            '❌ 格式 *{arg}* 无效。\n\n' +
            '*正确示例：*\n' +
            '• {prefix}resize 1:1\n' +
            '• {prefix}resize 16:9\n' +
            '• {prefix}resize 800x600\n' +
            '• {prefix}resize yt-thumb',
        too_large: '❌ 图片太大（最大 20 MB）。',
        header: `乂  *ᴀɴɢᴇʟ's - 调整大小*`,
        label_info: '信息',
        label_preset: '预设',
        label_original: '原始',
        label_result: '结果',
        label_mode: '模式',
        label_size: '大小',
        mode_value: '居中裁剪',
        fail: '❌ 调整失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
    uk: {
        no_image:
            '⚠️ Reply to an *image* you want to resize!\n\n' +
            '*Format:* {prefix}resize <ratio/size>\n\n' +
            '*Ratio Presets:*\n' +
            '• 1:1 · 4:5 · 9:16 · 16:9\n' +
            '• 4:3 · 3:2 · 2:1 · 21:9\n\n' +
            '*Size Presets:*\n' +
            '• ig-post · ig-story · yt-thumb\n' +
            '• yt-banner · fb-cover · tw-post\n' +
            '• wa-dp · hd · fhd · 4k\n\n' +
            '*Custom:*\n' +
            '• {prefix}resize 800x600\n' +
            '• {prefix}resize 3:4\n\n' +
            '_Example: reply image +_ `.resize 1:1`',
        invalid_format:
            '❌ Invalid format *{arg}*.\n\n' +
            '*Correct examples:*\n' +
            '• {prefix}resize 1:1\n' +
            '• {prefix}resize 16:9\n' +
            '• {prefix}resize 800x600\n' +
            '• {prefix}resize yt-thumb',
        too_large: '❌ Image is too large (max 20 MB).',
        header: `乂  *ᴀɴɢᴇʟ's - ʀᴇsɪᴢᴇ*`,
        label_info: 'Info',
        label_preset: 'Preset',
        label_original: 'Original',
        label_result: 'Result',
        label_mode: 'Mode',
        label_size: 'Size',
        mode_value: 'Center Crop',
        fail: '❌ Failed to resize: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function parseArgs(args) {
    if (!args || args.length === 0) return null;
    const raw = args.join(' ').trim().toLowerCase();

    if (SIZE_PRESETS[raw]) return { ...SIZE_PRESETS[raw], raw };
    if (RATIO_PRESETS[raw]) return { ...RATIO_PRESETS[raw], raw };

    const wxhMatch = raw.match(/^(\d+)\s*[x×]\s*(\d+)$/);
    if (wxhMatch) {
        const w = parseInt(wxhMatch[1]);
        const h = parseInt(wxhMatch[2]);
        if (w > 0 && h > 0 && w <= 5000 && h <= 5000) {
            return { w, h, label: `Custom ${w}×${h}` };
        }
    }

    const ratioMatch = raw.match(/^(\d+)\s*[:/]\s*(\d+)$/);
    if (ratioMatch) {
        const rw = parseInt(ratioMatch[1]);
        const rh = parseInt(ratioMatch[2]);
        if (rw > 0 && rh > 0 && rw <= 50 && rh <= 50) {
            const scale = 1080 / Math.max(rw, rh);
            return {
                w: Math.round(rw * scale),
                h: Math.round(rh * scale),
                label: `Ratio ${rw}:${rh}`,
            };
        }
    }

    return null;
}

export default async function handler(ctx) {
    const { sock, msg, reply, replyMedia, remoteJid, args, prefix, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directImage = msg.message?.imageMessage;
    const quotedImage = quoted?.imageMessage;
    if (!quotedImage && !directImage) {
        return reply(T(lang, 'no_image', { prefix }));
    }

    const config = parseArgs(args);
    if (!config) {
        return reply(T(lang, 'invalid_format', { arg: args.join(' '), prefix }));
    }

    await sendReaction(sock, remoteJid, msg.key, '🖼️');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        if (buffer.length > 20 * 1024 * 1024) return reply(T(lang, 'too_large'));

        await sendReaction(sock, remoteJid, msg.key, '⏳');

        const metadata = await sharp(buffer).metadata();
        const originalSize = `${metadata.width}×${metadata.height}`;

        const resized = await sharp(buffer)
            .rotate()
            .resize(config.w, config.h, {
                fit: 'cover',
                position: 'center',
                withoutEnlargement: false,
            })
            .jpeg({ quality: 92 })
            .toBuffer();

        const newSize = `${config.w}×${config.h}`;
        const sizeKb = (resized.length / 1024).toFixed(1);

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦ ${T(lang, 'label_preset')} : ${config.label}\n` +
            `   ◦ ${T(lang, 'label_original')} : ${originalSize}\n` +
            `   ◦ ${T(lang, 'label_result')} : ${newSize}\n` +
            `   ◦ ${T(lang, 'label_mode')} : ${T(lang, 'mode_value')}\n` +
            `   ◦ ${T(lang, 'label_size')} : ${sizeKb} KB\n\n` +
            `${T(lang, 'footer')}`;

        await replyMedia({ buffer: resized, mimetype: 'image/jpeg', caption });
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[resize]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}