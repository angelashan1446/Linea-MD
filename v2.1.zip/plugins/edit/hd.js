// plugins/ai/hd.js
// Naikkan kualitas/resolusi gambar dengan AI (HD Upscaler) — multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['hd', 'upscale', 'remini'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 15;

export const description_id = 'Naikkan kualitas/resolusi gambar dengan AI (HD Upscaler)';
export const description_ch = '使用 AI 提升图片质量/分辨率（HD 放大）';
export const description_uk = 'Enhance image quality/resolution with AI (HD Upscaler)';
export const description = description_id;

const TEXT = {
    id: {
        no_image: '⚠️ Balas sebuah gambar dengan command *.hd* untuk naikin kualitas',
        header: `乂  *ᴀɴɢᴇʟs - ʜᴅ ᴜᴘsᴄᴀʟᴇʀ*`,
        label_status: 'Status',
        status_value: 'Sukses',
        label_info: 'Info',
        label_type: 'Tipe',
        type_value: 'Gambar (HD)',
        label_quality: 'Kualitas',
        quality_value: 'Ditingkatkan',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        no_image: '⚠️ 请回复一张图片并使用 *.hd* 提升质量',
        header: `乂  *ᴀɴɢᴇʟs - ʜᴅ 放大*`,
        label_status: '状态',
        status_value: '成功',
        label_info: '信息',
        label_type: '类型',
        type_value: '图片（HD）',
        label_quality: '画质',
        quality_value: '已增强',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        no_image: '⚠️ Reply to an image with *.hd* to enhance quality',
        header: `乂  *ᴀɴɢᴇʟs - ʜᴅ ᴜᴘsᴄᴀʟᴇʀ*`,
        label_status: 'Status',
        status_value: 'Success',
        label_info: 'Info',
        label_type: 'Type',
        type_value: 'Image (HD)',
        label_quality: 'Quality',
        quality_value: 'Enhanced',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directImage = msg.message?.imageMessage;
    const quotedImage = quoted?.imageMessage;
    if (!quotedImage && !directImage) return reply(T(lang, 'no_image'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        const upload = await engine.upload.fromBuffer(buffer, 'jpg');
        await sendReaction(sock, remoteJid, msg.key, '⬆️');

        const res = await engine.run('hdimage', { url: upload.url });

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_status')}* : ${T(lang, 'status_value')}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦ ${T(lang, 'label_type')} : ${T(lang, 'type_value')}\n` +
            `   ◦ ${T(lang, 'label_quality')} : ${T(lang, 'quality_value')}\n\n` +
            `${T(lang, 'footer')}`;

        await sendReaction(sock, remoteJid, msg.key, '⬇️');
        await sendMediaUrl(sock, remoteJid, res.url, { quoted: msg, caption });
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error(err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}