// plugins/download/ig.js
// Download media Instagram + opsi audio (ketik 1) — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl, sendMedia, sendText } from '../../libx/whatsapp/sendmsg.js';
import { registerSession } from '../../libx/session_plugins.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegPath from 'ffmpeg-static';
import fs from 'fs';
import path from 'path';
import os from 'os';

ffmpeg.setFfmpegPath(ffmpegPath);

export const cmd = ['ig', 'instagram', 'igdl'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 10;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Download media Instagram + opsi audio (ketik 1 untuk audio)';
export const description_ch = '下载 Instagram 媒体 + 可选音频（输入 1 获取音频）';
export const description_uk = 'Download Instagram media + optional audio (type 1 for audio)';
export const description = description_id;

// ============================================================
// KONFIG
// ============================================================
const TIMEOUT_AUDIO = 5 * 60 * 1000;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        invalid_link:
            '⚠️ Masukkan link Instagram!\n' +
            'Contoh:\n' +
            '• .ig https://www.instagram.com/reel/xxx/\n' +
            '• .ig https://www.instagram.com/p/xxx/',
        no_media:
            '❌ Tidak ada media yang ditemukan (post private atau dihapus?).',
        header: `乂  *ᴀɴɢᴇʟs - ɪɴsᴛᴀɢʀᴀᴍ*`,
        label_creator: 'Kreator',
        label_info: 'Info',
        label_type: 'Tipe',
        label_total: 'Total',
        total_media: '{n} media',
        unknown_creator: 'Tidak diketahui',
        fail_media: '⚠️ Gagal kirim media {i}: {err}',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,

        // Audio prompt
        audio_prompt:
            '🎵 *Minta Audio MP3?*\n\n' +
            'Ketik *1* untuk download audio dari video ini.\n' +
            '⏱️ _Batas waktu: 60 detik_',
        audio_invalid:
            '❌ Balasan tidak valid.\nKetik *1* untuk minta audio, atau abaikan pesan ini.',
        audio_processing: '⏳ Memproses audio...',
        audio_success: '🎵 *Audio MP3 berhasil dikirim!*',
        audio_timeout: '⏱️ Waktu habis. Kalau mau audio, kirim ulang link Instagram-nya.',
        audio_fail: '❌ Gagal membuat audio: {err}',
    },
    ch: {
        invalid_link:
            '⚠️ 请输入 Instagram 链接！\n' +
            '示例：\n' +
            '• .ig https://www.instagram.com/reel/xxx/\n' +
            '• .ig https://www.instagram.com/p/xxx/',
        no_media:
            '❌ 未找到媒体（帖子私密或已删除？）。',
        header: `乂  *ᴀɴɢᴇʟs - ɪɴsᴛᴀɢʀᴀᴍ*`,
        label_creator: '创作者',
        label_info: '信息',
        label_type: '类型',
        label_total: '总计',
        total_media: '{n} 个媒体',
        unknown_creator: '未知',
        fail_media: '⚠️ 发送媒体 {i} 失败：{err}',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,

        audio_prompt:
            '🎵 *获取 MP3 音频？*\n\n' +
            '输入 *1* 下载此视频的音频。\n' +
            '⏱️ _时限：60 秒_',
        audio_invalid:
            '❌ 回复无效。\n输入 *1* 获取音频，或忽略此消息。',
        audio_processing: '⏳ 正在处理音频...',
        audio_success: '🎵 *MP3 音频已成功发送！*',
        audio_timeout: '⏱️ 时间到。如需音频，请重新发送 Instagram 链接。',
        audio_fail: '❌ 生成音频失败：{err}',
    },
    uk: {
        invalid_link:
            '⚠️ Enter an Instagram link!\n' +
            'Example:\n' +
            '• .ig https://www.instagram.com/reel/xxx/\n' +
            '• .ig https://www.instagram.com/p/xxx/',
        no_media:
            '❌ No media found (private or deleted post?).',
        header: `乂  *ᴀɴɢᴇʟs - ɪɴsᴛᴀɢʀᴀᴍ*`,
        label_creator: 'Creator',
        label_info: 'Info',
        label_type: 'Type',
        label_total: 'Total',
        total_media: '{n} media',
        unknown_creator: 'Unknown',
        fail_media: '⚠️ Failed to send media {i}: {err}',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,

        audio_prompt:
            '🎵 *Get MP3 audio?*\n\n' +
            'Type *1* to download the audio from this video.\n' +
            '⏱️ _Time limit: 60 seconds_',
        audio_invalid:
            '❌ Invalid reply.\nType *1* to get the audio, or ignore this message.',
        audio_processing: '⏳ Processing audio...',
        audio_success: '🎵 *MP3 audio sent successfully!*',
        audio_timeout: '⏱️ Time\'s up. To get the audio, send the Instagram link again.',
        audio_fail: '❌ Failed to generate audio: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function extractUrl(item) {
    if (!item) return null;
    if (typeof item === 'string') return item;
    return item.url || null;
}

function guessMimetype(url, fallback = 'image/jpeg') {
    if (!url) return fallback;
    const clean = url.split('?')[0].toLowerCase();
    if (clean.endsWith('.mp4') || clean.endsWith('.mov') || clean.endsWith('.webm')) return 'video/mp4';
    if (clean.endsWith('.jpg') || clean.endsWith('.jpeg')) return 'image/jpeg';
    if (clean.endsWith('.png')) return 'image/png';
    if (clean.endsWith('.webp')) return 'image/webp';
    if (clean.endsWith('.gif')) return 'image/gif';
    return fallback;
}

// ============================================================
// HELPER: CONVERT VIDEO → MP3
// ============================================================
async function convertVideoToMp3(videoUrl) {
    const tmpIn = path.join(os.tmpdir(), `ig_in_${Date.now()}.mp4`);
    const tmpOut = path.join(os.tmpdir(), `ig_out_${Date.now()}.mp3`);

    try {
        const vidRes = await fetch(videoUrl);
        const buffer = Buffer.from(await vidRes.arrayBuffer());
        fs.writeFileSync(tmpIn, buffer);

        await new Promise((resolve, reject) => {
            ffmpeg(tmpIn)
                .outputOptions([
                    '-vn',
                    '-ar', '44100',
                    '-ac', '2',
                    '-b:a', '128k',
                ])
                .toFormat('mp3')
                .on('end', resolve)
                .on('error', (err) => reject(new Error('FFmpeg: ' + err.message)))
                .save(tmpOut);
        });

        return fs.readFileSync(tmpOut);
    } finally {
        try { if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn); } catch {}
        try { if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut); } catch {}
    }
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text || !text.includes('instagram.com')) {
        return reply(T(lang, 'invalid_link'));
    }

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        // 2. Panggil API
        const res = await engine.run('instagram', { url: text });

        const creator = res.creator || T(lang, 'unknown_creator');
        const type = res.type || 'unknown';
        const videos = Array.isArray(res.videos) ? res.videos : [];
        const images = Array.isArray(res.images) ? res.images : [];

        if (videos.length === 0 && images.length === 0) {
            await sendReaction(sock, remoteJid, msg.key, '❌');
            return reply(T(lang, 'no_media'));
        }

        // 3. Caption
        const totalMedia = videos.length + images.length;
        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_creator')}* : ${creator}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦  *${T(lang, 'label_type')}*  : ${type}\n` +
            `   ◦  *${T(lang, 'label_total')}* : ${T(lang, 'total_media', { n: totalMedia })}\n\n` +
            `${T(lang, 'footer')}`;

        // 4. Kirim semua video
        for (let i = 0; i < videos.length; i++) {
            const videoUrl = extractUrl(videos[i]);
            if (!videoUrl) continue;

            try {
                await sendMediaUrl(sock, remoteJid, videoUrl, {
                    quoted: msg,
                    caption: i === 0 ? caption : '',
                    mimetype: guessMimetype(videoUrl, 'video/mp4'),
                });

                if (i < videos.length - 1) {
                    await new Promise((r) => setTimeout(r, 1500));
                }
            } catch (err) {
                console.error(`[IG] Gagal kirim video ${i + 1}:`, err.message);
                await sendMediaUrl(sock, remoteJid, videoUrl, {
                    quoted: msg,
                    caption: T(lang, 'fail_media', { i: i + 1, err: err.message }),
                }).catch(() => {});
            }
        }

        // 5. Kirim semua gambar (carousel)
        for (let i = 0; i < images.length; i++) {
            const imgUrl = extractUrl(images[i]);
            if (!imgUrl) continue;

            try {
                await sendMediaUrl(sock, remoteJid, imgUrl, {
                    quoted: msg,
                    caption: (videos.length === 0 && i === 0) ? caption : '',
                    mimetype: guessMimetype(imgUrl, 'image/jpeg'),
                });

                if (i < images.length - 1) {
                    await new Promise((r) => setTimeout(r, 1500));
                }
            } catch (err) {
                console.error(`[IG] Gagal kirim gambar ${i + 1}:`, err.message);
            }
        }

        // ============================================================
        // 6. Prompt audio (HANYA kalau ada video)
        // ============================================================
        const firstVideoUrl = videos.length > 0 ? extractUrl(videos[0]) : null;

        if (firstVideoUrl) {
            const audioPromptMsg = await reply(T(lang, 'audio_prompt'));
            if (!audioPromptMsg?.key?.id) {
                await sendReaction(sock, remoteJid, msg.key, '✅');
                return;
            }

            const onAudioReply = async (rCtx) => {
                const jawab = String(rCtx.text || '').trim();

                if (jawab !== '1') {
                    return rCtx.reply(T(lang, 'audio_invalid'));
                }

                await sendReaction(sock, remoteJid, rCtx.msg.key, '🎵');
                await rCtx.reply(T(lang, 'audio_processing'));

                try {
                    const audioBuffer = await convertVideoToMp3(firstVideoUrl);

                    const fileName =
                        `ig_audio_${Date.now()}.mp3`.replace(/[^\w\s.-]/gi, '');

                    await sendMedia(sock, remoteJid, {
                        buffer: audioBuffer,
                        mimetype: 'audio/mp4',
                        fileName,
                    }, { quoted: msg });

                    await sendReaction(sock, remoteJid, rCtx.msg.key, '✅');
                } catch (err) {
                    console.error('[IG-AUDIO]', err.message);
                    await rCtx.reply(T(lang, 'audio_fail', { err: err.message }));
                    await sendReaction(sock, remoteJid, rCtx.msg.key, '❌');
                }
            };

            registerSession(
                audioPromptMsg.key.id,
                remoteJid,
                onAudioReply,
                { videoUrl: firstVideoUrl, action: 'wait_audio' },
                {
                    once: true,
                    timeoutMs: TIMEOUT_AUDIO,
                    senderJid: sender?.lid || (sender?.nomor ? `${sender.nomor}@s.whatsapp.net` : null),
                    validateSender: true,
                    tag: 'ig_audio',
                    onExpire: async ({ chatJid }) => {
                        try {
                            await sendText(sock, chatJid, T(lang, 'audio_timeout'));
                        } catch (_) {}
                    },
                }
            );
        }

        // 7. Reaksi sukses
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error('[IG]', err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}