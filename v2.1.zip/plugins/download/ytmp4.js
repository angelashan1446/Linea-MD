// plugins/download/ytmp4.js
// Download video MP4 dari YouTube via link — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['ytmp4', 'mp4'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 25;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Download video MP4 dari YouTube via link';
export const description_ch = '通过链接从 YouTube 下载 MP4 视频';
export const description_uk = 'Download MP4 video from YouTube via link';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        invalid_link:
            '⚠️ Masukkan link YouTube!\nContoh: .ytmp4 https://youtu.be/er1we94HrvU',
        header: `乂  *ᴀɴɢᴇʟs - ʏᴏᴜᴛᴜʙᴇ ᴍᴘ4*`,
        label_title: 'Judul',
        label_info: 'Info',
        label_quality: 'Kualitas',
        unknown_title: 'Judul tidak diketahui',
        video_filename: 'video',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        invalid_link:
            '⚠️ 请输入 YouTube 链接！\n示例：.ytmp4 https://youtu.be/er1we94HrvU',
        header: `乂  *ᴀɴɢᴇʟs - ʏᴏᴜᴛᴜʙᴇ ᴍᴘ4*`,
        label_title: '标题',
        label_info: '信息',
        label_quality: '画质',
        unknown_title: '未知标题',
        video_filename: '视频',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        invalid_link:
            '⚠️ Enter a YouTube link!\nExample: .ytmp4 https://youtu.be/er1we94HrvU',
        header: `乂  *ᴀɴɢᴇʟs - ʏᴏᴜᴛᴜʙᴇ ᴍᴘ4*`,
        label_title: 'Title',
        label_info: 'Info',
        label_quality: 'Quality',
        unknown_title: 'Unknown Title',
        video_filename: 'video',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text || !text.includes('http')) {
        return reply(T(lang, 'invalid_link'));
    }

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        // 2. Panggil API
        const res = await engine.run('ytmp4', { url: text });
        const title = res.title || T(lang, 'unknown_title');

        // 3. Caption
        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_title')}* : ${title}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦  *${T(lang, 'label_quality')}* : 360p\n\n` +
            `${T(lang, 'footer')}`;

        // 4. Kirim thumbnail + caption
        if (res.thumb) {
            await sendMediaUrl(sock, remoteJid, res.thumb, { quoted: msg, caption });
        } else {
            await reply(caption);
        }

        // 5. Reaksi download
        await sendReaction(sock, remoteJid, msg.key, '⬇️');

        // 6. Kirim video MP4
        await sendMediaUrl(sock, remoteJid, res.url, {
            quoted: msg,
            mimetype: 'video/mp4',
            fileName: `${(res.title || T(lang, 'video_filename')).substring(0, 50)}.mp4`.replace(/[^\w\s.-]/gi, ''),
        });

        // 7. Reaksi sukses
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error(err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}