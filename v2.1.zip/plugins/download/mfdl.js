// plugins/download/mfdl.js
// Download file dari MediaFire — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['mfdl', 'mediafire'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 5;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Download file dari MediaFire';
export const description_ch = '从 MediaFire 下载文件';
export const description_uk = 'Download file from MediaFire';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_url: '⚠️ Kirim link MediaFire!\n\nContoh: *{prefix}mfdl* https://www.mediafire.com/file/...',
        invalid_url: '❌ Link tidak valid. Pastikan itu link MediaFire.',
        processing: '⏳ Sedang memproses file...',
        success: `✅ *File Ditemukan*\n\n📁 *Nama:* {name}\n📦 *Ukuran:* {size}\n📂 *Tipe:* {filetype}\n\n🔗 *Link Download:*\n{link}\n\n_Catatan: Link ini bersifat direct, bisa langsung diklik atau diunduh._`,
        fail: '❌ Gagal: {err}',
    },
    ch: {
        no_url: '⚠️ 请发送 MediaFire 链接！\n\n示例：*{prefix}mfdl* https://www.mediafire.com/file/...',
        invalid_url: '❌ 链接无效。请确保是 MediaFire 链接。',
        processing: '⏳ 正在处理文件...',
        success: `✅ *找到文件*\n\n📁 *名称:* {name}\n📦 *大小:* {size}\n📂 *类型:* {filetype}\n\n🔗 *下载链接:*\n{link}\n\n_注意：这是一个直接链接，可以直接点击或下载。_`,
        fail: '❌ 失败：{err}',
    },
    uk: {
        no_url: '⚠️ Send a MediaFire link!\n\nExample: *{prefix}mfdl* https://www.mediafire.com/file/...',
        invalid_url: '❌ Invalid link. Make sure it is a MediaFire link.',
        processing: '⏳ Processing file...',
        success: `✅ *File Found*\n\n📁 *Name:* {name}\n📦 *Size:* {size}\n📂 *Type:* {filetype}\n\n🔗 *Download Link:*\n{link}\n\n_Note: This is a direct link, you can click or download it immediately._`,
        fail: '❌ Failed: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, args, prefix, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const url = args[0];
    if (!url) {
        return reply(T(lang, 'no_url', { prefix }));
    }

    // Validasi URL sederhana
    if (!/^https?:\/\/(www\.)?mediafire\.com\//i.test(url)) {
        return reply(T(lang, 'invalid_url'));
    }

    await sendReaction(sock, remoteJid, msg.key, '⏳');

    try {
        // Panggil engine mfdl yang sudah kamu buat
        const res = await engine.run('mfdl', { url });

        // Susun pesan sukses
        const caption = T(lang, 'success', {
            name: res.name || 'Unknown',
            size: res.size || 'Unknown',
            filetype: res.filetype || '-',
            link: res.link
        });

        await reply(caption);
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error('[mfdl]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}