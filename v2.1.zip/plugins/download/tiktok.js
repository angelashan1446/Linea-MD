// plugins/download/tiktok.js
// Download video TikTok + opsi audio via reply "1" — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl, sendMedia, sendText } from '../../libx/whatsapp/sendmsg.js';
import { registerSession } from '../../libx/session_plugins.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegPath from 'ffmpeg-static';
import fs from 'fs';
import path from 'path';
import os from 'os';

ffmpeg.setFfmpegPath(ffmpegPath);

export const cmd = ['tt', 'tiktok'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 10;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Download video TikTok + opsi audio (ketik 1 untuk audio)';
export const description_ch = '下载 TikTok 视频 + 可选音频（输入 1 获取音频）';
export const description_uk = 'Download TikTok video + optional audio (type 1 for audio)';
export const description = description_id;

// ============================================================
// KONFIG
// ============================================================
const TIMEOUT_AUDIO = 5 * 60 * 1000; // 60 detik

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        invalid_link:
            '⚠️ Masukkan link TikTok!\nContoh: .tt https://vm.tiktok.com/...',
        header: `乂  *ᴀɴɢᴇʟs - ᴛɪᴋᴛᴏᴋ*`,
        label_title: 'Judul',
        label_info: 'Info',
        label_type: 'Tipe',
        type_value: 'Video',
        unknown_title: 'Judul tidak diketahui',
        audio_filename: 'audio',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,

        // Audio prompt
        audio_prompt:
            '🎵 *Minta Audio MP3?*\n\n' +
            'Ketik *1* untuk download audio dari video ini.\n' +
            '⏱️ _Batas waktu: 60 detik_',
        audio_invalid:
            '❌ Balasan tidak valid.\nKetik *1* untuk minta audio, atau abaikan pesan ini.',
        audio_processing: '⏳ Memproses audio...',
        audio_success: '🎵 *Audio MP3 berhasil dikirim!*',
        audio_timeout: '⏱️ Waktu habis. Kalau mau audio, kirim ulang link TikTok-nya.',
        audio_fail: '❌ Gagal membuat audio: {err}',
    },
    ch: {
        invalid_link:
            '⚠️ 请输入 TikTok 链接！\n示例：.tt https://vm.tiktok.com/...',
        header: `乂  *ᴀɴɢᴇʟs - ᴛɪᴋᴛᴏᴋ*`,
        label_title: '标题',
        label_info: '信息',
        label_type: '类型',
        type_value: '视频',
        unknown_title: '未知标题',
        audio_filename: '音频',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,

        audio_prompt:
            '🎵 *获取 MP3 音频？*\n\n' +
            '输入 *1* 下载此视频的音频。\n' +
            '⏱️ _时限：60 秒_',
        audio_invalid:
            '❌ 回复无效。\n输入 *1* 获取音频，或忽略此消息。',
        audio_processing: '⏳ 正在处理音频...',
        audio_success: '🎵 *MP3 音频已成功发送！*',
        audio_timeout: '⏱️ 时间到。如需音频，请重新发送 TikTok 链接。',
        audio_fail: '❌ 生成音频失败：{err}',
    },
    uk: {
        invalid_link:
            '⚠️ Enter a TikTok link!\nExample: .tt https://vm.tiktok.com/...',
        header: `乂  *ᴀɴɢᴇʟs - ᴛɪᴋᴛᴏᴋ*`,
        label_title: 'Title',
        label_info: 'Info',
        label_type: 'Type',
        type_value: 'Video',
        unknown_title: 'Unknown Title',
        audio_filename: 'audio',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,

        audio_prompt:
            '🎵 *Get MP3 audio?*\n\n' +
            'Type *1* to download the audio from this video.\n' +
            '⏱️ _Time limit: 60 seconds_',
        audio_invalid:
            '❌ Invalid reply.\nType *1* to get the audio, or ignore this message.',
        audio_processing: '⏳ Processing audio...',
        audio_success: '🎵 *MP3 audio sent successfully!*',
        audio_timeout: '⏱️ Time\'s up. To get the audio, send the TikTok link again.',
        audio_fail: '❌ Failed to generate audio: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HELPER: CONVERT MP4 → MP3
// ============================================================
async function convertVideoToMp3(videoUrl) {
    const tmpIn = path.join(os.tmpdir(), `tt_in_${Date.now()}.mp4`);
    const tmpOut = path.join(os.tmpdir(), `tt_out_${Date.now()}.mp3`);

    try {
        // Download video
        const vidRes = await fetch(videoUrl);
        const buffer = Buffer.from(await vidRes.arrayBuffer());
        fs.writeFileSync(tmpIn, buffer);

        // Convert
        await new Promise((resolve, reject) => {
            ffmpeg(tmpIn)
                .outputOptions([
                    '-vn',
                    '-ar', '44100',
                    '-ac', '2',
                    '-b:a', '128k',
                ])
                .toFormat('mp3')
                .on('end', resolve)
                .on('error', (err) => reject(new Error('FFmpeg: ' + err.message)))
                .save(tmpOut);
        });

        return fs.readFileSync(tmpOut);
    } finally {
        try { if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn); } catch {}
        try { if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut); } catch {}
    }
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text || !text.includes('tiktok.com')) {
        return reply(T(lang, 'invalid_link'));
    }

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        // 2. Panggil API
        const res = await engine.run('tiktok', { url: text });
        const title = res.title || T(lang, 'unknown_title');

        // 3. Caption
        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_title')}* :\n${title}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦  *${T(lang, 'label_type')}* : ${T(lang, 'type_value')}\n\n` +
            `${T(lang, 'footer')}`;

        // 4. Kirim video
        await sendMediaUrl(sock, remoteJid, res.video, {
            quoted: msg,
            caption,
            mimetype: 'video/mp4',
        });

        // 5. Tanya: mau audio? (dengan session)
        const audioPromptMsg = await reply(T(lang, 'audio_prompt'));
        if (!audioPromptMsg?.key?.id) return;

        // 6. Session: tunggu user reply "1" dalam 60 detik
        const onAudioReply = async (rCtx) => {
            const jawab = String(rCtx.text || '').trim();

            if (jawab !== '1') {
                // Bukan "1" → kasih warning, session tetap aktif
                return rCtx.reply(T(lang, 'audio_invalid'));
            }

            // User minta audio
            await sendReaction(sock, remoteJid, rCtx.msg.key, '🎵');
            await rCtx.reply(T(lang, 'audio_processing'));

            try {
                const audioBuffer = await convertVideoToMp3(res.video);

                const fileName =
                    `${(res.title || T(lang, 'audio_filename')).substring(0, 50)}.mp3`
                        .replace(/[^\w\s.-]/gi, '');

                await sendMedia(sock, remoteJid, {
                    buffer: audioBuffer,
                    mimetype: 'audio/mp4',
                    fileName,
                }, { quoted: msg });

                await sendReaction(sock, remoteJid, rCtx.msg.key, '✅');
            } catch (err) {
                console.error('[TIKTOK-AUDIO]', err.message);
                await rCtx.reply(T(lang, 'audio_fail', { err: err.message }));
                await sendReaction(sock, remoteJid, rCtx.msg.key, '❌');
            }
        };

        registerSession(
            audioPromptMsg.key.id,
            remoteJid,
            onAudioReply,
            { videoUrl: res.video, title: res.title || '', action: 'wait_audio' },
            {
                once: true,
                timeoutMs: TIMEOUT_AUDIO,
                senderJid: sender?.lid || (sender?.nomor ? `${sender.nomor}@s.whatsapp.net` : null),
                validateSender: true,
                tag: 'tiktok_audio',
                onExpire: async ({ chatJid }) => {
                    try {
                        await sendText(sock, chatJid, T(lang, 'audio_timeout'));
                    } catch (_) {}
                },
            }
        );

        // 7. Reaksi sukses awal (video terkirim)
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error(err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}