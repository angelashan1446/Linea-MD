// plugins/download/douyin.js
// Download video Douyin + opsi audio (ketik 1) — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendMediaUrl, sendMedia, sendText } from '../../libx/whatsapp/sendmsg.js';
import { registerSession } from '../../libx/session_plugins.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegPath from 'ffmpeg-static';
import fs from 'fs';
import path from 'path';
import os from 'os';

ffmpeg.setFfmpegPath(ffmpegPath);

export const cmd = ['douyin', 'dy'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 10;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Download video Douyin + opsi audio (ketik 1 untuk audio)';
export const description_ch = '下载抖音视频 + 可选音频（输入 1 获取音频）';
export const description_uk = 'Download Douyin video + optional audio (type 1 for audio)';
export const description = description_id;

// ============================================================
// KONFIG
// ============================================================
const TIMEOUT_AUDIO = 60 * 1000;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        invalid_link:
            '⚠️ Masukkan link Douyin!\n' +
            'Contoh:\n' +
            '• .douyin https://v.douyin.com/xxx/\n' +
            '• .douyin https://www.douyin.com/video/xxx',
        no_video: '❌ Tidak ada video yang ditemukan.',
        header: `乂  *ᴀɴɢᴇʟs - ᴅᴏᴜʏɪɴ*`,
        label_title: 'Judul',
        label_info: 'Info',
        label_platform: 'Platform',
        label_type: 'Tipe',
        type_video: 'Video',
        type_video_audio: 'Video + Audio',
        default_title: 'Douyin Video',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
        fail: '❌ Gagal: {err}',

        // Audio prompt
        audio_prompt:
            '🎵 *Minta Audio MP3?*\n\n' +
            'Ketik *1* untuk download audio dari video ini.\n' +
            '⏱️ _Batas waktu: 60 detik_',
        audio_invalid:
            '❌ Balasan tidak valid.\nKetik *1* untuk minta audio, atau abaikan pesan ini.',
        audio_processing: '⏳ Memproses audio...',
        audio_success: '🎵 *Audio MP3 berhasil dikirim!*',
        audio_timeout: '⏱️ Waktu habis. Kalau mau audio, kirim ulang link Douyin-nya.',
        audio_fail: '❌ Gagal membuat audio: {err}',
    },
    ch: {
        invalid_link:
            '⚠️ 请输入抖音链接！\n' +
            '示例：\n' +
            '• .douyin https://v.douyin.com/xxx/\n' +
            '• .douyin https://www.douyin.com/video/xxx',
        no_video: '❌ 未找到视频。',
        header: `乂  *ᴀɴɢᴇʟs - ᴅᴏᴜʏɪɴ*`,
        label_title: '标题',
        label_info: '信息',
        label_platform: '平台',
        label_type: '类型',
        type_video: '视频',
        type_video_audio: '视频 + 音频',
        default_title: '抖音视频',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
        fail: '❌ 失败：{err}',

        audio_prompt:
            '🎵 *获取 MP3 音频？*\n\n' +
            '输入 *1* 下载此视频的音频。\n' +
            '⏱️ _时限：60 秒_',
        audio_invalid:
            '❌ 回复无效。\n输入 *1* 获取音频，或忽略此消息。',
        audio_processing: '⏳ 正在处理音频...',
        audio_success: '🎵 *MP3 音频已成功发送！*',
        audio_timeout: '⏱️ 时间到。如需音频，请重新发送抖音链接。',
        audio_fail: '❌ 生成音频失败：{err}',
    },
    uk: {
        invalid_link:
            '⚠️ Enter a Douyin link!\n' +
            'Example:\n' +
            '• .douyin https://v.douyin.com/xxx/\n' +
            '• .douyin https://www.douyin.com/video/xxx',
        no_video: '❌ No video found.',
        header: `乂  *ᴀɴɢᴇʟs - ᴅᴏᴜʏɪɴ*`,
        label_title: 'Title',
        label_info: 'Info',
        label_platform: 'Platform',
        label_type: 'Type',
        type_video: 'Video',
        type_video_audio: 'Video + Audio',
        default_title: 'Douyin Video',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
        fail: '❌ Failed: {err}',

        audio_prompt:
            '🎵 *Get MP3 audio?*\n\n' +
            'Type *1* to download the audio from this video.\n' +
            '⏱️ _Time limit: 60 seconds_',
        audio_invalid:
            '❌ Invalid reply.\nType *1* to get the audio, or ignore this message.',
        audio_processing: '⏳ Processing audio...',
        audio_success: '🎵 *MP3 audio sent successfully!*',
        audio_timeout: '⏱️ Time\'s up. To get the audio, send the Douyin link again.',
        audio_fail: '❌ Failed to generate audio: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function extractUrl(item) {
    if (!item) return null;
    if (typeof item === 'string') return item;
    return item.url || null;
}

function guessMimetype(url, fallback = 'video/mp4') {
    if (!url) return fallback;
    const clean = url.split('?')[0].toLowerCase();
    if (clean.endsWith('.mp4') || clean.endsWith('.mov') || clean.endsWith('.webm')) return 'video/mp4';
    if (clean.endsWith('.mp3') || clean.endsWith('.m4a') || clean.endsWith('.ogg')) return 'audio/mpeg';
    if (clean.endsWith('.jpg') || clean.endsWith('.jpeg')) return 'image/jpeg';
    if (clean.endsWith('.png')) return 'image/png';
    return fallback;
}

// ============================================================
// HELPER: CONVERT VIDEO → MP3
// ============================================================
async function convertVideoToMp3(videoUrl) {
    const tmpIn = path.join(os.tmpdir(), `dy_in_${Date.now()}.mp4`);
    const tmpOut = path.join(os.tmpdir(), `dy_out_${Date.now()}.mp3`);

    try {
        const vidRes = await fetch(videoUrl);
        const buffer = Buffer.from(await vidRes.arrayBuffer());
        fs.writeFileSync(tmpIn, buffer);

        await new Promise((resolve, reject) => {
            ffmpeg(tmpIn)
                .outputOptions([
                    '-vn',
                    '-ar', '44100',
                    '-ac', '2',
                    '-b:a', '128k',
                ])
                .toFormat('mp3')
                .on('end', resolve)
                .on('error', (err) => reject(new Error('FFmpeg: ' + err.message)))
                .save(tmpOut);
        });

        return fs.readFileSync(tmpOut);
    } finally {
        try { if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn); } catch {}
        try { if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut); } catch {}
    }
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text || !text.includes('douyin.com')) {
        return reply(T(lang, 'invalid_link'));
    }

    // 1. Reaksi loading
    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        // 2. Panggil API
        const res = await engine.run('douyin', { url: text });

        const title = res.title || T(lang, 'default_title');
        const platform = res.platform || 'Douyin';
        const videoUrl = extractUrl(res.video);
        const audioUrl = extractUrl(res.audio);

        if (!videoUrl) {
            await sendReaction(sock, remoteJid, msg.key, '❌');
            return reply(T(lang, 'no_video'));
        }

        // 3. Caption
        const typeLabel = T(lang, 'type_video');

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_title')}* :\n${title}\n\n` +
            `*${T(lang, 'label_info')}* :\n` +
            `   ◦  *${T(lang, 'label_platform')}* : ${platform}\n` +
            `   ◦  *${T(lang, 'label_type')}*     : ${typeLabel}\n\n` +
            `${T(lang, 'footer')}`;

        // 4. Kirim video
        await sendMediaUrl(sock, remoteJid, videoUrl, {
            quoted: msg,
            caption,
            mimetype: guessMimetype(videoUrl, 'video/mp4'),
        });

        // ============================================================
        // 5. Audio: kalau API sudah kasih → kirim langsung
        //    Kalau tidak → prompt "ketik 1"
        // ============================================================
        if (audioUrl) {
            // API langsung kasih audio → kirim tanpa prompt
            try {
                await sendReaction(sock, remoteJid, msg.key, '🎵');
                await new Promise((r) => setTimeout(r, 1500));

                await sendMediaUrl(sock, remoteJid, audioUrl, {
                    quoted: msg,
                    mimetype: guessMimetype(audioUrl, 'audio/mpeg'),
                });
            } catch (err) {
                console.error('[DOUYIN] Gagal kirim audio:', err.message);
            }
        } else {
            // API tidak kasih audio → prompt interaktif
            const audioPromptMsg = await reply(T(lang, 'audio_prompt'));
            if (!audioPromptMsg?.key?.id) {
                await sendReaction(sock, remoteJid, msg.key, '✅');
                return;
            }

            const onAudioReply = async (rCtx) => {
                const jawab = String(rCtx.text || '').trim();

                if (jawab !== '1') {
                    return rCtx.reply(T(lang, 'audio_invalid'));
                }

                await sendReaction(sock, remoteJid, rCtx.msg.key, '🎵');
                await rCtx.reply(T(lang, 'audio_processing'));

                try {
                    const audioBuffer = await convertVideoToMp3(videoUrl);

                    const fileName =
                        `${(title || 'douyin_audio').substring(0, 50)}.mp3`
                            .replace(/[^\w\s.-]/gi, '');

                    await sendMedia(sock, remoteJid, {
                        buffer: audioBuffer,
                        mimetype: 'audio/mp4',
                        fileName,
                    }, { quoted: msg });

                    await sendReaction(sock, remoteJid, rCtx.msg.key, '✅');
                } catch (err) {
                    console.error('[DOUYIN-AUDIO]', err.message);
                    await rCtx.reply(T(lang, 'audio_fail', { err: err.message }));
                    await sendReaction(sock, remoteJid, rCtx.msg.key, '❌');
                }
            };

            registerSession(
                audioPromptMsg.key.id,
                remoteJid,
                onAudioReply,
                { videoUrl, title, action: 'wait_audio' },
                {
                    once: true,
                    timeoutMs: TIMEOUT_AUDIO,
                    senderJid: sender?.lid || (sender?.nomor ? `${sender.nomor}@s.whatsapp.net` : null),
                    validateSender: true,
                    tag: 'douyin_audio',
                    onExpire: async ({ chatJid }) => {
                        try {
                            await sendText(sock, chatJid, T(lang, 'audio_timeout'));
                        } catch (_) {}
                    },
                }
            );
        }

        // 6. Reaksi sukses
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error('[DOUYIN]', err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}