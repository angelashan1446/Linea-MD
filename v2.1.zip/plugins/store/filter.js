// plugins/tools/filter.js
// Filter grup — ADMIN ONLY.
//   .filter <alias>       → save (reply/caption)
//   .filter del <alias>   → hapus
//   .filter clear         → hapus semua
//   .filter stats         → statistik
//
// Member trigger via handler (ketik alias persis).
// Member lihat daftar via .filters (plugin terpisah).

import { sendReaction, sendText, sendMedia } from '../../libx/whatsapp/sendmsg.js';
import { getGroupLang } from '../../libx/grup_db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';
import {
  saveText,
  saveMedia,
  listItems,
  deleteItem,
  clearFilters,
  getFilterStats,
} from '../../libx/filters.js';

export const cmd = ['filter'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Kelola filter grup (admin): .filter <alias> / del / clear / stats';
export const description_ch = '管理群组过滤器（管理员）：.filter <别名> / del / clear / stats';
export const description_uk = 'Manage group filters (admin): .filter <alias> / del / clear / stats';
export const description = description_id;

// ============================================================
// KAMUS
// ============================================================
const TEXT = {
  id: {
    only_group: '❌ Command ini hanya bisa dipakai di grup.',
    only_admin: '❌ Command ini khusus *admin grup*.',

    usage:
      `乂  *ꜰɪʟᴛᴇʀ ɢʀᴜᴘ* (admin only)\n\n` +
      `📖 *Format:*\n` +
      `• .filter <alias> → simpan (reply/caption)\n` +
      `• .filter del <alias> → hapus\n` +
      `• .filter clear → hapus semua\n` +
      `• .filter stats → lihat penggunaan\n\n` +
      `*Contoh:*\n` +
      `• Reply gambar QR + \`.filter qr\`\n` +
      `• Reply teks rules + \`.filter rules\`\n\n` +
      `_Member tinggal ketik alias persis (contoh: "qr") di grup → bot auto kirim._\n` +
      `_Member bisa lihat daftar filter via \`.filters\`._`,

    save_no_content:
      '⚠️ *Tidak ada konten untuk disimpan.*\n\n' +
      'Reply sebuah pesan (teks/media) atau kirim dengan caption, lalu ketik:\n' +
      '• *.filter <alias>*\n\n' +
      'Contoh: reply gambar → *.filter qr*',
    save_success_text:
      '✅ *Filter Tersimpan!*\n\n' +
      '◦ Alias : `{alias}`\n' +
      '◦ Tipe  : Teks\n\n' +
      '_Member tinggal ketik `{alias}` di grup._',
    save_success_media:
      '✅ *Filter Tersimpan!*\n\n' +
      '◦ Alias : `{alias}`\n' +
      '◦ Tipe  : {type}\n\n' +
      '_Member tinggal ketik `{alias}` di grup._',
    save_fail: '❌ Gagal simpan: {reason}',

    del_success: '✅ Filter `{alias}` berhasil dihapus.',
    del_fail: '❌ Gagal hapus: {reason}',
    del_no_alias: '❌ Format: *.filter del <alias>*',

    clear_confirm:
      '⚠️ *Hapus semua filter grup?*\n\n' +
      'Total: {n} item\n\n' +
      'Reply *1* untuk konfirmasi.',
    clear_invalid: '❌ Reply *1* untuk konfirmasi.',
    clear_success: '✅ Semua filter dihapus ({n} item).',
    clear_empty: '📭 Belum ada filter.',

    stats_header: `乂  *sᴛᴀᴛs ꜰɪʟᴛᴇʀ*`,
    stats_total: 'Item terpakai',
    stats_free: 'Slot tersisa',
    stats_size: 'Total media',
    stats_hint: 'Maks: {max} item',

    footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    type_text: 'Teks',
    type_image: 'Gambar',
    type_video: 'Video',
    type_audio: 'Audio',
    type_sticker: 'Sticker',
    type_document: 'Dokumen',
  },
  ch: {
    only_group: '❌ 此命令仅可在群组中使用。',
    only_admin: '❌ 此命令仅限 *群组管理员*。',

    usage:
      `乂  *群组过滤器* (仅管理员)\n\n` +
      `📖 *格式：*\n` +
      `• .filter <别名> → 保存（回复/说明）\n` +
      `• .filter del <别名> → 删除\n` +
      `• .filter clear → 全部删除\n` +
      `• .filter stats → 使用情况\n\n` +
      `*示例：*\n` +
      `• 回复 QR 图片 + \`.filter qr\`\n` +
      `• 回复规则文本 + \`.filter rules\`\n\n` +
      `_成员在群组中输入别名原样（例如 "qr"）→ 机器人自动发送。_\n` +
      `_成员可用 \`.filters\` 查看列表。_`,

    save_no_content:
      '⚠️ *没有可保存的内容。*\n\n' +
      '请回复一条消息（文本/媒体）或使用说明发送，然后输入：\n' +
      '• *.filter <别名>*\n\n' +
      '示例：回复图片 → *.filter qr*',
    save_success_text:
      '✅ *过滤器已保存！*\n\n' +
      '◦ 别名 : `{alias}`\n' +
      '◦ 类型 : 文本\n\n' +
      '_成员只需在群组中输入 `{alias}`。_',
    save_success_media:
      '✅ *过滤器已保存！*\n\n' +
      '◦ 别名 : `{alias}`\n' +
      '◦ 类型 : {type}\n\n' +
      '_成员只需在群组中输入 `{alias}`。_',
    save_fail: '❌ 保存失败：{reason}',

    del_success: '✅ 过滤器 `{alias}` 已删除。',
    del_fail: '❌ 删除失败：{reason}',
    del_no_alias: '❌ 格式：*.filter del <别名>*',

    clear_confirm:
      '⚠️ *删除所有群组过滤器？*\n\n' +
      '总计：{n} 项\n\n' +
      '回复 *1* 确认。',
    clear_invalid: '❌ 回复 *1* 确认。',
    clear_success: '✅ 已删除所有过滤器（{n} 项）。',
    clear_empty: '📭 还没有过滤器。',

    stats_header: `乂  *过滤器统计*`,
    stats_total: '已用项目',
    stats_free: '剩余槽位',
    stats_size: '媒体总大小',
    stats_hint: '最大：{max} 项',

    footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    type_text: '文本',
    type_image: '图片',
    type_video: '视频',
    type_audio: '音频',
    type_sticker: '贴纸',
    type_document: '文档',
  },
  uk: {
    only_group: '❌ This command can only be used in a group.',
    only_admin: '❌ This command is for *group admins* only.',

    usage:
      `乂  *ɢʀᴏᴜᴘ ꜰɪʟᴛᴇʀ* (admin only)\n\n` +
      `📖 *Format:*\n` +
      `• .filter <alias> → save (reply/caption)\n` +
      `• .filter del <alias> → delete\n` +
      `• .filter clear → delete all\n` +
      `• .filter stats → usage info\n\n` +
      `*Example:*\n` +
      `• Reply QR image + \`.filter qr\`\n` +
      `• Reply rules text + \`.filter rules\`\n\n` +
      `_Members just type the alias verbatim (e.g. "qr") in group → bot auto-sends._\n` +
      `_Members can view the list via \`.filters\`._`,

    save_no_content:
      '⚠️ *Nothing to save.*\n\n' +
      'Reply to a message (text/media) or send with caption, then type:\n' +
      '• *.filter <alias>*\n\n' +
      'Example: reply image → *.filter qr*',
    save_success_text:
      '✅ *Filter Saved!*\n\n' +
      '◦ Alias : `{alias}`\n' +
      '◦ Type  : Text\n\n' +
      '_Members just type `{alias}` in group._',
    save_success_media:
      '✅ *Filter Saved!*\n\n' +
      '◦ Alias : `{alias}`\n' +
      '◦ Type  : {type}\n\n' +
      '_Members just type `{alias}` in group._',
    save_fail: '❌ Failed to save: {reason}',

    del_success: '✅ Filter `{alias}` deleted.',
    del_fail: '❌ Failed to delete: {reason}',
    del_no_alias: '❌ Format: *.filter del <alias>*',

    clear_confirm:
      '⚠️ *Delete all group filters?*\n\n' +
      'Total: {n} item(s)\n\n' +
      'Reply *1* to confirm.',
    clear_invalid: '❌ Reply *1* to confirm.',
    clear_success: '✅ All filters deleted ({n} item(s)).',
    clear_empty: '📭 No filters yet.',

    stats_header: `乂  *ꜰɪʟᴛᴇʀ ꜱᴛᴀᴛꜱ*`,
    stats_total: 'Used items',
    stats_free: 'Free slots',
    stats_size: 'Total media',
    stats_hint: 'Max: {max} item(s)',

    footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    type_text: 'Text',
    type_image: 'Image',
    type_video: 'Video',
    type_audio: 'Audio',
    type_sticker: 'Sticker',
    type_document: 'Document',
  },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
  const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
  let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
  for (const [k, v] of Object.entries(vars)) {
    str = str.replaceAll(`{${k}}`, String(v));
  }
  return str;
}

function resolveGroupLang(groupId) {
  try {
    const gl = getGroupLang(groupId);
    if (isValidLang(gl)) return gl;
  } catch {}
  return DEFAULT_LANG;
}

function typeLabel(lang, type) {
  if (type === 'image') return T(lang, 'type_image');
  if (type === 'video') return T(lang, 'type_video');
  if (type === 'audio') return T(lang, 'type_audio');
  if (type === 'sticker') return T(lang, 'type_sticker');
  if (type === 'document') return T(lang, 'type_document');
  return T(lang, 'type_text');
}

async function isGroupAdmin(sock, remoteJid, sender) {
  try {
    const metadata = await sock.groupMetadata(remoteJid);
    const p = metadata.participants.find(x =>
      x.id === sender.rawJid ||
      x.id === sender.lid ||
      x.phoneNumber === sender.nomor
    );
    return p?.admin === 'admin' || p?.admin === 'superadmin';
  } catch {
    return false;
  }
}

// ============================================================
// EKSTRAK MEDIA DARI PESAN
// ============================================================
async function extractFromMessage(sock, msg) {
  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

  const quotedMedia =
    quoted?.imageMessage ||
    quoted?.videoMessage ||
    quoted?.audioMessage ||
    quoted?.stickerMessage ||
    quoted?.documentMessage ||
    quoted?.documentWithCaptionMessage?.message?.documentMessage;

  const directMedia =
    msg.message?.imageMessage ||
    msg.message?.videoMessage ||
    msg.message?.audioMessage ||
    msg.message?.stickerMessage ||
    msg.message?.documentMessage;

  const media = quotedMedia || directMedia;

  const quotedText =
    quoted?.conversation ||
    quoted?.extendedTextMessage?.text ||
    null;

  const directText =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    null;

  if (!media) {
    return { hasMedia: false, text: quotedText || directText || null };
  }

  const isSticker = !!(quoted?.stickerMessage || msg.message?.stickerMessage);
  const isImage = !!(quoted?.imageMessage || msg.message?.imageMessage);
  const isVideo = !!(quoted?.videoMessage || msg.message?.videoMessage);
  const isAudio = !!(quoted?.audioMessage || msg.message?.audioMessage);
  const isDoc = !!(
    quoted?.documentMessage ||
    quoted?.documentWithCaptionMessage?.message?.documentMessage ||
    msg.message?.documentMessage
  );

  let mimetype = media.mimetype || 'application/octet-stream';
  let type = 'document';

  if (isSticker) { mimetype = 'image/webp'; type = 'sticker'; }
  else if (isImage) { mimetype = media.mimetype || 'image/jpeg'; type = 'image'; }
  else if (isVideo) { mimetype = media.mimetype || 'video/mp4'; type = 'video'; }
  else if (isAudio) { mimetype = media.mimetype || 'audio/mpeg'; type = 'audio'; }
  else if (isDoc) { mimetype = media.mimetype || 'application/octet-stream'; type = 'document'; }

  let buffer = null;
  try {
    buffer = await sock.downloadMediaMessage(msg);
  } catch (err) {
    return { hasMedia: false, error: err.message };
  }

  const mediaMeta = {
    isSticker, isImage, isVideo, isAudio, isDocument: isDoc,
    ptt: !!media.ptt,
    gifPlayback: !!media.gifPlayback,
    viewOnce: !!media.viewOnce,
    width: media.width || null,
    height: media.height || null,
    seconds: media.seconds || null,
    fileLength: media.fileLength || null,
    mimetype: media.mimetype || null,
  };

  return {
    hasMedia: true,
    buffer,
    mimetype,
    fileName: media.fileName || null,
    caption: media.caption || null,
    mediaMeta,
    type,
  };
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
  const { sock, msg, reply, remoteJid, isGroup, args, sender } = ctx;

  if (!isGroup) return reply(T('uk', 'only_group'));

  const groupId = remoteJid.split('@')[0];
  const lang = resolveGroupLang(groupId);

  // Admin only
  const isAdmin = await isGroupAdmin(sock, remoteJid, sender);
  if (!isAdmin) {
    await sendReaction(sock, remoteJid, msg.key, '❌');
    return reply(T(lang, 'only_admin'));
  }

  const subcmd = (args[0] || '').toLowerCase();
  const argRest = args.slice(1).join(' ').trim();
  const fullAlias = args.join(' ').trim();

  // ============================================================
  // Tanpa argumen → usage
  // ============================================================
  if (!subcmd) {
    await sendReaction(sock, remoteJid, msg.key, '⚙️');
    return reply(T(lang, 'usage') + `\n\n${T(lang, 'footer')}`);
  }

  // ============================================================
  // DEL
  // ============================================================
  if (subcmd === 'del') {
    if (!argRest) return reply(T(lang, 'del_no_alias'));

    await sendReaction(sock, remoteJid, msg.key, '🗑️');

    const res = deleteItem(groupId, argRest);
    if (!res.ok) {
      await sendReaction(sock, remoteJid, msg.key, '❌');
      return reply(T(lang, 'del_fail', { reason: res.reason }));
    }

    await sendReaction(sock, remoteJid, msg.key, '✅');
    return reply(T(lang, 'del_success', { alias: argRest }));
  }

  // ============================================================
  // CLEAR
  // ============================================================
  if (subcmd === 'clear') {
    const items = listItems(groupId);
    if (items.length === 0) return reply(T(lang, 'clear_empty'));

    await sendReaction(sock, remoteJid, msg.key, '⚠️');

    const confirmMsg = await reply(T(lang, 'clear_confirm', { n: items.length }));
    if (!confirmMsg?.key?.id) return;

    const { registerSession } = await import('../../libx/session_plugins.js');

    const onConfirm = async (rCtx) => {
      const jawab = String(rCtx.text || '').trim();
      if (jawab !== '1') return rCtx.reply(T(lang, 'clear_invalid'));

      const res = clearFilters(groupId);
      await sendReaction(sock, remoteJid, rCtx.msg.key, '✅');
      return rCtx.reply(T(lang, 'clear_success', { n: res.count }));
    };

    registerSession(
      confirmMsg.key.id,
      remoteJid,
      onConfirm,
      { step: 'filter_clear' },
      {
        once: true,
        timeoutMs: 60 * 1000,
        senderJid: sender?.lid || (sender?.nomor ? `${sender.nomor}@s.whatsapp.net` : null),
        validateSender: true,
        tag: 'filter_clear',
      }
    );
    return;
  }

  // ============================================================
  // STATS
  // ============================================================
  if (subcmd === 'stats') {
    await sendReaction(sock, remoteJid, msg.key, '📊');

    const s = getFilterStats(groupId);

    const out =
      `${T(lang, 'stats_header')}\n\n` +
      `◦ ${T(lang, 'stats_total')} : *${s.total}* / ${s.max}\n` +
      `◦ ${T(lang, 'stats_free')}  : *${s.free}*\n` +
      `◦ ${T(lang, 'stats_size')}  : *${s.totalSizeMb} MB*\n\n` +
      `_${T(lang, 'stats_hint', { max: s.max })}_\n\n` +
      T(lang, 'footer');

    await sendReaction(sock, remoteJid, msg.key, '✅');
    return reply(out);
  }

  // ============================================================
  // SAVE (default — argumen apapun = alias)
  // ============================================================
  // .filter qr
  // .filter list produk
  // .filter harga promo
  if (!fullAlias) {
    return reply(T(lang, 'usage'));
  }

  await sendReaction(sock, remoteJid, msg.key, '📥');

  const alias = fullAlias;
  const data = await extractFromMessage(sock, msg);
  const creator = sender.nomor;

  if (data.hasMedia && data.buffer) {
    const res = saveMedia(groupId, data.buffer, {
      mimetype: data.mimetype,
      fileName: data.fileName,
      caption: data.caption || null,
      alias,
      mediaMeta: data.mediaMeta,
      creator,
    });

    if (!res.ok) {
      await sendReaction(sock, remoteJid, msg.key, '❌');
      return reply(T(lang, 'save_fail', { reason: res.reason }));
    }

    await sendReaction(sock, remoteJid, msg.key, '✅');
    return reply(
      T(lang, 'save_success_media', {
        alias: res.item.alias,
        type: typeLabel(lang, res.item.type),
      }) + `\n\n${T(lang, 'footer')}`
    );
  }

  const textContent = data.text;
  if (!textContent) {
    await sendReaction(sock, remoteJid, msg.key, '❌');
    return reply(T(lang, 'save_no_content'));
  }

  const res = saveText(groupId, textContent, alias, creator);
  if (!res.ok) {
    await sendReaction(sock, remoteJid, msg.key, '❌');
    return reply(T(lang, 'save_fail', { reason: res.reason }));
  }

  await sendReaction(sock, remoteJid, msg.key, '✅');
  return reply(
    T(lang, 'save_success_text', { alias: res.item.alias }) + `\n\n${T(lang, 'footer')}`
  );
}