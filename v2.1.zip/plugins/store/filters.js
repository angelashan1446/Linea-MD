// plugins/tools/filters.js
// Lihat daftar filter grup (SEMUA MEMBER).

import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { getGroupLang } from '../../libx/grup_db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';
import { listItems, getFilterStats } from '../../libx/filters.js';

export const cmd = ['filters', 'listfilter', 'daftarfilter'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Lihat daftar filter grup';
export const description_ch = '查看群组过滤器列表';
export const description_uk = 'View group filter list';
export const description = description_id;

// ============================================================
// KAMUS
// ============================================================
const TEXT = {
  id: {
    only_group: '❌ Command ini hanya bisa dipakai di grup.',
    header: `乂  *ʟɪsᴛ ꜰɪʟᴛᴇʀ ɢʀᴜᴘ*`,
    empty: '📭 Belum ada filter di grup ini.',
    intro: 'Ini adalah list filter grup:',
    total: 'Total: {n} filter',
    hint: '_Ketik alias persis (contoh: `qr`) di grup → bot auto kirim._',
    footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
  },
  ch: {
    only_group: '❌ 此命令仅可在群组中使用。',
    header: `乂  *群组过滤器列表*`,
    empty: '📭 本群组还没有过滤器。',
    intro: '这是群组过滤器列表：',
    total: '总计：{n} 个过滤器',
    hint: '_在群组中输入别名原样（例如 `qr`）→ 机器人自动发送。_',
    footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
  },
  uk: {
    only_group: '❌ This command can only be used in a group.',
    header: `乂  *ɢʀᴏᴜᴘ ꜰɪʟᴛᴇʀ ʟɪꜱᴛ*`,
    empty: '📭 No filters yet in this group.',
    intro: 'This is the group filter list:',
    total: 'Total: {n} filter(s)',
    hint: '_Type the alias verbatim (e.g. `qr`) in group → bot auto-sends._',
    footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
  },
};

function T(lang, key, vars = {}) {
  const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
  let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
  for (const [k, v] of Object.entries(vars)) {
    str = str.replaceAll(`{${k}}`, String(v));
  }
  return str;
}

function resolveGroupLang(groupId) {
  try {
    const gl = getGroupLang(groupId);
    if (isValidLang(gl)) return gl;
  } catch {}
  return DEFAULT_LANG;
}

// ============================================================
// HANDLER
// ============================================================
export default async function handler(ctx) {
  const { sock, msg, reply, remoteJid, isGroup } = ctx;

  if (!isGroup) return reply(T('uk', 'only_group'));

  const groupId = remoteJid.split('@')[0];
  const lang = resolveGroupLang(groupId);

  await sendReaction(sock, remoteJid, msg.key, '📋');

  const items = listItems(groupId);

  if (items.length === 0) {
    return reply(T(lang, 'empty'));
  }

  const stats = getFilterStats(groupId);

  let out =
    `${T(lang, 'header')}\n\n` +
    `${T(lang, 'intro')}\n\n`;

  items.forEach((item) => {
    out += `• \`${item.alias}\`\n`;
  });

  out += `\n📊 *${T(lang, 'total', { n: stats.total })}*\n\n`;
  out += `${T(lang, 'hint')}\n\n`;
  out += `${T(lang, 'footer')}`;

  await sendReaction(sock, remoteJid, msg.key, '✅');
  return reply(out);
}