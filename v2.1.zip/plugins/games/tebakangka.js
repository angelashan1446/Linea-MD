// plugins/game/tebakangka.js
// Game: bot pilih angka random 1-100, user tebak dengan hint hot/cold.
// Reward berdasarkan jumlah percobaan (makin sedikit, makin besar hadiahnya).

import { registerSession } from '../../libx/session_plugins.js';

export const cmd = ['tebakangka', 'ta', 'angka'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 1;

// ============================================================
// KONFIGURASI GAME
// ============================================================
const MIN_ANGKA = 1;
const MAX_ANGKA = 100;
const TIMEOUT_MS = 3 * 60 * 1000; // 3 menit total
const MAKS_PERCOBAAN = 7;         // lebih dari ini = kalah

// Hadiah berdasarkan percobaan
// (makin sedikit percobaan = makin besar hadiah)
const HADIAH_BY_PERCOBAAN = {
  1: 200, // jackpot
  2: 150,
  3: 100,
  4: 75,
  5: 50,
  6: 30,
  7: 15,
};

const DENDA_KALAH = -20;

// ============================================================
// UTIL
// ============================================================
function randomAngka() {
  return Math.floor(Math.random() * (MAX_ANGKA - MIN_ANGKA + 1)) + MIN_ANGKA;
}

/**
 * Hint jarak: HOT (<=5), HANGAT (<=10), DINGIN (<=20), BEKU (>20)
 */
function hintJarak(selisih) {
  if (selisih === 0) return { label: '🎯 TEPAT', icon: '🎯' };
  if (selisih <= 3) return { label: '🔥🔥 SANGAT PANAS', icon: '🔥' };
  if (selisih <= 7) return { label: '🔥 PANAS', icon: '🔥' };
  if (selisih <= 15) return { label: '🌤️ HANGAT', icon: '🌤️' };
  if (selisih <= 30) return { label: '❄️ DINGIN', icon: '❄️' };
  return { label: '🧊 SANGAT DINGIN', icon: '🧊' };
}

function hintArah(tebakan, target) {
  if (tebakan === target) return '✅ Benar!';
  return tebakan < target ? '⬆️ Terlalu KECIL, coba lebih BESAR' : '⬇️ Terlalu BESAR, coba lebih KECIL';
}

// ============================================================
// HANDLER
// ============================================================
export default async function handler(ctx) {
  const { reply, remoteJid, sender } = ctx;

  const target = randomAngka();

  const teksAwal =
    `🎲 *TEBAK ANGKA*\n\n` +
    `Aku sudah pilih angka rahasia antara *${MIN_ANGKA}* sampai *${MAX_ANGKA}*.\n` +
    `Tebak dalam *${MAKS_PERCOBAAN}x percobaan*!\n\n` +
    `📌 Reply pesan ini dengan angka tebakanmu.\n\n` +
    `💰 *Hadiah:*\n` +
    `   • 1x percobaan → +${HADIAH_BY_PERCOBAAN[1]} poin 🏆\n` +
    `   • 2x percobaan → +${HADIAH_BY_PERCOBAAN[2]} poin\n` +
    `   • 3x percobaan → +${HADIAH_BY_PERCOBAAN[3]} poin\n` +
    `   • 4x percobaan → +${HADIAH_BY_PERCOBAAN[4]} poin\n` +
    `   • 5x percobaan → +${HADIAH_BY_PERCOBAAN[5]} poin\n` +
    `   • 6x percobaan → +${HADIAH_BY_PERCOBAAN[6]} poin\n` +
    `   • 7x percobaan → +${HADIAH_BY_PERCOBAAN[7]} poin\n` +
    `   • Gagal          → ${DENDA_KALAH} poin\n\n` +
    `⏱️ _Batas waktu: 3 menit_`;

  const sentMsg = await reply(teksAwal);
  if (!sentMsg?.key?.id) return;

  // ============================================================
  // HANDLER JAWABAN
  // ============================================================
  const handleTebakan = async (replyCtx) => {
    const meta = replyCtx.meta;

    // Parse angka
    const tebakan = parseInt(replyCtx.text.trim(), 10);

    // Validasi input
    if (isNaN(tebakan)) {
      return replyCtx.reply(
        `❌ Harus berupa *angka*, bukan "${replyCtx.text}".\n\n` +
        `📌 Reply pesan ini dengan angka *${MIN_ANGKA}-${MAX_ANGKA}*.`
      );
    }

    if (tebakan < MIN_ANGKA || tebakan > MAX_ANGKA) {
      return replyCtx.reply(
        `❌ Angka harus antara *${MIN_ANGKA}* dan *${MAX_ANGKA}*.\n\n` +
        `📌 Reply pesan ini dengan angka *${MIN_ANGKA}-${MAX_ANGKA}*.`
      );
    }

    // Cek duplikat
    if (meta.tebakanList.includes(tebakan)) {
      return replyCtx.reply(
        `⚠️ Kamu sudah pernah menebak *${tebakan}*.\n` +
        `Coba angka lain!\n\n` +
        `📌 Reply pesan ini dengan angka *${MIN_ANGKA}-${MAX_ANGKA}*.`
      );
    }

    // Simpan tebakan
    meta.tebakanList.push(tebakan);
    meta.percobaan += 1;

    const selisih = Math.abs(tebakan - meta.target);
    const hint = hintJarak(selisih);
    const arah = hintArah(tebakan, meta.target);

    // ===== BENAR =====
    if (tebakan === meta.target) {
      const hadiah = HADIAH_BY_PERCOBAAN[meta.percobaan] || 0;
      meta.poin = hadiah;
      return replyCtx.reply(
        `🎉 *BENAR!* Angkanya adalah *${meta.target}*\n\n` +
        `📊 Percobaan: *${meta.percobaan}x*\n` +
        `💰 Poin didapat: *+${hadiah}*\n\n` +
        `📝 Riwayat tebakan:\n` +
        meta.tebakanList.map((n, i) => `   ${i + 1}. ${n}`).join('\n') +
        `\n\n_Hebat! Main lagi? Ketik .tebakangka_`
      );
    }

    // ===== HABIS PERCOBAAN =====
    if (meta.percobaan >= MAKS_PERCOBAAN) {
      meta.poin = DENDA_KALAH;
      return replyCtx.reply(
        `💀 *GAME OVER — Percobaan habis!*\n\n` +
        `Angka yang benar: *${meta.target}*\n` +
        `📉 Poin: *${DENDA_KALAH}*\n\n` +
        `📝 Riwayat tebakan:\n` +
        meta.tebakanList.map((n, i) => `   ${i + 1}. ${n}`).join('\n') +
        `\n\n_Coba lagi dengan .tebakangka_`
      );
    }

    // ===== LANJUT (salah tapi masih ada kesempatan) =====
    const sisa = MAKS_PERCOBAAN - meta.percobaan;
    const hadiahMaks = HADIAH_BY_PERCOBAAN[meta.percobaan + 1] || 0;

    const newMsg = await replyCtx.reply(
      `${hint.icon} *${hint.label}*\n\n` +
      `Tebakanmu: *${tebakan}*\n` +
      `${arah}\n\n` +
      `📊 Percobaan: ${meta.percobaan}/${MAKS_PERCOBAAN}\n` +
      `🎯 Sisa: *${sisa}x*\n` +
      `💰 Hadiah maksimal berikutnya: +${hadiahMaks}\n\n` +
      `📝 Riwayat: ${meta.tebakanList.join(', ')}\n\n` +
      `📌 Reply pesan ini dengan angka *${MIN_ANGKA}-${MAX_ANGKA}*.`
    );

    // Recursive register
    if (newMsg?.key?.id) {
      registerSession(
        newMsg.key.id,
        remoteJid,
        handleTebakan,
        { ...meta, expireAt: Date.now() + TIMEOUT_MS },
        {
          once: true,
          timeoutMs: TIMEOUT_MS,
          senderJid: sender?.lid || (sender?.nomor ? sender.nomor + '@s.whatsapp.net' : null),
          validateSender: false,
          tag: 'tebakangka',
        }
      );
    }
  };

  // Register session pertama
  registerSession(
    sentMsg.key.id,
    remoteJid,
    handleTebakan,
    {
      target,
      tebakanList: [],
      percobaan: 0,
      poin: 0,
      expireAt: Date.now() + TIMEOUT_MS,
    },
    {
      once: true,
      timeoutMs: TIMEOUT_MS,
      senderJid: sender?.lid || (sender?.nomor ? sender.nomor + '@s.whatsapp.net' : null),
      validateSender: false,
      tag: 'tebakangka',
    }
  );
}