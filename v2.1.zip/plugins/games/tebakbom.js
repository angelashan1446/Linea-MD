// plugins/game/tebakbom.js
import { registerSession } from '../../libx/session_plugins.js';

export const cmd = ['tebakbom', 'bom'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 1;

// ============================================================
// KONFIGURASI GAME
// ============================================================
const TOTAL_KOTAK = 9;
const JUMLAH_BOM = 3;
const HADIAH_AMAN = 20;
const HADIAH_MENANG = 100;
const DENDA_BOM = -50;

/**
 * Render papan 3x3.
 * Kotak tertutup = angka (1-9), biar user tahu harus ketik apa.
 * Kotak terbuka = ✅ (aman) / 💥 (bom).
 * Saat game over, semua bom ditampilkan (💣).
 */
function renderPapan(opened, bomPositions, gameOver = false) {
    let papan = '';
    for (let i = 1; i <= TOTAL_KOTAK; i++) {
        let cell;
        if (opened.includes(i)) {
            cell = bomPositions.includes(i) ? '💥' : '✅';
        } else if (gameOver && bomPositions.includes(i)) {
            cell = '💣';
        } else {
            // Kotak tertutup → tampilkan angka
            cell = `${i}️⃣`;
        }
        papan += `${cell} `;
        if (i % 3 === 0) papan += '\n';
    }
    return papan;
}

function isWin(opened, bomPositions) {
    const totalAman = TOTAL_KOTAK - JUMLAH_BOM;
    const openedAman = opened.filter((n) => !bomPositions.includes(n)).length;
    return openedAman === totalAman;
}

export default async function handler(ctx) {
    const { reply, remoteJid } = ctx;

    // 1. Generate posisi bom random
    const bomPositions = [];
    while (bomPositions.length < JUMLAH_BOM) {
        const pos = Math.floor(Math.random() * TOTAL_KOTAK) + 1;
        if (!bomPositions.includes(pos)) bomPositions.push(pos);
    }

    // 2. Kirim papan awal
    const papanAwal = renderPapan([], bomPositions);

    const soal = `💣 *TEBAK BOM*\n\n` +
        `Ada *${JUMLAH_BOM} bom* tersembunyi di antara ${TOTAL_KOTAK} kotak.\n` +
        `Buka semua kotak aman untuk menang!\n\n` +
        `${papanAwal}\n` +
        `📌 Reply pesan ini dengan angka *1-${TOTAL_KOTAK}*\n\n` +
        `💰 Aman: +${HADIAH_AMAN} poin\n` +
        `💥 Bom : ${DENDA_BOM} poin\n` +
        `🏆 Menang: +${HADIAH_MENANG} bonus\n\n` +
        `⏱️ _Batas waktu: 10 menit_`;

    const sentMsg = await reply(soal);
    if (!sentMsg?.key?.id) return;

    // ============================================================
    // SESSION HANDLER (Recursive — bisa dipanggil berkali-kali)
    // ============================================================
    const handlePlayerReply = async (replyCtx) => {
        const pilihan = parseInt(replyCtx.text.trim());
        const meta = replyCtx.meta;
        const { opened, bomPositions, totalPoin } = meta;

        // Validasi input
        if (isNaN(pilihan) || pilihan < 1 || pilihan > TOTAL_KOTAK) {
            return replyCtx.reply(
                `❌ Pilihan tidak valid.\n` +
                `Ketik angka *1-${TOTAL_KOTAK}* saja.\n\n` +
                `${renderPapan(opened, bomPositions)}`
            );
        }

        // Sudah dibuka?
        if (opened.includes(pilihan)) {
            return replyCtx.reply(
                `⚠️ Kotak *[${pilihan}]* sudah kamu buka.\n` +
                `Pilih kotak lain!\n\n` +
                `${renderPapan(opened, bomPositions)}`
            );
        }

        // Buka kotak
        opened.push(pilihan);
        const kenaBom = bomPositions.includes(pilihan);

        // ===== KENA BOM → GAME OVER =====
        if (kenaBom) {
            meta.totalPoin += DENDA_BOM;
            const papanFinal = renderPapan(opened, bomPositions, true);
            await replyCtx.reply(
                `💥 *BOOM! GAME OVER*\n\n` +
                `Kamu memilih kotak *[${pilihan}]*.\n` +
                `Itu BOM! 💀\n\n` +
                `${papanFinal}\n` +
                `📉 Poin akhir: *${meta.totalPoin}*\n` +
                `📦 Kotak terbuka: ${opened.length}/${TOTAL_KOTAK}\n\n` +
                `_Coba lagi dengan .bom_`
            );
            return;
        }

        // Kotak aman
        meta.totalPoin += HADIAH_AMAN;

        // ===== MENANG =====
        if (isWin(opened, bomPositions)) {
            meta.totalPoin += HADIAH_MENANG;
            const papanFinal = renderPapan(opened, bomPositions, true);
            await replyCtx.reply(
                `🏆 *MENANG!* 🎉\n\n` +
                `Kamu berhasil membuka SEMUA kotak aman!\n\n` +
                `${papanFinal}\n` +
                `💰 Poin akhir: *${meta.totalPoin}*\n` +
                `✅ Kotak aman terbuka: ${opened.length}/${TOTAL_KOTAK}\n` +
                `🏆 Bonus menang: +${HADIAH_MENANG}\n\n` +
                `_Hebat! Main lagi? Ketik .bom_`
            );
            return;
        }

        // ===== LANJUT (belum selesai) =====
        const papanUpdate = renderPapan(opened, bomPositions);
        const sisaAman = (TOTAL_KOTAK - JUMLAH_BOM) - opened.filter((n) => !bomPositions.includes(n)).length;

        const newMsg = await replyCtx.reply(
            `✅ *AMAN!* Kotak [${pilihan}] kosong.\n\n` +
            `${papanUpdate}\n` +
            `💰 Poin sementara: *${meta.totalPoin}*\n` +
            `🎯 Sisa kotak aman: *${sisaAman}*\n\n` +
            `📌 Reply pesan ini dengan angka *1-${TOTAL_KOTAK}* untuk lanjut.\n` +
            `⏱️ _Sisa waktu: 10 menit_`
        );

        // Register ulang session (recursive)
        if (newMsg?.key?.id) {
            registerSession(
                newMsg.key.id,
                remoteJid,
                handlePlayerReply,
                meta // state yang sudah diupdate
            );
        }
    };

    // Register session pertama
    registerSession(
        sentMsg.key.id,
        remoteJid,
        handlePlayerReply,
        {
            opened: [],
            bomPositions,
            totalPoin: 0,
            startedAt: Date.now(),
        }
    );
}