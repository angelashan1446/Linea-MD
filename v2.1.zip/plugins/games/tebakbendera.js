// plugins/game/tebakbendera.js
// Game: user menebak nama negara dari emoji bendera.
// Hint: jumlah huruf + reveal bertahap setiap salah.

import { registerSession } from '../../libx/session_plugins.js';

export const cmd = ['tebakbendera', 'tb', 'bendera'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 1;

// ============================================================
// KONFIGURASI GAME
// ============================================================
const TIMEOUT_MS = 90 * 1000;
const HADIAH_BENAR = 60;
const DENDA_SALAH = -5;
const MAKS_SALAH = 3;

// ============================================================
// BANK SOAL (emoji → negara)
// Pakai nama negara versi Indonesia (tanpa spasi berlebih).
// ============================================================
const BANK_SOAL = [
  { kode: '🇮🇩', kata: 'INDONESIA',     alias: ['INDONESIA', 'NKRI'] },
  { kode: '🇲🇾', kata: 'MALAYSIA',      alias: ['MALAYSIA'] },
  { kode: '🇸🇬', kata: 'SINGAPURA',     alias: ['SINGAPURA', 'SINGAPORE'] },
  { kode: '🇹🇭', kata: 'THAILAND',      alias: ['THAILAND'] },
  { kode: '🇵🇭', kata: 'FILIPINA',      alias: ['FILIPINA', 'PHILIPPINES'] },
  { kode: '🇻🇳', kata: 'VIETNAM',       alias: ['VIETNAM'] },
  { kode: '🇯🇵', kata: 'JEPANG',        alias: ['JEPANG', 'JAPAN'] },
  { kode: '🇰🇷', kata: 'KOREA',         alias: ['KOREA', 'KOREASELATAN', 'SOUTHKOREA'] },
  { kode: '🇨🇳', kata: 'CHINA',         alias: ['CHINA', 'CINA', 'TIONGKOK'] },
  { kode: '🇮🇳', kata: 'INDIA',         alias: ['INDIA'] },
  { kode: '🇸🇦', kata: 'ARABSAUDI',     alias: ['ARABSAUDI', 'SAUDIARABIA', 'SAUDI'] },
  { kode: '🇦🇪', kata: 'UNIEMIRATARAB', alias: ['UNIEMIRATARAB', 'UAE', 'EMIRAT'] },
  { kode: '🇬🇧', kata: 'INGGRIS',       alias: ['INGGRIS', 'UK', 'BRITANIA', 'ENGLAND'] },
  { kode: '🇫🇷', kata: 'PRANCIS',       alias: ['PRANCIS', 'FRANCE'] },
  { kode: '🇩🇪', kata: 'JERMAN',        alias: ['JERMAN', 'GERMANY'] },
  { kode: '🇮🇹', kata: 'ITALIA',        alias: ['ITALIA', 'ITALY'] },
  { kode: '🇪🇸', kata: 'SPANYOL',       alias: ['SPANYOL', 'SPAIN'] },
  { kode: '🇵🇹', kata: 'PORTUGAL',      alias: ['PORTUGAL'] },
  { kode: '🇳🇱', kata: 'BELANDA',       alias: ['BELANDA', 'NETHERLANDS', 'HOLLAND'] },
  { kode: '🇷🇺', kata: 'RUSIA',         alias: ['RUSIA', 'RUSSIA'] },
  { kode: '🇺🇸', kata: 'AMERIKA',       alias: ['AMERIKA', 'USA', 'AMERIKASERIKAT', 'UNITEDSTATES'] },
  { kode: '🇨🇦', kata: 'KANADA',        alias: ['KANADA', 'CANADA'] },
  { kode: '🇧🇷', kata: 'BRAZIL',        alias: ['BRAZIL', 'BRASIL'] },
  { kode: '🇦🇷', kata: 'ARGENTINA',     alias: ['ARGENTINA'] },
  { kode: '🇲🇽', kata: 'MEKSIKO',       alias: ['MEKSIKO', 'MEXICO'] },
  { kode: '🇦🇺', kata: 'AUSTRALIA',     alias: ['AUSTRALIA'] },
  { kode: '🇳🇿', kata: 'SELANDIABARU',  alias: ['SELANDIABARU', 'NEWZEALAND'] },
  { kode: '🇪🇬', kata: 'MESIR',         alias: ['MESIR', 'EGYPT'] },
  { kode: '🇿🇦', kata: 'AFRIKASELATAN', alias: ['AFRIKASELATAN', 'SOUTHAFRICA'] },
  { kode: '🇹🇷', kata: 'TURKI',         alias: ['TURKI', 'TURKEY'] },
  { kode: '🇬🇷', kata: 'YUNANI',        alias: ['YUNANI', 'GREECE'] },
  { kode: '🇸🇪', kata: 'SWEDIA',        alias: ['SWEDIA', 'SWEDEN'] },
  { kode: '🇨🇭', kata: 'SWISS',         alias: ['SWISS', 'SWITZERLAND'] },
  { kode: '🇵🇱', kata: 'POLANDIA',      alias: ['POLANDIA', 'POLAND'] },
  { kode: '🇺🇦', kata: 'UKRAINA',       alias: ['UKRAINA', 'UKRAINE'] },
  { kode: '🇵🇰', kata: 'PAKISTAN',      alias: ['PAKISTAN'] },
  { kode: '🇧🇩', kata: 'BANGLADESH',    alias: ['BANGLADESH'] },
  { kode: '🇮🇷', kata: 'IRAN',          alias: ['IRAN'] },
  { kode: '🇮🇶', kata: 'IRAK',          alias: ['IRAK', 'IRAQ'] },
  { kode: '🇰🇵', kata: 'KOREAPUTARA',   alias: ['KOREAPUTARA', 'NORTHKOREA'] },
  { kode: '🇰🇭', kata: 'KAMBOJA',       alias: ['KAMBOJA', 'CAMBODIA'] },
  { kode: '🇱🇦', kata: 'LAOS',          alias: ['LAOS'] },
  { kode: '🇲🇲', kata: 'MYANMAR',       alias: ['MYANMAR', 'BURMA'] },
  { kode: '🇧🇳', kata: 'BRUNEI',        alias: ['BRUNEI', 'BRUNEIDARUSSALAM'] },
  { kode: '🇹🇱', kata: 'TIMORLESTE',    alias: ['TIMORLESTE', 'TIMORTIMUR', 'EASTTIMOR'] },
];

function pilihSoal() {
  return BANK_SOAL[Math.floor(Math.random() * BANK_SOAL.length)];
}

function normalisasi(str) {
  return String(str)
    .toUpperCase()
    .replace(/[^A-Z]/g, '') // buang spasi, tanda baca, emoji
    .trim();
}

function cekJawaban(input, soal) {
  const jawab = normalisasi(input);
  if (!jawab) return false;
  const semua = [soal.kata, ...(soal.alias || [])].map(normalisasi);
  return semua.includes(jawab);
}

// Hint bertahap: huruf pertama + underscore, reveal makin banyak tiap salah
function buatHint(kata, revealCount) {
  const n = Math.min(revealCount, kata.length - 1);
  return kata.slice(0, n) + '_'.repeat(kata.length - n);
}

// ============================================================
// HANDLER
// ============================================================
export default async function handler(ctx) {
  const { reply, remoteJid, sender } = ctx;

  const soal = pilihSoal();
  const kataAsli = soal.kata;
  const panjang = kataAsli.length;

  // Hint awal: cuma huruf pertama
  const hintAwal = buatHint(kataAsli, 1);

  const teksSoal =
    `🚩 *TEBAK BENDERA*\n\n` +
    `Negara manakah ini?\n\n` +
    `┌─────────────────\n` +
    `│   ${soal.kode}   *${kataAsli.length} huruf*\n` +
    `└─────────────────\n\n` +
    `🔤 *Hint:* ${hintAwal}\n\n` +
    `📌 Reply pesan ini dengan nama negara.\n` +
    `💰 Benar: +${HADIAH_BENAR} poin\n` +
    `❌ Salah: ${DENDA_SALAH} poin (maks ${MAKS_SALAH}x)\n\n` +
    `⏱️ _Batas waktu: 90 detik_`;

  const sentMsg = await reply(teksSoal);
  if (!sentMsg?.key?.id) return;

  const handleJawaban = async (replyCtx) => {
    const meta = replyCtx.meta;

    // Kosong → abaikan
    if (!normalisasi(replyCtx.text)) return;

    // Benar (cek alias juga)
    if (cekJawaban(replyCtx.text, meta.soal)) {
      return replyCtx.reply(
        `✅ *BENAR!* 🎉\n\n` +
        `Bendera ${meta.soal.kode} = *${meta.kataAsli}*\n` +
        `💰 Poin didapat: +${HADIAH_BENAR}\n\n` +
        `_Main lagi? Ketik .tebakbendera_`
      );
    }

    // Salah
    meta.salah += 1;
    meta.poin += DENDA_SALAH;

    if (meta.salah >= MAKS_SALAH) {
      return replyCtx.reply(
        `❌ *SALAH ${MAKS_SALAH}x — GAME OVER*\n\n` +
        `Bendera ${meta.soal.kode} = *${meta.kataAsli}*\n` +
        `📉 Poin akhir: ${meta.poin}\n\n` +
        `_Coba lagi dengan .tebakbendera_`
      );
    }

    const sisaKesempatan = MAKS_SALAH - meta.salah;

    // Hint baru makin terbuka
    const revealCount = meta.salah + 1;
    const hintBaru = buatHint(meta.kataAsli, revealCount);

    const newMsg = await replyCtx.reply(
      `❌ *Salah!* Jawabanmu: "${replyCtx.text}"\n\n` +
      `📊 Sisa kesempatan: *${sisaKesempatan}x*\n` +
      `📉 Poin sementara: ${meta.poin}\n\n` +
      `🚩 Bendera: ${meta.soal.kode}\n` +
      `🔤 *Hint baru:* ${hintBaru}\n` +
      `📏 *Jumlah huruf:* ${panjang}\n\n` +
      `📌 Reply pesan ini dengan jawaban lain.`
    );

    if (newMsg?.key?.id) {
      registerSession(
        newMsg.key.id,
        remoteJid,
        handleJawaban,
        { ...meta, expireAt: Date.now() + TIMEOUT_MS },
        {
          once: true,
          timeoutMs: TIMEOUT_MS,
          senderJid: sender?.lid || (sender?.nomor ? sender.nomor + '@s.whatsapp.net' : null),
          validateSender: false,
          tag: 'tebakbendera',
        }
      );
    }
  };

  registerSession(
    sentMsg.key.id,
    remoteJid,
    handleJawaban,
    {
      kataAsli,
      soal,
      salah: 0,
      poin: 0,
      expireAt: Date.now() + TIMEOUT_MS,
    },
    {
      once: true,
      timeoutMs: TIMEOUT_MS,
      senderJid: sender?.lid || (sender?.nomor ? sender.nomor + '@s.whatsapp.net' : null),
      validateSender: false,
      tag: 'tebakbendera',
    }
  );
}