// plugins/game/tebakkata.js
// Game: user menebak kata dari deskripsi/definisi.
// Mirip susunkata, tapi user menebak tanpa huruf acak.

import { registerSession } from '../../libx/session_plugins.js';

export const cmd = ['tebakkata', 'tk'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 1;

// ============================================================
// KONFIGURASI GAME
// ============================================================
const TIMEOUT_MS = 90 * 1000;
const HADIAH_BENAR = 50;
const DENDA_SALAH = -5;
const MAKS_SALAH = 3;

// ============================================================
// BANK SOAL (definisi → kata)
// ============================================================
const BANK_SOAL = [
  { kata: 'MATAHARI', definisi: 'Bintang di pusat tata surya, sumber energi utama bumi' },
  { kata: 'GUNUNG',   definisi: 'Daratan yang menjulang sangat tinggi, sering didaki' },
  { kata: 'PANTAI',   definisi: 'Tepi laut yang berpasir, tempat rekreasi' },
  { kata: 'BUKU',     definisi: 'Kumpulan lembaran kertas berisi tulisan untuk dibaca' },
  { kata: 'KAMERA',   definisi: 'Alat optik untuk memotret atau merekam gambar' },
  { kata: 'KUCING',   definisi: 'Hewan berkaki empat, berbulu, suka mengeong' },
  { kata: 'GAJAH',    definisi: 'Hewan darat terbesar, berbelalai panjang dan bertelinga lebar' },
  { kata: 'BUNGA',    definisi: 'Bagian tumbuhan yang indah, sering dijadikan hadiah' },
  { kata: 'HUJAN',    definisi: 'Air yang turun dari langit dalam butiran' },
  { kata: 'BULAN',    definisi: 'Satelit alami bumi, terlihat bercahaya di malam hari' },
  { kata: 'BINTANG',  definisi: 'Titik cahaya di langit malam, sering diibaratkan harapan' },
  { kata: 'AWAN',     definisi: 'Kumpulan uap air di langit, berwarna putih atau gelap' },
  { kata: 'ANGIN',    definisi: 'Udara yang bergerak, terasa sejuk di kulit' },
  { kata: 'SEPEDA',   definisi: 'Kendaraan roda dua yang dikayuh' },
  { kata: 'MOBIL',    definisi: 'Kendaraan roda empat bermesin' },
  { kata: 'PESAWAT',  definisi: 'Kendaraan terbang, punya sayap dan mesin jet' },
  { kata: 'KAPAL',    definisi: 'Kendaraan besar yang berlayar di laut' },
  { kata: 'PASAR',    definisi: 'Tempat bertemunya penjual dan pembeli' },
  { kata: 'SEKOLAH',  definisi: 'Tempat menuntut ilmu, ada guru dan murid' },
  { kata: 'RUMAH',    definisi: 'Tempat tinggal, tempat pulang' },
  { kata: 'PENSIL',   definisi: 'Alat tulis dari grafit, bisa dihapus' },
  { kata: 'PULAU',    definisi: 'Daratan yang dikelilingi air' },
  { kata: 'SUNGAI',   definisi: 'Aliran air alami menuju laut' },
  { kata: 'GURU',     definisi: 'Orang yang mengajar di sekolah' },
  { kata: 'DOKTER',   definisi: 'Orang yang mengobati pasien di rumah sakit' },
  { kata: 'PETANI',   definisi: 'Orang yang bekerja di sawah / ladang' },
  { kata: 'NELAYAN',  definisi: 'Orang yang menangkap ikan di laut' },
  { kata: 'PILOT',    definisi: 'Orang yang mengemudikan pesawat' },
  { kata: 'API',      definisi: 'Sesuatu yang panas, berwarna merah-kuning, membakar' },
  { kata: 'AIR',      definisi: 'Zat cair jernih, sangat dibutuhkan makhluk hidup' },
];

function pilihSoal() {
  return BANK_SOAL[Math.floor(Math.random() * BANK_SOAL.length)];
}

function normalisasi(str) {
  return String(str).toUpperCase().replace(/\s+/g, '').trim();
}

// ============================================================
// HANDLER
// ============================================================
export default async function handler(ctx) {
  const { reply, remoteJid, sender } = ctx;

  const soal = pilihSoal();
  const kataAsli = soal.kata;

  // Hint huruf pertama + jumlah huruf
  const hintAwal = `${kataAsli[0]}${'_'.repeat(kataAsli.length - 1)}`;
  const panjang = kataAsli.length;

  const teksSoal =
    `🔍 *TEBAK KATA*\n\n` +
    `Tebak kata dari definisi berikut:\n\n` +
    `┌─────────────────\n` +
    `│  ${soal.definisi}\n` +
    `└─────────────────\n\n` +
    `🔤 *Hint:* ${hintAwal}\n` +
    `📏 *Jumlah huruf:* ${panjang}\n\n` +
    `📌 Reply pesan ini dengan jawabanmu.\n` +
    `💰 Benar: +${HADIAH_BENAR} poin\n` +
    `❌ Salah: ${DENDA_SALAH} poin (maks ${MAKS_SALAH}x)\n\n` +
    `⏱️ _Batas waktu: 90 detik_`;

  const sentMsg = await reply(teksSoal);
  if (!sentMsg?.key?.id) return;

  const handleJawaban = async (replyCtx) => {
    const meta = replyCtx.meta;
    const jawaban = normalisasi(replyCtx.text);

    if (!jawaban) return;

    // Benar
    if (jawaban === kataAsli) {
      return replyCtx.reply(
        `✅ *BENAR!* 🎉\n\n` +
        `Jawaban: *${kataAsli}*\n` +
        `💰 Poin didapat: +${HADIAH_BENAR}\n\n` +
        `_Main lagi? Ketik .tebakkata_`
      );
    }

    // Salah
    meta.salah += 1;
    meta.poin += DENDA_SALAH;

    if (meta.salah >= MAKS_SALAH) {
      return replyCtx.reply(
        `❌ *SALAH ${MAKS_SALAH}x — GAME OVER*\n\n` +
        `Jawaban yang benar: *${kataAsli}*\n` +
        `📉 Poin akhir: ${meta.poin}\n\n` +
        `_Coba lagi dengan .tebakkata_`
      );
    }

    const sisaKesempatan = MAKS_SALAH - meta.salah;

    // Hint makin terbuka seiring salah
    const revealCount = Math.min(meta.salah + 1, panjang - 1);
    const hintBaru = kataAsli.slice(0, revealCount) + '_'.repeat(panjang - revealCount);

    const newMsg = await replyCtx.reply(
      `❌ *Salah!* Jawabanmu: "${replyCtx.text}"\n\n` +
      `📊 Sisa kesempatan: *${sisaKesempatan}x*\n` +
      `📉 Poin sementara: ${meta.poin}\n\n` +
      `🔤 *Hint baru:* ${hintBaru}\n` +
      `📏 *Jumlah huruf:* ${panjang}\n\n` +
      `📌 Reply pesan ini dengan jawaban lain.`
    );

    if (newMsg?.key?.id) {
      registerSession(
        newMsg.key.id,
        remoteJid,
        handleJawaban,
        { ...meta, expireAt: Date.now() + TIMEOUT_MS },
        {
          once: true,
          timeoutMs: TIMEOUT_MS,
          senderJid: sender?.lid || (sender?.nomor ? sender.nomor + '@s.whatsapp.net' : null),
          validateSender: false,
          tag: 'tebakkata',
        }
      );
    }
  };

  registerSession(
    sentMsg.key.id,
    remoteJid,
    handleJawaban,
    {
      kataAsli,
      soal,
      salah: 0,
      poin: 0,
      expireAt: Date.now() + TIMEOUT_MS,
    },
    {
      once: true,
      timeoutMs: TIMEOUT_MS,
      senderJid: sender?.lid || (sender?.nomor ? sender.nomor + '@s.whatsapp.net' : null),
      validateSender: false,
      tag: 'tebakkata',
    }
  );
}