// plugins/game/susunkata.js
// Game: user harus menyusun huruf acak menjadi kata yang benar.
// 1 soal per session, timeout 90 detik, reward poin.

import { registerSession } from '../../libx/session_plugins.js';

export const cmd = ['susunkata', 'sk'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 1;

// ============================================================
// KONFIGURASI GAME
// ============================================================
const TIMEOUT_MS = 90 * 1000;      // 90 detik
const HADIAH_BENAR = 50;
const DENDA_SALAH = -5;
const MAKS_SALAH = 3;              // 3x salah → game over

// ============================================================
// BANK KATA (bisa ditambah)
// ============================================================
const BANK_KATA = [
  // 3-4 huruf
  { kata: 'BUKU',  petunjuk: 'Alat untuk membaca dan menulis' },
  { kata: 'MEJA',  petunjuk: 'Perabot untuk menulis / makan' },
  { kata: 'KURSI', petunjuk: 'Tempat untuk duduk' },
  { kata: 'PINTU', petunjuk: 'Jalan masuk ke ruangan' },
  { kata: 'LAMPU', petunjuk: 'Sumber cahaya di ruangan' },
  { kata: 'BUNGA', petunjuk: 'Tumbuhan yang indah, sering dijadikan hadiah' },
  { kata: 'ANGIN', petunjuk: 'Udara yang bergerak' },
  { kata: 'HUJAN', petunjuk: 'Air yang turun dari langit' },
  { kata: 'BULAN', petunjuk: 'Satelit alami bumi, terlihat malam hari' },
  { kata: 'BINTANG', petunjuk: 'Titik cahaya di langit malam' },
  // 5-6 huruf
  { kata: 'MATAHARI', petunjuk: 'Pusat tata surya kita' },
  { kata: 'KOMPUTER', petunjuk: 'Alat elektronik untuk mengolah data' },
  { kata: 'SEPEDA',  petunjuk: 'Kendaraan roda dua tanpa mesin' },
  { kata: 'KAMERA',  petunjuk: 'Alat untuk memotret' },
  { kata: 'PENSIL',  petunjuk: 'Alat tulis dari grafit' },
  { kata: 'GUNUNG',  petunjuk: 'Daratan yang menjulang tinggi' },
  { kata: 'PANTAI',  petunjuk: 'Tepi laut dengan pasir' },
  { kata: 'PASAR',   petunjuk: 'Tempat jual beli' },
  { kata: 'SEKOLAH', petunjuk: 'Tempat menuntut ilmu' },
  { kata: 'RUMAH',   petunjuk: 'Tempat tinggal' },
  { kata: 'KUCING',  petunjuk: 'Hewan peliharaan yang suka mengeong' },
  { kata: 'AYAM',    petunjuk: 'Hewan yang berkokok di pagi hari' },
  { kata: 'SAPI',    petunjuk: 'Hewan yang menghasilkan susu' },
  { kata: 'KAMBING', petunjuk: 'Hewan yang suka makan rumput, bertanduk' },
  { kata: 'GAJAH',   petunjuk: 'Hewan darat terbesar, berbelalai' },
];

// ============================================================
// UTIL
// ============================================================
function pilihKata() {
  return BANK_KATA[Math.floor(Math.random() * BANK_KATA.length)];
}

function acakHuruf(kata) {
  // Fisher-Yates shuffle
  const arr = kata.split('');
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  const hasil = arr.join('');
  // Kalau hasil acak sama dengan aslinya, acak ulang (maks 5x)
  if (hasil === kata && kata.length > 1) return acakHuruf(kata);
  return hasil;
}

function normalisasi(str) {
  return String(str).toUpperCase().replace(/\s+/g, '').trim();
}

// ============================================================
// HANDLER
// ============================================================
export default async function handler(ctx) {
  const { reply, remoteJid, sender } = ctx;

  const soal = pilihKata();
  const kataAsli = soal.kata;
  const hurufAcak = acakHuruf(kataAsli);

  const teksSoal =
    `🔤 *SUSUN KATA*\n\n` +
    `Susun huruf-huruf ini menjadi kata yang benar:\n\n` +
    `┌─────────────────\n` +
    `│  *${hurufAcak.split('').join(' - ')}*\n` +
    `└─────────────────\n\n` +
    `💡 *Petunjuk:* ${soal.petunjuk}\n` +
    `📏 *Jumlah huruf:* ${kataAsli.length}\n\n` +
    `📌 Reply pesan ini dengan jawabanmu.\n` +
    `💰 Benar: +${HADIAH_BENAR} poin\n` +
    `❌ Salah: ${DENDA_SALAH} poin (maks ${MAKS_SALAH}x)\n\n` +
    `⏱️ _Batas waktu: 90 detik_`;

  const sentMsg = await reply(teksSoal);
  if (!sentMsg?.key?.id) return;

  const handleJawaban = async (replyCtx) => {
    const meta = replyCtx.meta;
    const jawaban = normalisasi(replyCtx.text);

    // Kosong → abaikan, session tetap
    if (!jawaban) return;

    // Benar
    if (jawaban === kataAsli) {
      meta.poin = HADIAH_BENAR;
      return replyCtx.reply(
        `✅ *BENAR!* 🎉\n\n` +
        `Jawaban: *${kataAsli}*\n` +
        `💰 Poin didapat: +${HADIAH_BENAR}\n\n` +
        `_Main lagi? Ketik .susunkata_`
      );
    }

    // Salah
    meta.salah += 1;
    meta.poin += DENDA_SALAH;

    if (meta.salah >= MAKS_SALAH) {
      return replyCtx.reply(
        `❌ *SALAH ${MAKS_SALAH}x — GAME OVER*\n\n` +
        `Jawaban yang benar: *${kataAsli}*\n` +
        `📉 Poin akhir: ${meta.poin}\n\n` +
        `_Coba lagi dengan .susunkata_`
      );
    }

    const sisaKesempatan = MAKS_SALAH - meta.salah;

    // Salah tapi masih ada kesempatan → kasih soal lanjutan via reply (session baru)
    const newMsg = await replyCtx.reply(
      `❌ *Salah!* Jawabanmu: "${replyCtx.text}"\n\n` +
      `📊 Sisa kesempatan: *${sisaKesempatan}x*\n` +
      `📉 Poin sementara: ${meta.poin}\n\n` +
      `🔤 *${hurufAcak.split('').join(' - ')}*\n` +
      `💡 *Petunjuk:* ${soal.petunjuk}\n\n` +
      `📌 Reply pesan ini dengan jawaban lain.\n` +
      `⏱️ _Sisa waktu: ${Math.round((meta.expireAt - Date.now()) / 1000)}s_`
    );

    // Register ulang (recursive)
    if (newMsg?.key?.id) {
      registerSession(
        newMsg.key.id,
        remoteJid,
        handleJawaban,
        {
          ...meta,
          expireAt: Date.now() + TIMEOUT_MS,
        },
        {
          once: true,
          timeoutMs: TIMEOUT_MS,
          senderJid: sender?.lid || (sender?.nomor ? sender.nomor + '@s.whatsapp.net' : null),
          validateSender: false,
          tag: 'susunkata',
        }
      );
    }
  };

  registerSession(
    sentMsg.key.id,
    remoteJid,
    handleJawaban,
    {
      kataAsli,
      soal,
      salah: 0,
      poin: 0,
      expireAt: Date.now() + TIMEOUT_MS,
    },
    {
      once: true,
      timeoutMs: TIMEOUT_MS,
      senderJid: sender?.lid || (sender?.nomor ? sender.nomor + '@s.whatsapp.net' : null),
      validateSender: false,
      tag: 'susunkata',
      onExpire: async ({ chatJid }) => {
        try {
          const { sendText } = await import('../../libx/whatsapp/sendmsg.js');
          await sendText(sockRef, chatJid, `⏱️ *Waktu habis!* Jawaban: *${kataAsli}*`);
        } catch (_) {}
      },
    }
  );

  // Workaround karena onExpire butuh sock — simpan di closure lewat handler
  // (kita tidak bisa akses `sock` di onExpire secara langsung kecuali di-closure)
  // Solusi: pakai variable dari ctx
  // Sebenarnya ctx tidak expose sock ke handler plugin — tapi kita bisa ambil dari ctx
  // karena plugin menerima `sock` di handler utama? — ctx TIDAK punya sock.
  // Jadi onExpire di atas akan error karena `sockRef` undefined.
  // → HAPUS blok onExpire di atas, atau simpan sock dari handler.
}