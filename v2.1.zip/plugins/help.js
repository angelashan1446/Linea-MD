// plugins/umum/help.js
import { scanMenu } from '../libx/menu_scanner.js';
import config from '../config.js';
import { sendReaction, sendText } from '../libx/whatsapp/sendmsg.js';
import { findUser } from '../libx/db.js';
import { resolveLang, isValidLang, DEFAULT_LANG } from '../libx/lang.js';

export const cmd = ['help', 'bantuan'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Lihat daftar command & detail per kategori';
export const description_ch = '查看命令列表及按分类的详细信息';
export const description_uk = 'View command list & details per category';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_plugins: '❌ Belum ada plugin.',

        help_header: `╭───「 *HELP MENU* 」`,
        help_intro: '│ Pilih kategori untuk lihat detail.',
        help_example: '│ Contoh: *{prefix}help download*',
        help_footer_line: `╰───────☉`,
        total_summary: '_Total: {n} command di {c} kategori_',

        invalid_category:
            '❌ Kategori *{cat}* tidak ditemukan.\n\n' +
            'Kategori tersedia:\n{list}',

        cat_count: '{n} command',
        badge_owner: 'Owner',
        badge_premium: 'Premium',
        badge_token: '{n} token',
        no_description: 'Tidak ada deskripsi',
        alias_label: 'Alias',
        back_hint: 'Ketik {prefix}help untuk kembali ke list kategori',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        no_plugins: '❌ 暂无插件。',

        help_header: `╭───「 *帮助菜单* 」`,
        help_intro: '│ 选择分类查看详情。',
        help_example: '│ 示例：*{prefix}help download*',
        help_footer_line: `╰───────☉`,
        total_summary: '_总计：{c} 个分类共 {n} 个命令_',

        invalid_category:
            '❌ 未找到分类 *{cat}*。\n\n' +
            '可用分类：\n{list}',

        cat_count: '{n} 个命令',
        badge_owner: '主人',
        badge_premium: '高级会员',
        badge_token: '{n} 代币',
        no_description: '无描述',
        alias_label: '别名',
        back_hint: '输入 {prefix}help 返回分类列表',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        no_plugins: '❌ No plugins registered yet.',

        help_header: `╭───「 *HELP MENU* 」`,
        help_intro: '│ Choose a category to see the details.',
        help_example: '│ Example: *{prefix}help download*',
        help_footer_line: `╰───────☉`,
        total_summary: '_Total: {n} command(s) in {c} categor(y|ies)_',

        invalid_category:
            '❌ Category *{cat}* not found.\n\n' +
            'Available categories:\n{list}',

        cat_count: '{n} command(s)',
        badge_owner: 'Owner',
        badge_premium: 'Premium',
        badge_token: '{n} token(s)',
        no_description: 'No description',
        alias_label: 'Alias',
        back_hint: 'Type {prefix}help to return to the category list',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

// ============================================================
// MAIN HANDLER
// ============================================================
export default async function handler(ctx) {
    const { sock, remoteJid, msg, prefix, args, sender, isGroup } = ctx;

    // Resolve bahasa: user → grup → uk
    const userDB = findUser({ lid: sender?.lid, nomor: sender?.nomor });
    const lang = resolveLang({ user: userDB, isGroup, remoteJid });

    await sendReaction(sock, remoteJid, msg.key, '📖');

    // Scan plugin pakai bahasa aktif
    const plugins = await scanMenu(undefined, { lang });

    if (plugins.length === 0) {
        return sendText(sock, remoteJid, T(lang, 'no_plugins'), { quoted: msg });
    }

    const grouped = {};
    for (const p of plugins) {
        if (!grouped[p.category]) grouped[p.category] = [];
        grouped[p.category].push(p);
    }

    const categories = Object.keys(grouped);
    const catArg = args[0]?.toLowerCase();

    // ============================================================
    // TANPA ARGUMEN → LIST KATEGORI
    // ============================================================
    if (!catArg) {
        let text = `${T(lang, 'help_header')}\n`;
        text += `${T(lang, 'help_intro')}\n`;
        text += `${T(lang, 'help_example', { prefix })}\n`;
        text += `${T(lang, 'help_footer_line')}\n\n`;

        for (const cat of categories) {
            const count = grouped[cat].reduce((a, p) => a + p.cmd.length, 0);
            text += `┌─ *${cat.toUpperCase()}* (${T(lang, 'cat_count', { n: count })})\n`;
            text += `└─ ${prefix}help ${cat}\n\n`;
        }

        text += T(lang, 'total_summary', {
            n: plugins.reduce((a, p) => a + p.cmd.length, 0),
            c: categories.length,
        });
        text += `\n\n${T(lang, 'footer')}`;

        return sendText(sock, remoteJid, text, { quoted: msg });
    }

    // ============================================================
    // DENGAN ARGUMEN → DETAIL KATEGORI
    // ============================================================
    if (!grouped[catArg]) {
        return sendText(
            sock,
            remoteJid,
            T(lang, 'invalid_category', {
                cat: catArg,
                list: categories.map(c => `• ${c}`).join('\n'),
            }),
            { quoted: msg }
        );
    }

    const catPlugins = grouped[catArg];
    const totalCmd = catPlugins.reduce((a, p) => a + p.cmd.length, 0);

    let detail = `*${catArg.toUpperCase()}* — ${T(lang, 'cat_count', { n: totalCmd })}\n\n`;

    for (const p of catPlugins) {
        // Badge (owner / premium / token)
        const badge = [];
        if (p.only_owner) badge.push(T(lang, 'badge_owner'));
        if (p.only_premium) badge.push(T(lang, 'badge_premium'));
        if (p.token_usage > 0) badge.push(T(lang, 'badge_token', { n: p.token_usage }));

        const badgeStr = badge.length ? ` (${badge.join(', ')})` : '';

        detail += `*${prefix}${p.cmd[0]}*${badgeStr}\n`;

        if (p.description) {
            detail += `_${p.description}_\n`;
        } else {
            detail += `_${T(lang, 'no_description')}_\n`;
        }

        if (p.cmd.length > 1) {
            const aliases = p.cmd.slice(1).map(c => `${prefix}${c}`).join(', ');
            detail += `> ${T(lang, 'alias_label')}: ${aliases}\n`;
        }

        detail += `\n`;
    }

    detail += `_${T(lang, 'back_hint', { prefix })}_`;

    return sendText(sock, remoteJid, detail, { quoted: msg });
}