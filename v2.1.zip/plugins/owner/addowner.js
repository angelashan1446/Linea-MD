// plugins/owner/addowner.js
import { findUser, readDb, writeDb } from '../../libx/db.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['addowner'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Tambahkan user jadi owner (khusus owner)';
export const description_ch = '添加用户为主人（仅限主人）';
export const description_uk = 'Add user as owner (owner only)';
export const description = description_id;

const TEXT = {
    id: {
        no_arg: '⚠️ Format: .addowner <62xxx> atau reply pesan target',
        user_not_found: 'User tidak ditemukan di database',
        header: `乂  *ᴀɴɢᴇʟs - ᴀᴅᴅ ᴏᴡɴᴇʀ*`,
        label_target: 'Target',
        label_status: 'Status',
        status_value: 'Owner ✅',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        no_arg: '⚠️ 格式：.addowner <62xxx> 或回复目标消息',
        user_not_found: '数据库中未找到用户',
        header: `乂  *ᴀɴɢᴇʟs - 添加主人*`,
        label_target: '目标',
        label_status: '状态',
        status_value: '主人 ✅',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        no_arg: '⚠️ Format: .addowner <62xxx> or reply the target message',
        user_not_found: 'User not found in database',
        header: `乂  *ᴀɴɢᴇʟs - ᴀᴅᴅ ᴏᴡɴᴇʀ*`,
        label_target: 'Target',
        label_status: 'Status',
        status_value: 'Owner ✅',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text) return reply(T(lang, 'no_arg'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        let targetNomor, targetLid;

        if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            const quoted = msg.message.extendedTextMessage.contextInfo;
            const jid = quoted.participant || quoted.remoteJid || '';
            if (jid.endsWith('@s.whatsapp.net')) targetNomor = jid.split('@')[0];
            else if (jid.endsWith('@lid')) targetLid = jid;
        } else {
            targetNomor = text.trim();
        }

        const user = findUser({ lid: targetLid, nomor: targetNomor });
        if (!user) throw new Error(T(lang, 'user_not_found'));

        const db = readDb();
        const u = db.users.find((x) => x.nomor === user.nomor);
        u.owner = true;
        writeDb(db);

        await sendReaction(sock, remoteJid, msg.key, '✅');

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_target')}* : ${user.nomor}\n` +
            `*${T(lang, 'label_status')}* : ${T(lang, 'status_value')}\n\n` +
            `${T(lang, 'footer')}`;

        await reply(caption);
    } catch (err) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        await reply(T(lang, 'fail', { err: err.message }));
    }
}