// plugins/owner/maintenance.js
import { isMaintenance, setMaintenance } from '../../libx/system.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['maintenance', 'mt', 'maint'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Aktifkan/matikan mode maintenance bot (khusus owner)';
export const description_ch = '开启/关闭机器人维护模式（仅限主人）';
export const description_uk = 'Enable/disable bot maintenance mode (owner only)';
export const description = description_id;

const TEXT = {
    id: {
        status_header: `乂  *ᴀɴɢᴇʟs - ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ ᴍᴏᴅᴇ*`,
        status_on: '🔧 *ON* (bot maintenance)',
        status_off: '✅ *OFF* (bot normal)',
        status_line: 'Status : {v}',
        how_to: '*Cara pakai:*',
        how_on: '• {prefix}maintenance on  → aktifkan maintenance',
        how_off: '• {prefix}maintenance off → matikan maintenance',
        invalid_arg: '❌ Argumen tidak valid.\nGunakan: *{prefix}mt on* atau *{prefix}mt off*',
        already: '⚠️ Maintenance mode udah *{arg}* dari tadi.',
        save_fail: '❌ Gagal menyimpan konfigurasi. Cek log server.',
        on_header: `乂  *ᴀɴɢᴇʟs - ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ ᴏɴ*`,
        off_header: `乂  *ᴀɴɢᴇʟs - ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ ᴏғғ*`,
        on_body: '🔧 Bot sekarang *SEDANG MAINTENANCE*.\nSemua user (kecuali owner) akan menerima pesan maintenance.',
        off_body: '✅ Bot sekarang *NORMAL* kembali.\nSemua user bisa pakai bot seperti biasa.',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        status_header: `乂  *ᴀɴɢᴇʟs - 维护模式*`,
        status_on: '🔧 *开启*（机器人维护中）',
        status_off: '✅ *关闭*（机器人正常）',
        status_line: '状态：{v}',
        how_to: '*使用方法：*',
        how_on: '• {prefix}maintenance on  → 开启维护',
        how_off: '• {prefix}maintenance off → 关闭维护',
        invalid_arg: '❌ 参数无效。\n使用：*{prefix}mt on* 或 *{prefix}mt off*',
        already: '⚠️ 维护模式此前已处于 *{arg}* 状态。',
        save_fail: '❌ 保存配置失败。请检查服务器日志。',
        on_header: `乂  *ᴀɴɢᴇʟs - 维护开启*`,
        off_header: `乂  *ᴀɴɢᴇʟs - 维护关闭*`,
        on_body: '🔧 机器人现在*维护中*。\n所有用户（除主人外）将收到维护提示。',
        off_body: '✅ 机器人已*恢复正常*。\n所有用户可以正常使用。',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        status_header: `乂  *ᴀɴɢᴇʟs - ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ ᴍᴏᴅᴇ*`,
        status_on: '🔧 *ON* (bot under maintenance)',
        status_off: '✅ *OFF* (bot normal)',
        status_line: 'Status : {v}',
        how_to: '*How to use:*',
        how_on: '• {prefix}maintenance on  → enable maintenance',
        how_off: '• {prefix}maintenance off → disable maintenance',
        invalid_arg: '❌ Invalid argument.\nUse: *{prefix}mt on* or *{prefix}mt off*',
        already: '⚠️ Maintenance mode was already *{arg}*.',
        save_fail: '❌ Failed to save configuration. Check server logs.',
        on_header: `乂  *ᴀɴɢᴇʟs - ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ ᴏɴ*`,
        off_header: `乂  *ᴀɴɢᴇʟs - ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ ᴏғғ*`,
        on_body: '🔧 Bot is now *UNDER MAINTENANCE*.\nAll users (except owner) will receive maintenance message.',
        off_body: '✅ Bot is now *NORMAL* again.\nAll users can use the bot as usual.',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, args, prefix, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const arg = (args[0] || '').toLowerCase();

    if (!arg) {
        const status = isMaintenance();
        return reply(
            `${T(lang, 'status_header')}\n\n` +
            `${T(lang, 'status_line', { v: status ? T(lang, 'status_on') : T(lang, 'status_off') })}\n\n` +
            `${T(lang, 'how_to')}\n` +
            `${T(lang, 'how_on', { prefix })}\n` +
            `${T(lang, 'how_off', { prefix })}\n\n` +
            `${T(lang, 'footer')}`
        );
    }

    if (arg !== 'on' && arg !== 'off') {
        return reply(T(lang, 'invalid_arg', { prefix }));
    }

    const value = arg === 'on';
    const current = isMaintenance();

    if (current === value) {
        return reply(T(lang, 'already', { arg: arg.toUpperCase() }));
    }

    await sendReaction(sock, remoteJid, msg.key, value ? '🔧' : '✅');

    const success = setMaintenance(value);
    if (!success) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        return reply(T(lang, 'save_fail'));
    }

    await reply(
        `${value ? T(lang, 'on_header') : T(lang, 'off_header')}\n\n` +
        `${value ? T(lang, 'on_body') : T(lang, 'off_body')}\n\n` +
        `${T(lang, 'footer')}`
    );

    await sendReaction(sock, remoteJid, msg.key, '✅');
}