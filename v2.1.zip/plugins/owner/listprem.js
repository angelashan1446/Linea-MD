// plugins/owner/listprem.js
import fs from 'fs';
import path from 'path';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['listprem', 'premlist', 'daftarpremium'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Lihat daftar user premium (khusus owner)';
export const description_ch = '查看高级会员用户列表（仅限主人）';
export const description_uk = 'View premium user list (owner only)';
export const description = description_id;

const DB_FILE = path.join(process.cwd(), 'db', 'users.json');

const TEXT = {
    id: {
        db_missing: '❌ Belum ada data user.',
        db_fail: '❌ Gagal baca database: {err}',
        empty:
            `乂  *ᴀɴɢᴇʟs - ʟɪsᴛ ᴘʀᴇᴍɪᴜᴍ*\n\n` +
            `📭 Belum ada user premium.\n\n` +
            `_Ketik .addprem <62xxx>,<hari> untuk menambahkan_`,
        header: `乂  *ᴀɴɢᴇʟs - ʟɪsᴛ ᴘʀᴇᴍɪᴜᴍ*`,
        stat_title: '📊 *Statistik*',
        stat_total: 'Total: {n} user',
        stat_active: 'Aktif: {n}',
        stat_expired: 'Expired: {n}',
        filter_label: '🔍 *Filter:* {f} ({n} hasil)',
        list_title: '👑 *Daftar Premium:*',
        label_token: 'Token',
        active_label: 'Aktif ({sisa})',
        expired_label: 'Expired ({sisa})',
        other_users: '_...dan {n} user lainnya_',
        filter_hint: '_Filter: .listprem aktif / expired / all_',
        ago_days: '{d} hari lalu',
        ago_hours: '{h} jam lalu',
        ago_just: 'Baru aja expired',
        left_days: '{d}h {h}j',
        left_hours: '{h}j {m}m',
        left_minutes: '{m} menit',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        db_missing: '❌ 暂无用户数据。',
        db_fail: '❌ 读取数据库失败：{err}',
        empty:
            `乂  *ᴀɴɢᴇʟs - 高级会员列表*\n\n` +
            `📭 暂无高级会员。\n\n` +
            `_输入 .addprem <62xxx>,<天> 添加_`,
        header: `乂  *ᴀɴɢᴇʟs - 高级会员列表*`,
        stat_title: '📊 *统计*',
        stat_total: '总计：{n} 个用户',
        stat_active: '活跃：{n}',
        stat_expired: '已过期：{n}',
        filter_label: '🔍 *筛选：* {f}（{n} 条结果）',
        list_title: '👑 *高级会员列表：*',
        label_token: '代币',
        active_label: '活跃（{sisa}）',
        expired_label: '已过期（{sisa}）',
        other_users: '_...还有 {n} 位用户_',
        filter_hint: '_筛选：.listprem aktif / expired / all_',
        ago_days: '{d} 天前',
        ago_hours: '{h} 小时前',
        ago_just: '刚刚过期',
        left_days: '{d}天{h}时',
        left_hours: '{h}时{m}分',
        left_minutes: '{m} 分钟',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        db_missing: '❌ No user data yet.',
        db_fail: '❌ Failed to read database: {err}',
        empty:
            `乂  *ᴀɴɢᴇʟs - ᴘʀᴇᴍɪᴜᴍ ʟɪsᴛ*\n\n` +
            `📭 No premium users yet.\n\n` +
            `_Type .addprem <62xxx>,<days> to add_`,
        header: `乂  *ᴀɴɢᴇʟs - ᴘʀᴇᴍɪᴜᴍ ʟɪsᴛ*`,
        stat_title: '📊 *Statistics*',
        stat_total: 'Total: {n} user(s)',
        stat_active: 'Active: {n}',
        stat_expired: 'Expired: {n}',
        filter_label: '🔍 *Filter:* {f} ({n} results)',
        list_title: '👑 *Premium List:*',
        label_token: 'Token',
        active_label: 'Active ({sisa})',
        expired_label: 'Expired ({sisa})',
        other_users: '_...and {n} more user(s)_',
        filter_hint: '_Filter: .listprem aktif / expired / all_',
        ago_days: '{d} days ago',
        ago_hours: '{h} hours ago',
        ago_just: 'Just expired',
        left_days: '{d}d {h}h',
        left_hours: '{h}h {m}m',
        left_minutes: '{m} minutes',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, args, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    await sendReaction(sock, remoteJid, msg.key, '👑');

    let db;
    try {
        if (!fs.existsSync(DB_FILE)) return reply(T(lang, 'db_missing'));
        db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    } catch (e) {
        return reply(T(lang, 'db_fail', { err: e.message }));
    }

    const users = db.users || [];
    const now = Date.now();

    const premList = [];
    for (const u of users) {
        if (!u?.premium) continue;
        const expiredAt = new Date(u.premium).getTime();
        const isActive = expiredAt > now;
        premList.push({
            nomor: u.nomor,
            lid: u.lid,
            expiredAt,
            isActive,
            token: u.token || 0,
        });
    }

    if (premList.length === 0) return reply(T(lang, 'empty'));

    premList.sort((a, b) => {
        if (a.isActive !== b.isActive) return a.isActive ? -1 : 1;
        return a.expiredAt - b.expiredAt;
    });

    const filterArg = (args[0] || '').toLowerCase();
    let filtered = premList;
    if (filterArg === 'aktif' || filterArg === 'active') {
        filtered = premList.filter(p => p.isActive);
    } else if (filterArg === 'expired' || filterArg === 'mati') {
        filtered = premList.filter(p => !p.isActive);
    }

    function formatSisa(expiredAt) {
        const diff = expiredAt - now;
        if (diff <= 0) {
            const ago = Math.abs(diff);
            const d = Math.floor(ago / (24 * 3600 * 1000));
            const h = Math.floor((ago % (24 * 3600 * 1000)) / (3600 * 1000));
            if (d > 0) return T(lang, 'ago_days', { d });
            if (h > 0) return T(lang, 'ago_hours', { h });
            return T(lang, 'ago_just');
        }
        const d = Math.floor(diff / (24 * 3600 * 1000));
        const h = Math.floor((diff % (24 * 3600 * 1000)) / (3600 * 1000));
        const m = Math.floor((diff % (3600 * 1000)) / (60 * 1000));
        if (d > 0) return T(lang, 'left_days', { d, h });
        if (h > 0) return T(lang, 'left_hours', { h, m });
        return T(lang, 'left_minutes', { m });
    }

    function formatTanggal(ts) {
        return new Date(ts).toLocaleString('id-ID', {
            day: '2-digit', month: 'short', year: 'numeric',
            hour: '2-digit', minute: '2-digit',
            timeZone: 'Asia/Jakarta',
        });
    }

    const activeCount = premList.filter(p => p.isActive).length;
    const expiredCount = premList.length - activeCount;

    let text = `${T(lang, 'header')}\n\n`;
    text += `${T(lang, 'stat_title')}\n`;
    text += `• ${T(lang, 'stat_total', { n: premList.length })}\n`;
    text += `• ${T(lang, 'stat_active', { n: activeCount })}\n`;
    text += `• ${T(lang, 'stat_expired', { n: expiredCount })}\n\n`;

    if (filterArg) {
        text += `${T(lang, 'filter_label', { f: filterArg, n: filtered.length })}\n\n`;
    }

    text += `${T(lang, 'list_title')}\n\n`;

    const limit = 20;
    const displayList = filtered.slice(0, limit);

    displayList.forEach((p, i) => {
        const status = p.isActive ? '✅' : '❌';
        text += `${i + 1}. ${status} *+${p.nomor || p.lid?.split('@')[0] || 'Unknown'}*\n`;
        text += `   🪙 ${T(lang, 'label_token')}: ${p.token}\n`;
        text += `   ⏰ ${formatTanggal(p.expiredAt)}\n`;
        text += `   📊 ${p.isActive ? T(lang, 'active_label', { sisa: formatSisa(p.expiredAt) }) : T(lang, 'expired_label', { sisa: formatSisa(p.expiredAt) })}\n\n`;
    });

    if (filtered.length > limit) {
        text += `${T(lang, 'other_users', { n: filtered.length - limit })}\n\n`;
    }

    text += `${T(lang, 'filter_hint')}\n\n${T(lang, 'footer')}`;

    await reply(text);
    await sendReaction(sock, remoteJid, msg.key, '✅');
}