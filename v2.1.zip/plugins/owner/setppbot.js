// plugins/owner/setppbot.js
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import sharp from 'sharp';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['setppbot', 'setbotpp', 'setpp'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Ganti foto profil bot (khusus owner)';
export const description_ch = '更改机器人头像（仅限主人）';
export const description_uk = 'Change bot profile picture (owner only)';
export const description = description_id;

const TEXT = {
    id: {
        no_image:
            '⚠️ *Cara pakai .setppbot:*\n\n' +
            '1. Reply sebuah gambar + ketik .setppbot\n' +
            '2. Atau kirim gambar dengan caption .setppbot\n\n' +
            '_Gambar akan dijadikan foto profil bot._',
        download_fail: 'Gagal download gambar.',
        too_large: '❌ Gambar terlalu besar (maks 10 MB).',
        success:
            '✅ Foto profil bot berhasil diubah!\n\n' +
            '*Info* :\n' +
            '   ◦ Bot : +{bot}\n' +
            '   ◦ Ukuran asli : {orig} KB\n' +
            '   ◦ Ukuran hasil : {hasil} KB\n' +
            '   ◦ Resolusi : 640x640\n\n' +
            '_Mungkin butuh beberapa saat untuk update di semua chat._',
        err_not_auth: '❌ Gagal: bot tidak punya izin ubah foto profil (mungkin perlu login ulang).',
        err_not_found: '❌ Gagal: bot tidak ditemukan.',
        err_generic: '❌ Gagal ubah foto profil bot: {err}',
    },
    ch: {
        no_image:
            '⚠️ *.setppbot 使用方法：*\n\n' +
            '1. 回复一张图片 + 输入 .setppbot\n' +
            '2. 或发送图片并配文 .setppbot\n\n' +
            '_图片将被设为机器人头像。_',
        download_fail: '下载图片失败。',
        too_large: '❌ 图片太大（最大 10 MB）。',
        success:
            '✅ 机器人头像已成功更改！\n\n' +
            '*信息* ：\n' +
            '   ◦ 机器人 ：+{bot}\n' +
            '   ◦ 原始大小 ：{orig} KB\n' +
            '   ◦ 处理后 ：{hasil} KB\n' +
            '   ◦ 分辨率 ：640x640\n\n' +
            '_在所有聊天中更新可能需要片刻。_',
        err_not_auth: '❌ 失败：机器人无权限更改头像（可能需要重新登录）。',
        err_not_found: '❌ 失败：未找到机器人。',
        err_generic: '❌ 更改机器人头像失败：{err}',
    },
    uk: {
        no_image:
            '⚠️ *How to use .setppbot:*\n\n' +
            '1. Reply an image + type .setppbot\n' +
            '2. Or send an image with caption .setppbot\n\n' +
            '_The image will be set as the bot profile picture._',
        download_fail: 'Failed to download image.',
        too_large: '❌ Image is too large (max 10 MB).',
        success:
            '✅ Bot profile picture updated successfully!\n\n' +
            '*Info* :\n' +
            '   ◦ Bot : +{bot}\n' +
            '   ◦ Original size : {orig} KB\n' +
            '   ◦ Result size : {hasil} KB\n' +
            '   ◦ Resolution : 640x640\n\n' +
            '_May take a moment to update across all chats._',
        err_not_auth: '❌ Failed: bot lacks permission to change profile picture (may need re-login).',
        err_not_found: '❌ Failed: bot not found.',
        err_generic: '❌ Failed to update bot profile picture: {err}',
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, reply, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedImage = quoted?.imageMessage;
    const directImage = msg.message?.imageMessage;
    if (!quotedImage && !directImage) return reply(T(lang, 'no_image'));

    await sendReaction(sock, remoteJid, msg.key, '🖼️');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        if (!buffer || buffer.length === 0) throw new Error(T(lang, 'download_fail'));
        if (buffer.length > 10 * 1024 * 1024) return reply(T(lang, 'too_large'));

        await sendReaction(sock, remoteJid, msg.key, '⏳');

        const processed = await sharp(buffer)
            .resize(640, 640, { fit: 'cover', position: 'centre' })
            .jpeg({ quality: 90 })
            .toBuffer();

        await sock.updateProfilePicture(sock.user.id, processed);

        const botNumber = sock.user?.id?.split(':')[0]?.split('@')[0] || 'Bot';

        await reply(T(lang, 'success', {
            bot: botNumber,
            orig: (buffer.length / 1024).toFixed(1),
            hasil: (processed.length / 1024).toFixed(1),
        }));

        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[setppbot]', err.message);
        const errMsg = err?.message || String(err);

        if (errMsg.includes('not-authorized')) await reply(T(lang, 'err_not_auth'));
        else if (errMsg.includes('item-not-found')) await reply(T(lang, 'err_not_found'));
        else await reply(T(lang, 'err_generic', { err: errMsg }));

        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}