// plugins/owner/addtoken.js
import { findUser, readDb, writeDb } from '../../libx/db.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['addtoken', 'addtok'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Tambahkan token user (khusus owner)';
export const description_ch = '为用户添加代币（仅限主人）';
export const description_uk = 'Add tokens to a user (owner only)';
export const description = description_id;

const TEXT = {
    id: {
        no_arg: '⚠️ Format: .addtoken <62xxx>,<jumlah> atau reply target',
        amount_invalid: 'Jumlah token harus angka',
        format_invalid: 'Format salah. Gunakan: .addtoken 62xxx,100',
        user_not_found: 'User tidak ditemukan di database',
        header: `乂  *ᴀɴɢᴇʟs - ᴀᴅᴅ ᴛᴏᴋᴇɴ*`,
        label_target: 'Target',
        label_added: 'Ditambahkan',
        label_total: 'Total Token',
        added_value: '+{n} token',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        no_arg: '⚠️ 格式：.addtoken <62xxx>,<数量> 或回复目标',
        amount_invalid: '代币数量必须是数字',
        format_invalid: '格式错误。使用：.addtoken 62xxx,100',
        user_not_found: '数据库中未找到用户',
        header: `乂  *ᴀɴɢᴇʟs - 添加代币*`,
        label_target: '目标',
        label_added: '已添加',
        label_total: '代币总数',
        added_value: '+{n} 代币',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        no_arg: '⚠️ Format: .addtoken <62xxx>,<amount> or reply target',
        amount_invalid: 'Token amount must be a number',
        format_invalid: 'Wrong format. Use: .addtoken 62xxx,100',
        user_not_found: 'User not found in database',
        header: `乂  *ᴀɴɢᴇʟs - ᴀᴅᴅ ᴛᴏᴋᴇɴ*`,
        label_target: 'Target',
        label_added: 'Added',
        label_total: 'Total Token',
        added_value: '+{n} token(s)',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text) return reply(T(lang, 'no_arg'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        let targetNomor, targetLid, amount;

        if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            const quoted = msg.message.extendedTextMessage.contextInfo;
            const jid = quoted.participant || quoted.remoteJid || '';
            if (jid.endsWith('@s.whatsapp.net')) targetNomor = jid.split('@')[0];
            else if (jid.endsWith('@lid')) targetLid = jid;

            amount = parseInt(text);
            if (isNaN(amount)) throw new Error(T(lang, 'amount_invalid'));
        } else {
            const parts = text.split(',');
            if (parts.length !== 2) throw new Error(T(lang, 'format_invalid'));
            targetNomor = parts[0].trim();
            amount = parseInt(parts[1].trim());
            if (isNaN(amount)) throw new Error(T(lang, 'amount_invalid'));
        }

        const user = findUser({ lid: targetLid, nomor: targetNomor });
        if (!user) throw new Error(T(lang, 'user_not_found'));

        const db = readDb();
        const u = db.users.find((x) => x.nomor === user.nomor);
        u.token += amount;
        writeDb(db);

        await sendReaction(sock, remoteJid, msg.key, '✅');

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_target')}* : ${user.nomor}\n` +
            `*${T(lang, 'label_added')}* : ${T(lang, 'added_value', { n: amount })}\n` +
            `*${T(lang, 'label_total')}* : ${u.token}\n\n` +
            `${T(lang, 'footer')}`;

        await reply(caption);
    } catch (err) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        await reply(T(lang, 'fail', { err: err.message }));
    }
}