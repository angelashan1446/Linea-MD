// plugins/owner/promoteme.js
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['promoteme', 'jadikanakadmin', 'pm'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Jadikan owner jadi admin grup (khusus owner)';
export const description_ch = '将主人提升为群组管理员（仅限主人）';
export const description_uk = 'Promote owner to group admin (owner only)';
export const description = description_id;

const TEXT = {
    id: {
        only_group: '❌ Command ini hanya bisa digunakan di grup.',
        metadata_fail: '❌ Gagal mengambil data grup.',
        owner_id_fail: '❌ Gagal mendeteksi ID owner.',
        not_in_group: '❌ Owner tidak ditemukan di grup ini.\n\n_Pastikan owner udah masuk grup dulu._',
        already_admin: '⚠️ Owner sudah jadi *admin* di grup ini.',
        success:
            '✅ Owner berhasil di-*promote* jadi admin!\n\n' +
            '*Info* :\n' +
            '   ◦ Grup : {group}\n' +
            '   ◦ Owner : +{owner}',
        fail: '❌ Gagal promote owner: {err}',
        hint_bot_not_admin: '\n\n_💡 Kemungkinan: bot bukan admin grup._',
    },
    ch: {
        only_group: '❌ 此命令仅可在群组中使用。',
        metadata_fail: '❌ 无法获取群组数据。',
        owner_id_fail: '❌ 无法检测主人 ID。',
        not_in_group: '❌ 主人不在此群组中。\n\n_请确保主人已加入群组。_',
        already_admin: '⚠️ 主人已经是本群组的*管理员*。',
        success:
            '✅ 主人已成功被*提升*为管理员！\n\n' +
            '*信息* ：\n' +
            '   ◦ 群组 ：{group}\n' +
            '   ◦ 主人 ：+{owner}',
        fail: '❌ 提升主人失败：{err}',
        hint_bot_not_admin: '\n\n_💡 可能原因：机器人不是群组管理员。_',
    },
    uk: {
        only_group: '❌ This command can only be used in a group.',
        metadata_fail: '❌ Failed to fetch group data.',
        owner_id_fail: '❌ Failed to detect owner ID.',
        not_in_group: '❌ Owner not found in this group.\n\n_Make sure the owner has joined the group first._',
        already_admin: '⚠️ Owner is already an *admin* in this group.',
        success:
            '✅ Owner has been successfully *promoted* to admin!\n\n' +
            '*Info* :\n' +
            '   ◦ Group : {group}\n' +
            '   ◦ Owner : +{owner}',
        fail: '❌ Failed to promote owner: {err}',
        hint_bot_not_admin: '\n\n_💡 Possible reason: the bot is not a group admin._',
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, reply, remoteJid, isGroup, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!isGroup) return reply(T(lang, 'only_group'));

    const groupMetadata = await sock.groupMetadata(remoteJid).catch(() => null);
    if (!groupMetadata) return reply(T(lang, 'metadata_fail'));

    let ownerJid = null;
    if (sender.lid) ownerJid = sender.lid;
    else if (sender.nomor) ownerJid = `${sender.nomor}@s.whatsapp.net`;
    else if (sender.rawJid) ownerJid = sender.rawJid;

    if (!ownerJid) return reply(T(lang, 'owner_id_fail'));

    const ownerParticipant = groupMetadata.participants.find(p =>
        p.id === ownerJid || p.phoneNumber === sender.nomor
    );

    if (!ownerParticipant) return reply(T(lang, 'not_in_group'));

    if (ownerParticipant.admin === 'admin' || ownerParticipant.admin === 'superadmin') {
        return reply(T(lang, 'already_admin'));
    }

    await sendReaction(sock, remoteJid, msg.key, '⬆️');

    try {
        await sock.groupParticipantsUpdate(remoteJid, [ownerParticipant.id], 'promote');
        await reply(T(lang, 'success', {
            group: groupMetadata.subject,
            owner: sender.nomor || sender.lid?.split('@')[0] || 'Unknown',
        }));
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        const errMsg = err?.message || String(err);
        const hint = (errMsg.includes('not-authorized') || errMsg.includes('403'))
            ? T(lang, 'hint_bot_not_admin')
            : '';
        await reply(T(lang, 'fail', { err: errMsg }) + hint);
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}