// plugins/owner/sewabot.js
import { setRent } from '../../libx/grup_db.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['sewabot'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Sewakan bot untuk grup (durasi hari) via grup ini atau link undangan';
export const description_ch = '通过当前群组或邀请链接租用机器人（按天计）';
export const description_uk = 'Rent the bot for a group (days) via this group or invite link';
export const description = description_id;

const TEXT = {
    id: {
        usage:
            `乂  *ᴀɴɢᴇʟs - sᴇᴡᴀ ʙᴏᴛ*\n\n` +
            `📖 *CARA PAKAI*\n\n` +
            `1. *Sewa grup ini* (bot harus sudah di grup):\n` +
            `   .sewabot <hari>\n` +
            `   Contoh: .sewabot 30\n\n` +
            `2. *Sewa grup lain via link* (bot otomatis join):\n` +
            `   .sewabot <linkgrup>,<hari>\n` +
            `   Contoh: .sewabot https://chat.whatsapp.com/ABCxxx,30\n\n` +
            `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
        only_group_mode:
            '❌ Mode ini hanya bisa dipakai di dalam grup.\n\nGunakan mode link: .sewabot <linkgrup>,<hari>',
        invalid_duration: '❌ Durasi tidak valid. Contoh: *.sewabot 30*',
        invalid_link: '❌ Link grup tidak valid.\nContoh: *.sewabot https://chat.whatsapp.com/ABCxxx,30*',
        invite_not_found: '❌ Kode undangan tidak ditemukan di link.',
        processing: '⏳ Memproses sewa grup...\n\n🔗 Link: {link}\n📅 Durasi: {dur} hari',
        invalid_info: '❌ Link grup tidak valid atau info grup tidak terbaca.',
        join_fail_header: '❌ *Gagal join grup.*\n\n{fail}\n\n_Sewa TIDAK dicatat._',
        fail_reason_expired: 'Link sudah expired / direset admin.',
        fail_reason_forbidden: 'Grup menolak bot (butuh persetujuan admin).',
        fail_reason_full: 'Grup sudah penuh.',
        success_current:
            `乂  *ᴀɴɢᴇʟs - sᴇᴡᴀ ʙᴇʀʜᴀsɪʟ* ✅\n\n` +
            `📌 Grup      : {id}\n` +
            `📅 Durasi    : {dur} hari\n` +
            `⏰ Expired   : {exp}\n\n` +
            `_Bot akan aktif melayani grup ini sampai tanggal tersebut._`,
        success_join:
            `乂  *ᴀɴɢᴇʟs - sᴇᴡᴀ ʙᴇʀʜᴀsɪʟ* ✅\n\n` +
            `📌 Nama Grup : {name}\n` +
            `📌 ID Grup   : {id}\n` +
            `📅 Durasi    : {dur} hari\n` +
            `⏰ Expired   : {exp}\n\n` +
            `_Bot sudah masuk ke grup dan siap melayani._`,
        group_notif:
            `乂  *ᴀɴɢᴇʟs - ʙᴏᴛ ᴛᴇʟᴀʜ ᴅɪsᴇᴡᴀ*\n\n` +
            `👋 Bot Angels telah disewa di grup ini.\n\n` +
            `📅 Durasi   : {dur} hari\n` +
            `⏰ Expired  : {exp}\n\n` +
            `Ketik *.on* untuk mengaktifkan fitur grup.\n` +
            `Ketik *.off* untuk menonaktifkan fitur grup.`,
        generic_fail: '❌ Gagal memproses sewa: {err}',
    },
    ch: {
        usage:
            `乂  *ᴀɴɢᴇʟs - 租用机器人*\n\n` +
            `📖 *使用方法*\n\n` +
            `1. *租用本群*（机器人需已在群内）：\n` +
            `   .sewabot <天>\n` +
            `   示例：.sewabot 30\n\n` +
            `2. *通过链接租用其他群*（机器人自动加入）：\n` +
            `   .sewabot <群组链接>,<天>\n` +
            `   示例：.sewabot https://chat.whatsapp.com/ABCxxx,30\n\n` +
            `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
        only_group_mode:
            '❌ 该模式仅可在群组内使用。\n\n请使用链接模式：.sewabot <群组链接>,<天>',
        invalid_duration: '❌ 时长无效。示例：*.sewabot 30*',
        invalid_link: '❌ 群组链接无效。\n示例：*.sewabot https://chat.whatsapp.com/ABCxxx,30*',
        invite_not_found: '❌ 链接中未找到邀请码。',
        processing: '⏳ 正在处理租用...\n\n🔗 链接：{link}\n📅 时长：{dur} 天',
        invalid_info: '❌ 群组链接无效或无法读取群组信息。',
        join_fail_header: '❌ *加入群组失败。*\n\n{fail}\n\n_租用未记录。_',
        fail_reason_expired: '链接已过期 / 被管理员重置。',
        fail_reason_forbidden: '群组拒绝机器人（需要管理员批准）。',
        fail_reason_full: '群组已满。',
        success_current:
            `乂  *ᴀɴɢᴇʟs - 租用成功* ✅\n\n` +
            `📌 群组      : {id}\n` +
            `📅 时长      : {dur} 天\n` +
            `⏰ 到期      : {exp}\n\n` +
            `_机器人将服务本群至上述日期。_`,
        success_join:
            `乂  *ᴀɴɢᴇʟs - 租用成功* ✅\n\n` +
            `📌 群组名称  : {name}\n` +
            `📌 群组 ID   : {id}\n` +
            `📅 时长      : {dur} 天\n` +
            `⏰ 到期      : {exp}\n\n` +
            `_机器人已进入群组并准备就绪。_`,
        group_notif:
            `乂  *ᴀɴɢᴇʟs - 机器人已被租用*\n\n` +
            `👋 Angels 机器人已被租用到本群组。\n\n` +
            `📅 时长      : {dur} 天\n` +
            `⏰ 到期      : {exp}\n\n` +
            `输入 *.on* 启用群组功能。\n` +
            `输入 *.off* 关闭群组功能。`,
        generic_fail: '❌ 处理租用失败：{err}',
    },
    uk: {
        usage:
            `乂  *ᴀɴɢᴇʟs - ʀᴇɴᴛ ʙᴏᴛ*\n\n` +
            `📖 *HOW TO USE*\n\n` +
            `1. *Rent this group* (bot must be in the group):\n` +
            `   .sewabot <days>\n` +
            `   Example: .sewabot 30\n\n` +
            `2. *Rent another group via link* (bot auto joins):\n` +
            `   .sewabot <grouplink>,<days>\n` +
            `   Example: .sewabot https://chat.whatsapp.com/ABCxxx,30\n\n` +
            `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
        only_group_mode:
            '❌ This mode can only be used inside a group.\n\nUse link mode: .sewabot <grouplink>,<days>',
        invalid_duration: '❌ Invalid duration. Example: *.sewabot 30*',
        invalid_link: '❌ Invalid group link.\nExample: *.sewabot https://chat.whatsapp.com/ABCxxx,30*',
        invite_not_found: '❌ Invite code not found in the link.',
        processing: '⏳ Processing group rental...\n\n🔗 Link: {link}\n📅 Duration: {dur} days',
        invalid_info: '❌ Invalid group link or group info unreadable.',
        join_fail_header: '❌ *Failed to join group.*\n\n{fail}\n\n_Rental NOT recorded._',
        fail_reason_expired: 'Link expired / reset by admin.',
        fail_reason_forbidden: 'Group rejects the bot (requires admin approval).',
        fail_reason_full: 'Group is full.',
        success_current:
            `乂  *ᴀɴɢᴇʟs - ʀᴇɴᴛᴀʟ ꜱᴜᴄᴄᴇꜱꜱ* ✅\n\n` +
            `📌 Group      : {id}\n` +
            `📅 Duration   : {dur} days\n` +
            `⏰ Expires    : {exp}\n\n` +
            `_The bot will serve this group until the date above._`,
        success_join:
            `乂  *ᴀɴɢᴇʟs - ʀᴇɴᴛᴀʟ ꜱᴜᴄᴄᴇꜱꜱ* ✅\n\n` +
            `📌 Group Name : {name}\n` +
            `📌 Group ID   : {id}\n` +
            `📅 Duration   : {dur} days\n` +
            `⏰ Expires    : {exp}\n\n` +
            `_The bot has joined the group and is ready to serve._`,
        group_notif:
            `乂  *ᴀɴɢᴇʟs - ʙᴏᴛ ʜᴀꜱ ʙᴇᴇɴ ʀᴇɴᴛᴇᴅ*\n\n` +
            `👋 Angels bot has been rented to this group.\n\n` +
            `📅 Duration  : {dur} days\n` +
            `⏰ Expires   : {exp}\n\n` +
            `Type *.on* to enable group features.\n` +
            `Type *.off* to disable group features.`,
        generic_fail: '❌ Failed to process rental: {err}',
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, isGroup, text, args, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text) return reply(T(lang, 'usage'));

    // ============================================================
    // MODE 1: .sewabot 30
    // ============================================================
    if (!text.includes(',')) {
        if (!isGroup) return reply(T(lang, 'only_group_mode'));

        const durasi = parseInt(args[0], 10);
        if (!durasi || durasi <= 0) return reply(T(lang, 'invalid_duration'));

        const expired = new Date();
        expired.setDate(expired.getDate() + durasi);
        const groupId = remoteJid.split('@')[0];

        setRent(groupId, expired.toISOString());

        return reply(T(lang, 'success_current', {
            id: groupId,
            dur: durasi,
            exp: expired.toLocaleDateString('id-ID', {
                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Jakarta',
            }),
        }));
    }

    // ============================================================
    // MODE 2: .sewabot <link>,<hari>
    // ============================================================
    const parts = text.split(',');
    const link = parts[0]?.trim();
    const durasi = parseInt(parts[1]?.trim(), 10);

    if (!link || !link.includes('chat.whatsapp.com')) return reply(T(lang, 'invalid_link'));
    if (!durasi || durasi <= 0) return reply(T(lang, 'invalid_link'));

    const inviteCode = link.split('chat.whatsapp.com/')[1]?.split(/[?&]/)[0];
    if (!inviteCode) return reply(T(lang, 'invite_not_found'));

    await reply(T(lang, 'processing', { link, dur: durasi }));

    try {
        const infoGrub = await sock.groupGetInviteInfo(inviteCode);
        if (!infoGrub?.jid) return reply(T(lang, 'invalid_info'));

        const groupJid = infoGrub.jid;
        const groupId = groupJid.split('@')[0];
        const groupName = infoGrub.subject || groupId;

        const expired = new Date();
        expired.setDate(expired.getDate() + durasi);
        setRent(groupId, expired.toISOString());

        let joinFailed = false;
        let failReason = '';

        try {
            await sock.groupAcceptInvite(inviteCode);
        } catch (err) {
            const errMsg = String(err?.message || err).toLowerCase();

            if (
                errMsg.includes('expected <group> node') ||
                errMsg.includes('409') ||
                errMsg.includes('conflict') ||
                errMsg.includes('already') ||
                errMsg.includes('not-authorized')
            ) {
                console.log(`[SEWABOT] Join "gagal" tapi dianggap sukses: ${errMsg}`);
            } else if (errMsg.includes('gone') || errMsg.includes('410')) {
                joinFailed = true;
                failReason = T(lang, 'fail_reason_expired');
            } else if (errMsg.includes('forbidden') || errMsg.includes('403')) {
                joinFailed = true;
                failReason = T(lang, 'fail_reason_forbidden');
            } else if (errMsg.includes('resource-limit') || errMsg.includes('full')) {
                joinFailed = true;
                failReason = T(lang, 'fail_reason_full');
            } else {
                joinFailed = true;
                failReason = errMsg;
            }
        }

        if (joinFailed) {
            setRent(groupId, null);
            return reply(T(lang, 'join_fail_header', { fail: failReason }));
        }

        try {
            await sock.sendMessage(groupJid, {
                text: T(lang, 'group_notif', {
                    dur: durasi,
                    exp: expired.toLocaleDateString('id-ID', {
                        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Jakarta',
                    }),
                }),
            });
        } catch (e) {
            console.log(`[SEWABOT] Gagal kirim notif ke grup: ${e.message}`);
        }

        return reply(T(lang, 'success_join', {
            name: groupName,
            id: groupId,
            dur: durasi,
            exp: expired.toLocaleDateString('id-ID', {
                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Jakarta',
            }),
        }));

    } catch (error) {
        console.error('[SEWABOT]', error);
        return reply(T(lang, 'generic_fail', { err: error.message }));
    }
}