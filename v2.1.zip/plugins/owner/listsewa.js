// plugins/owner/listsewa.js
import fs from 'fs';
import path from 'path';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['listsewa', 'sewalist', 'daftarsewa'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Lihat daftar semua grup yang sedang disewa (khusus owner)';
export const description_ch = '查看所有已租用群组列表（仅限主人）';
export const description_uk = 'View all rented groups (owner only)';
export const description = description_id;

const DB_FILE = path.join(process.cwd(), 'db', 'grups.json');

const TEXT = {
    id: {
        db_missing: '❌ Belum ada data sewa.',
        db_fail: '❌ Gagal baca database: {err}',
        empty:
            `乂  *ᴀɴɢᴇʟs - ʟɪsᴛ sᴇᴡᴀ*\n\n` +
            `📭 Belum ada grup yang disewa.\n\n` +
            `_Ketik .sewabot untuk mulai sewa_`,
        header: `乂  *ᴀɴɢᴇʟs - ʟɪsᴛ sᴇᴡᴀ*`,
        stat_title: '📊 *Statistik*',
        stat_total: 'Total: {n} grup',
        stat_active: 'Aktif: {n}',
        stat_expired: 'Expired: {n}',
        filter_label: '🔍 *Filter:* {f} ({n} hasil)',
        list_title: '📋 *Daftar Sewa:*',
        label_bot: 'Bot',
        label_feature: '{n} fitur aktif',
        active_label: 'Aktif ({sisa})',
        expired_label: 'Expired ({sisa})',
        filter_hint: '_Filter: .listsewa aktif / expired / all_',
        truncated: '_... (truncated)_',
        ago_days: '{d} hari lalu',
        ago_hours: '{h} jam lalu',
        ago_just: 'Baru aja expired',
        left_days: '{d}h {h}j',
        left_hours: '{h}j {m}m',
        left_minutes: '{m} menit',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        db_missing: '❌ 暂无租用数据。',
        db_fail: '❌ 读取数据库失败：{err}',
        empty:
            `乂  *ᴀɴɢᴇʟs - 租用列表*\n\n` +
            `📭 暂无租用的群组。\n\n` +
            `_输入 .sewabot 开始租用_`,
        header: `乂  *ᴀɴɢᴇʟs - 租用列表*`,
        stat_title: '📊 *统计*',
        stat_total: '总计：{n} 个群组',
        stat_active: '活跃：{n}',
        stat_expired: '已过期：{n}',
        filter_label: '🔍 *筛选：* {f}（{n} 条结果）',
        list_title: '📋 *租用列表：*',
        label_bot: '机器人',
        label_feature: '{n} 个功能已启用',
        active_label: '活跃（{sisa}）',
        expired_label: '已过期（{sisa}）',
        filter_hint: '_筛选：.listsewa aktif / expired / all_',
        truncated: '_...（已截断）_',
        ago_days: '{d} 天前',
        ago_hours: '{h} 小时前',
        ago_just: '刚刚过期',
        left_days: '{d}天{h}时',
        left_hours: '{h}时{m}分',
        left_minutes: '{m} 分钟',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        db_missing: '❌ No rental data yet.',
        db_fail: '❌ Failed to read database: {err}',
        empty:
            `乂  *ᴀɴɢᴇʟs - ʀᴇɴᴛᴀʟ ʟɪsᴛ*\n\n` +
            `📭 No rented groups yet.\n\n` +
            `_Type .sewabot to start renting_`,
        header: `乂  *ᴀɴɢᴇʟs - ʀᴇɴᴛᴀʟ ʟɪsᴛ*`,
        stat_title: '📊 *Statistics*',
        stat_total: 'Total: {n} group(s)',
        stat_active: 'Active: {n}',
        stat_expired: 'Expired: {n}',
        filter_label: '🔍 *Filter:* {f} ({n} results)',
        list_title: '📋 *Rental List:*',
        label_bot: 'Bot',
        label_feature: '{n} active feature(s)',
        active_label: 'Active ({sisa})',
        expired_label: 'Expired ({sisa})',
        filter_hint: '_Filter: .listsewa aktif / expired / all_',
        truncated: '_... (truncated)_',
        ago_days: '{d} days ago',
        ago_hours: '{h} hours ago',
        ago_just: 'Just expired',
        left_days: '{d}d {h}h',
        left_hours: '{h}h {m}m',
        left_minutes: '{m} minutes',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, args, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    await sendReaction(sock, remoteJid, msg.key, '📋');

    let db;
    try {
        if (!fs.existsSync(DB_FILE)) return reply(T(lang, 'db_missing'));
        db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    } catch (e) {
        return reply(T(lang, 'db_fail', { err: e.message }));
    }

    const groups = db.groups || {};
    const now = Date.now();

    const sewaList = [];
    for (const [groupId, data] of Object.entries(groups)) {
        if (!data?.rent) continue;
        const expiredAt = new Date(data.rent).getTime();
        const isActive = expiredAt > now;

        sewaList.push({
            groupId,
            expiredAt,
            isActive,
            botId: data.bot_id || null,
            featureCount: data.feature
                ? Object.values(data.feature).filter(Boolean).length
                : 0,
        });
    }

    if (sewaList.length === 0) return reply(T(lang, 'empty'));

    sewaList.sort((a, b) => {
        if (a.isActive !== b.isActive) return a.isActive ? -1 : 1;
        return a.expiredAt - b.expiredAt;
    });

    const filterArg = (args[0] || '').toLowerCase();
    let filtered = sewaList;
    if (filterArg === 'aktif' || filterArg === 'active') {
        filtered = sewaList.filter(s => s.isActive);
    } else if (filterArg === 'expired' || filterArg === 'mati') {
        filtered = sewaList.filter(s => !s.isActive);
    }

    function formatSisa(expiredAt) {
        const diff = expiredAt - now;
        if (diff <= 0) {
            const ago = Math.abs(diff);
            const d = Math.floor(ago / (24 * 3600 * 1000));
            const h = Math.floor((ago % (24 * 3600 * 1000)) / (3600 * 1000));
            if (d > 0) return T(lang, 'ago_days', { d });
            if (h > 0) return T(lang, 'ago_hours', { h });
            return T(lang, 'ago_just');
        }
        const d = Math.floor(diff / (24 * 3600 * 1000));
        const h = Math.floor((diff % (24 * 3600 * 1000)) / (3600 * 1000));
        const m = Math.floor((diff % (3600 * 1000)) / (60 * 1000));
        if (d > 0) return T(lang, 'left_days', { d, h });
        if (h > 0) return T(lang, 'left_hours', { h, m });
        return T(lang, 'left_minutes', { m });
    }

    function formatTanggal(ts) {
        return new Date(ts).toLocaleString('id-ID', {
            day: '2-digit', month: 'short', year: 'numeric',
            hour: '2-digit', minute: '2-digit',
            timeZone: 'Asia/Jakarta',
        });
    }

    const activeCount = sewaList.filter(s => s.isActive).length;
    const expiredCount = sewaList.length - activeCount;

    let text = `${T(lang, 'header')}\n\n`;
    text += `${T(lang, 'stat_title')}\n`;
    text += `• ${T(lang, 'stat_total', { n: sewaList.length })}\n`;
    text += `• ${T(lang, 'stat_active', { n: activeCount })}\n`;
    text += `• ${T(lang, 'stat_expired', { n: expiredCount })}\n\n`;

    if (filterArg) {
        text += `${T(lang, 'filter_label', { f: filterArg, n: filtered.length })}\n\n`;
    }

    text += `${T(lang, 'list_title')}\n\n`;

    filtered.forEach((s, i) => {
        const status = s.isActive ? '✅' : '❌';
        text += `${i + 1}. ${status} *${s.groupId}*\n`;
        if (s.botId) text += `   🤖 ${T(lang, 'label_bot')}: +${s.botId}\n`;
        text += `   ⏰ ${formatTanggal(s.expiredAt)}\n`;
        text += `   📊 ${s.isActive ? T(lang, 'active_label', { sisa: formatSisa(s.expiredAt) }) : T(lang, 'expired_label', { sisa: formatSisa(s.expiredAt) })}\n`;
        text += `   ⚙️ ${T(lang, 'label_feature', { n: s.featureCount })}\n\n`;
    });

    text += `${T(lang, 'filter_hint')}\n\n${T(lang, 'footer')}`;

    if (text.length > 60000) {
        text = text.slice(0, 60000) + '\n\n' + T(lang, 'truncated');
    }

    await reply(text);
    await sendReaction(sock, remoteJid, msg.key, '✅');
}