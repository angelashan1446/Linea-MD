// plugins/owner/setname.js
import { setAlias } from '../../libx/utils/alias_numberbot.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['setname', 'setalias', 'botname'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Kasih nama alias ke nomor bot (khusus owner)';
export const description_ch = '为机器人号码设置别名（仅限主人）';
export const description_uk = 'Set an alias for the bot number (owner only)';
export const description = description_id;

const TEXT = {
    id: {
        usage:
            `乂  *sᴇᴛ ɴᴀᴍᴀ ʙᴏᴛ*\n\n` +
            `📖 *Format:* .setname <nomor>,<alias>\n\n` +
            `*Contoh:*\n` +
            `• .setname 6281111111111,linea1\n` +
            `• .setname 6282222222222,jualan\n\n` +
            `_Setelah di-set, admin grup bisa pakai .setbot linea1_`,
        format_invalid: '❌ Format salah.\nContoh: *.setname 6281111111111,linea1*',
        success: '✅ {msg}',
        fail: '❌ {msg}',
        error: '❌ Error: {err}',
    },
    ch: {
        usage:
            `乂  *设置机器人别名*\n\n` +
            `📖 *格式：* .setname <号码>,<别名>\n\n` +
            `*示例：*\n` +
            `• .setname 6281111111111,linea1\n` +
            `• .setname 6282222222222,jualan\n\n` +
            `_设置后，群组管理员可用 .setbot linea1_`,
        format_invalid: '❌ 格式错误。\n示例：*.setname 6281111111111,linea1*',
        success: '✅ {msg}',
        fail: '❌ {msg}',
        error: '❌ 错误：{err}',
    },
    uk: {
        usage:
            `乂  *sᴇᴛ ʙᴏᴛ ᴀʟɪᴀs*\n\n` +
            `📖 *Format:* .setname <number>,<alias>\n\n` +
            `*Example:*\n` +
            `• .setname 6281111111111,linea1\n` +
            `• .setname 6282222222222,jualan\n\n` +
            `_After setting, group admins can use .setbot linea1_`,
        format_invalid: '❌ Wrong format.\nExample: *.setname 6281111111111,linea1*',
        success: '✅ {msg}',
        fail: '❌ {msg}',
        error: '❌ Error: {err}',
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, args, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!args[0]) return reply(T(lang, 'usage'));

    let nomor, alias;
    const raw = args.join(' ');

    if (raw.includes(',')) {
        [nomor, alias] = raw.split(',').map(s => s.trim());
    } else {
        const parts = raw.split(/\s+/);
        nomor = parts[0];
        alias = parts[1];
    }

    if (!nomor || !alias) {
        return reply(T(lang, 'format_invalid'));
    }

    await sendReaction(sock, remoteJid, msg.key, '🏷️');

    try {
        const result = setAlias(alias, nomor);
        if (!result.ok) {
            await sendReaction(sock, remoteJid, msg.key, '❌');
            return reply(T(lang, 'fail', { msg: result.message }));
        }
        await sendReaction(sock, remoteJid, msg.key, '✅');
        return reply(T(lang, 'success', { msg: result.message }));
    } catch (err) {
        console.error('[setname]', err);
        await sendReaction(sock, remoteJid, msg.key, '❌');
        return reply(T(lang, 'error', { err: err.message }));
    }
}