// plugins/owner/addprem.js
import { findUser, setPremium } from '../../libx/db.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['addprem', 'addpremium'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Tambahkan masa premium user (khusus owner)';
export const description_ch = '为用户添加高级会员时长（仅限主人）';
export const description_uk = 'Add premium duration to a user (owner only)';
export const description = description_id;

const TEXT = {
    id: {
        no_arg: '⚠️ Format: .addprem <62xxx>,<hari> atau .addprem <hari> (reply pesan)',
        days_invalid: 'Jumlah hari harus angka',
        format_invalid: 'Format salah. Gunakan: .addprem 62xxx,30',
        user_not_found: 'User tidak ditemukan di database',
        header: `乂  *ᴀɴɢᴇʟs - ᴀᴅᴅ ᴘʀᴇᴍɪᴜᴍ*`,
        label_target: 'Target',
        label_duration: 'Durasi',
        label_expired: 'Kedaluwarsa',
        duration_value: '{d} hari',
        fail: '❌ Gagal: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        no_arg: '⚠️ 格式：.addprem <62xxx>,<天> 或 .addprem <天>（回复消息）',
        days_invalid: '天数必须是数字',
        format_invalid: '格式错误。使用：.addprem 62xxx,30',
        user_not_found: '数据库中未找到用户',
        header: `乂  *ᴀɴɢᴇʟs - 添加高级会员*`,
        label_target: '目标',
        label_duration: '时长',
        label_expired: '到期时间',
        duration_value: '{d} 天',
        fail: '❌ 失败：{err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        no_arg: '⚠️ Format: .addprem <62xxx>,<days> or .addprem <days> (reply message)',
        days_invalid: 'Days must be a number',
        format_invalid: 'Wrong format. Use: .addprem 62xxx,30',
        user_not_found: 'User not found in database',
        header: `乂  *ᴀɴɢᴇʟs - ᴀᴅᴅ ᴘʀᴇᴍɪᴜᴍ*`,
        label_target: 'Target',
        label_duration: 'Duration',
        label_expired: 'Expires',
        duration_value: '{d} days',
        fail: '❌ Failed: {err}',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text) return reply(T(lang, 'no_arg'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        let targetNomor, targetLid, days;

        if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            const quoted = msg.message.extendedTextMessage.contextInfo;
            const jid = quoted.participant || quoted.remoteJid || '';
            if (jid.endsWith('@s.whatsapp.net')) targetNomor = jid.split('@')[0];
            else if (jid.endsWith('@lid')) targetLid = jid;

            days = parseInt(text);
            if (isNaN(days)) throw new Error(T(lang, 'days_invalid'));
        } else {
            const parts = text.split(',');
            if (parts.length !== 2) throw new Error(T(lang, 'format_invalid'));
            targetNomor = parts[0].trim();
            days = parseInt(parts[1].trim());
            if (isNaN(days)) throw new Error(T(lang, 'days_invalid'));
        }

        const user = findUser({ lid: targetLid, nomor: targetNomor });
        if (!user) throw new Error(T(lang, 'user_not_found'));

        const now = new Date();
        const currentExpired = user.premium ? new Date(user.premium) : null;
        const baseDate = currentExpired && currentExpired > now ? currentExpired : now;
        baseDate.setDate(baseDate.getDate() + days);

        setPremium(user.nomor, baseDate.toISOString());

        await sendReaction(sock, remoteJid, msg.key, '✅');

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_target')}* : ${user.nomor}\n` +
            `*${T(lang, 'label_duration')}* : ${T(lang, 'duration_value', { d: days })}\n` +
            `*${T(lang, 'label_expired')}* : ${baseDate.toLocaleDateString('id-ID', { dateStyle: 'long' })}\n\n` +
            `${T(lang, 'footer')}`;

        await reply(caption);
    } catch (err) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        await reply(T(lang, 'fail', { err: err.message }));
    }
}