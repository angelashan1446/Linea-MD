// plugins/owner/selft.js
import { isSelft, setSelft } from '../../libx/system.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['selft', 'self'];
export const only_owner = true;
export const only_premium = false;
export const token_usage = 0;

export const description_id = 'Aktifkan/matikan self mode — bot hanya respon owner (khusus owner)';
export const description_ch = '开启/关闭自用模式 — 机器人仅响应主人（仅限主人）';
export const description_uk = 'Enable/disable self mode — bot only responds to owner (owner only)';
export const description = description_id;

const TEXT = {
    id: {
        status_header: `乂  *ᴀɴɢᴇʟs - sᴇʟғ ᴍᴏᴅᴇ*`,
        status_on: '✅ *ON* (hanya owner)',
        status_off: '❌ *OFF* (semua user)',
        status_line: 'Status : {v}',
        how_to: '*Cara pakai:*',
        how_on: '• {prefix}selft on  → hanya owner yang bisa pakai',
        how_off: '• {prefix}selft off → semua user bisa pakai',
        invalid_arg: '❌ Argumen tidak valid.\nGunakan: *{prefix}selft on* atau *{prefix}selft off*',
        already: '⚠️ Selft mode udah *{arg}* dari tadi.',
        save_fail: '❌ Gagal menyimpan konfigurasi. Cek log server.',
        on_header: `乂  *ᴀɴɢᴇʟs - sᴇʟғ ᴍᴏᴅᴇ ᴏɴ*`,
        off_header: `乂  *ᴀɴɢᴇʟs - sᴇʟғ ᴍᴏᴅᴇ ᴏғғ*`,
        on_body: '🔒 Bot sekarang *HANYA* merespon *owner*.\nSemua user lain akan diabaikan.',
        off_body: '🔓 Bot sekarang merespon *semua user* seperti biasa.',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        status_header: `乂  *ᴀɴɢᴇʟs - 自用模式*`,
        status_on: '✅ *开启*（仅主人）',
        status_off: '❌ *关闭*（所有用户）',
        status_line: '状态：{v}',
        how_to: '*使用方法：*',
        how_on: '• {prefix}selft on  → 仅主人可用',
        how_off: '• {prefix}selft off → 所有用户可用',
        invalid_arg: '❌ 参数无效。\n使用：*{prefix}selft on* 或 *{prefix}selft off*',
        already: '⚠️ 自用模式此前已处于 *{arg}* 状态。',
        save_fail: '❌ 保存配置失败。请检查服务器日志。',
        on_header: `乂  *ᴀɴɢᴇʟs - 自用模式开启*`,
        off_header: `乂  *ᴀɴɢᴇʟs - 自用模式关闭*`,
        on_body: '🔒 机器人现在*仅响应主人*。\n其他用户将被忽略。',
        off_body: '🔓 机器人现在响应*所有用户*。',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        status_header: `乂  *ᴀɴɢᴇʟs - sᴇʟғ ᴍᴏᴅᴇ*`,
        status_on: '✅ *ON* (owner only)',
        status_off: '❌ *OFF* (all users)',
        status_line: 'Status : {v}',
        how_to: '*How to use:*',
        how_on: '• {prefix}selft on  → only owner can use',
        how_off: '• {prefix}selft off → all users can use',
        invalid_arg: '❌ Invalid argument.\nUse: *{prefix}selft on* or *{prefix}selft off*',
        already: '⚠️ Self mode was already *{arg}*.',
        save_fail: '❌ Failed to save configuration. Check server logs.',
        on_header: `乂  *ᴀɴɢᴇʟs - sᴇʟғ ᴍᴏᴅᴇ ᴏɴ*`,
        off_header: `乂  *ᴀɴɢᴇʟs - sᴇʟғ ᴍᴏᴅᴇ ᴏғғ*`,
        on_body: '🔒 Bot now *ONLY* responds to *owner*.\nAll other users will be ignored.',
        off_body: '🔓 Bot now responds to *all users* as usual.',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, remoteJid, msg, reply, args, prefix, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const arg = (args[0] || '').toLowerCase();

    if (!arg) {
        const status = isSelft();
        return reply(
            `${T(lang, 'status_header')}\n\n` +
            `${T(lang, 'status_line', { v: status ? T(lang, 'status_on') : T(lang, 'status_off') })}\n\n` +
            `${T(lang, 'how_to')}\n` +
            `${T(lang, 'how_on', { prefix })}\n` +
            `${T(lang, 'how_off', { prefix })}\n\n` +
            `${T(lang, 'footer')}`
        );
    }

    if (arg !== 'on' && arg !== 'off') {
        return reply(T(lang, 'invalid_arg', { prefix }));
    }

    const value = arg === 'on';
    const current = isSelft();

    if (current === value) {
        return reply(T(lang, 'already', { arg: arg.toUpperCase() }));
    }

    await sendReaction(sock, remoteJid, msg.key, value ? '🔒' : '🔓');

    const success = setSelft(value);
    if (!success) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        return reply(T(lang, 'save_fail'));
    }

    await reply(
        `${value ? T(lang, 'on_header') : T(lang, 'off_header')}\n\n` +
        `${value ? T(lang, 'on_body') : T(lang, 'off_body')}\n\n` +
        `${T(lang, 'footer')}`
    );

    await sendReaction(sock, remoteJid, msg.key, '✅');
}