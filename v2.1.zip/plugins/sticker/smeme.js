// plugins/maker/smeme.js
// Buat sticker meme dari gambar/sticker + teks atas | bawah — multi-bahasa.

import sharp from 'sharp';
import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import fs from 'fs';
import path from 'path';
import axios from 'axios';
import { sendReaction, sendSticker } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['smeme'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 5;

export const description_id = 'Buat sticker meme dari gambar/sticker + teks atas | bawah';
export const description_ch = '根据图片/贴纸 + 上下文本生成表情包贴纸';
export const description_uk = 'Create a meme sticker from image/sticker + top | bottom text';
export const description = description_id;

const TEXT = {
    id: {
        no_text:
            '⚠️ *Cara pakai:*\nReply gambar/sticker dengan teks!\n\n' +
            '📌 *Contoh:*\n.smeme Aku sayang kamu ❤️ | Kamu hebat 🚀\n\n' +
            '*Maksimal 3 kata per bagian!*',
        no_media:
            '⚠️ *Media tidak ditemukan.*\n\n' +
            'Kamu harus me-reply sebuah gambar atau sticker dengan command ini.\n\n' +
            '📌 *Contoh:*\n.smeme Aku sayang kamu ❤️ | Kamu hebat 🚀',
        too_many_words:
            '❌ *Maksimal 3 kata per bagian!*\n\n' +
            '📝 *Contoh:*\n.smeme Aku sayang kamu ❤️ | Kamu hebat 🚀',
        fail: '❌ Gagal membuat sticker.\n{err}',
    },
    ch: {
        no_text:
            '⚠️ *使用方法：*\n回复图片/贴纸并输入文本！\n\n' +
            '📌 *示例：*\n.smeme 我爱你 ❤️ | 你真棒 🚀\n\n' +
            '*每部分最多 3 个词！*',
        no_media:
            '⚠️ *未找到媒体。*\n\n' +
            '你需要回复一张图片或贴纸来使用此命令。\n\n' +
            '📌 *示例：*\n.smeme 我爱你 ❤️ | 你真棒 🚀',
        too_many_words:
            '❌ *每部分最多 3 个词！*\n\n' +
            '📝 *示例：*\n.smeme 我爱你 ❤️ | 你真棒 🚀',
        fail: '❌ 创建贴纸失败。\n{err}',
    },
    uk: {
        no_text:
            '⚠️ *How to use:*\nReply to an image/sticker with text!\n\n' +
            '📌 *Example:*\n.smeme I love you ❤️ | You are awesome 🚀\n\n' +
            '*Max 3 words per section!*',
        no_media:
            '⚠️ *Media not found.*\n\n' +
            'You must reply to an image or sticker with this command.\n\n' +
            '📌 *Example:*\n.smeme I love you ❤️ | You are awesome 🚀',
        too_many_words:
            '❌ *Max 3 words per section!*\n\n' +
            '📝 *Example:*\n.smeme I love you ❤️ | You are awesome 🚀',
        fail: '❌ Failed to create sticker.\n{err}',
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

const ASSETS_FONTS = path.join(process.cwd(), 'assets', 'fonts');
const EMOJI_JSON_URL = 'https://media.githubusercontent.com/media/Ditzzx-vibecoder/entahlah/main/emoji-apple.json';
const EMOJI_JSON_LOCAL = path.join(ASSETS_FONTS, 'emoji-apple-image.json');

if (!fs.existsSync(ASSETS_FONTS)) {
    try { fs.mkdirSync(ASSETS_FONTS, { recursive: true }); } catch {}
}

let FONT_PATH = null;
const fontCandidates = [
    path.join(ASSETS_FONTS, 'Epep.ttf'),
    path.join(ASSETS_FONTS, 'Roboto-Bold.ttf'),
    path.join(process.cwd(), 'assets/fonts/Epep.ttf'),
];
for (const p of fontCandidates) {
    if (fs.existsSync(p)) { FONT_PATH = p; break; }
}
if (FONT_PATH) {
    try { GlobalFonts.registerFromPath(FONT_PATH, 'Epep'); } catch {}
}

let appleEmojiMap = null;
const emojiCache = new Map();

async function loadEmojiMap() {
    if (appleEmojiMap) return appleEmojiMap;
    if (!fs.existsSync(EMOJI_JSON_LOCAL)) {
        try {
            const res = await axios.get(EMOJI_JSON_URL, { responseType: 'arraybuffer', timeout: 10000 });
            fs.writeFileSync(EMOJI_JSON_LOCAL, Buffer.from(res.data));
        } catch {
            appleEmojiMap = {};
            return appleEmojiMap;
        }
    }
    try {
        appleEmojiMap = JSON.parse(fs.readFileSync(EMOJI_JSON_LOCAL, 'utf-8'));
    } catch {
        appleEmojiMap = {};
    }
    return appleEmojiMap;
}

function emojiToUnicode(emoji) {
    return [...emoji].map(c => c.codePointAt(0).toString(16).padStart(4, '0')).join('-');
}

async function getEmojiImage(emoji) {
    if (emojiCache.has(emoji)) return emojiCache.get(emoji);
    const map = await loadEmojiMap();
    const base = emojiToUnicode(emoji);
    const variants = [base, base.replace(/-fe0f/gi, ''), base.toUpperCase()];
    let b64 = null;
    for (const v of variants) {
        if (map[v]) { b64 = map[v]; break; }
    }
    if (!b64) return null;
    try {
        const img = await loadImage(Buffer.from(b64, 'base64'));
        emojiCache.set(emoji, img);
        return img;
    } catch {
        return null;
    }
}

const EMOJI_REGEX = /(\p{Emoji_Modifier_Base}\p{Emoji_Modifier}|\p{Emoji_Presentation}\uFE0F?|\p{Emoji}\uFE0F|[\u{1F1E0}-\u{1F1FF}]{2}|\p{Extended_Pictographic}\uFE0F?)/gu;

function parseTextAndEmojis(textStr) {
    const tokens = [];
    const chars = [...textStr];
    let currentText = '';
    for (let i = 0; i < chars.length; i++) {
        EMOJI_REGEX.lastIndex = 0;
        if (EMOJI_REGEX.test(chars[i])) {
            if (currentText) { tokens.push({ type: 'text', value: currentText }); currentText = ''; }
            let emojiVal = chars[i];
            if (chars[i + 1] === '\uFE0F') { emojiVal += chars[i + 1]; i++; }
            tokens.push({ type: 'emoji', value: emojiVal });
        } else {
            currentText += chars[i];
        }
    }
    if (currentText) tokens.push({ type: 'text', value: currentText });
    return tokens;
}

function wrapText(ctx, text, maxWidth, fontFamily, fontSize) {
    const words = text.split(' ');
    const lines = [];
    let currentLine = '';
    for (const word of words) {
        const testLine = currentLine + (currentLine ? ' ' : '') + word;
        ctx.font = `bold ${fontSize}px ${fontFamily}`;
        if (ctx.measureText(testLine).width > maxWidth && currentLine) {
            lines.push(currentLine); currentLine = word;
        } else {
            currentLine = testLine;
        }
    }
    if (currentLine) lines.push(currentLine);
    return lines.length ? lines : [text];
}

async function drawTextWithEmojis(ctx, text, x, y, fontSize, fontFamily, maxWidth) {
    if (!text || !text.trim()) return;
    ctx.font = `bold ${fontSize}px ${fontFamily}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';

    const lines = ctx.measureText(text).width > maxWidth ? wrapText(ctx, text, maxWidth, fontFamily, fontSize) : [text];
    const lineHeight = fontSize * 1.3;
    let startY = y - (lines.length * lineHeight) / 2 + lineHeight / 2;

    for (const line of lines) {
        const tokens = parseTextAndEmojis(line);
        let totalWidth = 0;
        for (const t of tokens) {
            if (t.type === 'emoji') totalWidth += fontSize * 1.05;
            else { ctx.font = `bold ${fontSize}px ${fontFamily}`; totalWidth += ctx.measureText(t.value).width; }
        }
        let startX = x - totalWidth / 2;

        for (const t of tokens) {
            if (t.type === 'emoji') {
                const emojiSize = fontSize * 1.05;
                const img = await getEmojiImage(t.value);
                if (img) {
                    ctx.drawImage(img, startX, startY - emojiSize / 2, emojiSize, emojiSize);
                } else {
                    ctx.strokeStyle = 'rgba(0,0,0,0.9)';
                    ctx.lineWidth = 4;
                    ctx.strokeText(t.value, startX, startY);
                    ctx.fillStyle = '#FFFFFF';
                    ctx.fillText(t.value, startX, startY);
                }
                startX += emojiSize;
            } else {
                ctx.strokeStyle = 'rgba(0,0,0,0.9)';
                ctx.lineWidth = 4;
                ctx.lineJoin = 'round';
                ctx.strokeText(t.value, startX, startY);
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(t.value, startX, startY);
                startX += ctx.measureText(t.value).width;
            }
        }
        startY += lineHeight;
    }
}

function countWords(text) {
    if (!text) return 0;
    return text.trim().split(/\s+/).filter(w => w.length > 0).length;
}

export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, text, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text) return reply(T(lang, 'no_text'));

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directImage = msg.message?.imageMessage;
    const directSticker = msg.message?.stickerMessage;
    const quotedImage = quoted?.imageMessage;
    const quotedSticker = quoted?.stickerMessage;

    const hasMedia = quotedImage || quotedSticker || directImage || directSticker;
    if (!hasMedia) return reply(T(lang, 'no_media'));

    const isSticker = !!(quotedSticker || directSticker);

    await sendReaction(sock, remoteJid, msg.key, '⏰');

    try {
        let topText = '', bottomText = '';
        const parts = text.split('|');
        if (parts.length >= 1) topText = parts[0]?.trim() || '';
        if (parts.length >= 2) bottomText = parts[1]?.trim() || '';
        if (parts.length === 1 && !text.includes('|')) topText = text.trim();

        if (countWords(topText) > 3 || countWords(bottomText) > 3) {
            return reply(T(lang, 'too_many_words'));
        }

        const buffer = await sock.downloadMediaMessage(msg);

        let imageBuffer = buffer;
        if (isSticker) imageBuffer = await sharp(buffer).png().toBuffer();

        const TARGET_SIZE = 512;
        const PADDING = 30;
        const resizedBuffer = await sharp(imageBuffer)
            .resize(TARGET_SIZE, TARGET_SIZE, { fit: 'cover', position: 'centre' })
            .png().toBuffer();

        const img = await loadImage(resizedBuffer);
        const canvas = createCanvas(TARGET_SIZE, TARGET_SIZE);
        const c = canvas.getContext('2d');
        c.drawImage(img, 0, 0, TARGET_SIZE, TARGET_SIZE);

        if (topText || bottomText) {
            const maxWidth = TARGET_SIZE - PADDING * 2;
            const fontFamily = FONT_PATH ? 'Epep' : 'sans-serif';

            let fontSize = 68;
            while (fontSize > 20) {
                c.font = `bold ${fontSize}px ${fontFamily}`;
                const topW = topText ? c.measureText(topText).width : 0;
                const botW = bottomText ? c.measureText(bottomText).width : 0;
                if (topW <= maxWidth && botW <= maxWidth) break;
                fontSize -= 2;
            }

            if (topText) await drawTextWithEmojis(c, topText, TARGET_SIZE / 2, PADDING + fontSize / 2, fontSize, fontFamily, maxWidth);
            if (bottomText) await drawTextWithEmojis(c, bottomText, TARGET_SIZE / 2, TARGET_SIZE - PADDING - fontSize / 2, fontSize, fontFamily, maxWidth);
        }

        const pngBuffer = await canvas.encode('png');
        const webpBuffer = await sharp(pngBuffer).webp({ quality: 80 }).toBuffer();

        await sendSticker(sock, remoteJid, webpBuffer, { quoted: msg });
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[SMEME] Error:', err);
        await sendReaction(sock, remoteJid, msg.key, '❌');
        await reply(T(lang, 'fail', { err: err.message }));
    }
}