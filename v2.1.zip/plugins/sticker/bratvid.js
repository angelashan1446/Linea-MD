// plugins/maker/bratvid.js
// Buat sticker "brat" versi video (animasi) dari teks — multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendSticker } from '../../libx/whatsapp/sendmsg.js';
import ffmpegPath from 'ffmpeg-static';
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['bratvid'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 10;

export const description_id = 'Buat sticker "brat" versi video (animasi) dari teks';
export const description_ch = '根据文本生成 "brat" 动画视频贴纸';
export const description_uk = 'Create a "brat" animated video sticker from text';
export const description = description_id;

const TEXT = {
    id: {
        no_text: '⚠️ Masukkan teks untuk video brat.\n\n📌 *Contoh:* .bratvid Halo Dunia',
        too_large: 'Sticker terlalu besar ({size} KB). Maksimal 500 KB.',
        fail: '❌ Gagal: {err}',
    },
    ch: {
        no_text: '⚠️ 请输入 "brat" 视频贴纸的文本。\n\n📌 *示例：* .bratvid 你好世界',
        too_large: '贴纸太大（{size} KB）。最大 500 KB。',
        fail: '❌ 失败：{err}',
    },
    uk: {
        no_text: '⚠️ Enter text for the brat video.\n\n📌 *Example:* .bratvid Hello World',
        too_large: 'Sticker too large ({size} KB). Max 500 KB.',
        fail: '❌ Failed: {err}',
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text) return reply(T(lang, 'no_text'));

    await sendReaction(sock, remoteJid, msg.key, '🎬');

    const stamp = Date.now();
    const tmpIn = path.join(os.tmpdir(), `bratvid_in_${stamp}.mp4`);
    const tmpOut = path.join(os.tmpdir(), `bratvid_out_${stamp}.webp`);

    try {
        const res = await engine.run('bratvid', { text });

        const vidRes = await fetch(res.url);
        const buffer = Buffer.from(await vidRes.arrayBuffer());
        fs.writeFileSync(tmpIn, buffer);

        await sendReaction(sock, remoteJid, msg.key, '⬇️');

        await new Promise((resolve, reject) => {
            const args = [
                '-y',
                '-i', tmpIn,
                '-vcodec', 'libwebp',
                '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white,fps=15',
                '-loop', '0',
                '-preset', 'default',
                '-an',
                '-vsync', '0',
                '-t', '10',
                '-q:v', '50',
                tmpOut,
            ];

            const proc = spawn(ffmpegPath, args, { windowsHide: true });
            let stderr = '';
            proc.stderr.on('data', (data) => { stderr += data.toString(); });
            proc.on('error', (err) => reject(new Error(`FFmpeg spawn error: ${err.message}`)));
            proc.on('close', (code) => {
                if (code === 0) resolve();
                else reject(new Error(`FFmpeg exit code ${code}: ${stderr.split('\n').pop()}`));
            });
        });

        const webpBuffer = fs.readFileSync(tmpOut);

        if (webpBuffer.length > 500 * 1024) {
            throw new Error(T(lang, 'too_large', { size: (webpBuffer.length / 1024).toFixed(1) }));
        }

        await sendSticker(sock, remoteJid, webpBuffer, { quoted: msg });
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error(err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    } finally {
        try { if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn); } catch {}
        try { if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut); } catch {}
    }
}