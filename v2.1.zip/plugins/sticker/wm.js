// plugins/tools/wm.js
// Buat stiker dengan custom Pack Name & Author (Watermark) — multi-bahasa.

import sharp from 'sharp';
import { sendReaction, sendSticker } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['wm', 'watermark', 'stikerwm'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 2;

export const description_id = 'Buat stiker dengan custom Pack Name & Author (Watermark)';
export const description_ch = '使用自定义包名和作者名创建贴纸（水印）';
export const description_uk = 'Create sticker with custom Pack Name & Author (Watermark)';
export const description = description_id;

const TEXT = {
    id: {
        no_media:
            '⚠️ *Cara pakai:*\n' +
            'Kirim/reply gambar atau stiker, lalu ketik:\n\n' +
            '• `{prefix}wm Nama Bot`\n' +
            '• `{prefix}wm Nama Bot | Author`\n\n' +
            '_Contoh:_ `{prefix}wm Linea MD | Angela`',
        no_text:
            '⚠️ Masukkan nama pack!\n\n' +
            'Contoh: `{prefix}wm Linea MD | Angela`',
        download_fail: 'Gagal download media.',
        fail: '❌ Gagal buat stiker: {err}',
        default_pack: 'Linea MD',
    },
    ch: {
        no_media:
            '⚠️ *使用方法：*\n' +
            '发送/回复图片或贴纸，然后输入：\n\n' +
            '• `{prefix}wm 机器人名称`\n' +
            '• `{prefix}wm 机器人名称 | 作者`\n\n' +
            '_示例：_ `{prefix}wm Linea MD | Angela`',
        no_text:
            '⚠️ 请输入包名！\n\n' +
            '示例：`{prefix}wm Linea MD | Angela`',
        download_fail: '下载媒体失败。',
        fail: '❌ 创建贴纸失败：{err}',
        default_pack: 'Linea MD',
    },
    uk: {
        no_media:
            '⚠️ *How to use:*\n' +
            'Send/reply image or sticker, then type:\n\n' +
            '• `{prefix}wm Bot Name`\n' +
            '• `{prefix}wm Bot Name | Author`\n\n' +
            '_Example:_ `{prefix}wm Linea MD | Angela`',
        no_text:
            '⚠️ Enter pack name!\n\n' +
            'Example: `{prefix}wm Linea MD | Angela`',
        download_fail: 'Failed to download media.',
        fail: '❌ Failed to create sticker: {err}',
        default_pack: 'Linea MD',
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, text, prefix, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directImage = msg.message?.imageMessage;
    const directSticker = msg.message?.stickerMessage;
    const quotedImage = quoted?.imageMessage;
    const quotedSticker = quoted?.stickerMessage;

    const isMedia = directImage || directSticker || quotedImage || quotedSticker;
    if (!isMedia) return reply(T(lang, 'no_media', { prefix }));

    if (!text) return reply(T(lang, 'no_text', { prefix }));

    let packName = text.trim();
    let authorName = '';

    if (text.includes('|')) {
        const parts = text.split('|').map(s => s.trim());
        packName = parts[0] || T(lang, 'default_pack');
        authorName = parts[1] || '';
    }

    packName = packName.substring(0, 100);
    authorName = authorName.substring(0, 100);

    await sendReaction(sock, remoteJid, msg.key, '🎨');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        if (!buffer || buffer.length === 0) throw new Error(T(lang, 'download_fail'));

        const webpBuffer = await sharp(buffer)
            .resize(512, 512, {
                fit: 'contain',
                background: { r: 0, g: 0, b: 0, alpha: 0 },
            })
            .webp({ quality: 80 })
            .toBuffer();

        await sendSticker(sock, remoteJid, webpBuffer, {
            quoted: msg,
            pack: packName,
            author: authorName,
        });

        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[wm]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}