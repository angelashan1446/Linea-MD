// plugins/tools/sticker.js
// Convert gambar/video jadi sticker WhatsApp — multi-bahasa.

import sharp from 'sharp';
import ffmpegPath from 'ffmpeg-static';
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { sendReaction, sendSticker } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['s', 'sticker', 'stiker'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 5;

export const description_id = 'Convert gambar/video jadi sticker WhatsApp (reply/kirim langsung)';
export const description_ch = '将图片/视频转换为 WhatsApp 贴纸（回复/直接发送）';
export const description_uk = 'Convert image/video to WhatsApp sticker (reply/send directly)';
export const description = description_id;

const TEXT = {
    id: {
        no_media:
            '⚠️ Balas sebuah *gambar* atau *video* dengan command *.s*\n\n' +
            '*Contoh:*\n' +
            '• Reply gambar + .s\n' +
            '• Reply video + .s (maks 10 detik)',
        process_fail: 'Gagal memproses media.',
        fail: '❌ Gagal membuat sticker: {err}',
        video_too_large: 'Sticker terlalu besar ({size} KB). Maksimal {max} KB.',
    },
    ch: {
        no_media:
            '⚠️ 请回复*图片*或*视频*并使用 *.s*\n\n' +
            '*示例：*\n' +
            '• 回复图片 + .s\n' +
            '• 回复视频 + .s（最长 10 秒）',
        process_fail: '处理媒体失败。',
        fail: '❌ 创建贴纸失败：{err}',
        video_too_large: '贴纸太大（{size} KB）。最大 {max} KB。',
    },
    uk: {
        no_media:
            '⚠️ Reply to an *image* or *video* with *.s*\n\n' +
            '*Example:*\n' +
            '• Reply image + .s\n' +
            '• Reply video + .s (max 10 seconds)',
        process_fail: 'Failed to process media.',
        fail: '❌ Failed to create sticker: {err}',
        video_too_large: 'Sticker too large ({size} KB). Max {max} KB.',
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

async function imageToStickerWebp(buffer) {
    return await sharp(buffer)
        .resize(512, 512, { fit: 'cover', position: 'centre' })
        .webp({ quality: 80 })
        .toBuffer();
}

function videoToStickerWebp(videoBuffer, opts = {}, lang = 'uk') {
    return new Promise((resolve, reject) => {
        const { duration = 10, fps = 15, maxSizeKb = 500 } = opts;

        const stamp = Date.now();
        const tmpIn = path.join(os.tmpdir(), `stk_in_${stamp}.mp4`);
        const tmpOut = path.join(os.tmpdir(), `stk_out_${stamp}.webp`);

        const cleanup = () => {
            try { if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn); } catch {}
            try { if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut); } catch {}
        };

        try {
            fs.writeFileSync(tmpIn, videoBuffer);
        } catch (err) {
            return reject(new Error(`Gagal tulis temp file: ${err.message}`));
        }

        const args = [
            '-y',
            '-i', tmpIn,
            '-vcodec', 'libwebp',
            '-vf', `scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white,fps=${fps}`,
            '-loop', '0',
            '-preset', 'default',
            '-an',
            '-vsync', '0',
            '-t', String(duration),
            '-q:v', '50',
            tmpOut,
        ];

        const proc = spawn(ffmpegPath, args, { windowsHide: true });
        let stderr = '';
        proc.stderr.on('data', (data) => { stderr += data.toString(); });
        proc.on('error', (err) => { cleanup(); reject(new Error(`FFmpeg spawn error: ${err.message}`)); });
        proc.on('close', (code) => {
            if (code !== 0) {
                cleanup();
                return reject(new Error(`FFmpeg exit code ${code}: ${stderr.split('\n').pop()}`));
            }
            try {
                const buf = fs.readFileSync(tmpOut);
                cleanup();
                if (buf.length > maxSizeKb * 1024) {
                    return reject(new Error(T(lang, 'video_too_large', {
                        size: (buf.length / 1024).toFixed(1),
                        max: maxSizeKb,
                    })));
                }
                resolve(buf);
            } catch (err) {
                cleanup();
                reject(new Error(`Gagal baca output: ${err.message}`));
            }
        });
    });
}

export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const directImage = msg.message?.imageMessage;
    const directVideo = msg.message?.videoMessage;
    const quotedImage = quoted?.imageMessage;
    const quotedVideo = quoted?.videoMessage;

    const isImage = quotedImage || directImage;
    const isVideo = quotedVideo || directVideo;

    if (!isImage && !isVideo) return reply(T(lang, 'no_media'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        const buffer = await sock.downloadMediaMessage(msg);
        let webpBuffer = null;

        if (isImage) {
            webpBuffer = await imageToStickerWebp(buffer);
        } else if (isVideo) {
            await sendReaction(sock, remoteJid, msg.key, '⏳');
            webpBuffer = await videoToStickerWebp(
                buffer,
                { duration: 10, fps: 15, maxSizeKb: 500 },
                lang
            );
        }

        if (!webpBuffer) throw new Error(T(lang, 'process_fail'));

        await sendSticker(sock, remoteJid, webpBuffer, { quoted: msg });
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error('[sticker]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}