// plugins/maker/brat.js
// Buat sticker "brat" dari teks (gaya album Brat) — multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction, sendSticker } from '../../libx/whatsapp/sendmsg.js';
import sharp from 'sharp';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['brat'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 10;

export const description_id = 'Buat sticker "brat" dari teks (gaya album Brat)';
export const description_ch = '根据文本生成 "brat" 风格贴纸（专辑 Brat 风格）';
export const description_uk = 'Create a "brat" sticker from text (Brat album style)';
export const description = description_id;

const TEXT = {
    id: {
        no_text: '⚠️ Masukkan teks!\nContoh: .brat Halo Dunia',
        fail: '❌ Gagal: {err}',
    },
    ch: {
        no_text: '⚠️ 请输入文本！\n示例：.brat 你好世界',
        fail: '❌ 失败：{err}',
    },
    uk: {
        no_text: '⚠️ Enter text!\nExample: .brat Hello World',
        fail: '❌ Failed: {err}',
    },
};

function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, String(v));
    return str;
}
function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

export default async function handler(ctx) {
    const { text, reply, sock, remoteJid, msg, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (!text) return reply(T(lang, 'no_text'));

    await sendReaction(sock, remoteJid, msg.key, '🔍');

    try {
        const res = await engine.run('brat', { text });

        const imgRes = await fetch(res.url);
        const buffer = Buffer.from(await imgRes.arrayBuffer());

        const webpBuffer = await sharp(buffer)
            .resize(512, 512, { fit: 'inside' })
            .webp({ quality: 80 })
            .toBuffer();

        await sendSticker(sock, remoteJid, webpBuffer, { quoted: msg });
        await sendReaction(sock, remoteJid, msg.key, '✅');
    } catch (err) {
        console.error(err);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}