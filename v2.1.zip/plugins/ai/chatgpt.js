// plugins/ai/chatgpt.js
// Tanya jawab dengan ChatGPT (GPT-4o) — support multi-bahasa.

import { engine } from '../../libx/engine/index.js';
import { sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['ai', 'gpt', 'chatgpt'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 5;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Tanya jawab dengan ChatGPT (GPT-4o)';
export const description_ch = '与 ChatGPT (GPT-4o) 问答';
export const description_uk = 'Ask and answer with ChatGPT (GPT-4o)';
export const description = description_id;

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        no_question:
            '⚠️ Kirim pertanyaan!\n\nContoh: *{prefix}ai* apa itu javascript?',
        too_long: '❌ Teks terlalu panjang (maks 4000 karakter).',
        header: `乂  *ᴀɴɢᴇʟ's - ᴄʜᴀᴛɢᴘᴛ*`,
        label_question: 'Pertanyaan',
        label_answer: 'Jawaban',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Gagal: {err}',
    },
    ch: {
        no_question:
            '⚠️ 请输入问题！\n\n示例：*{prefix}ai* 什么是 javascript？',
        too_long: '❌ 文本太长（最多 4000 字符）。',
        header: `乂  *ᴀɴɢᴇʟ's - ᴄʜᴀᴛɢᴘᴛ*`,
        label_question: '问题',
        label_answer: '回答',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ 失败：{err}',
    },
    uk: {
        no_question:
            '⚠️ Please send a question!\n\nExample: *{prefix}ai* what is javascript?',
        too_long: '❌ Text is too long (max 4000 characters).',
        header: `乂  *ᴀɴɢᴇʟ's - ᴄʜᴀᴛɢᴘᴛ*`,
        label_question: 'Question',
        label_answer: 'Answer',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟ's ᴀɪ ッ`,
        fail: '❌ Failed: {err}',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, args, prefix, sender } = ctx;

    // Deteksi bahasa
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const text = args.join(' ');
    if (!text) {
        return reply(T(lang, 'no_question', { prefix }));
    }

    if (text.length > 4000) {
        return reply(T(lang, 'too_long'));
    }

    await sendReaction(sock, remoteJid, msg.key, '🤖');

    try {
        const res = await engine.run('aichatgpt', { text });

        const caption =
            `${T(lang, 'header')}\n\n` +
            `*${T(lang, 'label_question')}* :\n${text}\n\n` +
            `*${T(lang, 'label_answer')}* :\n${res.response}\n\n` +
            `${T(lang, 'footer')}`;

        await reply(caption);
        await sendReaction(sock, remoteJid, msg.key, '✅');

    } catch (err) {
        console.error('[gpt]', err.message);
        await reply(T(lang, 'fail', { err: err.message }));
        await sendReaction(sock, remoteJid, msg.key, '❌');
    }
}