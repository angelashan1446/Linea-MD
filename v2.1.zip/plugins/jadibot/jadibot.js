// plugins/jadibot.js
// Jadikan bot sebagai "jadibot" — wizard interaktif sebelum pairing.
// Support multi-bahasa (ID / CH / UK).

import fs from 'fs';
import path from 'path';
import config from '../../config.js';
import { sessions, createNewSession, getPairingCode } from '../../libx/whatsapp/connect.js';
import { addSessionOwner, findUser } from '../../libx/db.js';
import { sendText, sendReaction } from '../../libx/whatsapp/sendmsg.js';
import { registerSession } from '../../libx/session_plugins.js';
import { isValidLang, DEFAULT_LANG, LANGS } from '../../libx/lang.js';

export const cmd = ['jadibot'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION MULTI-BAHASA
// ============================================================
export const description_id = 'Jadikan bot sebagai "jadibot" — pairing nomor via kode (chat pribadi)';
export const description_ch = '将机器人作为"子机器人" — 通过代码配对号码（私聊）';
export const description_uk = 'Make the bot a "sub-bot" — pair number via code (private chat)';
export const description = description_id;

// ============================================================
// DB JADIBOT
// ============================================================
const DB_DIR = path.join(process.cwd(), 'db');
const JADIBOT_FILE = path.join(DB_DIR, 'jadibot.json');

function ensureDb() {
    if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
    if (!fs.existsSync(JADIBOT_FILE)) {
        fs.writeFileSync(JADIBOT_FILE, JSON.stringify({ bots: {} }, null, 2));
    }
}

function readJadibotDb() {
    ensureDb();
    try {
        return JSON.parse(fs.readFileSync(JADIBOT_FILE, 'utf8'));
    } catch {
        return { bots: {} };
    }
}

function writeJadibotDb(data) {
    ensureDb();
    fs.writeFileSync(JADIBOT_FILE, JSON.stringify(data, null, 2));
}

/**
 * Simpan konfigurasi jadibot.
 * @param {object} cfg - { lid, nomor_owner, nomor_bot, selft_bot, mode_chat }
 */
function saveJadibotConfig(cfg) {
    const db = readJadibotDb();
    const key = cfg.nomor_bot;
    db.bots[key] = {
        lid: cfg.lid || null,
        nomor_owner: cfg.nomor_owner || null,
        nomor_bot: cfg.nomor_bot || null,
        selft_bot: !!cfg.selft_bot,
        mode_chat: cfg.mode_chat || 'both',
        updated_at: new Date().toISOString(),
    };
    writeJadibotDb(db);
    return db.bots[key];
}

// ============================================================
// PICKER AWAL SELALU ENGLISH
// ============================================================
const PICKER_LANG = 'uk';
const TIMEOUT_WIZARD = 120 * 1000; // 2 menit buat satu langkah

// ============================================================
// KAMUS BAHASA PLUGIN
// ============================================================
const TEXT = {
    id: {
        group_only_private:
            '⚠️ Fitur jadibot hanya bisa digunakan di chat pribadi.',
        number_unknown:
            '❌ Gagal mendeteksi nomor HP kamu. Silakan ketik manual: *.jadibot 628xxx*',
        number_invalid:
            '❌ Nomor tidak valid. Pastikan menggunakan format internasional (contoh: 628xxx).',
        max_sessions:
            '❌ Batas maksimal {max} sesi tercapai. Hubungi owner.',

        header_install: `乂  *ᴀɴɢᴇʟs - ᴊᴀᴅɪʙᴏᴛ ɪɴꜱᴛᴀʟʟ*`,
        info_owner: 'Nomor Owner',
        info_bot: 'Nomor Bot',
        info_lid: 'LID',
        step_selft_header: '🔒 *Apakah bot hanya untuk kamu sendiri?*',
        step_selft_body:
            '*1.* Yes — bot hanya respon kamu (self mode)\n' +
            '*2.* No — bot bisa dipakai semua orang',
        step_selft_reply_hint: '📌 Reply pesan ini dengan angka (1/2).',

        step_chat_header: '📱 *Pilih mode chat bot:*',
        step_chat_body:
            '*1.* Private — hanya di chat pribadi\n' +
            '*2.* Grup — hanya di grup\n' +
            '*3.* Both — private + grup',
        step_chat_reply_hint: '📌 Reply pesan ini dengan angka (1/2/3).',

        invalid_selft: '❌ Pilihan tidak valid. Reply *1* (Yes) atau *2* (No).',
        invalid_chat: '❌ Pilihan tidak valid. Reply *1* (private), *2* (grup), atau *3* (both).',

        confirm_header: `乂  *ᴀɴɢᴇʟs - ᴋᴏɴꜰɪʀᴍᴀꜱɪ*`,
        confirm_intro: 'Berikut konfigurasi bot kamu:\n',
        confirm_selft_on: '✅ Ya (self mode)',
        confirm_selft_off: '❌ Tidak',
        confirm_chat_private: 'Private',
        confirm_chat_grup: 'Grup',
        confirm_chat_both: 'Both (Private + Grup)',
        confirm_footer:
            '📌 Reply *1* untuk mulai pairing, atau *2* untuk batalkan.',
        invalid_confirm: '❌ Pilihan tidak valid. Reply *1* (lanjut) atau *2* (batal).',
        cancelled: '⏱️ Install dibatalkan. Ketik *.jadibot* lagi kalau mau ulang.',

        pairing_header: `乂  *ᴀɴɢᴇʟs - ᴘᴀɪʀɪɴɢ*`,
        status_deleting: 'Menghapus Sesi Lama...',
        status_waiting: 'Menunggu Koneksi',
        waiting_hint: '_Silakan tunggu, kode pairing akan dikirim sebentar lagi..._',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,

        connected_header: `乂  *ᴀɴɢᴇʟs - ʙᴇʀʜᴀsɪʟ* ✅`,
        connected_body:
            'Bot *{number}* sekarang sudah aktif dan terhubung.\n\n' +
            '*Konfigurasi:*\n' +
            '◦ Self mode : {selft}\n' +
            '◦ Mode chat : {chat}',
        pairing_fail:
            '❌ Gagal mengambil kode pairing.\nPastikan bot utama menggunakan mode \'pairing\' di config.js.',
        create_fail: '❌ Gagal membuat sesi: {err}',

        timeout_msg:
            '⏱️ Waktu habis. Install dibatalkan.\nKetik *.jadibot* lagi kalau mau ulang.',
    },
    ch: {
        group_only_private:
            '⚠️ 子机器人功能仅可在私聊中使用。',
        number_unknown:
            '❌ 无法检测到您的手机号码。请手动输入：*.jadibot 628xxx*',
        number_invalid:
            '❌ 号码无效。请使用国际格式（例如：628xxx）。',
        max_sessions:
            '❌ 已达到最大 {max} 个会话的限制。请联系主人。',

        header_install: `乂  *ᴀɴɢᴇʟs - 子机器人安装*`,
        info_owner: '主人号码',
        info_bot: '机器人号码',
        info_lid: 'LID',
        step_selft_header: '🔒 *机器人仅限你自己使用吗？*',
        step_selft_body:
            '*1.* 是 — 机器人仅响应你（自用模式）\n' +
            '*2.* 否 — 机器人所有用户可用',
        step_selft_reply_hint: '📌 请回复数字 (1/2)。',

        step_chat_header: '📱 *选择机器人聊天模式：*',
        step_chat_body:
            '*1.* 私聊 — 仅限私聊\n' +
            '*2.* 群组 — 仅限群组\n' +
            '*3.* 全部 — 私聊 + 群组',
        step_chat_reply_hint: '📌 请回复数字 (1/2/3)。',

        invalid_selft: '❌ 选择无效。请回复 *1*（是）或 *2*（否）。',
        invalid_chat: '❌ 选择无效。请回复 *1*（私聊）、*2*（群组）或 *3*（全部）。',

        confirm_header: `乂  *ᴀɴɢᴇʟs - 确认配置*`,
        confirm_intro: '以下是您的机器人配置：\n',
        confirm_selft_on: '✅ 是（自用模式）',
        confirm_selft_off: '❌ 否',
        confirm_chat_private: '私聊',
        confirm_chat_grup: '群组',
        confirm_chat_both: '全部（私聊 + 群组）',
        confirm_footer:
            '📌 回复 *1* 开始配对，或 *2* 取消。',
        invalid_confirm: '❌ 选择无效。请回复 *1*（继续）或 *2*（取消）。',
        cancelled: '⏱️ 安装已取消。如需重试，请输入 *.jadibot*。',

        pairing_header: `乂  *ᴀɴɢᴇʟs - 配对*`,
        status_deleting: '正在删除旧会话...',
        status_waiting: '等待连接',
        waiting_hint: '_请稍候，配对代码即将发送..._',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,

        connected_header: `乂  *ᴀɴɢᴇʟs - 成功* ✅`,
        connected_body:
            '机器人 *{number}* 现已激活并连接。\n\n' +
            '*配置：*\n' +
            '◦ 自用模式 : {selft}\n' +
            '◦ 聊天模式 : {chat}',
        pairing_fail:
            '❌ 无法获取配对代码。\n请确保主机器人在 config.js 中设置为 \'pairing\' 模式。',
        create_fail: '❌ 创建会话失败：{err}',

        timeout_msg:
            '⏱️ 时间到。安装已取消。\n如需重试，请输入 *.jadibot*。',
    },
    uk: {
        group_only_private:
            '⚠️ The jadibot feature can only be used in private chat.',
        number_unknown:
            '❌ Failed to detect your phone number. Please type manually: *.jadibot 628xxx*',
        number_invalid:
            '❌ Invalid number. Please use international format (e.g. 628xxx).',
        max_sessions:
            '❌ Maximum {max} sessions reached. Contact owner.',

        header_install: `乂  *ᴀɴɢᴇʟs - ᴊᴀᴅɪʙᴏᴛ ɪɴꜱᴛᴀʟʟ*`,
        info_owner: 'Owner Number',
        info_bot: 'Bot Number',
        info_lid: 'LID',
        step_selft_header: '🔒 *Is this bot only for you?*',
        step_selft_body:
            '*1.* Yes — bot only responds to you (self mode)\n' +
            '*2.* No — bot can be used by everyone',
        step_selft_reply_hint: '📌 Reply to this message with a number (1/2).',

        step_chat_header: '📱 *Choose bot chat mode:*',
        step_chat_body:
            '*1.* Private — private chat only\n' +
            '*2.* Group — group only\n' +
            '*3.* Both — private + group',
        step_chat_reply_hint: '📌 Reply to this message with a number (1/2/3).',

        invalid_selft: '❌ Invalid choice. Reply *1* (Yes) or *2* (No).',
        invalid_chat: '❌ Invalid choice. Reply *1* (private), *2* (group), or *3* (both).',

        confirm_header: `乂  *ᴀɴɢᴇʟs - ᴄᴏɴꜰɪʀᴍᴀᴛɪᴏɴ*`,
        confirm_intro: 'Here is your bot configuration:\n',
        confirm_selft_on: '✅ Yes (self mode)',
        confirm_selft_off: '❌ No',
        confirm_chat_private: 'Private',
        confirm_chat_grup: 'Group',
        confirm_chat_both: 'Both (Private + Group)',
        confirm_footer:
            '📌 Reply *1* to start pairing, or *2* to cancel.',
        invalid_confirm: '❌ Invalid choice. Reply *1* (continue) or *2* (cancel).',
        cancelled: '⏱️ Install cancelled. Type *.jadibot* again to retry.',

        pairing_header: `乂  *ᴀɴɢᴇʟs - ᴘᴀɪʀɪɴɢ*`,
        status_deleting: 'Deleting Old Session...',
        status_waiting: 'Waiting for Connection',
        waiting_hint: '_Please wait, pairing code will be sent shortly..._',
        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,

        connected_header: `乂  *ᴀɴɢᴇʟs - ꜱᴜᴄᴄᴇꜱꜱ* ✅`,
        connected_body:
            'Bot *{number}* is now active and connected.\n\n' +
            '*Configuration:*\n' +
            '◦ Self mode : {selft}\n' +
            '◦ Chat mode : {chat}',
        pairing_fail:
            '❌ Failed to get pairing code.\nMake sure the main bot uses \'pairing\' mode in config.js.',
        create_fail: '❌ Failed to create session: {err}',

        timeout_msg:
            '⏱️ Time\'s up. Install cancelled.\nType *.jadibot* again to retry.',
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return PICKER_LANG; // fallback universal
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function labelSelft(lang, on) {
    return on ? T(lang, 'confirm_selft_on') : T(lang, 'confirm_selft_off');
}

function labelChat(lang, mode) {
    if (mode === 'private') return T(lang, 'confirm_chat_private');
    if (mode === 'grup') return T(lang, 'confirm_chat_grup');
    return T(lang, 'confirm_chat_both');
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, text, sender, isGroup } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    if (isGroup) return reply(T(lang, 'group_only_private'));

    let targetNumber = text ? text.replace(/\D/g, '') : sender.nomor;

    if (!targetNumber) return reply(T(lang, 'number_unknown'));
    if (targetNumber.length < 8) return reply(T(lang, 'number_invalid'));

    const maxSessions = config.max_sessions || 10;
    if (sessions.size >= maxSessions) {
        return reply(T(lang, 'max_sessions', { max: maxSessions }));
    }

    // ============================================================
    // STATE INSTALL
    // ============================================================
    const installData = {
        lid: sender.lid || null,
        nomor_owner: sender.nomor || null,
        nomor_bot: targetNumber,
        selft_bot: null,
        mode_chat: null,
    };

    await sendReaction(sock, remoteJid, msg.key, '📦');

    // ============================================================
    // STEP 1 — Tampilkan info + tanya "self mode?"
    // ============================================================
    const infoHeader =
        `${T(lang, 'header_install')}\n\n` +
        `◦  *${T(lang, 'info_owner')}* : ${installData.nomor_owner || '-'}\n` +
        `◦  *${T(lang, 'info_bot')}*   : ${installData.nomor_bot}\n` +
        `◦  *${T(lang, 'info_lid')}*   : ${installData.lid ? installData.lid.split('@')[0] : '-'}\n\n` +
        `${T(lang, 'step_selft_header')}\n\n` +
        `${T(lang, 'step_selft_body')}\n\n` +
        `${T(lang, 'step_selft_reply_hint')}\n\n` +
        `${T(lang, 'footer')}`;

    const step1Msg = await reply(infoHeader);
    if (!step1Msg?.key?.id) return;

    // ============================================================
    // STEP 2 — Dengerin jawaban self mode
    // ============================================================
    const onSelftReply = async (rc1) => {
        const jawab = String(rc1.text || '').trim();
        if (jawab !== '1' && jawab !== '2') {
            return rc1.reply(T(lang, 'invalid_selft'));
        }

        installData.selft_bot = jawab === '1';

        // --- Tanya mode chat ---
        const chatText =
            `${T(lang, 'step_chat_header')}\n\n` +
            `${T(lang, 'step_chat_body')}\n\n` +
            `${T(lang, 'step_chat_reply_hint')}\n\n` +
            `${T(lang, 'footer')}`;

        const step2Msg = await rc1.reply(chatText);
        if (!step2Msg?.key?.id) return;

        // --- STEP 3: Dengerin jawaban mode chat ---
        const onChatReply = async (rc2) => {
            const j2 = String(rc2.text || '').trim();
            if (!['1', '2', '3'].includes(j2)) {
                return rc2.reply(T(lang, 'invalid_chat'));
            }

            installData.mode_chat = j2 === '1' ? 'private' : j2 === '2' ? 'grup' : 'both';

            // --- Konfirmasi akhir ---
            const confirmText =
                `${T(lang, 'confirm_header')}\n\n` +
                `${T(lang, 'confirm_intro')}\n` +
                `◦  Self mode : ${labelSelft(lang, installData.selft_bot)}\n` +
                `◦  Mode chat : ${labelChat(lang, installData.mode_chat)}\n\n` +
                `${T(lang, 'confirm_footer')}\n\n` +
                `${T(lang, 'footer')}`;

            const step3Msg = await rc2.reply(confirmText);
            if (!step3Msg?.key?.id) return;

            // --- STEP 4: Konfirmasi → mulai pairing ---
            const onConfirm = async (rc3) => {
                const j3 = String(rc3.text || '').trim();
                if (j3 === '2') {
                    return rc3.reply(T(lang, 'cancelled'));
                }
                if (j3 !== '1') {
                    return rc3.reply(T(lang, 'invalid_confirm'));
                }

                // === MULAI PAIRING ===
                await startPairing({
                    sock,
                    reply: rc3.reply,
                    remoteJid,
                    targetNumber,
                    installData,
                    sender,
                    lang,
                });
            };

            registerSession(
                step3Msg.key.id,
                remoteJid,
                onConfirm,
                { step: 'confirm' },
                {
                    once: true,
                    timeoutMs: TIMEOUT_WIZARD,
                    senderJid: sender.lid || (sender.nomor ? `${sender.nomor}@s.whatsapp.net` : null),
                    validateSender: true,
                    tag: 'jadibot_confirm',
                    onExpire: async ({ chatJid }) => {
                        try { await sendText(sock, chatJid, T(lang, 'timeout_msg')); } catch {}
                    },
                }
            );
        };

        registerSession(
            step2Msg.key.id,
            remoteJid,
            onChatReply,
            { step: 'chat' },
            {
                once: true,
                timeoutMs: TIMEOUT_WIZARD,
                senderJid: sender.lid || (sender.nomor ? `${sender.nomor}@s.whatsapp.net` : null),
                validateSender: true,
                tag: 'jadibot_chat',
                onExpire: async ({ chatJid }) => {
                    try { await sendText(sock, chatJid, T(lang, 'timeout_msg')); } catch {}
                },
            }
        );
    };

    registerSession(
        step1Msg.key.id,
        remoteJid,
        onSelftReply,
        { step: 'selft' },
        {
            once: true,
            timeoutMs: TIMEOUT_WIZARD,
            senderJid: sender.lid || (sender.nomor ? `${sender.nomor}@s.whatsapp.net` : null),
            validateSender: true,
            tag: 'jadibot_selft',
            onExpire: async ({ chatJid }) => {
                try { await sendText(sock, chatJid, T(lang, 'timeout_msg')); } catch {}
            },
        }
    );
}

// ============================================================
// START PAIRING (dipanggil setelah wizard selesai)
// ============================================================
async function startPairing({ sock, reply, remoteJid, targetNumber, installData, sender, lang }) {
    // Simpan konfigurasi ke DB DULU
    saveJadibotConfig(installData);

    const sessionExists = sessions.has(targetNumber);

    const cardText =
        `${T(lang, 'pairing_header')}\n\n` +
        `◦  *${T(lang, 'info_owner')}* : ${installData.nomor_owner || '-'}\n` +
        `◦  *${T(lang, 'info_bot')}*   : ${targetNumber}\n` +
        `◦  *${T(lang, 'info_lid')}*   : ${installData.lid ? installData.lid.split('@')[0] : '-'}\n` +
        `◦  *Status* : ${sessionExists ? T(lang, 'status_deleting') : T(lang, 'status_waiting')}\n\n` +
        `${T(lang, 'waiting_hint')}\n\n` +
        `${T(lang, 'footer')}`;

    await reply(cardText);

    try {
        await createNewSession(targetNumber, {
            onMessage: global.__handleMessage,
            onConnected: (s, folder) => {
                console.log(`[${folder}] ✅ Terhubung (via .jadibot)`);
                const successText =
                    `${T(lang, 'connected_header')}\n\n` +
                    `${T(lang, 'connected_body', {
                        number: targetNumber,
                        selft: labelSelft(lang, installData.selft_bot),
                        chat: labelChat(lang, installData.mode_chat),
                    })}\n\n` +
                    `${T(lang, 'footer')}`;
                sendText(sock, remoteJid, successText);
            },
            onDisconnected: (folder) => {
                console.log(`[${folder}] ⚠️ Terputus`);
            },
        });

        if (sender.nomor) {
            addSessionOwner(sender.nomor, targetNumber);
        }

        setTimeout(async () => {
            const pairingCode = getPairingCode(targetNumber);
            if (pairingCode) {
                await sendText(sock, remoteJid, pairingCode);
            } else {
                await sendText(sock, remoteJid, T(lang, 'pairing_fail'));
            }
        }, 4000);
    } catch (err) {
        console.error('[JADIBOT ERROR]', err);
        await reply(T(lang, 'create_fail', { err: err.message }));
    }
}