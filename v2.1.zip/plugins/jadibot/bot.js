// plugins/tools/bot.js
// Kelola config bot jadibot per bot milik user sendiri.
//   .bot selft [nomor|alias]    → self mode ON
//   .bot unselft [nomor|alias]  → self mode OFF
//   .bot modechat [nomor|alias] → picker mode chat
//   .bot alias [nomor]          → set alias via wizard
//   .bot info [nomor|alias]     → lihat config bot
//   .bot list                   → daftar bot milik sendiri

import fs from 'fs';
import path from 'path';
import { sendReaction, sendText } from '../../libx/whatsapp/sendmsg.js';
import { registerSession } from '../../libx/session_plugins.js';
import { findUser } from '../../libx/db.js';
import { isValidLang, DEFAULT_LANG } from '../../libx/lang.js';

export const cmd = ['bot'];
export const only_owner = false;
export const only_premium = false;
export const token_usage = 0;

// ============================================================
// DESCRIPTION
// ============================================================
export const description_id = 'Kelola config bot milikmu (selft / mode chat / alias / info / list)';
export const description_ch = '管理你的子机器人配置（自用 / 聊天模式 / 别名 / 信息 / 列表）';
export const description_uk = 'Manage your own sub-bot config (selft / mode chat / alias / info / list)';
export const description = description_id;

// ============================================================
// DB JADIBOT
// ============================================================
const DB_DIR = path.join(process.cwd(), 'db');
const JADIBOT_FILE = path.join(DB_DIR, 'jadibot.json');

function ensureDb() {
    if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
    if (!fs.existsSync(JADIBOT_FILE)) {
        fs.writeFileSync(JADIBOT_FILE, JSON.stringify({ bots: {} }, null, 2));
    }
}
function readDb() {
    ensureDb();
    try { return JSON.parse(fs.readFileSync(JADIBOT_FILE, 'utf8')); }
    catch { return { bots: {} }; }
}
function writeDb(data) {
    ensureDb();
    fs.writeFileSync(JADIBOT_FILE, JSON.stringify(data, null, 2));
}

function getBotConfig(nomor) {
    const db = readDb();
    return db.bots?.[nomor] || null;
}

function updateBotConfig(nomor, patch = {}) {
    const db = readDb();
    if (!db.bots) db.bots = {};
    if (!db.bots[nomor]) return { ok: false, reason: 'not_found' };

    db.bots[nomor] = {
        ...db.bots[nomor],
        ...patch,
        updated_at: new Date().toISOString(),
    };
    writeDb(db);
    return { ok: true, bot: db.bots[nomor] };
}

function findBotByAlias(alias) {
    if (!alias) return null;
    const clean = String(alias).trim().toLowerCase();
    const db = readDb();
    for (const [nomor, cfg] of Object.entries(db.bots || {})) {
        if (cfg.alias && String(cfg.alias).toLowerCase() === clean) {
            return nomor;
        }
    }
    return null;
}

function isAliasTaken(alias, exceptNomor = null) {
    if (!alias) return false;
    const clean = String(alias).trim().toLowerCase();
    const db = readDb();
    for (const [nomor, cfg] of Object.entries(db.bots || {})) {
        if (nomor === exceptNomor) continue;
        if (cfg.alias && String(cfg.alias).toLowerCase() === clean) return true;
    }
    return false;
}

function listBotsOwnedBy({ lid, nomor }) {
    const db = readDb();
    const all = Object.values(db.bots || {});

    return all.filter((b) => {
        if (nomor && b.nomor_owner && String(b.nomor_owner).replace(/\D/g, '') === String(nomor).replace(/\D/g, '')) {
            return true;
        }
        if (lid && b.lid && b.lid === lid) return true;
        return false;
    });
}

function isBotOwnedBy(nomorBot, { lid, nomor }) {
    const cfg = getBotConfig(nomorBot);
    if (!cfg) return { owned: false, cfg: null };

    if (nomor && cfg.nomor_owner && String(cfg.nomor_owner).replace(/\D/g, '') === String(nomor).replace(/\D/g, '')) {
        return { owned: true, cfg };
    }
    if (lid && cfg.lid && cfg.lid === lid) {
        return { owned: true, cfg };
    }
    return { owned: false, cfg };
}

// ============================================================
// TIMEOUT
// ============================================================
const TIMEOUT_PICKER = 60 * 1000;

// ============================================================
// KAMUS BAHASA
// ============================================================
const TEXT = {
    id: {
        usage:
            `乂  *ᴋᴇʟᴏʟᴀ ʙᴏᴛ*\n\n` +
            `📖 *Format:*\n` +
            `• .bot selft [nomor/alias] → self mode ON\n` +
            `• .bot unselft [nomor/alias] → self mode OFF\n` +
            `• .bot modechat [nomor/alias] → pilih mode chat\n` +
            `• .bot alias [nomor] → set alias (nama pendek)\n` +
            `• .bot info [nomor/alias] → lihat config bot\n` +
            `• .bot list → daftar bot milikmu`,
        subcmd_invalid:
            '❌ Subcommand tidak valid.\nGunakan: selft / unselft / modechat / alias / info / list',
        no_bot_owned:
            '❌ Kamu belum punya bot terdaftar.\n\nKetik *.jadibot* dulu untuk membuat bot.',
        no_bot_target:
            '⚠️ Kamu punya lebih dari 1 bot.\nSebutkan nomor/alias botnya: *.bot {sub} <nomor|alias>*',
        bot_not_found: '❌ Bot *{nomor}* tidak ditemukan di database jadibot.',
        bot_not_owned: '❌ Bot *{nomor}* bukan milikmu.',

        header_selft_on: `乂  *sᴇʟꜰᴛ ᴏɴ* ✅`,
        header_selft_off: `乂  *sᴇʟꜰᴛ ᴏꜰꜰ* ❌`,
        selft_success: 'Self mode bot *{nomor}* berhasil di-set ke *{value}*.',

        header_modechat: `乂  *ᴘɪʟɪʜ ᴍᴏᴅᴇ ᴄʜᴀᴛ*`,
        modechat_intro: 'Pilih mode chat untuk bot *{nomor}*:\n',
        modechat_body:
            '*1.* Private — hanya chat pribadi\n' +
            '*2.* Grup — hanya grup\n' +
            '*3.* Both — private + grup',
        modechat_reply_hint: '📌 Reply pesan ini dengan angka (1/2/3).',
        modechat_invalid: '❌ Pilihan tidak valid. Reply *1* (private), *2* (grup), atau *3* (both).',
        modechat_success: '✅ Mode chat bot *{nomor}* di-set ke *{mode}*.',
        modechat_already: '⚠️ Mode chat bot *{nomor}* sudah *{mode}* dari tadi.',
        modechat_timeout: '⏱️ Waktu habis. Mode chat *tidak* diubah.',

        mode_private: 'Private',
        mode_grup: 'Grup',
        mode_both: 'Both (Private + Group)',

        alias_header: `乂  *sᴇᴛ ᴀʟɪᴀꜱ ʙᴏᴛ*`,
        alias_intro: 'Kirim nama pendek (alias) untuk bot *{nomor}*:\n',
        alias_hint:
            '📌 Reply pesan ini dengan alias.\n' +
            '📏 *2-20 karakter*, hanya huruf/angka/underscore.\n' +
            '⏱️ _Batas waktu: 60 detik_',
        alias_invalid:
            '❌ Alias tidak valid.\nHarus 2-20 karakter (huruf/angka/underscore).',
        alias_taken: '❌ Alias *{alias}* sudah dipakai bot lain. Coba nama lain.',
        alias_success: '✅ Alias bot *{nomor}* berhasil di-set ke *{alias}*.',
        alias_timeout: '⏱️ Waktu habis. Alias *tidak* diubah.',

        header_info: `乂  *ɪɴꜰᴏ ʙᴏᴛ*`,
        info_alias: 'Alias',
        info_owner: 'Owner',
        info_bot: 'Nomor Bot',
        info_lid: 'LID',
        info_selft: 'Self Mode',
        info_chat: 'Mode Chat',
        info_updated: 'Terakhir Update',
        yes: 'Ya',
        no: 'Tidak',
        alias_none: '_belum di-set_',

        header_list: `乂  *ʟɪsᴛ ʙᴏᴛ ᴍɪʟɪᴋᴍᴜ*`,
        list_empty: '⚠️ Kamu belum punya bot terdaftar di database jadibot.',
        list_total: 'Total: {n} bot',
        list_item_selft: 'Self: {v}',
        list_item_chat: 'Chat: {v}',
        list_item_alias: 'Alias: {v}',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    ch: {
        usage:
            `乂  *管理机器人*\n\n` +
            `📖 *格式：*\n` +
            `• .bot selft [号码/别名] → 开启自用模式\n` +
            `• .bot unselft [号码/别名] → 关闭自用模式\n` +
            `• .bot modechat [号码/别名] → 选择聊天模式\n` +
            `• .bot alias [号码] → 设置别名（短名称）\n` +
            `• .bot info [号码/别名] → 查看机器人配置\n` +
            `• .bot list → 我的机器人列表`,
        subcmd_invalid:
            '❌ 子命令无效。\n请使用：selft / unselft / modechat / alias / info / list',
        no_bot_owned:
            '❌ 您还没有注册的机器人。\n\n请输入 *.jadibot* 创建机器人。',
        no_bot_target:
            '⚠️ 您有多个机器人。\n请指定机器人号码/别名：*.bot {sub} <号码|别名>*',
        bot_not_found: '❌ 未找到机器人 *{nomor}*。',
        bot_not_owned: '❌ 机器人 *{nomor}* 不属于你。',

        header_selft_on: `乂  *自用模式开启* ✅`,
        header_selft_off: `乂  *自用模式关闭* ❌`,
        selft_success: '机器人 *{nomor}* 的自用模式已设置为 *{value}*。',

        header_modechat: `乂  *选择聊天模式*`,
        modechat_intro: '为机器人 *{nomor}* 选择聊天模式：\n',
        modechat_body:
            '*1.* 私聊 — 仅限私聊\n' +
            '*2.* 群组 — 仅限群组\n' +
            '*3.* 全部 — 私聊 + 群组',
        modechat_reply_hint: '📌 请回复数字 (1/2/3)。',
        modechat_invalid: '❌ 选择无效。请回复 *1*（私聊）、*2*（群组）或 *3*（全部）。',
        modechat_success: '✅ 机器人 *{nomor}* 的聊天模式已设置为 *{mode}*。',
        modechat_already: '⚠️ 机器人 *{nomor}* 的聊天模式此前已是 *{mode}*。',
        modechat_timeout: '⏱️ 时间到。聊天模式*未更改*。',

        mode_private: '私聊',
        mode_grup: '群组',
        mode_both: '全部（私聊 + 群组）',

        alias_header: `乂  *设置机器人别名*`,
        alias_intro: '请发送机器人 *{nomor}* 的短别名：\n',
        alias_hint:
            '📌 请回复此消息输入别名。\n' +
            '📏 *2-20 个字符*，仅限字母/数字/下划线。\n' +
            '⏱️ _时限：60 秒_',
        alias_invalid:
            '❌ 别名无效。\n必须为 2-20 个字符（字母/数字/下划线）。',
        alias_taken: '❌ 别名 *{alias}* 已被其他机器人使用。请换一个。',
        alias_success: '✅ 机器人 *{nomor}* 的别名已设置为 *{alias}*。',
        alias_timeout: '⏱️ 时间到。别名*未更改*。',

        header_info: `乂  *机器人信息*`,
        info_alias: '别名',
        info_owner: '主人',
        info_bot: '机器人号码',
        info_lid: 'LID',
        info_selft: '自用模式',
        info_chat: '聊天模式',
        info_updated: '最后更新',
        yes: '是',
        no: '否',
        alias_none: '_未设置_',

        header_list: `乂  *我的机器人列表*`,
        list_empty: '⚠️ 您在子机器人数据库中还没有机器人。',
        list_total: '总计：{n} 个机器人',
        list_item_selft: '自用: {v}',
        list_item_chat: '聊天: {v}',
        list_item_alias: '别名: {v}',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
    uk: {
        usage:
            `乂  *ᴍᴀɴᴀɢᴇ ʙᴏᴛ*\n\n` +
            `📖 *Format:*\n` +
            `• .bot selft [number/alias] → self mode ON\n` +
            `• .bot unselft [number/alias] → self mode OFF\n` +
            `• .bot modechat [number/alias] → choose chat mode\n` +
            `• .bot alias [number] → set alias (short name)\n` +
            `• .bot info [number/alias] → view bot config\n` +
            `• .bot list → list of your bots`,
        subcmd_invalid:
            '❌ Invalid subcommand.\nUse: selft / unselft / modechat / alias / info / list',
        no_bot_owned:
            '❌ You have no registered bots yet.\n\nType *.jadibot* to create a bot.',
        no_bot_target:
            '⚠️ You have more than 1 bot.\nSpecify the bot number/alias: *.bot {sub} <number|alias>*',
        bot_not_found: '❌ Bot *{nomor}* not found in jadibot database.',
        bot_not_owned: '❌ Bot *{nomor}* is not yours.',

        header_selft_on: `乂  *ꜱᴇʟꜰᴛ ᴏɴ* ✅`,
        header_selft_off: `乂  *ꜱᴇʟꜰᴛ ᴏꜰꜰ* ❌`,
        selft_success: 'Self mode for bot *{nomor}* has been set to *{value}*.',

        header_modechat: `乂  *ᴄʜᴏᴏꜱᴇ ᴄʜᴀᴛ ᴍᴏᴅᴇ*`,
        modechat_intro: 'Choose chat mode for bot *{nomor}*:\n',
        modechat_body:
            '*1.* Private — private chat only\n' +
            '*2.* Group — group only\n' +
            '*3.* Both — private + group',
        modechat_reply_hint: '📌 Reply to this message with a number (1/2/3).',
        modechat_invalid: '❌ Invalid choice. Reply *1* (private), *2* (group), or *3* (both).',
        modechat_success: '✅ Chat mode for bot *{nomor}* set to *{mode}*.',
        modechat_already: '⚠️ Chat mode for bot *{nomor}* was already *{mode}*.',
        modechat_timeout: '⏱️ Time\'s up. Chat mode *NOT* changed.',

        mode_private: 'Private',
        mode_grup: 'Group',
        mode_both: 'Both (Private + Group)',

        alias_header: `乂  *ꜱᴇᴛ ʙᴏᴛ ᴀʟɪᴀꜱ*`,
        alias_intro: 'Send a short alias for bot *{nomor}*:\n',
        alias_hint:
            '📌 Reply to this message with the alias.\n' +
            '📏 *2-20 characters*, letters/numbers/underscore only.\n' +
            '⏱️ _Time limit: 60 seconds_',
        alias_invalid:
            '❌ Invalid alias.\nMust be 2-20 characters (letters/numbers/underscore).',
        alias_taken: '❌ Alias *{alias}* is already used by another bot. Try another name.',
        alias_success: '✅ Alias for bot *{nomor}* set to *{alias}*.',
        alias_timeout: '⏱️ Time\'s up. Alias *NOT* changed.',

        header_info: `乂  *ʙᴏᴛ ɪɴꜰᴏ*`,
        info_alias: 'Alias',
        info_owner: 'Owner',
        info_bot: 'Bot Number',
        info_lid: 'LID',
        info_selft: 'Self Mode',
        info_chat: 'Chat Mode',
        info_updated: 'Last Update',
        yes: 'Yes',
        no: 'No',
        alias_none: '_not set_',

        header_list: `乂  *ʏᴏᴜʀ ʙᴏᴛ ʟɪꜱᴛ*`,
        list_empty: '⚠️ You have no bots registered in jadibot database.',
        list_total: 'Total: {n} bot(s)',
        list_item_selft: 'Self: {v}',
        list_item_chat: 'Chat: {v}',
        list_item_alias: 'Alias: {v}',

        footer: `ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴀɴɢᴇʟs ᴀɪ ッ`,
    },
};

// ============================================================
// HELPER
// ============================================================
function T(lang, key, vars = {}) {
    const code = isValidLang(lang) ? lang.toLowerCase() : DEFAULT_LANG;
    let str = (TEXT[code] || TEXT[DEFAULT_LANG])[key] ?? TEXT[DEFAULT_LANG][key] ?? key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function langOfSender({ lid, nomor }) {
    const user = findUser({ lid, nomor });
    if (!user) return 'uk';
    return isValidLang(user.lang) ? user.lang : DEFAULT_LANG;
}

function labelMode(lang, mode) {
    if (mode === 'private') return T(lang, 'mode_private');
    if (mode === 'grup') return T(lang, 'mode_grup');
    return T(lang, 'mode_both');
}

/**
 * Bangun senderJid PERSIS seperti .jadibot — biar session match.
 */
function buildSenderJid(sender) {
    return sender?.lid || (sender?.nomor ? `${sender.nomor}@s.whatsapp.net` : null);
}

function resolveTargetBot({ arg, senderKey, subcmd }) {
    if (arg) {
        const cleanNum = String(arg).replace(/\D/g, '');
        if (cleanNum.length >= 8) {
            const { owned, cfg } = isBotOwnedBy(cleanNum, senderKey);
            if (!cfg) return { error: 'not_found', nomor: cleanNum };
            if (!owned) return { error: 'not_owned', nomor: cleanNum };
            return { cfg };
        }

        const nomorByAlias = findBotByAlias(arg);
        if (nomorByAlias) {
            const { owned, cfg } = isBotOwnedBy(nomorByAlias, senderKey);
            if (!cfg) return { error: 'not_found', nomor: nomorByAlias };
            if (!owned) return { error: 'not_owned', nomor: nomorByAlias };
            return { cfg };
        }

        return { error: 'not_found', nomor: arg };
    }

    const owned = listBotsOwnedBy(senderKey);
    if (owned.length === 0) return { error: 'no_bot_owned' };
    if (owned.length === 1) return { cfg: owned[0] };
    return { error: 'need_target', subcmd, count: owned.length };
}

// ============================================================
// HANDLER UTAMA
// ============================================================
export default async function handler(ctx) {
    const { sock, msg, reply, remoteJid, args, sender } = ctx;
    const lang = langOfSender({ lid: sender?.lid, nomor: sender?.nomor });

    const subcmd = (args[0] || '').toLowerCase();
    const arg = args[1] ? String(args[1]).trim() : null;

    // ============================================================
    // TANPA SUBCOMMAND
    // ============================================================
    if (!subcmd) {
        await sendReaction(sock, remoteJid, msg.key, '🤖');
        return reply(T(lang, 'usage') + `\n\n${T(lang, 'footer')}`);
    }

    // ============================================================
    // LIST
    // ============================================================
    if (subcmd === 'list') {
        await sendReaction(sock, remoteJid, msg.key, '📋');

        const owned = listBotsOwnedBy({ lid: sender?.lid, nomor: sender?.nomor });
        if (owned.length === 0) {
            return reply(T(lang, 'list_empty'));
        }

        let out =
            `${T(lang, 'header_list')}\n\n` +
            `📊 *${T(lang, 'list_total', { n: owned.length })}*\n\n`;

        owned.forEach((b, i) => {
            const selftLabel = b.selft_bot ? T(lang, 'yes') : T(lang, 'no');
            const chatLabel = labelMode(lang, b.mode_chat);
            const aliasLabel = b.alias ? `\`${b.alias}\`` : T(lang, 'alias_none');

            out += `*${i + 1}.* +${b.nomor_bot}\n`;
            out += `   🏷️ ${T(lang, 'list_item_alias', { v: aliasLabel })}\n`;
            out += `   👤 ${T(lang, 'info_owner')}: ${b.nomor_owner}\n`;
            out += `   🔒 ${T(lang, 'list_item_selft', { v: selftLabel })}\n`;
            out += `   📱 ${T(lang, 'list_item_chat', { v: chatLabel })}\n\n`;
        });

        out += T(lang, 'footer');
        await sendReaction(sock, remoteJid, msg.key, '✅');
        return reply(out);
    }

    // ============================================================
    // Validasi subcommand
    // ============================================================
    const validSub = ['selft', 'unselft', 'modechat', 'alias', 'info'];
    if (!validSub.includes(subcmd)) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        return reply(T(lang, 'subcmd_invalid'));
    }

    // ============================================================
    // Resolve bot target
    // ============================================================
    const target = resolveTargetBot({
        arg,
        senderKey: { lid: sender?.lid, nomor: sender?.nomor },
        subcmd,
    });

    if (target.error) {
        await sendReaction(sock, remoteJid, msg.key, '❌');
        if (target.error === 'no_bot_owned') return reply(T(lang, 'no_bot_owned'));
        if (target.error === 'need_target') return reply(T(lang, 'no_bot_target', { sub: subcmd }));
        if (target.error === 'not_found') return reply(T(lang, 'bot_not_found', { nomor: target.nomor }));
        if (target.error === 'not_owned') return reply(T(lang, 'bot_not_owned', { nomor: target.nomor }));
        return reply('❌ Error tidak diketahui.');
    }

    const cfg = target.cfg;
    const nomorBot = cfg.nomor_bot;

    // ============================================================
    // SELFT / UNSELFT
    // ============================================================
    if (subcmd === 'selft' || subcmd === 'unselft') {
        const value = subcmd === 'selft';

        await sendReaction(sock, remoteJid, msg.key, value ? '🔒' : '🔓');

        const res = updateBotConfig(nomorBot, { selft_bot: value });
        if (!res.ok) {
            await sendReaction(sock, remoteJid, msg.key, '❌');
            return reply(T(lang, 'bot_not_found', { nomor: nomorBot }));
        }

        const header = value ? T(lang, 'header_selft_on') : T(lang, 'header_selft_off');
        const label = value ? 'ON' : 'OFF';

        await sendReaction(sock, remoteJid, msg.key, '✅');
        return reply(
            `${header}\n\n` +
            `${T(lang, 'selft_success', { nomor: nomorBot, value: label })}\n\n` +
            `${T(lang, 'footer')}`
        );
    }

    // ============================================================
    // INFO
    // ============================================================
    if (subcmd === 'info') {
        await sendReaction(sock, remoteJid, msg.key, 'ℹ️');

        const selftLabel = cfg.selft_bot ? T(lang, 'yes') : T(lang, 'no');
        const chatLabel = labelMode(lang, cfg.mode_chat);
        const aliasLabel = cfg.alias ? `\`${cfg.alias}\`` : T(lang, 'alias_none');
        const updated = cfg.updated_at
            ? new Date(cfg.updated_at).toLocaleString('id-ID', {
                day: '2-digit', month: 'short', year: 'numeric',
                hour: '2-digit', minute: '2-digit',
                timeZone: 'Asia/Jakarta',
            })
            : '-';

        const out =
            `${T(lang, 'header_info')}\n\n` +
            `◦  *${T(lang, 'info_bot')}*    : +${nomorBot}\n` +
            `◦  *${T(lang, 'info_alias')}*  : ${aliasLabel}\n` +
            `◦  *${T(lang, 'info_owner')}*  : +${cfg.nomor_owner || '-'}\n` +
            `◦  *${T(lang, 'info_lid')}*    : ${cfg.lid ? cfg.lid.split('@')[0] : '-'}\n` +
            `◦  *${T(lang, 'info_selft')}*  : ${selftLabel}\n` +
            `◦  *${T(lang, 'info_chat')}*   : ${chatLabel}\n` +
            `◦  *${T(lang, 'info_updated')}*: ${updated}\n\n` +
            `${T(lang, 'footer')}`;

        await sendReaction(sock, remoteJid, msg.key, '✅');
        return reply(out);
    }

    // ============================================================
    // ALIAS — Wizard (PERSIS seperti .jadibot)
    // ============================================================
    if (subcmd === 'alias') {
        const introText =
            `${T(lang, 'alias_header')}\n\n` +
            `${T(lang, 'alias_intro', { nomor: nomorBot })}\n\n` +
            `${T(lang, 'alias_hint')}\n\n` +
            `${T(lang, 'footer')}`;

        await sendReaction(sock, remoteJid, msg.key, '🏷️');

        const wizardMsg = await reply(introText);
        if (!wizardMsg?.key?.id) return;

        // ✅ SAMA PERSIS dengan .jadibot
        const senderJid = buildSenderJid(sender);

        const onAliasReply = async (rCtx) => {
            const raw = String(rCtx.text || '').trim();

            if (!/^[a-zA-Z0-9_]{2,20}$/.test(raw)) {
                return rCtx.reply(T(lang, 'alias_invalid'));
            }

            if (isAliasTaken(raw, nomorBot)) {
                return rCtx.reply(T(lang, 'alias_taken', { alias: raw }));
            }

            const res = updateBotConfig(nomorBot, { alias: raw });
            if (!res.ok) {
                return rCtx.reply(T(lang, 'bot_not_found', { nomor: nomorBot }));
            }

            await sendReaction(sock, remoteJid, rCtx.msg.key, '✅');
            return rCtx.reply(
                `${T(lang, 'alias_success', { nomor: nomorBot, alias: raw })}\n\n` +
                `${T(lang, 'footer')}`
            );
        };

        registerSession(
            wizardMsg.key.id,
            remoteJid,
            onAliasReply,
            { step: 'alias_input' },
            {
                once: true,
                timeoutMs: TIMEOUT_PICKER,
                senderJid,
                validateSender: true,
                tag: 'bot_alias',
                onExpire: async ({ chatJid }) => {
                    try {
                        await sendText(sock, chatJid, T(lang, 'alias_timeout'));
                    } catch (_) {}
                },
            }
        );
        return;
    }

    // ============================================================
    // MODECHAT — Picker (PERSIS seperti .jadibot)
    // ============================================================
    if (subcmd === 'modechat') {
        const currentMode = cfg.mode_chat || 'both';

        const pickerText =
            `${T(lang, 'header_modechat')}\n\n` +
            `${T(lang, 'modechat_intro', { nomor: nomorBot })}\n\n` +
            `${T(lang, 'modechat_body')}\n\n` +
            `${T(lang, 'modechat_reply_hint')}\n\n` +
            `${T(lang, 'footer')}`;

        await sendReaction(sock, remoteJid, msg.key, '📱');

        const pickerMsg = await reply(pickerText);
        if (!pickerMsg?.key?.id) return;

        // ✅ SAMA PERSIS dengan .jadibot
        const senderJid = buildSenderJid(sender);

        const onPickReply = async (rCtx) => {
            const jawab = String(rCtx.text || '').trim();

            if (!['1', '2', '3'].includes(jawab)) {
                return rCtx.reply(T(lang, 'modechat_invalid'));
            }

            const newMode = jawab === '1' ? 'private' : jawab === '2' ? 'grup' : 'both';

            if (newMode === currentMode) {
                return rCtx.reply(T(lang, 'modechat_already', {
                    nomor: nomorBot,
                    mode: labelMode(lang, newMode),
                }));
            }

            const res = updateBotConfig(nomorBot, { mode_chat: newMode });
            if (!res.ok) {
                return rCtx.reply(T(lang, 'bot_not_found', { nomor: nomorBot }));
            }

            await sendReaction(sock, remoteJid, rCtx.msg.key, '✅');
            return rCtx.reply(
                `${T(lang, 'modechat_success', {
                    nomor: nomorBot,
                    mode: labelMode(lang, newMode),
                })}\n\n${T(lang, 'footer')}`
            );
        };

        registerSession(
            pickerMsg.key.id,
            remoteJid,
            onPickReply,
            { pickedMode: null },
            {
                once: true,
                timeoutMs: TIMEOUT_PICKER,
                senderJid,
                validateSender: true,
                tag: 'bot_modechat',
                onExpire: async ({ chatJid }) => {
                    try {
                        await sendText(sock, chatJid, T(lang, 'modechat_timeout'));
                    } catch (_) {}
                },
            }
        );
        return;
    }
}