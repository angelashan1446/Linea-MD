// config.js

export default {
  // ==========================================
  // ✅ INFORMASI BOT
  // ==========================================
  bot_name: 'Linea MD',
  bot_version: '2.1.0',
  prefix: '.',

  // --- Koneksi Utama ---
  phone_number_bot: '62895337302084', // nomor wa bot 62xxx
  type_connection: 'pairing', // 'qr' | 'pairing'

  // --- Owner ---
  owners: ['6285126189342'], // nomor owner 62xxx

  // --- Multi-Session ---
  max_sessions: 20,
  session_concurrency: 3,

  // --- Mode Chat ---
  // Pilihan: 'both' | 'grup' | 'private'
  mode_chat: 'grup',

  // --- Rent ---
  // true  : Bot hanya melayani grup yang terdaftar disewa (rent aktif).
  //         Grup gratis / belum disewa tidak akan dilayani sama sekali.
  // false : Bot melayani semua grup (gratis maupun sewa).
  only_rent_grup: false,

  // --- Debug ---
  // 'development' | 'production'
  mode: 'development',

  // ==========================================
  // ✅ KONFIGURASI API ANGELS CLOUD
  // ==========================================
  // Masukkan banyak token di sini (Rotasi otomatis kalau token 1 habis)
  api_tokens: [
    'LiFreeToken'  // Token Komunitas Terbatas, Beli Token Pribadi Di https://linea.zone.id/index.html
  ],
};