<div align="center">

# ⚙️ Linea MD

**WhatsApp Bot Multi-Session · Anti-Disconnect · Auto-Reconnect**

![Version](https://img.shields.io/badge/version-1.6.0-blue?style=for-the-badge)
![Node](https://img.shields.io/badge/node-%3E%3D18-green?style=for-the-badge&logo=node.js)
![License](https://img.shields.io/badge/license-MIT-yellow?style=for-the-badge)

[Setup](#-setup-awal) · [Config](#-penjelasan-config) · [Anti-Ban](#️-aturan-anti-ban) · [Troubleshooting](#-troubleshooting)

</div>

---

## ⚠️ BACA DULU — Aturan Wajib

> **Nomor bot yang masih baru (< 1 minggu) sangat rentan banned permanen.**
> Ikuti aturan di bawah ini **tanpa terkecuali**.

| # | Aturan | Kenapa |
|:-:|--------|--------|
| 🚫 | **Bot HANYA dipakai di grup** selama nomor < 1 minggu | Private chat dari nomor baru = auto-detect spam → ban |
| ✅ | **Private chat wajib mutual save** — pemakai save nomor bot, dan nomor bot save nomor pemakai | WhatsApp hanya izinkan private chat aman antar kontak saling save |
| ⛔ | **JANGAN pernah ubah config system** (semua di luar `config.js`) | Config system sudah dioptimalkan. Mengubahnya = risiko **BAN PERMANEN** |

> 💡 **Config system** yang dimaksud: `keepAliveIntervalMs`, `markOnlineOnConnect`, `connectTimeoutMs`, `iqTimeoutMs`, `nodeQueryTimeoutMs`, dll di `libx/whatsapp/connect.js`. Biarkan apa adanya.

---

## 📑 Daftar Isi

- [Setup Awal](#-setup-awal)
- [Penjelasan Config](#-penjelasan-config)
- [Aturan Anti-Ban](#️-aturan-anti-ban)
- [Perilaku Reconnect](#-perilaku-reconnect-v160)
- [Troubleshooting](#-troubleshooting)
- [FAQ](#-faq)

---

## 🚀 Setup Awal

### 1️⃣ Isi `config.js`

```javascript
export default {
  // ── Info bot ───────────────────────────────────────
  bot_name: 'Linea MD',
  bot_version: '1.6.0',
  prefix: '.',

  // ── Koneksi WhatsApp ───────────────────────────────
  phone_number_bot: '6281234567890',  // nomor bot (62xxx, tanpa +)
  type_connection: 'pairing',         // 'pairing' | 'qr'

  // ── Owner ──────────────────────────────────────────
  owners: ['6281234567890'],          // nomor kamu (bisa >1)

  // ── Multi-session ──────────────────────────────────
  max_sessions: 20,
  session_concurrency: 3,

  // ── Mode chat ──────────────────────────────────────
  mode_chat: 'grup',                  // ⚠️ WAJIB 'grup' kalau nomor baru

  // ── Rent ───────────────────────────────────────────
  only_rent_grup: false,

  // ── Debug ──────────────────────────────────────────
  mode: 'production',

  // ── API Tokens ─────────────────────────────────────
  api_tokens: [
    'LiFreeTokenKamu',
  ],
};
```

### 2️⃣ Pilih `mode_chat` Sesuai Umur Nomor

| Umur Nomor | `mode_chat` | Catatan |
|:----------:|:-----------:|---------|
| **< 1 minggu** | `'grup'` | ⚠️ **WAJIB**. Private = risiko ban tinggi |
| 1–2 minggu | `'grup'` / `'both'` | `'both'` hanya kalau sudah mutual save |
| **> 2 minggu** | `'both'` | Aman, tetap jangan spam |

### 3️⃣ Ambil API Token

1. Buka 👉 **[linea.zone.id/rest.html](https://linea.zone.id/rest.html)**
2. Login pakai **akun Telegram**
3. Klik **"Buat API Key Baru"** → dapat **1000 token gratis** (berlaku 7 hari)
4. Copy token → paste ke `api_tokens`

> 💡 **Tips**: isi **2–3 token** sekaligus. Kalau token utama habis, bot otomatis rotasi ke token berikutnya.

```javascript
api_tokens: [
  'LiTokenUtama',     // prioritas 1
  'LiTokenCadangan',  // fallback
  'LiTokenCadangan2', // fallback terakhir
],
```

### 4️⃣ Jalankan Bot

```bash
npm start
```

#### 🔑 Kalau `type_connection: 'pairing'`

Terminal akan menampilkan:

```
[main] PHONE: 6281234567890
[main] PAIRING CODE: ABCD-EFGH
```

**Cara memasukkan:**
1. Buka WhatsApp di **HP nomor bot**
2. Masuk ke **Perangkat Tertaut** → **Tautkan Perangkat**
3. Pilih **"Tautkan dengan nomor telepon"**
4. Masukkan kode 8 digit di atas

#### 📱 Kalau `type_connection: 'qr'`

Scan QR yang muncul di terminal menggunakan WhatsApp HP nomor bot.

---

## 📋 Penjelasan Config

### 🤖 Informasi Bot

| Field | Fungsi |
|-------|--------|
| `bot_name` | Nama bot (muncul di menu & pesan) |
| `bot_version` | Versi bot (tampil di `.menu` / info bot) |
| `prefix` | Karakter awalan command (`.` `!` `/` dll) |

### 🔌 Koneksi WhatsApp

| Field | Keterangan |
|-------|-----------|
| `phone_number_bot` | Nomor WA bot — **format `62xxx` tanpa `+`** |
| `type_connection` | `'pairing'` = kode 8 digit · `'qr'` = scan QR |

> 💡 **Saran**: pakai `'pairing'` — lebih mudah, tidak perlu buka kamera.

### 👑 Owner

```javascript
owners: ['6281234567890', '6289876543210'],
```

Owner punya akses **penuh**:

- `.setlevel` — atur level user
- `.ban` / `.unban` — ban user
- `.addsession` / `.delsession` — kelola sesi
- Semua command tanpa batasan limit

### 📱 Multi-Session

| Field | Keterangan |
|-------|-----------|
| `max_sessions: 20` | Batas total sesi yang bisa jalan bareng |
| `session_concurrency: 3` | Sesi yang boot bersamaan |

**Rekomendasi RAM:**

| RAM VPS | `session_concurrency` | `max_sessions` |
|:-------:|:---------------------:|:--------------:|
| 1 GB | 2 | 5 |
| 2 GB | 3 | 10 |
| 4 GB | 5 | 20 |
| 8 GB+ | 8 | 20+ |

> ⚠️ **Jangan** set terlalu tinggi di RAM kecil → OOM (Out of Memory) → bot crash → semua session mati.

### 💬 Mode Chat

| Mode | Perilaku |
|------|----------|
| `'both'` | Respon di grup **dan** private |
| `'grup'` | **Cuma** respon di grup |
| `'private'` | **Cuma** respon di private |

> 🕐 **Nomor < 1 minggu** → **WAJIB** pakai `'grup'`.

### 💰 Mode Rent (Sewa Grup)

| Nilai | Perilaku |
|-------|----------|
| `false` | Layani **semua** grup (gratis & sewa) |
| `true` | **Hanya** grup yang aktif disewa |

Cocok kalau bot mau dijual sebagai produk berbayar.

### 🐛 Debug Mode

| Mode | Keterangan |
|------|-----------|
| `'production'` | Log minimal, performa maksimal |
| `'development'` | Log detail — **hanya untuk debug plugin baru** |

> ⚠️ Jangan pakai `'development'` di production → log spam → RAM cepat penuh.

### 🔑 API Tokens (Rotasi Otomatis)

**Cara kerja:**

```
Token #1 → valid? pakai.
         ↓ habis/invalid
Token #2 → valid? pakai.
         ↓ habis/invalid
Token #3 → valid? pakai.
         ↓ habis/invalid
Semua habis → bot return error.
```

**Tips:**

- Isi minimal **2 token** untuk redundancy
- Token berlaku **7 hari** — jangan lupa rotasi
- Taruh token **paling baru** di urutan atas (prioritas utama)

---

## 🛡️ Aturan Anti-Ban

### ✅ YANG HARUS DILAKUKAN

- ✅ **Nomor baru < 1 minggu** → `mode_chat: 'grup'`, jangan private
- ✅ **Pemanasan nomor** — biarkan bot di 1–2 grup kecil dulu, 3–5 hari
- ✅ **Mutual save** sebelum pakai private chat
- ✅ **Jangan spam** — hindari broadcast ke banyak nomor tak dikenal
- ✅ **Jangan ubah config system** (di luar `config.js`)

### ❌ YANG TIDAK BOLEH DILAKUKAN

| Larangan | Alasan |
|----------|--------|
| Private chat di nomor < 1 minggu | Dianggap spam → ban |
| Kirim pesan ke nomor yang tidak save bot | Dianggap spam → ban |
| Broadcast massal (> 20 nomor sekaligus) | Auto-detect spam → ban |
| Ubah config system di luar `config.js` | Picu deteksi anomali → ban permanen |
| Pakai bot untuk judi / scam / konten ilegal | Ban permanen + laporan |
| Login nomor bot di HP **dan** bot bersamaan | Konflik session (`440`) → disconnect terus |

### 🔥 Kalau Mau Pakai Private Chat (Nomor Baru)

Lakukan **manual** dulu sebelum aktifkan `mode_chat: 'both'`:

1. Di **HP pemakai** → save nomor bot ke kontak
2. Di **HP nomor bot** → save nomor pemakai ke kontak
3. Kirim 1–2 pesan biasa (bukan command) untuk pemanasan
4. **Baru** aktifkan private mode

> ⚠️ Tanpa langkah ini, WhatsApp bisa anggap bot spam → **banned permanen**.

---

## 🔄 Perilaku Reconnect (v1.6.0)

Bot punya sistem **anti-disconnect otomatis**:

| Situasi | Perilaku Bot |
|---------|-------------|
| Error jaringan / timeout | Reconnect otomatis — max **20x**, backoff 5s → 60s |
| `515 Restart required` | Reconnect cepat 2s |
| User logout di HP (session dihapus) | ⛔ **Folder session langsung dihapus** — tidak bikin pairing baru |
| Reconnect habis 20x | Folder session dihapus (bersih) |
| Heartbeat gagal (zombie connection) | Force reconnect |
| Watchdog deteksi session mati | Reconnect otomatis tiap 5 menit |

> 💡 **Penting**: kalau session kena logout, bot **tidak akan** munculkan pairing code baru. Kamu harus jalankan `npm start` ulang (atau `.addsession` via bot lain) untuk pairing manual.

### 🧠 Bedanya New Session vs Pernah Connect

| Jenis | Penanda | Perilaku Saat Error |
|-------|---------|---------------------|
| **New Session** | Belum ada file `.connected` di folder | Reconnect max 20x → hapus kalau gagal |
| **Pernah Connect** | Ada file `.connected` | Sama — reconnect max 20x → hapus kalau gagal |

> Keduanya **diperlakukan sama**. Bedanya cuma di **log** (label alasan hapus). Tidak ada whitelist khusus — **semua error coba reconnect**, hanya **logout (401)** yang langsung hapus.

---

## 🆘 Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Bot tidak muncul QR / pairing code | Cek `phone_number_bot` format `62xxx` (tanpa +), cek `type_connection` |
| Pairing code invalid | Pastikan pilih **"Tautkan dengan nomor telepon"** (bukan scan QR) |
| Bot disconnect terus | Cek internet VPS, **jangan ubah** `keepAliveIntervalMs` |
| Session hilang setelah restart | Normal kalau kena logout — pairing ulang |
| RAM penuh / bot crash | Turunkan `session_concurrency`, kurangi `max_sessions` |
| `440 Conflict` | Nomor bot login di HP lain — logout dari HP, biarkan hanya bot |
| Token habis | Rotasi token baru di `api_tokens` |
| `401 Logout` terus | User hapus session di HP — pairing ulang dari awal |
| `403 Forbidden` | Nomor kena banned — ganti nomor baru |

---

## ❓ FAQ

<details>
<summary><b>Kenapa bot tidak respon di private chat?</b></summary>

Cek `mode_chat` di `config.js`. Kalau `'grup'`, bot memang tidak respon private. Kalau mau respon private, ubah ke `'both'` — **tapi lihat aturan anti-ban dulu** (nomor < 1 minggu jangan private).
</details>

<details>
<summary><b>Kenapa session hilang sendiri?</b></summary>

Beberapa kemungkinan:
1. **Logout di HP** → user hapus "Perangkat Tertaut" → bot deteksi `401` → folder dihapus
2. **Reconnect habis 20x** → folder dihapus otomatis (bersih)
3. **RAM penuh** → OOM killer bunuh proses Node → session corrupt → hapus manual

Kalau sering terjadi, turunkan `session_concurrency`.
</details>

<details>
<summary><b>Bisa pakai nomor yang sama untuk 2 bot?</b></summary>

**Tidak bisa.** Satu nomor WhatsApp hanya bisa tersambung ke **satu** sesi aktif. Kalau login di 2 tempat → `440 Conflict` → disconnect terus.
</details>

<details>
<summary><b>Kenapa pairing code expired terus?</b></summary>

Pairing code berlaku **~60 detik**. Kalau lewat, harus minta ulang (`npm start` lagi atau restart sesi). Pastikan langsung masukkan kode setelah muncul.
</details>

<details>
<summary><b>Apakah bot aman dari banned?</b></summary>

**Tidak ada bot WhatsApp yang 100% aman dari banned.** Yang bisa dilakukan:
- Ikuti aturan anti-ban di atas
- Jangan ubah config system
- Pemanasan nomor baru 1 minggu
- Hindari spam / broadcast massal

Kalau nomor kena banned, **tidak ada cara recover** — harus ganti nomor baru.
</details>

<details>
<summary><b>Kenapa heartbeat gagal terus?</b></summary>

Heartbeat gagal = koneksi ke server WA putus diam-diam (zombie connection). Bot akan force reconnect otomatis. Kalau sering terjadi:
- Cek koneksi internet VPS (ping stabil?)
- Cek firewall tidak block port WA
- Cek `keepAliveIntervalMs` tidak diubah dari default
</details>

---

## 📞 Bantuan & Link

- 🔑 **API Token** → [linea.zone.id/rest.html](https://linea.zone.id/rest.html)
- 📖 **Dokumentasi plugin** → lihat folder `plugins/`
- 🐛 **Lapor bug** → buka issue di repo

---

<div align="center">

**⚠️ Ingat: Nomor baru < 1 minggu = HANYA grup. Config system JANGAN diubah.**

**Prinsip utama: Aman > Cepat.**

Made with ❤️ for Linea MD users

</div>